(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))i(r);new MutationObserver(r=>{for(const s of r)if(s.type==="childList")for(const a of s.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&i(a)}).observe(document,{childList:!0,subtree:!0});function t(r){const s={};return r.integrity&&(s.integrity=r.integrity),r.referrerPolicy&&(s.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?s.credentials="include":r.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function i(r){if(r.ep)return;r.ep=!0;const s=t(r);fetch(r.href,s)}})();/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const pd="186",om=0,uu=1,lm=2,ks=1,cm=2,Os=3,gr=0,vn=1,Ei=2,Ai=0,$s=1,Kr=2,hu=3,fu=4,dm=5,Yr=100,um=101,hm=102,fm=103,pm=104,mm=200,gm=201,vm=202,ym=203,zh=204,Hh=205,_m=206,xm=207,bm=208,Sm=209,Mm=210,wm=211,Em=212,Tm=213,Am=214,ec=0,tc=1,nc=2,js=3,ic=4,rc=5,sc=6,ac=7,Gh=0,Rm=1,Cm=2,di=0,Vh=1,Wh=2,Xh=3,md=4,qh=5,Yh=6,Zh=7,Kh=300,vr=301,ls=302,cl=303,dl=304,Go=306,oc=1e3,Ti=1001,lc=1002,Jt=1003,Im=1004,Sa=1005,sn=1006,ul=1007,ur=1008,Tn=1009,Jh=1010,jh=1011,Qs=1012,gd=1013,pi=1014,oi=1015,mi=1016,vd=1017,yd=1018,ea=1020,Qh=35902,ef=35899,tf=1021,nf=1022,Wn=1023,Li=1026,hr=1027,rf=1028,_d=1029,yr=1030,xd=1031,bd=1033,ao=33776,oo=33777,lo=33778,co=33779,cc=35840,dc=35841,uc=35842,hc=35843,fc=36196,pc=37492,mc=37496,gc=37488,vc=37489,wo=37490,yc=37491,_c=37808,xc=37809,bc=37810,Sc=37811,Mc=37812,wc=37813,Ec=37814,Tc=37815,Ac=37816,Rc=37817,Cc=37818,Ic=37819,Pc=37820,Lc=37821,Nc=36492,Dc=36494,Uc=36495,Oc=36283,Fc=36284,Eo=36285,Bc=36286,Pm=3200,kc=0,Lm=1,Zi="",hn="srgb",To="srgb-linear",Ao="linear",gt="srgb",hl=7680,Nm=519,Dm=512,Um=513,Om=514,Sd=515,Fm=516,Bm=517,Md=518,km=519,sf=35044,pu="300 es",li=2e3,ta=2001;function $m(n){for(let e=n.length-1;e>=0;--e)if(n[e]>=65535)return!0;return!1}function Ro(n){return document.createElementNS("http://www.w3.org/1999/xhtml",n)}function zm(){const n=Ro("canvas");return n.style.display="block",n}const mu={};function Co(...n){const e="THREE."+n.shift();console.log(e,...n)}function af(n){const e=n[0];if(typeof e=="string"&&e.startsWith("TSL:")){const t=n[1];t&&t.isStackTrace?n[0]+=" "+t.getLocation():n[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return n}function ke(...n){n=af(n);const e="THREE."+n.shift();{const t=n[0];t&&t.isStackTrace?console.warn(t.getError(e)):console.warn(e,...n)}}function st(...n){n=af(n);const e="THREE."+n.shift();{const t=n[0];t&&t.isStackTrace?console.error(t.getError(e)):console.error(e,...n)}}function ns(...n){const e=n.join(" ");e in mu||(mu[e]=!0,ke(...n))}function Hm(n,e,t){return new Promise(function(i,r){function s(){switch(n.clientWaitSync(e,n.SYNC_FLUSH_COMMANDS_BIT,0)){case n.WAIT_FAILED:r();break;case n.TIMEOUT_EXPIRED:setTimeout(s,t);break;default:i()}}setTimeout(s,t)})}const Gm={[ec]:tc,[nc]:sc,[ic]:ac,[js]:rc,[tc]:ec,[sc]:nc,[ac]:ic,[rc]:js};class Er{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const i=this._listeners;i[e]===void 0&&(i[e]=[]),i[e].indexOf(t)===-1&&i[e].push(t)}hasEventListener(e,t){const i=this._listeners;return i===void 0?!1:i[e]!==void 0&&i[e].indexOf(t)!==-1}removeEventListener(e,t){const i=this._listeners;if(i===void 0)return;const r=i[e];if(r!==void 0){const s=r.indexOf(t);s!==-1&&r.splice(s,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const i=t[e.type];if(i!==void 0){e.target=this;const r=i.slice(0);for(let s=0,a=r.length;s<a;s++)r[s].call(this,e);e.target=null}}}const nn=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let gu=1234567;const zs=Math.PI/180,na=180/Math.PI;function ui(){const n=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(nn[n&255]+nn[n>>8&255]+nn[n>>16&255]+nn[n>>24&255]+"-"+nn[e&255]+nn[e>>8&255]+"-"+nn[e>>16&15|64]+nn[e>>24&255]+"-"+nn[t&63|128]+nn[t>>8&255]+"-"+nn[t>>16&255]+nn[t>>24&255]+nn[i&255]+nn[i>>8&255]+nn[i>>16&255]+nn[i>>24&255]).toLowerCase()}function et(n,e,t){return Math.max(e,Math.min(t,n))}function wd(n,e){return(n%e+e)%e}function Vm(n,e,t,i,r){return i+(n-e)*(r-i)/(t-e)}function Wm(n,e,t){return n!==e?(t-n)/(e-n):0}function Hs(n,e,t){return(1-t)*n+t*e}function Xm(n,e,t,i){return Hs(n,e,1-Math.exp(-t*i))}function qm(n,e=1){return e-Math.abs(wd(n,e*2)-e)}function Ym(n,e,t){return n<=e?0:n>=t?1:(n=(n-e)/(t-e),n*n*(3-2*n))}function Zm(n,e,t){return n<=e?0:n>=t?1:(n=(n-e)/(t-e),n*n*n*(n*(n*6-15)+10))}function Km(n,e){return n+Math.floor(Math.random()*(e-n+1))}function Jm(n,e){return n+Math.random()*(e-n)}function jm(n){return n*(.5-Math.random())}function Qm(n){n!==void 0&&(gu=n);let e=gu+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function eg(n){return n*zs}function tg(n){return n*na}function ng(n){return n>0&&Number.isInteger(n)&&2**Math.round(Math.log2(n))===n}function ig(n){return Math.pow(2,Math.ceil(Math.log(n)/Math.LN2))}function rg(n){return Math.pow(2,Math.floor(Math.log(n)/Math.LN2))}function sg(n,e,t,i,r){const s=Math.cos,a=Math.sin,o=s(t/2),l=a(t/2),c=s((e+i)/2),d=a((e+i)/2),u=s((e-i)/2),h=a((e-i)/2),f=s((i-e)/2),p=a((i-e)/2);switch(r){case"XYX":n.set(o*d,l*u,l*h,o*c);break;case"YZY":n.set(l*h,o*d,l*u,o*c);break;case"ZXZ":n.set(l*u,l*h,o*d,o*c);break;case"XZX":n.set(o*d,l*p,l*f,o*c);break;case"YXY":n.set(l*f,o*d,l*p,o*c);break;case"ZYZ":n.set(l*p,l*f,o*d,o*c);break;default:ke("MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+r)}}function Vn(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return n/4294967295;case Uint16Array:return n/65535;case Uint8Array:case Uint8ClampedArray:return n/255;case Int32Array:return Math.max(n/2147483647,-1);case Int16Array:return Math.max(n/32767,-1);case Int8Array:return Math.max(n/127,-1);default:throw new Error("THREE.MathUtils: Invalid component type.")}}function vt(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return Math.round(n*4294967295);case Uint16Array:return Math.round(n*65535);case Uint8Array:case Uint8ClampedArray:return Math.round(n*255);case Int32Array:return Math.round(n*2147483647);case Int16Array:return Math.round(n*32767);case Int8Array:return Math.round(n*127);default:throw new Error("THREE.MathUtils: Invalid component type.")}}const fl={DEG2RAD:zs,RAD2DEG:na,generateUUID:ui,clamp:et,euclideanModulo:wd,mapLinear:Vm,inverseLerp:Wm,lerp:Hs,damp:Xm,pingpong:qm,smoothstep:Ym,smootherstep:Zm,randInt:Km,randFloat:Jm,randFloatSpread:jm,seededRandom:Qm,degToRad:eg,radToDeg:tg,isPowerOfTwo:ng,ceilPowerOfTwo:ig,floorPowerOfTwo:rg,setQuaternionFromProperEuler:sg,normalize:vt,denormalize:Vn};class le{static{le.prototype.isVector2=!0}constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("THREE.Vector2: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,i=this.y,r=e.elements;return this.x=r[0]*t+r[3]*i+r[6],this.y=r[1]*t+r[4]*i+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=et(this.x,e.x,t.x),this.y=et(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=et(this.x,e,t),this.y=et(this.y,e,t),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(et(i,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(et(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y;return t*t+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const i=Math.cos(t),r=Math.sin(t),s=this.x-e.x,a=this.y-e.y;return this.x=s*i-a*r+e.x,this.y=s*r+a*i+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class ms{constructor(e=0,t=0,i=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=i,this._w=r}static slerpFlat(e,t,i,r,s,a,o){let l=i[r+0],c=i[r+1],d=i[r+2],u=i[r+3],h=s[a+0],f=s[a+1],p=s[a+2],v=s[a+3];if(u!==v||l!==h||c!==f||d!==p){let m=l*h+c*f+d*p+u*v;m<0&&(h=-h,f=-f,p=-p,v=-v,m=-m);let g=1-o;if(m<.9995){const x=Math.acos(m),E=Math.sin(x);g=Math.sin(g*x)/E,o=Math.sin(o*x)/E,l=l*g+h*o,c=c*g+f*o,d=d*g+p*o,u=u*g+v*o}else{l=l*g+h*o,c=c*g+f*o,d=d*g+p*o,u=u*g+v*o;const x=1/Math.sqrt(l*l+c*c+d*d+u*u);l*=x,c*=x,d*=x,u*=x}}e[t]=l,e[t+1]=c,e[t+2]=d,e[t+3]=u}static multiplyQuaternionsFlat(e,t,i,r,s,a){const o=i[r],l=i[r+1],c=i[r+2],d=i[r+3],u=s[a],h=s[a+1],f=s[a+2],p=s[a+3];return e[t]=o*p+d*u+l*f-c*h,e[t+1]=l*p+d*h+c*u-o*f,e[t+2]=c*p+d*f+o*h-l*u,e[t+3]=d*p-o*u-l*h-c*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,i,r){return this._x=e,this._y=t,this._z=i,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const i=e._x,r=e._y,s=e._z,a=e._order,o=Math.cos,l=Math.sin,c=o(i/2),d=o(r/2),u=o(s/2),h=l(i/2),f=l(r/2),p=l(s/2);switch(a){case"XYZ":this._x=h*d*u+c*f*p,this._y=c*f*u-h*d*p,this._z=c*d*p+h*f*u,this._w=c*d*u-h*f*p;break;case"YXZ":this._x=h*d*u+c*f*p,this._y=c*f*u-h*d*p,this._z=c*d*p-h*f*u,this._w=c*d*u+h*f*p;break;case"ZXY":this._x=h*d*u-c*f*p,this._y=c*f*u+h*d*p,this._z=c*d*p+h*f*u,this._w=c*d*u-h*f*p;break;case"ZYX":this._x=h*d*u-c*f*p,this._y=c*f*u+h*d*p,this._z=c*d*p-h*f*u,this._w=c*d*u+h*f*p;break;case"YZX":this._x=h*d*u+c*f*p,this._y=c*f*u+h*d*p,this._z=c*d*p-h*f*u,this._w=c*d*u-h*f*p;break;case"XZY":this._x=h*d*u-c*f*p,this._y=c*f*u-h*d*p,this._z=c*d*p+h*f*u,this._w=c*d*u+h*f*p;break;default:ke("Quaternion: .setFromEuler() encountered an unknown order: "+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const i=t/2,r=Math.sin(i);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,i=t[0],r=t[4],s=t[8],a=t[1],o=t[5],l=t[9],c=t[2],d=t[6],u=t[10],h=i+o+u;if(h>0){const f=.5/Math.sqrt(h+1);this._w=.25/f,this._x=(d-l)*f,this._y=(s-c)*f,this._z=(a-r)*f}else if(i>o&&i>u){const f=2*Math.sqrt(1+i-o-u);this._w=(d-l)/f,this._x=.25*f,this._y=(r+a)/f,this._z=(s+c)/f}else if(o>u){const f=2*Math.sqrt(1+o-i-u);this._w=(s-c)/f,this._x=(r+a)/f,this._y=.25*f,this._z=(l+d)/f}else{const f=2*Math.sqrt(1+u-i-o);this._w=(a-r)/f,this._x=(s+c)/f,this._y=(l+d)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let i=e.dot(t)+1;return i<1e-8?(i=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=i):(this._x=0,this._y=-e.z,this._z=e.y,this._w=i)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=i),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(et(this.dot(e),-1,1)))}rotateTowards(e,t){const i=this.angleTo(e);if(i===0)return this;const r=Math.min(1,t/i);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const i=e._x,r=e._y,s=e._z,a=e._w,o=t._x,l=t._y,c=t._z,d=t._w;return this._x=i*d+a*o+r*c-s*l,this._y=r*d+a*l+s*o-i*c,this._z=s*d+a*c+i*l-r*o,this._w=a*d-i*o-r*l-s*c,this._onChangeCallback(),this}slerp(e,t){let i=e._x,r=e._y,s=e._z,a=e._w,o=this.dot(e);o<0&&(i=-i,r=-r,s=-s,a=-a,o=-o);let l=1-t;if(o<.9995){const c=Math.acos(o),d=Math.sin(c);l=Math.sin(l*c)/d,t=Math.sin(t*c)/d,this._x=this._x*l+i*t,this._y=this._y*l+r*t,this._z=this._z*l+s*t,this._w=this._w*l+a*t,this._onChangeCallback()}else this._x=this._x*l+i*t,this._y=this._y*l+r*t,this._z=this._z*l+s*t,this._w=this._w*l+a*t,this.normalize();return this}slerpQuaternions(e,t,i){return this.copy(e).slerp(t,i)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),i=Math.random(),r=Math.sqrt(1-i),s=Math.sqrt(i);return this.set(r*Math.sin(e),r*Math.cos(e),s*Math.sin(t),s*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class P{static{P.prototype.isVector3=!0}constructor(e=0,t=0,i=0){this.x=e,this.y=t,this.z=i}set(e,t,i){return i===void 0&&(i=this.z),this.x=e,this.y=t,this.z=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("THREE.Vector3: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(vu.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(vu.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,i=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[3]*i+s[6]*r,this.y=s[1]*t+s[4]*i+s[7]*r,this.z=s[2]*t+s[5]*i+s[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,i=this.y,r=this.z,s=e.elements,a=1/(s[3]*t+s[7]*i+s[11]*r+s[15]);return this.x=(s[0]*t+s[4]*i+s[8]*r+s[12])*a,this.y=(s[1]*t+s[5]*i+s[9]*r+s[13])*a,this.z=(s[2]*t+s[6]*i+s[10]*r+s[14])*a,this}applyQuaternion(e){const t=this.x,i=this.y,r=this.z,s=e.x,a=e.y,o=e.z,l=e.w,c=2*(a*r-o*i),d=2*(o*t-s*r),u=2*(s*i-a*t);return this.x=t+l*c+a*u-o*d,this.y=i+l*d+o*c-s*u,this.z=r+l*u+s*d-a*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,i=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[4]*i+s[8]*r,this.y=s[1]*t+s[5]*i+s[9]*r,this.z=s[2]*t+s[6]*i+s[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=et(this.x,e.x,t.x),this.y=et(this.y,e.y,t.y),this.z=et(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=et(this.x,e,t),this.y=et(this.y,e,t),this.z=et(this.z,e,t),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(et(i,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const i=e.x,r=e.y,s=e.z,a=t.x,o=t.y,l=t.z;return this.x=r*l-s*o,this.y=s*a-i*l,this.z=i*o-r*a,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const i=e.dot(this)/t;return this.copy(e).multiplyScalar(i)}projectOnPlane(e){return pl.copy(this).projectOnVector(e),this.sub(pl)}reflect(e){return this.sub(pl.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(et(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y,r=this.z-e.z;return t*t+i*i+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,i){const r=Math.sin(t)*e;return this.x=r*Math.sin(i),this.y=Math.cos(t)*e,this.z=r*Math.cos(i),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,i){return this.x=e*Math.sin(t),this.y=i,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),i=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=i,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,i=Math.sqrt(1-t*t);return this.x=i*Math.cos(e),this.y=t,this.z=i*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const pl=new P,vu=new ms;class qe{static{qe.prototype.isMatrix3=!0}constructor(e,t,i,r,s,a,o,l,c){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,i,r,s,a,o,l,c)}set(e,t,i,r,s,a,o,l,c){const d=this.elements;return d[0]=e,d[1]=r,d[2]=o,d[3]=t,d[4]=s,d[5]=l,d[6]=i,d[7]=a,d[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],this}extractBasis(e,t,i){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,r=t.elements,s=this.elements,a=i[0],o=i[3],l=i[6],c=i[1],d=i[4],u=i[7],h=i[2],f=i[5],p=i[8],v=r[0],m=r[3],g=r[6],x=r[1],E=r[4],b=r[7],w=r[2],S=r[5],T=r[8];return s[0]=a*v+o*x+l*w,s[3]=a*m+o*E+l*S,s[6]=a*g+o*b+l*T,s[1]=c*v+d*x+u*w,s[4]=c*m+d*E+u*S,s[7]=c*g+d*b+u*T,s[2]=h*v+f*x+p*w,s[5]=h*m+f*E+p*S,s[8]=h*g+f*b+p*T,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],d=e[8];return t*a*d-t*o*c-i*s*d+i*o*l+r*s*c-r*a*l}invert(){const e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],d=e[8],u=d*a-o*c,h=o*l-d*s,f=c*s-a*l,p=t*u+i*h+r*f;if(p===0)return this.set(0,0,0,0,0,0,0,0,0);const v=1/p;return e[0]=u*v,e[1]=(r*c-d*i)*v,e[2]=(o*i-r*a)*v,e[3]=h*v,e[4]=(d*t-r*l)*v,e[5]=(r*s-o*t)*v,e[6]=f*v,e[7]=(i*l-c*t)*v,e[8]=(a*t-i*s)*v,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,i,r,s,a,o){const l=Math.cos(s),c=Math.sin(s);return this.set(i*l,i*c,-i*(l*a+c*o)+a+e,-r*c,r*l,-r*(-c*a+l*o)+o+t,0,0,1),this}scale(e,t){return ns("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(ml.makeScale(e,t)),this}rotate(e){return ns("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(ml.makeRotation(-e)),this}translate(e,t){return ns("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(ml.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,i,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,i=e.elements;for(let r=0;r<9;r++)if(t[r]!==i[r])return!1;return!0}fromArray(e,t=0){for(let i=0;i<9;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const ml=new qe,yu=new qe().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),_u=new qe().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function ag(){const n={enabled:!0,workingColorSpace:To,spaces:{},convert:function(r,s,a){return this.enabled===!1||s===a||!s||!a||(this.spaces[s].transfer===gt&&(r.r=Ri(r.r),r.g=Ri(r.g),r.b=Ri(r.b)),this.spaces[s].primaries!==this.spaces[a].primaries&&(r.applyMatrix3(this.spaces[s].toXYZ),r.applyMatrix3(this.spaces[a].fromXYZ)),this.spaces[a].transfer===gt&&(r.r=is(r.r),r.g=is(r.g),r.b=is(r.b))),r},workingToColorSpace:function(r,s){return this.convert(r,this.workingColorSpace,s)},colorSpaceToWorking:function(r,s){return this.convert(r,s,this.workingColorSpace)},getPrimaries:function(r){return this.spaces[r].primaries},getTransfer:function(r){return r===Zi?Ao:this.spaces[r].transfer},getToneMappingMode:function(r){return this.spaces[r].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(r,s=this.workingColorSpace){return r.fromArray(this.spaces[s].luminanceCoefficients)},define:function(r){Object.assign(this.spaces,r)},_getMatrix:function(r,s,a){return r.copy(this.spaces[s].toXYZ).multiply(this.spaces[a].fromXYZ)},_getDrawingBufferColorSpace:function(r){return this.spaces[r].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(r=this.workingColorSpace){return this.spaces[r].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(r,s){return ns("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),n.workingToColorSpace(r,s)},toWorkingColorSpace:function(r,s){return ns("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),n.colorSpaceToWorking(r,s)}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],i=[.3127,.329];return n.define({[To]:{primaries:e,whitePoint:i,transfer:Ao,toXYZ:yu,fromXYZ:_u,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:hn},outputColorSpaceConfig:{drawingBufferColorSpace:hn}},[hn]:{primaries:e,whitePoint:i,transfer:gt,toXYZ:yu,fromXYZ:_u,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:hn}}}),n}const at=ag();function Ri(n){return n<.04045?n*.0773993808:Math.pow(n*.9478672986+.0521327014,2.4)}function is(n){return n<.0031308?n*12.92:1.055*Math.pow(n,.41666)-.055}let Cr;class og{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let i;if(e instanceof HTMLCanvasElement)i=e;else{Cr===void 0&&(Cr=Ro("canvas")),Cr.width=e.width,Cr.height=e.height;const r=Cr.getContext("2d");e instanceof ImageData?r.putImageData(e,0,0):r.drawImage(e,0,0,e.width,e.height),i=Cr}return i.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=Ro("canvas");t.width=e.width,t.height=e.height;const i=t.getContext("2d");i.drawImage(e,0,0,e.width,e.height);const r=i.getImageData(0,0,e.width,e.height),s=r.data;for(let a=0;a<s.length;a++)s[a]=Ri(s[a]/255)*255;return i.putImageData(r,0,0),t}else if(e.data){const t=e.data.slice(0);for(let i=0;i<t.length;i++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[i]=Math.floor(Ri(t[i]/255)*255):t[i]=Ri(t[i]);return{data:t,width:e.width,height:e.height}}else return ke("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let lg=0;class Ed{constructor(e=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:lg++}),this.uuid=ui(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):typeof VideoFrame<"u"&&t instanceof VideoFrame?e.set(t.displayWidth,t.displayHeight,0):t!==null?e.set(t.width,t.height,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const i={uuid:this.uuid,url:""},r=this.data;if(r!==null){let s;if(Array.isArray(r)){s=[];for(let a=0,o=r.length;a<o;a++)r[a].isDataTexture?s.push(gl(r[a].image)):s.push(gl(r[a]))}else s=gl(r);i.url=s}return t||(e.images[this.uuid]=i),i}}function gl(n){return typeof HTMLImageElement<"u"&&n instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&n instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&n instanceof ImageBitmap?og.getDataURL(n):n.data?{data:Array.from(n.data),width:n.width,height:n.height,type:n.data.constructor.name}:(ke("Texture: Unable to serialize Texture."),{})}let cg=0;const vl=new P;class an extends Er{constructor(e=an.DEFAULT_IMAGE,t=an.DEFAULT_MAPPING,i=Ti,r=Ti,s=sn,a=ur,o=Wn,l=Tn,c=an.DEFAULT_ANISOTROPY,d=Zi){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:cg++}),this.uuid=ui(),this.name="",this.source=new Ed(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=i,this.wrapT=r,this.magFilter=s,this.minFilter=a,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new le(0,0),this.repeat=new le(1,1),this.center=new le(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new qe,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=d,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(vl).x}get height(){return this.source.getSize(vl).y}get depth(){return this.source.getSize(vl).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const i=e[t];if(i===void 0){ke(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){ke(`Texture.setValues(): property '${t}' does not exist.`);continue}r&&i&&r.isVector2&&i.isVector2||r&&i&&r.isVector3&&i.isVector3||r&&i&&r.isMatrix3&&i.isMatrix3?r.copy(i):this[t]=i}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const i={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),t||(e.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==Kh)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case oc:e.x=e.x-Math.floor(e.x);break;case Ti:e.x=e.x<0?0:1;break;case lc:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case oc:e.y=e.y-Math.floor(e.y);break;case Ti:e.y=e.y<0?0:1;break;case lc:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}an.DEFAULT_IMAGE=null;an.DEFAULT_MAPPING=Kh;an.DEFAULT_ANISOTROPY=1;class Rt{static{Rt.prototype.isVector4=!0}constructor(e=0,t=0,i=0,r=1){this.x=e,this.y=t,this.z=i,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,i,r){return this.x=e,this.y=t,this.z=i,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("THREE.Vector4: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,i=this.y,r=this.z,s=this.w,a=e.elements;return this.x=a[0]*t+a[4]*i+a[8]*r+a[12]*s,this.y=a[1]*t+a[5]*i+a[9]*r+a[13]*s,this.z=a[2]*t+a[6]*i+a[10]*r+a[14]*s,this.w=a[3]*t+a[7]*i+a[11]*r+a[15]*s,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,i,r,s;const l=e.elements,c=l[0],d=l[4],u=l[8],h=l[1],f=l[5],p=l[9],v=l[2],m=l[6],g=l[10];if(Math.abs(d-h)<.01&&Math.abs(u-v)<.01&&Math.abs(p-m)<.01){if(Math.abs(d+h)<.1&&Math.abs(u+v)<.1&&Math.abs(p+m)<.1&&Math.abs(c+f+g-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const E=(c+1)/2,b=(f+1)/2,w=(g+1)/2,S=(d+h)/4,T=(u+v)/4,y=(p+m)/4;return E>b&&E>w?E<.01?(i=0,r=.707106781,s=.707106781):(i=Math.sqrt(E),r=S/i,s=T/i):b>w?b<.01?(i=.707106781,r=0,s=.707106781):(r=Math.sqrt(b),i=S/r,s=y/r):w<.01?(i=.707106781,r=.707106781,s=0):(s=Math.sqrt(w),i=T/s,r=y/s),this.set(i,r,s,t),this}let x=Math.sqrt((m-p)*(m-p)+(u-v)*(u-v)+(h-d)*(h-d));return Math.abs(x)<.001&&(x=1),this.x=(m-p)/x,this.y=(u-v)/x,this.z=(h-d)/x,this.w=Math.acos((c+f+g-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=et(this.x,e.x,t.x),this.y=et(this.y,e.y,t.y),this.z=et(this.z,e.z,t.z),this.w=et(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=et(this.x,e,t),this.y=et(this.y,e,t),this.z=et(this.z,e,t),this.w=et(this.w,e,t),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(et(i,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this.w=e.w+(t.w-e.w)*i,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class dg extends Er{constructor(e=1,t=1,i={}){super(),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:sn,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},i),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=i.depth,this.scissor=new Rt(0,0,e,t),this.scissorTest=!1,this.viewport=new Rt(0,0,e,t),this.textures=[];const r={width:e,height:t,depth:i.depth},s=new an(r),a=i.count;for(let o=0;o<a;o++)this.textures[o]=s.clone(),this.textures[o].isRenderTargetTexture=!0,this.textures[o].renderTarget=this;this._setTextureOptions(i),this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.resolveColorBuffer=i.resolveColorBuffer,this.resolveDepthBuffer=i.resolveDepthBuffer,this.resolveStencilBuffer=i.resolveStencilBuffer,this.storeMultisampledColorBuffer=i.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=i.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=i.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=i.depthTexture,this.samples=i.samples,this.multiview=i.multiview,this.useArrayDepthTexture=i.useArrayDepthTexture}_setTextureOptions(e={}){const t={minFilter:sn,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let i=0;i<this.textures.length;i++)this.textures[i].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),e!==null&&e.renderTarget===null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,i=1){if(this.width!==e||this.height!==t||this.depth!==i){this.width=e,this.height=t,this.depth=i;for(let r=0,s=this.textures.length;r<s;r++)this.textures[r].image.width=e,this.textures[r].image.height=t,this.textures[r].image.depth=i,this.textures[r].isData3DTexture!==!0&&(this.textures[r].isArrayTexture=this.textures[r].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,i=e.textures.length;t<i;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const r=Object.assign({},e.textures[t].image);this.textures[t].source=new Ed(r)}if(this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveColorBuffer=e.resolveColorBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,this.storeMultisampledColorBuffer=e.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=e.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=e.storeMultisampledStencilBuffer,e.depthTexture!==null)if(e.depthTexture.renderTarget===e){const t=e.depthTexture.clone();t.renderTarget=null,this.depthTexture=t}else this.depthTexture=e.depthTexture;return this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Xn extends dg{constructor(e=1,t=1,i={}){super(e,t,i),this.isWebGLRenderTarget=!0}}class of extends an{constructor(e=null,t=1,i=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:i,depth:r},this.magFilter=Jt,this.minFilter=Jt,this.wrapR=Ti,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class ug extends an{constructor(e=null,t=1,i=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:i,depth:r},this.magFilter=Jt,this.minFilter=Jt,this.wrapR=Ti,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}}class yt{static{yt.prototype.isMatrix4=!0}constructor(e,t,i,r,s,a,o,l,c,d,u,h,f,p,v,m){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,i,r,s,a,o,l,c,d,u,h,f,p,v,m)}set(e,t,i,r,s,a,o,l,c,d,u,h,f,p,v,m){const g=this.elements;return g[0]=e,g[4]=t,g[8]=i,g[12]=r,g[1]=s,g[5]=a,g[9]=o,g[13]=l,g[2]=c,g[6]=d,g[10]=u,g[14]=h,g[3]=f,g[7]=p,g[11]=v,g[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new yt().fromArray(this.elements)}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],t[9]=i[9],t[10]=i[10],t[11]=i[11],t[12]=i[12],t[13]=i[13],t[14]=i[14],t[15]=i[15],this}copyPosition(e){const t=this.elements,i=e.elements;return t[12]=i[12],t[13]=i[13],t[14]=i[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,i){return this.determinantAffine()===0?(e.set(1,0,0),t.set(0,1,0),i.set(0,0,1),this):(e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this)}makeBasis(e,t,i){return this.set(e.x,t.x,i.x,0,e.y,t.y,i.y,0,e.z,t.z,i.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();const t=this.elements,i=e.elements,r=1/Ir.setFromMatrixColumn(e,0).length(),s=1/Ir.setFromMatrixColumn(e,1).length(),a=1/Ir.setFromMatrixColumn(e,2).length();return t[0]=i[0]*r,t[1]=i[1]*r,t[2]=i[2]*r,t[3]=0,t[4]=i[4]*s,t[5]=i[5]*s,t[6]=i[6]*s,t[7]=0,t[8]=i[8]*a,t[9]=i[9]*a,t[10]=i[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,i=e.x,r=e.y,s=e.z,a=Math.cos(i),o=Math.sin(i),l=Math.cos(r),c=Math.sin(r),d=Math.cos(s),u=Math.sin(s);if(e.order==="XYZ"){const h=a*d,f=a*u,p=o*d,v=o*u;t[0]=l*d,t[4]=-l*u,t[8]=c,t[1]=f+p*c,t[5]=h-v*c,t[9]=-o*l,t[2]=v-h*c,t[6]=p+f*c,t[10]=a*l}else if(e.order==="YXZ"){const h=l*d,f=l*u,p=c*d,v=c*u;t[0]=h+v*o,t[4]=p*o-f,t[8]=a*c,t[1]=a*u,t[5]=a*d,t[9]=-o,t[2]=f*o-p,t[6]=v+h*o,t[10]=a*l}else if(e.order==="ZXY"){const h=l*d,f=l*u,p=c*d,v=c*u;t[0]=h-v*o,t[4]=-a*u,t[8]=p+f*o,t[1]=f+p*o,t[5]=a*d,t[9]=v-h*o,t[2]=-a*c,t[6]=o,t[10]=a*l}else if(e.order==="ZYX"){const h=a*d,f=a*u,p=o*d,v=o*u;t[0]=l*d,t[4]=p*c-f,t[8]=h*c+v,t[1]=l*u,t[5]=v*c+h,t[9]=f*c-p,t[2]=-c,t[6]=o*l,t[10]=a*l}else if(e.order==="YZX"){const h=a*l,f=a*c,p=o*l,v=o*c;t[0]=l*d,t[4]=v-h*u,t[8]=p*u+f,t[1]=u,t[5]=a*d,t[9]=-o*d,t[2]=-c*d,t[6]=f*u+p,t[10]=h-v*u}else if(e.order==="XZY"){const h=a*l,f=a*c,p=o*l,v=o*c;t[0]=l*d,t[4]=-u,t[8]=c*d,t[1]=h*u+v,t[5]=a*d,t[9]=f*u-p,t[2]=p*u-f,t[6]=o*d,t[10]=v*u+h}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(hg,e,fg)}lookAt(e,t,i){const r=this.elements;return Sn.subVectors(e,t),Sn.lengthSq()===0&&(Sn.z=1),Sn.normalize(),ki.crossVectors(i,Sn),ki.lengthSq()===0&&(Math.abs(i.z)===1?Sn.x+=1e-4:Sn.z+=1e-4,Sn.normalize(),ki.crossVectors(i,Sn)),ki.normalize(),Ma.crossVectors(Sn,ki),r[0]=ki.x,r[4]=Ma.x,r[8]=Sn.x,r[1]=ki.y,r[5]=Ma.y,r[9]=Sn.y,r[2]=ki.z,r[6]=Ma.z,r[10]=Sn.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,r=t.elements,s=this.elements,a=i[0],o=i[4],l=i[8],c=i[12],d=i[1],u=i[5],h=i[9],f=i[13],p=i[2],v=i[6],m=i[10],g=i[14],x=i[3],E=i[7],b=i[11],w=i[15],S=r[0],T=r[4],y=r[8],A=r[12],C=r[1],L=r[5],I=r[9],B=r[13],N=r[2],U=r[6],V=r[10],$=r[14],ie=r[3],X=r[7],Q=r[11],ne=r[15];return s[0]=a*S+o*C+l*N+c*ie,s[4]=a*T+o*L+l*U+c*X,s[8]=a*y+o*I+l*V+c*Q,s[12]=a*A+o*B+l*$+c*ne,s[1]=d*S+u*C+h*N+f*ie,s[5]=d*T+u*L+h*U+f*X,s[9]=d*y+u*I+h*V+f*Q,s[13]=d*A+u*B+h*$+f*ne,s[2]=p*S+v*C+m*N+g*ie,s[6]=p*T+v*L+m*U+g*X,s[10]=p*y+v*I+m*V+g*Q,s[14]=p*A+v*B+m*$+g*ne,s[3]=x*S+E*C+b*N+w*ie,s[7]=x*T+E*L+b*U+w*X,s[11]=x*y+E*I+b*V+w*Q,s[15]=x*A+E*B+b*$+w*ne,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[4],r=e[8],s=e[12],a=e[1],o=e[5],l=e[9],c=e[13],d=e[2],u=e[6],h=e[10],f=e[14],p=e[3],v=e[7],m=e[11],g=e[15],x=l*f-c*h,E=o*f-c*u,b=o*h-l*u,w=a*f-c*d,S=a*h-l*d,T=a*u-o*d;return t*(v*x-m*E+g*b)-i*(p*x-m*w+g*S)+r*(p*E-v*w+g*T)-s*(p*b-v*S+m*T)}determinantAffine(){const e=this.elements,t=e[0],i=e[4],r=e[8],s=e[1],a=e[5],o=e[9],l=e[2],c=e[6],d=e[10];return t*(a*d-o*c)-i*(s*d-o*l)+r*(s*c-a*l)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,i){const r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=i),this}invert(){const e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],d=e[8],u=e[9],h=e[10],f=e[11],p=e[12],v=e[13],m=e[14],g=e[15],x=t*o-i*a,E=t*l-r*a,b=t*c-s*a,w=i*l-r*o,S=i*c-s*o,T=r*c-s*l,y=d*v-u*p,A=d*m-h*p,C=d*g-f*p,L=u*m-h*v,I=u*g-f*v,B=h*g-f*m,N=x*B-E*I+b*L+w*C-S*A+T*y;if(N===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const U=1/N;return e[0]=(o*B-l*I+c*L)*U,e[1]=(r*I-i*B-s*L)*U,e[2]=(v*T-m*S+g*w)*U,e[3]=(h*S-u*T-f*w)*U,e[4]=(l*C-a*B-c*A)*U,e[5]=(t*B-r*C+s*A)*U,e[6]=(m*b-p*T-g*E)*U,e[7]=(d*T-h*b+f*E)*U,e[8]=(a*I-o*C+c*y)*U,e[9]=(i*C-t*I-s*y)*U,e[10]=(p*S-v*b+g*x)*U,e[11]=(u*b-d*S-f*x)*U,e[12]=(o*A-a*L-l*y)*U,e[13]=(t*L-i*A+r*y)*U,e[14]=(v*E-p*w-m*x)*U,e[15]=(d*w-u*E+h*x)*U,this}scale(e){const t=this.elements,i=e.x,r=e.y,s=e.z;return t[0]*=i,t[4]*=r,t[8]*=s,t[1]*=i,t[5]*=r,t[9]*=s,t[2]*=i,t[6]*=r,t[10]*=s,t[3]*=i,t[7]*=r,t[11]*=s,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],i=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,i,r))}makeTranslation(e,t,i){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,i,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),i=Math.sin(e);return this.set(1,0,0,0,0,t,-i,0,0,i,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,0,i,0,0,1,0,0,-i,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,0,i,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const i=Math.cos(t),r=Math.sin(t),s=1-i,a=e.x,o=e.y,l=e.z,c=s*a,d=s*o;return this.set(c*a+i,c*o-r*l,c*l+r*o,0,c*o+r*l,d*o+i,d*l-r*a,0,c*l-r*o,d*l+r*a,s*l*l+i,0,0,0,0,1),this}makeScale(e,t,i){return this.set(e,0,0,0,0,t,0,0,0,0,i,0,0,0,0,1),this}makeShear(e,t,i,r,s,a){return this.set(1,i,s,0,e,1,a,0,t,r,1,0,0,0,0,1),this}compose(e,t,i){const r=this.elements,s=t._x,a=t._y,o=t._z,l=t._w,c=s+s,d=a+a,u=o+o,h=s*c,f=s*d,p=s*u,v=a*d,m=a*u,g=o*u,x=l*c,E=l*d,b=l*u,w=i.x,S=i.y,T=i.z;return r[0]=(1-(v+g))*w,r[1]=(f+b)*w,r[2]=(p-E)*w,r[3]=0,r[4]=(f-b)*S,r[5]=(1-(h+g))*S,r[6]=(m+x)*S,r[7]=0,r[8]=(p+E)*T,r[9]=(m-x)*T,r[10]=(1-(h+v))*T,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,i){const r=this.elements;e.x=r[12],e.y=r[13],e.z=r[14];const s=this.determinantAffine();if(s===0)return i.set(1,1,1),t.identity(),this;let a=Ir.set(r[0],r[1],r[2]).length();const o=Ir.set(r[4],r[5],r[6]).length(),l=Ir.set(r[8],r[9],r[10]).length();s<0&&(a=-a),kn.copy(this);const c=1/a,d=1/o,u=1/l;return kn.elements[0]*=c,kn.elements[1]*=c,kn.elements[2]*=c,kn.elements[4]*=d,kn.elements[5]*=d,kn.elements[6]*=d,kn.elements[8]*=u,kn.elements[9]*=u,kn.elements[10]*=u,t.setFromRotationMatrix(kn),i.x=a,i.y=o,i.z=l,this}makePerspective(e,t,i,r,s,a,o=li,l=!1){const c=this.elements,d=2*s/(t-e),u=2*s/(i-r),h=(t+e)/(t-e),f=(i+r)/(i-r);let p,v;if(l)p=s/(a-s),v=a*s/(a-s);else if(o===li)p=-(a+s)/(a-s),v=-2*a*s/(a-s);else if(o===ta)p=-a/(a-s),v=-a*s/(a-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return c[0]=d,c[4]=0,c[8]=h,c[12]=0,c[1]=0,c[5]=u,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=p,c[14]=v,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,i,r,s,a,o=li,l=!1){const c=this.elements,d=2/(t-e),u=2/(i-r),h=-(t+e)/(t-e),f=-(i+r)/(i-r);let p,v;if(l)p=1/(a-s),v=a/(a-s);else if(o===li)p=-2/(a-s),v=-(a+s)/(a-s);else if(o===ta)p=-1/(a-s),v=-s/(a-s);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return c[0]=d,c[4]=0,c[8]=0,c[12]=h,c[1]=0,c[5]=u,c[9]=0,c[13]=f,c[2]=0,c[6]=0,c[10]=p,c[14]=v,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){const t=this.elements,i=e.elements;for(let r=0;r<16;r++)if(t[r]!==i[r])return!1;return!0}fromArray(e,t=0){for(let i=0;i<16;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e[t+9]=i[9],e[t+10]=i[10],e[t+11]=i[11],e[t+12]=i[12],e[t+13]=i[13],e[t+14]=i[14],e[t+15]=i[15],e}}const Ir=new P,kn=new yt,hg=new P(0,0,0),fg=new P(1,1,1),ki=new P,Ma=new P,Sn=new P,xu=new yt,bu=new ms;class Ji{constructor(e=0,t=0,i=0,r=Ji.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=i,this._order=r}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,i,r=this._order){return this._x=e,this._y=t,this._z=i,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,i=!0){const r=e.elements,s=r[0],a=r[4],o=r[8],l=r[1],c=r[5],d=r[9],u=r[2],h=r[6],f=r[10];switch(t){case"XYZ":this._y=Math.asin(et(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-d,f),this._z=Math.atan2(-a,s)):(this._x=Math.atan2(h,c),this._z=0);break;case"YXZ":this._x=Math.asin(-et(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(o,f),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,s),this._z=0);break;case"ZXY":this._x=Math.asin(et(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(l,s));break;case"ZYX":this._y=Math.asin(-et(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(h,f),this._z=Math.atan2(l,s)):(this._x=0,this._z=Math.atan2(-a,c));break;case"YZX":this._z=Math.asin(et(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-d,c),this._y=Math.atan2(-u,s)):(this._x=0,this._y=Math.atan2(o,f));break;case"XZY":this._z=Math.asin(-et(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(h,c),this._y=Math.atan2(o,s)):(this._x=Math.atan2(-d,f),this._y=0);break;default:ke("Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,i===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,i){return xu.makeRotationFromQuaternion(e),this.setFromRotationMatrix(xu,t,i)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return bu.setFromEuler(this),this.setFromQuaternion(bu,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Ji.DEFAULT_ORDER="XYZ";class Td{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let pg=0;const Su=new P,Pr=new ms,_i=new yt,wa=new P,bs=new P,mg=new P,gg=new ms,Mu=new P(1,0,0),wu=new P(0,1,0),Eu=new P(0,0,1),Tu={type:"added"},vg={type:"removed"},Lr={type:"childadded",child:null},yl={type:"childremoved",child:null};class Gt extends Er{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:pg++}),this.uuid=ui(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Gt.DEFAULT_UP.clone();const e=new P,t=new Ji,i=new ms,r=new P(1,1,1);function s(){i.setFromEuler(t,!1)}function a(){t.setFromQuaternion(i,void 0,!1)}t._onChange(s),i._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:r},modelViewMatrix:{value:new yt},normalMatrix:{value:new qe}}),this.matrix=new yt,this.matrixWorld=new yt,this.matrixAutoUpdate=Gt.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Gt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Td,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Pr.setFromAxisAngle(e,t),this.quaternion.multiply(Pr),this}rotateOnWorldAxis(e,t){return Pr.setFromAxisAngle(e,t),this.quaternion.premultiply(Pr),this}rotateX(e){return this.rotateOnAxis(Mu,e)}rotateY(e){return this.rotateOnAxis(wu,e)}rotateZ(e){return this.rotateOnAxis(Eu,e)}translateOnAxis(e,t){return Su.copy(e).applyQuaternion(this.quaternion),this.position.add(Su.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Mu,e)}translateY(e){return this.translateOnAxis(wu,e)}translateZ(e){return this.translateOnAxis(Eu,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(_i.copy(this.matrixWorld).invert())}lookAt(e,t,i){e.isVector3?wa.copy(e):wa.set(e,t,i);const r=this.parent;this.updateWorldMatrix(!0,!1),bs.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?_i.lookAt(bs,wa,this.up):_i.lookAt(wa,bs,this.up),this.quaternion.setFromRotationMatrix(_i),r&&(_i.extractRotation(r.matrixWorld),Pr.setFromRotationMatrix(_i),this.quaternion.premultiply(Pr.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(st("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Tu),Lr.child=e,this.dispatchEvent(Lr),Lr.child=null):st("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(vg),yl.child=e,this.dispatchEvent(yl),yl.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),_i.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),_i.multiply(e.parent.matrixWorld)),e.applyMatrix4(_i),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Tu),Lr.child=e,this.dispatchEvent(Lr),Lr.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let i=0,r=this.children.length;i<r;i++){const a=this.children[i].getObjectByProperty(e,t);if(a!==void 0)return a}}getObjectsByProperty(e,t,i=[]){this[e]===t&&i.push(this);const r=this.children;for(let s=0,a=r.length;s<a;s++)r[s].getObjectsByProperty(e,t,i);return i}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(bs,e,mg),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(bs,gg,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}intersectsFrustum(){}traverse(e){e(this);const t=this.children;for(let i=0,r=t.length;i<r;i++)t[i].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let i=0,r=t.length;i<r;i++)t[i].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const e=this.pivot;if(e!==null){const t=e.x,i=e.y,r=e.z,s=this.matrix.elements;s[12]+=t-s[0]*t-s[4]*i-s[8]*r,s[13]+=i-s[1]*t-s[5]*i-s[9]*r,s[14]+=r-s[2]*t-s[6]*i-s[10]*r}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let i=0,r=t.length;i<r;i++)t[i].updateMatrixWorld(e)}updateWorldMatrix(e,t,i=!1){const r=this.parent;if(e===!0&&r!==null&&r.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||i)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,i=!0),t===!0){const s=this.children;for(let a=0,o=s.length;a<o;a++)s[a].updateWorldMatrix(!1,!0,i)}}toJSON(e){const t=e===void 0||typeof e=="string",i={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const r={};r.uuid=this.uuid,r.type=this.type,r.name=this.name,r.castShadow=this.castShadow,r.receiveShadow=this.receiveShadow,r.visible=this.visible,r.frustumCulled=this.frustumCulled,r.renderOrder=this.renderOrder,r.static=this.static,r.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.pivot!==null&&(r.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(r.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(r.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(r.type="InstancedMesh",r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type="BatchedMesh",r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.geometryInfo=this._geometryInfo.map(o=>({...o,boundingBox:o.boundingBox?o.boundingBox.toJSON():void 0,boundingSphere:o.boundingSphere?o.boundingSphere.toJSON():void 0})),r.instanceInfo=this._instanceInfo.map(o=>({...o})),r.availableInstanceIds=this._availableInstanceIds.slice(),r.availableGeometryIds=this._availableGeometryIds.slice(),r.nextIndexStart=this._nextIndexStart,r.nextVertexStart=this._nextVertexStart,r.geometryCount=this._geometryCount,r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.matricesTexture=this._matricesTexture.toJSON(e),r.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(r.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(r.boundingBox=this.boundingBox.toJSON()));function s(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=s(e.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const l=o.shapes;if(Array.isArray(l))for(let c=0,d=l.length;c<d;c++){const u=l[c];s(e.shapes,u)}else s(e.shapes,l)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(s(e.materials,this.material[l]));r.material=o}else r.material=s(e.materials,this.material);if(this.children.length>0){r.children=[];for(let o=0;o<this.children.length;o++)r.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let o=0;o<this.animations.length;o++){const l=this.animations[o];r.animations.push(s(e.animations,l))}}if(t){const o=a(e.geometries),l=a(e.materials),c=a(e.textures),d=a(e.images),u=a(e.shapes),h=a(e.skeletons),f=a(e.animations),p=a(e.nodes);o.length>0&&(i.geometries=o),l.length>0&&(i.materials=l),c.length>0&&(i.textures=c),d.length>0&&(i.images=d),u.length>0&&(i.shapes=u),h.length>0&&(i.skeletons=h),f.length>0&&(i.animations=f),p.length>0&&(i.nodes=p)}return i.object=r,i;function a(o){const l=[];for(const c in o){const d=o[c];delete d.metadata,l.push(d)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot!==null?e.pivot.clone():null,this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let i=0;i<e.children.length;i++){const r=e.children[i];this.add(r.clone())}return this}dispose(){this.dispatchEvent({type:"dispose"})}}Gt.DEFAULT_UP=new P(0,1,0);Gt.DEFAULT_MATRIX_AUTO_UPDATE=!0;Gt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class fr extends Gt{constructor(){super(),this.isGroup=!0,this.type="Group"}}const yg={type:"move"};class _l{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new fr,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new fr,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new P,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new P),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new fr,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new P,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new P,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const i of e.hand.values())this._getHandJoint(t,i)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,i){let r=null,s=null,a=null;const o=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){a=!0;for(const v of e.hand.values()){const m=t.getJointPose(v,i),g=this._getHandJoint(c,v);m!==null&&(g.matrix.fromArray(m.transform.matrix),g.matrix.decompose(g.position,g.rotation,g.scale),g.matrixWorldNeedsUpdate=!0,g.jointRadius=m.radius),g.visible=m!==null}const d=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],h=d.position.distanceTo(u.position),f=.02,p=.005;c.inputState.pinching&&h>f+p?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&h<=f-p&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(s=t.getPose(e.gripSpace,i),s!==null&&(l.matrix.fromArray(s.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,s.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(s.linearVelocity)):l.hasLinearVelocity=!1,s.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(s.angularVelocity)):l.hasAngularVelocity=!1,l.eventsEnabled&&l.dispatchEvent({type:"gripUpdated",data:e,target:this})));o!==null&&(r=t.getPose(e.targetRaySpace,i),r===null&&s!==null&&(r=s),r!==null&&(o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,r.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(r.linearVelocity)):o.hasLinearVelocity=!1,r.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(r.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(yg)))}return o!==null&&(o.visible=r!==null),l!==null&&(l.visible=s!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const i=new fr;i.matrixAutoUpdate=!1,i.visible=!1,e.joints[t.jointName]=i,e.add(i)}return e.joints[t.jointName]}}const lf={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},$i={h:0,s:0,l:0},Ea={h:0,s:0,l:0};function xl(n,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?n+(e-n)*6*t:t<1/2?e:t<2/3?n+(e-n)*6*(2/3-t):n}class Qe{constructor(e,t,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,i)}set(e,t,i){if(t===void 0&&i===void 0){const r=e;r&&r.isColor?this.copy(r):typeof r=="number"?this.setHex(r):typeof r=="string"&&this.setStyle(r)}else this.setRGB(e,t,i);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=hn){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,at.colorSpaceToWorking(this,t),this}setRGB(e,t,i,r=at.workingColorSpace){return this.r=e,this.g=t,this.b=i,at.colorSpaceToWorking(this,r),this}setHSL(e,t,i,r=at.workingColorSpace){if(e=wd(e,1),t=et(t,0,1),i=et(i,0,1),t===0)this.r=this.g=this.b=i;else{const s=i<=.5?i*(1+t):i+t-i*t,a=2*i-s;this.r=xl(a,s,e+1/3),this.g=xl(a,s,e),this.b=xl(a,s,e-1/3)}return at.colorSpaceToWorking(this,r),this}setStyle(e,t=hn){function i(s){s!==void 0&&parseFloat(s)<1&&ke("Color: Alpha component of "+e+" will be ignored.")}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let s;const a=r[1],o=r[2];switch(a){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,t);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:ke("Color: Unknown color model "+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){const s=r[1],a=s.length;if(a===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);if(a===6)return this.setHex(parseInt(s,16),t);ke("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=hn){const i=lf[e.toLowerCase()];return i!==void 0?this.setHex(i,t):ke("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Ri(e.r),this.g=Ri(e.g),this.b=Ri(e.b),this}copyLinearToSRGB(e){return this.r=is(e.r),this.g=is(e.g),this.b=is(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=hn){return at.workingToColorSpace(rn.copy(this),e),Math.round(et(rn.r*255,0,255))*65536+Math.round(et(rn.g*255,0,255))*256+Math.round(et(rn.b*255,0,255))}getHexString(e=hn){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=at.workingColorSpace){at.workingToColorSpace(rn.copy(this),t);const i=rn.r,r=rn.g,s=rn.b,a=Math.max(i,r,s),o=Math.min(i,r,s);let l,c;const d=(o+a)/2;if(o===a)l=0,c=0;else{const u=a-o;switch(c=d<=.5?u/(a+o):u/(2-a-o),a){case i:l=(r-s)/u+(r<s?6:0);break;case r:l=(s-i)/u+2;break;case s:l=(i-r)/u+4;break}l/=6}return e.h=l,e.s=c,e.l=d,e}getRGB(e,t=at.workingColorSpace){return at.workingToColorSpace(rn.copy(this),t),e.r=rn.r,e.g=rn.g,e.b=rn.b,e}getStyle(e=hn){at.workingToColorSpace(rn.copy(this),e);const t=rn.r,i=rn.g,r=rn.b;return e!==hn?`color(${e} ${t.toFixed(3)} ${i.toFixed(3)} ${r.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(i*255)},${Math.round(r*255)})`}offsetHSL(e,t,i){return this.getHSL($i),this.setHSL($i.h+e,$i.s+t,$i.l+i)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,i){return this.r=e.r+(t.r-e.r)*i,this.g=e.g+(t.g-e.g)*i,this.b=e.b+(t.b-e.b)*i,this}lerpHSL(e,t){this.getHSL($i),e.getHSL(Ea);const i=Hs($i.h,Ea.h,t),r=Hs($i.s,Ea.s,t),s=Hs($i.l,Ea.l,t);return this.setHSL(i,r,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,i=this.g,r=this.b,s=e.elements;return this.r=s[0]*t+s[3]*i+s[6]*r,this.g=s[1]*t+s[4]*i+s[7]*r,this.b=s[2]*t+s[5]*i+s[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const rn=new Qe;Qe.NAMES=lf;class cf extends Gt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Ji,this.environmentIntensity=1,this.environmentRotation=new Ji,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),t.object.backgroundBlurriness=this.backgroundBlurriness,t.object.backgroundIntensity=this.backgroundIntensity,t.object.backgroundRotation=this.backgroundRotation.toArray(),t.object.environmentIntensity=this.environmentIntensity,t.object.environmentRotation=this.environmentRotation.toArray(),t}}const $n=new P,xi=new P,bl=new P,bi=new P,Nr=new P,Dr=new P,Au=new P,Sl=new P,Ml=new P,wl=new P,El=new Rt,Tl=new Rt,Al=new Rt;class Ln{constructor(e=new P,t=new P,i=new P){this.a=e,this.b=t,this.c=i}static getNormal(e,t,i,r){r.subVectors(i,t),$n.subVectors(e,t),r.cross($n);const s=r.lengthSq();return s>0?r.multiplyScalar(1/Math.sqrt(s)):r.set(0,0,0)}static getBarycoord(e,t,i,r,s){$n.subVectors(r,t),xi.subVectors(i,t),bl.subVectors(e,t);const a=$n.dot($n),o=$n.dot(xi),l=$n.dot(bl),c=xi.dot(xi),d=xi.dot(bl),u=a*c-o*o;if(u===0)return s.set(0,0,0),null;const h=1/u,f=(c*l-o*d)*h,p=(a*d-o*l)*h;return s.set(1-f-p,p,f)}static containsPoint(e,t,i,r){return this.getBarycoord(e,t,i,r,bi)===null?!1:bi.x>=0&&bi.y>=0&&bi.x+bi.y<=1}static getInterpolation(e,t,i,r,s,a,o,l){return this.getBarycoord(e,t,i,r,bi)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(s,bi.x),l.addScaledVector(a,bi.y),l.addScaledVector(o,bi.z),l)}static getInterpolatedAttribute(e,t,i,r,s,a){return El.setScalar(0),Tl.setScalar(0),Al.setScalar(0),El.fromBufferAttribute(e,t),Tl.fromBufferAttribute(e,i),Al.fromBufferAttribute(e,r),a.setScalar(0),a.addScaledVector(El,s.x),a.addScaledVector(Tl,s.y),a.addScaledVector(Al,s.z),a}static isFrontFacing(e,t,i,r){return $n.subVectors(i,t),xi.subVectors(e,t),$n.cross(xi).dot(r)<0}set(e,t,i){return this.a.copy(e),this.b.copy(t),this.c.copy(i),this}setFromPointsAndIndices(e,t,i,r){return this.a.copy(e[t]),this.b.copy(e[i]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,i,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,i),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return $n.subVectors(this.c,this.b),xi.subVectors(this.a,this.b),$n.cross(xi).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return Ln.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return Ln.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,i,r,s){return Ln.getInterpolation(e,this.a,this.b,this.c,t,i,r,s)}containsPoint(e){return Ln.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return Ln.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const i=this.a,r=this.b,s=this.c;let a,o;Nr.subVectors(r,i),Dr.subVectors(s,i),Sl.subVectors(e,i);const l=Nr.dot(Sl),c=Dr.dot(Sl);if(l<=0&&c<=0)return t.copy(i);Ml.subVectors(e,r);const d=Nr.dot(Ml),u=Dr.dot(Ml);if(d>=0&&u<=d)return t.copy(r);const h=l*u-d*c;if(h<=0&&l>=0&&d<=0)return a=l/(l-d),t.copy(i).addScaledVector(Nr,a);wl.subVectors(e,s);const f=Nr.dot(wl),p=Dr.dot(wl);if(p>=0&&f<=p)return t.copy(s);const v=f*c-l*p;if(v<=0&&c>=0&&p<=0)return o=c/(c-p),t.copy(i).addScaledVector(Dr,o);const m=d*p-f*u;if(m<=0&&u-d>=0&&f-p>=0)return Au.subVectors(s,r),o=(u-d)/(u-d+(f-p)),t.copy(r).addScaledVector(Au,o);const g=1/(m+v+h);return a=v*g,o=h*g,t.copy(i).addScaledVector(Nr,a).addScaledVector(Dr,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}class _r{constructor(e=new P(1/0,1/0,1/0),t=new P(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t+=3)this.expandByPoint(zn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,i=e.count;t<i;t++)this.expandByPoint(zn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const i=zn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const i=e.geometry;if(i!==void 0){const s=i.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0)for(let a=0,o=s.count;a<o;a++)e.isMesh===!0?e.getVertexPosition(a,zn):zn.fromBufferAttribute(s,a),zn.applyMatrix4(e.matrixWorld),this.expandByPoint(zn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Ta.copy(e.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),Ta.copy(i.boundingBox)),Ta.applyMatrix4(e.matrixWorld),this.union(Ta)}const r=e.children;for(let s=0,a=r.length;s<a;s++)this.expandByObject(r[s],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,zn),zn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,i;return e.normal.x>0?(t=e.normal.x*this.min.x,i=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,i=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,i+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,i+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,i+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,i+=e.normal.z*this.min.z),t<=-e.constant&&i>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Ss),Aa.subVectors(this.max,Ss),Ur.subVectors(e.a,Ss),Or.subVectors(e.b,Ss),Fr.subVectors(e.c,Ss),zi.subVectors(Or,Ur),Hi.subVectors(Fr,Or),rr.subVectors(Ur,Fr);let t=[0,-zi.z,zi.y,0,-Hi.z,Hi.y,0,-rr.z,rr.y,zi.z,0,-zi.x,Hi.z,0,-Hi.x,rr.z,0,-rr.x,-zi.y,zi.x,0,-Hi.y,Hi.x,0,-rr.y,rr.x,0];return!Rl(t,Ur,Or,Fr,Aa)||(t=[1,0,0,0,1,0,0,0,1],!Rl(t,Ur,Or,Fr,Aa))?!1:(Ra.crossVectors(zi,Hi),t=[Ra.x,Ra.y,Ra.z],Rl(t,Ur,Or,Fr,Aa))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,zn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(zn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(Si[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Si[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Si[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Si[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Si[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Si[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Si[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Si[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Si),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const Si=[new P,new P,new P,new P,new P,new P,new P,new P],zn=new P,Ta=new _r,Ur=new P,Or=new P,Fr=new P,zi=new P,Hi=new P,rr=new P,Ss=new P,Aa=new P,Ra=new P,sr=new P;function Rl(n,e,t,i,r){for(let s=0,a=n.length-3;s<=a;s+=3){sr.fromArray(n,s);const o=r.x*Math.abs(sr.x)+r.y*Math.abs(sr.y)+r.z*Math.abs(sr.z),l=e.dot(sr),c=t.dot(sr),d=i.dot(sr);if(Math.max(-Math.max(l,c,d),Math.min(l,c,d))>o)return!1}return!0}const kt=new P,Ca=new le;let _g=0;class hi extends Er{constructor(e,t,i=!1){if(super(),Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:_g++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=i,this.usage=sf,this.updateRanges=[],this.gpuType=oi,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,i){e*=this.itemSize,i*=t.itemSize;for(let r=0,s=this.itemSize;r<s;r++)this.array[e+r]=t.array[i+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,i=this.count;t<i;t++)Ca.fromBufferAttribute(this,t),Ca.applyMatrix3(e),this.setXY(t,Ca.x,Ca.y);else if(this.itemSize===3)for(let t=0,i=this.count;t<i;t++)kt.fromBufferAttribute(this,t),kt.applyMatrix3(e),this.setXYZ(t,kt.x,kt.y,kt.z);return this}applyMatrix4(e){for(let t=0,i=this.count;t<i;t++)kt.fromBufferAttribute(this,t),kt.applyMatrix4(e),this.setXYZ(t,kt.x,kt.y,kt.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)kt.fromBufferAttribute(this,t),kt.applyNormalMatrix(e),this.setXYZ(t,kt.x,kt.y,kt.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)kt.fromBufferAttribute(this,t),kt.transformDirection(e),this.setXYZ(t,kt.x,kt.y,kt.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let i=this.array[e*this.itemSize+t];return this.normalized&&(i=Vn(i,this.array)),i}setComponent(e,t,i){return this.normalized&&(i=vt(i,this.array)),this.array[e*this.itemSize+t]=i,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=Vn(t,this.array)),t}setX(e,t){return this.normalized&&(t=vt(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=Vn(t,this.array)),t}setY(e,t){return this.normalized&&(t=vt(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=Vn(t,this.array)),t}setZ(e,t){return this.normalized&&(t=vt(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=Vn(t,this.array)),t}setW(e,t){return this.normalized&&(t=vt(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,i){return e*=this.itemSize,this.normalized&&(t=vt(t,this.array),i=vt(i,this.array)),this.array[e+0]=t,this.array[e+1]=i,this}setXYZ(e,t,i,r){return e*=this.itemSize,this.normalized&&(t=vt(t,this.array),i=vt(i,this.array),r=vt(r,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=r,this}setXYZW(e,t,i,r,s){return e*=this.itemSize,this.normalized&&(t=vt(t,this.array),i=vt(i,this.array),r=vt(r,this.array),s=vt(s,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=r,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return e.name=this.name,e.usage=this.usage,e.gpuType=this.gpuType,e}dispose(){this.dispatchEvent({type:"dispose"})}}class df extends hi{constructor(e,t,i){super(new Uint16Array(e),t,i)}}class uf extends hi{constructor(e,t,i){super(new Uint32Array(e),t,i)}}class bt extends hi{constructor(e,t,i){super(new Float32Array(e),t,i)}}const xg=new _r,Ms=new P,Cl=new P;class pa{constructor(e=new P,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const i=this.center;t!==void 0?i.copy(t):xg.setFromPoints(e).getCenter(i);let r=0;for(let s=0,a=e.length;s<a;s++)r=Math.max(r,i.distanceToSquared(e[s]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const i=this.center.distanceToSquared(e);return t.copy(e),i>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Ms.subVectors(e,this.center);const t=Ms.lengthSq();if(t>this.radius*this.radius){const i=Math.sqrt(t),r=(i-this.radius)*.5;this.center.addScaledVector(Ms,r/i),this.radius+=r}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Cl.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Ms.copy(e.center).add(Cl)),this.expandByPoint(Ms.copy(e.center).sub(Cl))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}let bg=0;const In=new yt,Il=new Gt,Br=new P,Mn=new _r,ws=new _r,Yt=new P;class Ot extends Er{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:bg++}),this.uuid=ui(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new($m(e)?uf:df)(e,1):this.index=e,this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,i=0){this.groups.push({start:e,count:t,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const i=this.attributes.normal;if(i!==void 0){const s=new qe().getNormalMatrix(e);i.applyNormalMatrix(s),i.needsUpdate=!0}const r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return In.makeRotationFromQuaternion(e),this.applyMatrix4(In),this}rotateX(e){return In.makeRotationX(e),this.applyMatrix4(In),this}rotateY(e){return In.makeRotationY(e),this.applyMatrix4(In),this}rotateZ(e){return In.makeRotationZ(e),this.applyMatrix4(In),this}translate(e,t,i){return In.makeTranslation(e,t,i),this.applyMatrix4(In),this}scale(e,t,i){return In.makeScale(e,t,i),this.applyMatrix4(In),this}lookAt(e){return Il.lookAt(e),Il.updateMatrix(),this.applyMatrix4(Il.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Br).negate(),this.translate(Br.x,Br.y,Br.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const i=[];for(let r=0,s=e.length;r<s;r++){const a=e[r];i.push(a.x,a.y,a.z||0)}this.setAttribute("position",new bt(i,3))}else{const i=Math.min(e.length,t.count);for(let r=0;r<i;r++){const s=e[r];t.setXYZ(r,s.x,s.y,s.z||0)}e.length>t.count&&ke("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new _r);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){st("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new P(-1/0,-1/0,-1/0),new P(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let i=0,r=t.length;i<r;i++){const s=t[i];Mn.setFromBufferAttribute(s),this.morphTargetsRelative?(Yt.addVectors(this.boundingBox.min,Mn.min),this.boundingBox.expandByPoint(Yt),Yt.addVectors(this.boundingBox.max,Mn.max),this.boundingBox.expandByPoint(Yt)):(this.boundingBox.expandByPoint(Mn.min),this.boundingBox.expandByPoint(Mn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&st('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new pa);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){st("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new P,1/0);return}if(e){const i=this.boundingSphere.center;if(Mn.setFromBufferAttribute(e),t)for(let s=0,a=t.length;s<a;s++){const o=t[s];ws.setFromBufferAttribute(o),this.morphTargetsRelative?(Yt.addVectors(Mn.min,ws.min),Mn.expandByPoint(Yt),Yt.addVectors(Mn.max,ws.max),Mn.expandByPoint(Yt)):(Mn.expandByPoint(ws.min),Mn.expandByPoint(ws.max))}Mn.getCenter(i);let r=0;for(let s=0,a=e.count;s<a;s++)Yt.fromBufferAttribute(e,s),r=Math.max(r,i.distanceToSquared(Yt));if(t)for(let s=0,a=t.length;s<a;s++){const o=t[s],l=this.morphTargetsRelative;for(let c=0,d=o.count;c<d;c++)Yt.fromBufferAttribute(o,c),l&&(Br.fromBufferAttribute(e,c),Yt.add(Br)),r=Math.max(r,i.distanceToSquared(Yt))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&st('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){st("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const i=t.position,r=t.normal,s=t.uv;let a=this.getAttribute("tangent");(a===void 0||a.count!==i.count)&&(a=new hi(new Float32Array(4*i.count),4),this.setAttribute("tangent",a));const o=[],l=[];for(let y=0;y<i.count;y++)o[y]=new P,l[y]=new P;const c=new P,d=new P,u=new P,h=new le,f=new le,p=new le,v=new P,m=new P;function g(y,A,C){c.fromBufferAttribute(i,y),d.fromBufferAttribute(i,A),u.fromBufferAttribute(i,C),h.fromBufferAttribute(s,y),f.fromBufferAttribute(s,A),p.fromBufferAttribute(s,C),d.sub(c),u.sub(c),f.sub(h),p.sub(h);const L=1/(f.x*p.y-p.x*f.y);isFinite(L)&&(v.copy(d).multiplyScalar(p.y).addScaledVector(u,-f.y).multiplyScalar(L),m.copy(u).multiplyScalar(f.x).addScaledVector(d,-p.x).multiplyScalar(L),o[y].add(v),o[A].add(v),o[C].add(v),l[y].add(m),l[A].add(m),l[C].add(m))}let x=this.groups;x.length===0&&(x=[{start:0,count:e.count}]);for(let y=0,A=x.length;y<A;++y){const C=x[y],L=C.start,I=C.count;for(let B=L,N=L+I;B<N;B+=3)g(e.getX(B+0),e.getX(B+1),e.getX(B+2))}const E=new P,b=new P,w=new P,S=new P;function T(y){w.fromBufferAttribute(r,y),S.copy(w);const A=o[y];E.copy(A),E.sub(w.multiplyScalar(w.dot(A))).normalize(),b.crossVectors(S,A);const L=b.dot(l[y])<0?-1:1;a.setXYZW(y,E.x,E.y,E.z,L)}for(let y=0,A=x.length;y<A;++y){const C=x[y],L=C.start,I=C.count;for(let B=L,N=L+I;B<N;B+=3)T(e.getX(B+0)),T(e.getX(B+1)),T(e.getX(B+2))}this._transformed=!0}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let i=this.getAttribute("normal");if(i===void 0||i.count!==t.count)i=new hi(new Float32Array(t.count*3),3),this.setAttribute("normal",i);else for(let h=0,f=i.count;h<f;h++)i.setXYZ(h,0,0,0);const r=new P,s=new P,a=new P,o=new P,l=new P,c=new P,d=new P,u=new P;if(e)for(let h=0,f=e.count;h<f;h+=3){const p=e.getX(h+0),v=e.getX(h+1),m=e.getX(h+2);r.fromBufferAttribute(t,p),s.fromBufferAttribute(t,v),a.fromBufferAttribute(t,m),d.subVectors(a,s),u.subVectors(r,s),d.cross(u),o.fromBufferAttribute(i,p),l.fromBufferAttribute(i,v),c.fromBufferAttribute(i,m),o.add(d),l.add(d),c.add(d),i.setXYZ(p,o.x,o.y,o.z),i.setXYZ(v,l.x,l.y,l.z),i.setXYZ(m,c.x,c.y,c.z)}else for(let h=0,f=t.count;h<f;h+=3)r.fromBufferAttribute(t,h+0),s.fromBufferAttribute(t,h+1),a.fromBufferAttribute(t,h+2),d.subVectors(a,s),u.subVectors(r,s),d.cross(u),i.setXYZ(h+0,d.x,d.y,d.z),i.setXYZ(h+1,d.x,d.y,d.z),i.setXYZ(h+2,d.x,d.y,d.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,i=e.count;t<i;t++)Yt.fromBufferAttribute(e,t),Yt.normalize(),e.setXYZ(t,Yt.x,Yt.y,Yt.z)}toNonIndexed(){function e(o,l){const c=o.array,d=o.itemSize,u=o.normalized,h=new c.constructor(l.length*d);let f=0,p=0;for(let v=0,m=l.length;v<m;v++){o.isInterleavedBufferAttribute?f=l[v]*o.data.stride+o.offset:f=l[v]*d;for(let g=0;g<d;g++)h[p++]=c[f++]}return new hi(h,d,u)}if(this.index===null)return ke("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new Ot,i=this.index.array,r=this.attributes;for(const o in r){const l=r[o],c=e(l,i);t.setAttribute(o,c)}const s=this.morphAttributes;for(const o in s){const l=[],c=s[o];for(let d=0,u=c.length;d<u;d++){const h=c[d],f=e(h,i);l.push(f)}t.morphAttributes[o]=l}t.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let o=0,l=a.length;o<l;o++){const c=a[o];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,e.name=this.name,Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){const l=this.parameters;for(const c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const i=this.attributes;for(const l in i){const c=i[l];e.data.attributes[l]=c.toJSON(e.data)}const r={};let s=!1;for(const l in this.morphAttributes){const c=this.morphAttributes[l],d=[];for(let u=0,h=c.length;u<h;u++){const f=c[u];d.push(f.toJSON(e.data))}d.length>0&&(r[l]=d,s=!0)}s&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));const o=this.boundingSphere;return o!==null&&(e.data.boundingSphere=o.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const i=e.index;i!==null&&this.setIndex(i.clone());const r=e.attributes;for(const c in r){const d=r[c];this.setAttribute(c,d.clone(t))}const s=e.morphAttributes;for(const c in s){const d=[],u=s[c];for(let h=0,f=u.length;h<f;h++)d.push(u[h].clone(t));this.morphAttributes[c]=d}this.morphTargetsRelative=e.morphTargetsRelative;const a=e.groups;for(let c=0,d=a.length;c<d;c++){const u=a[c];this.addGroup(u.start,u.count,u.materialIndex)}const o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());const l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Sg{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=sf,this.updateRanges=[],this.version=0,this.uuid=ui()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,i){e*=this.stride,i*=t.stride;for(let r=0,s=this.stride;r<s;r++)this.array[e+r]=t.array[i+r];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ui()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),i=new this.constructor(t,this.stride);return i.setUsage(this.usage),i}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ui()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer)));const t={uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride};return t.usage=this.usage,t}}const cn=new P;class Io{constructor(e,t,i,r=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=i,this.normalized=r}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,i=this.data.count;t<i;t++)cn.fromBufferAttribute(this,t),cn.applyMatrix4(e),this.setXYZ(t,cn.x,cn.y,cn.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)cn.fromBufferAttribute(this,t),cn.applyNormalMatrix(e),this.setXYZ(t,cn.x,cn.y,cn.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)cn.fromBufferAttribute(this,t),cn.transformDirection(e),this.setXYZ(t,cn.x,cn.y,cn.z);return this}getComponent(e,t){let i=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(i=Vn(i,this.array)),i}setComponent(e,t,i){return this.normalized&&(i=vt(i,this.array)),this.data.array[e*this.data.stride+this.offset+t]=i,this}setX(e,t){return this.normalized&&(t=vt(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=vt(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=vt(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=vt(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=Vn(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=Vn(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=Vn(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=Vn(t,this.array)),t}setXY(e,t,i){return e=e*this.data.stride+this.offset,this.normalized&&(t=vt(t,this.array),i=vt(i,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this}setXYZ(e,t,i,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=vt(t,this.array),i=vt(i,this.array),r=vt(r,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=r,this}setXYZW(e,t,i,r,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=vt(t,this.array),i=vt(i,this.array),r=vt(r,this.array),s=vt(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=r,this.data.array[e+3]=s,this}clone(e){if(e===void 0){Co("InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let i=0;i<this.count;i++){const r=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[r+s])}return new hi(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new Io(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){Co("InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let i=0;i<this.count;i++){const r=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[r+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}const Pl=new P,Mg=new P,wg=new qe;class Yi{constructor(e=new P(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,i,r){return this.normal.set(e,t,i),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,i){const r=Pl.subVectors(i,t).cross(Mg.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t,i=!0){const r=e.delta(Pl),s=this.normal.dot(r);if(s===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const a=-(e.start.dot(this.normal)+this.constant)/s;return i===!0&&(a<0||a>1)?null:t.copy(e.start).addScaledVector(r,a)}intersectsLine(e){const t=this.distanceToPoint(e.start),i=this.distanceToPoint(e.end);return t<0&&i>0||i<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const i=t||wg.getNormalMatrix(e),r=this.coplanarPoint(Pl).applyMatrix4(e),s=this.normal.applyMatrix3(i).normalize();return this.constant=-r.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(e){return this.normal.fromArray(e.normal),this.constant=e.constant,this}}let Eg=0;class er extends Er{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Eg++}),this.uuid=ui(),this.name="",this.type="Material",this.blending=$s,this.side=gr,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=zh,this.blendDst=Hh,this.blendEquation=Yr,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Qe(0,0,0),this.blendAlpha=0,this.depthFunc=js,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Nm,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=hl,this.stencilZFail=hl,this.stencilZPass=hl,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const i=e[t];if(i===void 0){ke(`Material: parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){ke(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(i):r&&r.isVector2&&i&&i.isVector2||r&&r.isEuler&&i&&i.isEuler||r&&r.isVector3&&i&&i.isVector3?r.copy(i):this[t]=i}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const i={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};i.uuid=this.uuid,i.type=this.type,i.blending=this.blending,i.side=this.side,i.shadowSide=this.shadowSide,i.vertexColors=this.vertexColors,i.opacity=this.opacity,i.transparent=this.transparent,i.blendSrc=this.blendSrc,i.blendDst=this.blendDst,i.blendEquation=this.blendEquation,i.blendSrcAlpha=this.blendSrcAlpha,i.blendDstAlpha=this.blendDstAlpha,i.blendEquationAlpha=this.blendEquationAlpha,i.blendColor=this.blendColor.getHex(),i.blendAlpha=this.blendAlpha,i.depthFunc=this.depthFunc,i.depthTest=this.depthTest,i.depthWrite=this.depthWrite,i.colorWrite=this.colorWrite,i.clipIntersection=this.clipIntersection,i.clipShadows=this.clipShadows,i.stencilWriteMask=this.stencilWriteMask,i.stencilFunc=this.stencilFunc,i.stencilRef=this.stencilRef,i.stencilFuncMask=this.stencilFuncMask,i.stencilFail=this.stencilFail,i.stencilZFail=this.stencilZFail,i.stencilZPass=this.stencilZPass,i.stencilWrite=this.stencilWrite,i.polygonOffset=this.polygonOffset,i.polygonOffsetFactor=this.polygonOffsetFactor,i.polygonOffsetUnits=this.polygonOffsetUnits,i.dithering=this.dithering,i.alphaTest=this.alphaTest,i.alphaHash=this.alphaHash,i.alphaToCoverage=this.alphaToCoverage,i.premultipliedAlpha=this.premultipliedAlpha,i.forceSinglePass=this.forceSinglePass,i.allowOverride=this.allowOverride,i.visible=this.visible,i.toneMapped=this.toneMapped,i.name=this.name,this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(i.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(i.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(i.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(i.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(e).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(e).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(e).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(e).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(e).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapRotation!==void 0&&(i.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(i.clippingPlanes=this.clippingPlanes.map(s=>s.toJSON())),this.rotation!==void 0&&(i.rotation=this.rotation),this.depthPacking!==void 0&&(i.depthPacking=this.depthPacking),this.linewidth!==void 0&&(i.linewidth=this.linewidth),this.linecap!==void 0&&(i.linecap=this.linecap),this.linejoin!==void 0&&(i.linejoin=this.linejoin),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.wireframe!==void 0&&(i.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(i.flatShading=this.flatShading),this.fog!==void 0&&(i.fog=this.fog),Object.keys(this.userData).length>0&&(i.userData=this.userData);function r(s){const a=[];for(const o in s){const l=s[o];delete l.metadata,a.push(l)}return a}if(t){const s=r(e.textures),a=r(e.images);s.length>0&&(i.textures=s),a.length>0&&(i.images=a)}return i}fromJSON(e,t){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new Qe().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.retroreflectivity!==void 0&&(this.retroreflectivity=e.retroreflectivity),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=e.iridescenceThicknessRange),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.clippingPlanes!==void 0&&(this.clippingPlanes=e.clippingPlanes.map(i=>new Yi().fromJSON(i))),e.clipIntersection!==void 0&&(this.clipIntersection=e.clipIntersection),e.clipShadows!==void 0&&(this.clipShadows=e.clipShadows),e.depthPacking!==void 0&&(this.depthPacking=e.depthPacking),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.linecap!==void 0&&(this.linecap=e.linecap),e.linejoin!==void 0&&(this.linejoin=e.linejoin),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(typeof e.vertexColors=="number"?this.vertexColors=e.vertexColors>0:this.vertexColors=e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=t[e.map]||null),e.matcap!==void 0&&(this.matcap=t[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=t[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=t[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=t[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let i=e.normalScale;Array.isArray(i)===!1&&(i=[i,i]),this.normalScale=new le().fromArray(i)}return e.displacementMap!==void 0&&(this.displacementMap=t[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=t[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=t[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=t[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=t[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=t[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=t[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=t[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=t[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=t[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=t[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=t[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=t[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=t[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new le().fromArray(e.clearcoatNormalScale)),e.iridescenceMap!==void 0&&(this.iridescenceMap=t[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=t[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=t[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=t[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=t[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=t[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=t[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let i=null;if(t!==null){const r=t.length;i=new Array(r);for(let s=0;s!==r;++s)i[s]=t[s].clone()}return this.clippingPlanes=i,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class uo extends er{constructor(e){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new Qe(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}let kr;const Es=new P,$r=new P,zr=new P,Hr=new le,Ts=new le,hf=new yt,Ia=new P,As=new P,Pa=new P,Ru=new le,Ll=new le,Cu=new le;class Nl extends Gt{constructor(e=new uo){if(super(),this.isSprite=!0,this.type="Sprite",kr===void 0){kr=new Ot;const t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),i=new Sg(t,5);kr.setIndex([0,1,2,0,2,3]),kr.setAttribute("position",new Io(i,3,0,!1)),kr.setAttribute("uv",new Io(i,2,3,!1))}this.geometry=kr,this.material=e,this.center=new le(.5,.5),this.count=1}intersectsFrustum(e){return e.intersectsSprite(this)}raycast(e,t){e.camera===null&&st('Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),$r.setFromMatrixScale(this.matrixWorld),hf.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),zr.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&$r.multiplyScalar(-zr.z);const i=this.material.rotation;let r,s;i!==0&&(s=Math.cos(i),r=Math.sin(i));const a=this.center;La(Ia.set(-.5,-.5,0),zr,a,$r,r,s),La(As.set(.5,-.5,0),zr,a,$r,r,s),La(Pa.set(.5,.5,0),zr,a,$r,r,s),Ru.set(0,0),Ll.set(1,0),Cu.set(1,1);let o=e.ray.intersectTriangle(Ia,As,Pa,!1,Es);if(o===null&&(La(As.set(-.5,.5,0),zr,a,$r,r,s),Ll.set(0,1),o=e.ray.intersectTriangle(Ia,Pa,As,!1,Es),o===null))return;const l=e.ray.origin.distanceTo(Es);l<e.near||l>e.far||t.push({distance:l,point:Es.clone(),uv:Ln.getInterpolation(Es,Ia,As,Pa,Ru,Ll,Cu,new le),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}}function La(n,e,t,i,r,s){Hr.subVectors(n,t).addScalar(.5).multiply(i),r!==void 0?(Ts.x=s*Hr.x-r*Hr.y,Ts.y=r*Hr.x+s*Hr.y):Ts.copy(Hr),n.copy(e),n.x+=Ts.x,n.y+=Ts.y,n.applyMatrix4(hf)}const Mi=new P,Dl=new P,Na=new P,Da=new P;class Vo{constructor(e=new P,t=new P(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Mi)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const i=t.dot(this.direction);return i<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=Mi.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(Mi.copy(this.origin).addScaledVector(this.direction,t),Mi.distanceToSquared(e))}distanceSqToSegment(e,t,i,r){Dl.copy(e).add(t).multiplyScalar(.5),Na.copy(t).sub(e).normalize(),Da.copy(this.origin).sub(Dl);const s=e.distanceTo(t)*.5,a=-this.direction.dot(Na),o=Da.dot(this.direction),l=-Da.dot(Na),c=Da.lengthSq(),d=Math.abs(1-a*a);let u,h,f,p;if(d>0)if(u=a*l-o,h=a*o-l,p=s*d,u>=0)if(h>=-p)if(h<=p){const v=1/d;u*=v,h*=v,f=u*(u+a*h+2*o)+h*(a*u+h+2*l)+c}else h=s,u=Math.max(0,-(a*h+o)),f=-u*u+h*(h+2*l)+c;else h=-s,u=Math.max(0,-(a*h+o)),f=-u*u+h*(h+2*l)+c;else h<=-p?(u=Math.max(0,-(-a*s+o)),h=u>0?-s:Math.min(Math.max(-s,-l),s),f=-u*u+h*(h+2*l)+c):h<=p?(u=0,h=Math.min(Math.max(-s,-l),s),f=h*(h+2*l)+c):(u=Math.max(0,-(a*s+o)),h=u>0?s:Math.min(Math.max(-s,-l),s),f=-u*u+h*(h+2*l)+c);else h=a>0?-s:s,u=Math.max(0,-(a*h+o)),f=-u*u+h*(h+2*l)+c;return i&&i.copy(this.origin).addScaledVector(this.direction,u),r&&r.copy(Dl).addScaledVector(Na,h),f}intersectSphere(e,t){if(e.radius<0)return null;Mi.subVectors(e.center,this.origin);const i=Mi.dot(this.direction),r=Mi.dot(Mi)-i*i,s=e.radius*e.radius;if(r>s)return null;const a=Math.sqrt(s-r),o=i-a,l=i+a;return l<0?null:o<0?this.at(l,t):this.at(o,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const i=-(this.origin.dot(e.normal)+e.constant)/t;return i>=0?i:null}intersectPlane(e,t){const i=this.distanceToPlane(e);return i===null?null:this.at(i,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let i,r,s,a,o,l;const c=1/this.direction.x,d=1/this.direction.y,u=1/this.direction.z,h=this.origin;return c>=0?(i=(e.min.x-h.x)*c,r=(e.max.x-h.x)*c):(i=(e.max.x-h.x)*c,r=(e.min.x-h.x)*c),d>=0?(s=(e.min.y-h.y)*d,a=(e.max.y-h.y)*d):(s=(e.max.y-h.y)*d,a=(e.min.y-h.y)*d),i>a||s>r||((s>i||isNaN(i))&&(i=s),(a<r||isNaN(r))&&(r=a),u>=0?(o=(e.min.z-h.z)*u,l=(e.max.z-h.z)*u):(o=(e.max.z-h.z)*u,l=(e.min.z-h.z)*u),i>l||o>r)||((o>i||i!==i)&&(i=o),(l<r||r!==r)&&(r=l),r<0)?null:this.at(i>=0?i:r,t)}intersectsBox(e){return this.intersectBox(e,Mi)!==null}intersectTriangle(e,t,i,r,s){const a=this.origin,o=this.direction,l=o.x,c=o.y,d=o.z,u=e.x-a.x,h=e.y-a.y,f=e.z-a.z,p=t.x-a.x,v=t.y-a.y,m=t.z-a.z,g=i.x-a.x,x=i.y-a.y,E=i.z-a.z,b=Math.abs(l),w=Math.abs(c),S=Math.abs(d);let T,y,A,C,L,I,B,N,U,V,$,ie;if(b>=w&&b>=S?(A=l,I=u,U=p,ie=g,l>=0?(T=c,y=d,C=h,L=f,B=v,N=m,V=x,$=E):(T=d,y=c,C=f,L=h,B=m,N=v,V=E,$=x)):w>=S?(A=c,I=h,U=v,ie=x,c>=0?(T=d,y=l,C=f,L=u,B=m,N=p,V=E,$=g):(T=l,y=d,C=u,L=f,B=p,N=m,V=g,$=E)):(A=d,I=f,U=m,ie=E,d>=0?(T=l,y=c,C=u,L=h,B=p,N=v,V=g,$=x):(T=c,y=l,C=h,L=u,B=v,N=p,V=x,$=g)),A===0)return null;const X=T/A,Q=y/A,ne=1/A,Pe=C-X*I,Ee=L-Q*I,ut=B-X*U,tt=N-Q*U,lt=V-X*ie,Z=$-Q*ie,ee=lt*tt-Z*ut,ye=Pe*Z-Ee*lt,ze=ut*Ee-tt*Pe;if(r){if(ee<0||ye<0||ze<0)return null}else if((ee<0||ye<0||ze<0)&&(ee>0||ye>0||ze>0))return null;const Se=ee+ye+ze;if(Se===0)return null;const He=ne*(ee*I+ye*U+ze*ie);return(Se>0?He<0:He>0)?null:this.at(He/Se,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Po extends er{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Qe(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Ji,this.combine=Gh,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Iu=new yt,ar=new Vo,Ua=new pa,Pu=new P,Oa=new P,Fa=new P,Ba=new P,Ul=new P,ka=new P,Lu=new P,$a=new P;class Un extends Gt{constructor(e=new Ot,t=new Po){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,i=Object.keys(t);if(i.length>0){const r=t[i[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=r.length;s<a;s++){const o=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}getVertexPosition(e,t){const i=this.geometry,r=i.attributes.position,s=i.morphAttributes.position,a=i.morphTargetsRelative;t.fromBufferAttribute(r,e);const o=this.morphTargetInfluences;if(s&&o){ka.set(0,0,0);for(let l=0,c=s.length;l<c;l++){const d=o[l],u=s[l];d!==0&&(Ul.fromBufferAttribute(u,e),a?ka.addScaledVector(Ul,d):ka.addScaledVector(Ul.sub(t),d))}t.add(ka)}return t}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){const i=this.geometry,r=this.material,s=this.matrixWorld;r!==void 0&&(i.boundingSphere===null&&i.computeBoundingSphere(),Ua.copy(i.boundingSphere),Ua.applyMatrix4(s),ar.copy(e.ray).recast(e.near),!(Ua.containsPoint(ar.origin)===!1&&(ar.intersectSphere(Ua,Pu)===null||ar.origin.distanceToSquared(Pu)>(e.far-e.near)**2))&&(Iu.copy(s).invert(),ar.copy(e.ray).applyMatrix4(Iu),!(i.boundingBox!==null&&ar.intersectsBox(i.boundingBox)===!1)&&this._computeIntersections(e,t,ar)))}_computeIntersections(e,t,i){let r;const s=this.geometry,a=this.material,o=s.index,l=s.attributes.position,c=s.attributes.uv,d=s.attributes.uv1,u=s.attributes.normal,h=s.groups,f=s.drawRange;if(o!==null)if(Array.isArray(a))for(let p=0,v=h.length;p<v;p++){const m=h[p],g=a[m.materialIndex],x=Math.max(m.start,f.start),E=Math.min(o.count,Math.min(m.start+m.count,f.start+f.count));for(let b=x,w=E;b<w;b+=3){const S=o.getX(b),T=o.getX(b+1),y=o.getX(b+2);r=za(this,g,e,i,c,d,u,S,T,y),r&&(r.faceIndex=Math.floor(b/3),r.face.materialIndex=m.materialIndex,t.push(r))}}else{const p=Math.max(0,f.start),v=Math.min(o.count,f.start+f.count);for(let m=p,g=v;m<g;m+=3){const x=o.getX(m),E=o.getX(m+1),b=o.getX(m+2);r=za(this,a,e,i,c,d,u,x,E,b),r&&(r.faceIndex=Math.floor(m/3),t.push(r))}}else if(l!==void 0)if(Array.isArray(a))for(let p=0,v=h.length;p<v;p++){const m=h[p],g=a[m.materialIndex],x=Math.max(m.start,f.start),E=Math.min(l.count,Math.min(m.start+m.count,f.start+f.count));for(let b=x,w=E;b<w;b+=3){const S=b,T=b+1,y=b+2;r=za(this,g,e,i,c,d,u,S,T,y),r&&(r.faceIndex=Math.floor(b/3),r.face.materialIndex=m.materialIndex,t.push(r))}}else{const p=Math.max(0,f.start),v=Math.min(l.count,f.start+f.count);for(let m=p,g=v;m<g;m+=3){const x=m,E=m+1,b=m+2;r=za(this,a,e,i,c,d,u,x,E,b),r&&(r.faceIndex=Math.floor(m/3),t.push(r))}}}}function Tg(n,e,t,i,r,s,a,o){let l;if(e.side===vn?l=i.intersectTriangle(a,s,r,!0,o):l=i.intersectTriangle(r,s,a,e.side===gr,o),l===null)return null;$a.copy(o),$a.applyMatrix4(n.matrixWorld);const c=t.ray.origin.distanceTo($a);return c<t.near||c>t.far?null:{distance:c,point:$a.clone(),object:n}}function za(n,e,t,i,r,s,a,o,l,c){n.getVertexPosition(o,Oa),n.getVertexPosition(l,Fa),n.getVertexPosition(c,Ba);const d=Tg(n,e,t,i,Oa,Fa,Ba,Lu);if(d){const u=new P;Ln.getBarycoord(Lu,Oa,Fa,Ba,u),r&&(d.uv=Ln.getInterpolatedAttribute(r,o,l,c,u,new le)),s&&(d.uv1=Ln.getInterpolatedAttribute(s,o,l,c,u,new le)),a&&(d.normal=Ln.getInterpolatedAttribute(a,o,l,c,u,new P),d.normal.dot(i.direction)>0&&d.normal.multiplyScalar(-1));const h={a:o,b:l,c,normal:new P,materialIndex:0};Ln.getNormal(Oa,Fa,Ba,h.normal),d.face=h,d.barycoord=u}return d}class Ag extends an{constructor(e=null,t=1,i=1,r,s,a,o,l,c=Jt,d=Jt,u,h){super(null,a,o,l,c,d,r,s,u,h),this.isDataTexture=!0,this.image={data:e,width:t,height:i},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const or=new pa,Rg=new le(.5,.5),Ha=new P;class Ad{constructor(e=new Yi,t=new Yi,i=new Yi,r=new Yi,s=new Yi,a=new Yi){this.planes=[e,t,i,r,s,a]}set(e,t,i,r,s,a){const o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(i),o[3].copy(r),o[4].copy(s),o[5].copy(a),this}copy(e){const t=this.planes;for(let i=0;i<6;i++)t[i].copy(e.planes[i]);return this}setFromProjectionMatrix(e,t=li,i=!1){const r=this.planes,s=e.elements,a=s[0],o=s[1],l=s[2],c=s[3],d=s[4],u=s[5],h=s[6],f=s[7],p=s[8],v=s[9],m=s[10],g=s[11],x=s[12],E=s[13],b=s[14],w=s[15];if(r[0].setComponents(c-a,f-d,g-p,w-x).normalize(),r[1].setComponents(c+a,f+d,g+p,w+x).normalize(),r[2].setComponents(c+o,f+u,g+v,w+E).normalize(),r[3].setComponents(c-o,f-u,g-v,w-E).normalize(),i)r[4].setComponents(l,h,m,b).normalize(),r[5].setComponents(c-l,f-h,g-m,w-b).normalize();else if(r[4].setComponents(c-l,f-h,g-m,w-b).normalize(),t===li)r[5].setComponents(c+l,f+h,g+m,w+b).normalize();else if(t===ta)r[5].setComponents(l,h,m,b).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),or.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),or.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(or)}intersectsSprite(e){or.center.set(0,0,0);const t=Rg.distanceTo(e.center);return or.radius=.7071067811865476+t,or.applyMatrix4(e.matrixWorld),this.intersectsSphere(or)}intersectsSphere(e){const t=this.planes,i=e.center,r=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(i)<r)return!1;return!0}intersectsBox(e){const t=this.planes;for(let i=0;i<6;i++){const r=t[i];if(Ha.x=r.normal.x>0?e.max.x:e.min.x,Ha.y=r.normal.y>0?e.max.y:e.min.y,Ha.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(Ha)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let i=0;i<6;i++)if(t[i].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class Lo extends er{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new Qe(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const No=new P,Do=new P,Nu=new yt,Rs=new Vo,Ga=new pa,Ol=new P,Du=new P;class Rd extends Gt{constructor(e=new Ot,t=new Lo){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,i=[0];for(let r=1,s=t.count;r<s;r++)No.fromBufferAttribute(t,r-1),Do.fromBufferAttribute(t,r),i[r]=i[r-1],i[r]+=No.distanceTo(Do);e.setAttribute("lineDistance",new bt(i,1))}else ke("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){const i=this.geometry,r=this.matrixWorld,s=e.params.Line.threshold,a=i.drawRange;if(i.boundingSphere===null&&i.computeBoundingSphere(),Ga.copy(i.boundingSphere),Ga.applyMatrix4(r),Ga.radius+=s,e.ray.intersectsSphere(Ga)===!1)return;Nu.copy(r).invert(),Rs.copy(e.ray).applyMatrix4(Nu);const o=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=this.isLineSegments?2:1,d=i.index,h=i.attributes.position;if(d!==null){const f=Math.max(0,a.start),p=Math.min(d.count,a.start+a.count);for(let v=f,m=p-1;v<m;v+=c){const g=d.getX(v),x=d.getX(v+1),E=Va(this,e,Rs,l,g,x,v);E&&t.push(E)}if(this.isLineLoop){const v=d.getX(p-1),m=d.getX(f),g=Va(this,e,Rs,l,v,m,p-1);g&&t.push(g)}}else{const f=Math.max(0,a.start),p=Math.min(h.count,a.start+a.count);for(let v=f,m=p-1;v<m;v+=c){const g=Va(this,e,Rs,l,v,v+1,v);g&&t.push(g)}if(this.isLineLoop){const v=Va(this,e,Rs,l,p-1,f,p-1);v&&t.push(v)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,i=Object.keys(t);if(i.length>0){const r=t[i[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=r.length;s<a;s++){const o=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}}function Va(n,e,t,i,r,s,a){const o=n.geometry.attributes.position;if(No.fromBufferAttribute(o,r),Do.fromBufferAttribute(o,s),t.distanceSqToSegment(No,Do,Ol,Du)>i)return;Ol.applyMatrix4(n.matrixWorld);const c=e.ray.origin.distanceTo(Ol);if(!(c<e.near||c>e.far))return{distance:c,point:Du.clone().applyMatrix4(n.matrixWorld),index:a,face:null,faceIndex:null,barycoord:null,object:n}}const Uu=new P,Ou=new P;class Cg extends Rd{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,i=[];for(let r=0,s=t.count;r<s;r+=2)Uu.fromBufferAttribute(t,r),Ou.fromBufferAttribute(t,r+1),i[r]=r===0?0:i[r-1],i[r+1]=i[r]+Uu.distanceTo(Ou);e.setAttribute("lineDistance",new bt(i,1))}else ke("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class ff extends er{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Qe(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const Fu=new yt,$c=new Vo,Wa=new pa,Xa=new P;class Ig extends Gt{constructor(e=new Ot,t=new ff){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){const i=this.geometry,r=this.matrixWorld,s=e.params.Points.threshold,a=i.drawRange;if(i.boundingSphere===null&&i.computeBoundingSphere(),Wa.copy(i.boundingSphere),Wa.applyMatrix4(r),Wa.radius+=s,e.ray.intersectsSphere(Wa)===!1)return;Fu.copy(r).invert(),$c.copy(e.ray).applyMatrix4(Fu);const o=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=i.index,u=i.attributes.position;if(c!==null){const h=Math.max(0,a.start),f=Math.min(c.count,a.start+a.count);for(let p=h,v=f;p<v;p++){const m=c.getX(p);Xa.fromBufferAttribute(u,m),Bu(Xa,m,l,r,e,t,this)}}else{const h=Math.max(0,a.start),f=Math.min(u.count,a.start+a.count);for(let p=h,v=f;p<v;p++)Xa.fromBufferAttribute(u,p),Bu(Xa,p,l,r,e,t,this)}}updateMorphTargets(){const t=this.geometry.morphAttributes,i=Object.keys(t);if(i.length>0){const r=t[i[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=r.length;s<a;s++){const o=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}}function Bu(n,e,t,i,r,s,a){const o=$c.distanceSqToPoint(n);if(o<t){const l=new P;$c.closestPointToPoint(n,l),l.applyMatrix4(i);const c=r.ray.origin.distanceTo(l);if(c<r.near||c>r.far)return;s.push({distance:c,distanceToRay:Math.sqrt(o),point:l,index:e,face:null,faceIndex:null,barycoord:null,object:a})}}class pf extends an{constructor(e=[],t=vr,i,r,s,a,o,l,c,d){super(e,t,i,r,s,a,o,l,c,d),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class Pg extends an{constructor(e,t,i,r,s,a,o,l,c){super(e,t,i,r,s,a,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}}class ia extends an{constructor(e,t,i=pi,r,s,a,o=Jt,l=Jt,c,d=Li,u=1){if(d!==Li&&d!==hr)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const h={width:e,height:t,depth:u};super(h,r,s,a,o,l,d,i,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Ed(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return t.compareFunction=this.compareFunction,t}}class Lg extends ia{constructor(e,t=pi,i=vr,r,s,a=Jt,o=Jt,l,c=Li){const d={width:e,height:e,depth:1},u=[d,d,d,d,d,d];super(e,e,t,i,r,s,a,o,l,c),this.image=u,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}}class mf extends an{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class gs extends Ot{constructor(e=1,t=1,i=1,r=1,s=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:i,widthSegments:r,heightSegments:s,depthSegments:a};const o=this;r=Math.floor(r),s=Math.floor(s),a=Math.floor(a);const l=[],c=[],d=[],u=[];let h=0,f=0;p("z","y","x",-1,-1,i,t,e,a,s,0),p("z","y","x",1,-1,i,t,-e,a,s,1),p("x","z","y",1,1,e,i,t,r,a,2),p("x","z","y",1,-1,e,i,-t,r,a,3),p("x","y","z",1,-1,e,t,i,r,s,4),p("x","y","z",-1,-1,e,t,-i,r,s,5),this.setIndex(l),this.setAttribute("position",new bt(c,3)),this.setAttribute("normal",new bt(d,3)),this.setAttribute("uv",new bt(u,2));function p(v,m,g,x,E,b,w,S,T,y,A){const C=b/T,L=w/y,I=b/2,B=w/2,N=S/2,U=T+1,V=y+1;let $=0,ie=0;const X=new P;for(let Q=0;Q<V;Q++){const ne=Q*L-B;for(let Pe=0;Pe<U;Pe++){const Ee=Pe*C-I;X[v]=Ee*x,X[m]=ne*E,X[g]=N,c.push(X.x,X.y,X.z),X[v]=0,X[m]=0,X[g]=S>0?1:-1,d.push(X.x,X.y,X.z),u.push(Pe/T),u.push(1-Q/y),$+=1}}for(let Q=0;Q<y;Q++)for(let ne=0;ne<T;ne++){const Pe=h+ne+U*Q,Ee=h+ne+U*(Q+1),ut=h+(ne+1)+U*(Q+1),tt=h+(ne+1)+U*Q;l.push(Pe,Ee,tt),l.push(Ee,ut,tt),ie+=6}o.addGroup(f,ie,A),f+=ie,h+=$}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new gs(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}class Cd extends Ot{constructor(e=1,t=32,i=0,r=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:i,thetaLength:r},t=Math.max(3,t);const s=[],a=[],o=[],l=[],c=new P,d=new le;a.push(0,0,0),o.push(0,0,1),l.push(.5,.5);for(let u=0,h=3;u<=t;u++,h+=3){const f=i+u/t*r;c.x=e*Math.cos(f),c.y=e*Math.sin(f),a.push(c.x,c.y,c.z),o.push(0,0,1),d.x=(a[h]/e+1)/2,d.y=(a[h+1]/e+1)/2,l.push(d.x,d.y)}for(let u=1;u<=t;u++)s.push(u,u+1,0);this.setIndex(s),this.setAttribute("position",new bt(a,3)),this.setAttribute("normal",new bt(o,3)),this.setAttribute("uv",new bt(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Cd(e.radius,e.segments,e.thetaStart,e.thetaLength)}}class Id extends Ot{constructor(e=1,t=1,i=1,r=32,s=1,a=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:i,radialSegments:r,heightSegments:s,openEnded:a,thetaStart:o,thetaLength:l};const c=this;r=Math.floor(r),s=Math.floor(s);const d=[],u=[],h=[],f=[];let p=0;const v=[],m=i/2;let g=0;x(),a===!1&&(e>0&&E(!0),t>0&&E(!1)),this.setIndex(d),this.setAttribute("position",new bt(u,3)),this.setAttribute("normal",new bt(h,3)),this.setAttribute("uv",new bt(f,2));function x(){const b=new P,w=new P;let S=0;const T=(t-e)/i;for(let y=0;y<=s;y++){const A=[],C=y/s,L=C*(t-e)+e;for(let I=0;I<=r;I++){const B=I/r,N=B*l+o,U=Math.sin(N),V=Math.cos(N);w.x=L*U,w.y=-C*i+m,w.z=L*V,u.push(w.x,w.y,w.z),b.set(U,T,V).normalize(),h.push(b.x,b.y,b.z),f.push(B,1-C),A.push(p++)}v.push(A)}for(let y=0;y<r;y++)for(let A=0;A<s;A++){const C=v[A][y],L=v[A+1][y],I=v[A+1][y+1],B=v[A][y+1];(e>0||A!==0)&&(d.push(C,L,B),S+=3),(t>0||A!==s-1)&&(d.push(L,I,B),S+=3)}c.addGroup(g,S,0),g+=S}function E(b){const w=p,S=new le,T=new P;let y=0;const A=b===!0?e:t,C=b===!0?1:-1;for(let I=1;I<=r;I++)u.push(0,m*C,0),h.push(0,C,0),f.push(.5,.5),p++;const L=p;for(let I=0;I<=r;I++){const N=I/r*l+o,U=Math.cos(N),V=Math.sin(N);T.x=A*V,T.y=m*C,T.z=A*U,u.push(T.x,T.y,T.z),h.push(0,C,0),S.x=U*.5+.5,S.y=V*.5*C+.5,f.push(S.x,S.y),p++}for(let I=0;I<r;I++){const B=w+I,N=L+I;b===!0?d.push(N,N+1,B):d.push(N+1,N,B),y+=3}c.addGroup(g,y,b===!0?1:2),g+=y}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Id(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class yi{constructor(){this.type="Curve",this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){ke("Curve: .getPoint() not implemented.")}getPointAt(e,t){const i=this.getUtoTmapping(e);return this.getPoint(i,t)}getPoints(e=5){const t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return t}getSpacedPoints(e=5){const t=[];for(let i=0;i<=e;i++)t.push(this.getPointAt(i/e));return t}getLength(){const e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const t=[];let i,r=this.getPoint(0),s=0;t.push(0);for(let a=1;a<=e;a++)i=this.getPoint(a/e),s+=i.distanceTo(r),t.push(s),r=i;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t=null){const i=this.getLengths();let r=0;const s=i.length;let a;t?a=t:a=e*i[s-1];let o=0,l=s-1,c;for(;o<=l;)if(r=Math.floor(o+(l-o)/2),c=i[r]-a,c<0)o=r+1;else if(c>0)l=r-1;else{l=r;break}if(r=l,i[r]===a)return r/(s-1);const d=i[r],h=i[r+1]-d,f=(a-d)/h;return(r+f)/(s-1)}getTangent(e,t){let r=e-1e-4,s=e+1e-4;r<0&&(r=0),s>1&&(s=1);const a=this.getPoint(r),o=this.getPoint(s),l=t||(a.isVector2?new le:new P);return l.copy(o).sub(a).normalize(),l}getTangentAt(e,t){const i=this.getUtoTmapping(e);return this.getTangent(i,t)}computeFrenetFrames(e,t=!1){const i=new P,r=[],s=[],a=[],o=new P,l=new yt;for(let f=0;f<=e;f++){const p=f/e;r[f]=this.getTangentAt(p,new P)}s[0]=new P,a[0]=new P;let c=Number.MAX_VALUE;const d=Math.abs(r[0].x),u=Math.abs(r[0].y),h=Math.abs(r[0].z);d<=c&&(c=d,i.set(1,0,0)),u<=c&&(c=u,i.set(0,1,0)),h<=c&&i.set(0,0,1),o.crossVectors(r[0],i).normalize(),s[0].crossVectors(r[0],o),a[0].crossVectors(r[0],s[0]);for(let f=1;f<=e;f++){if(s[f]=s[f-1].clone(),a[f]=a[f-1].clone(),o.crossVectors(r[f-1],r[f]),o.length()>Number.EPSILON){o.normalize();const p=Math.acos(et(r[f-1].dot(r[f]),-1,1));s[f].applyMatrix4(l.makeRotationAxis(o,p))}a[f].crossVectors(r[f],s[f])}if(t===!0){let f=Math.acos(et(s[0].dot(s[e]),-1,1));f/=e,r[0].dot(o.crossVectors(s[0],s[e]))>0&&(f=-f);for(let p=1;p<=e;p++)s[p].applyMatrix4(l.makeRotationAxis(r[p],f*p)),a[p].crossVectors(r[p],s[p])}return{tangents:r,normals:s,binormals:a}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){const e={metadata:{version:4.7,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}}class Pd extends yi{constructor(e=0,t=0,i=1,r=1,s=0,a=Math.PI*2,o=!1,l=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=e,this.aY=t,this.xRadius=i,this.yRadius=r,this.aStartAngle=s,this.aEndAngle=a,this.aClockwise=o,this.aRotation=l}getPoint(e,t=new le){const i=t,r=Math.PI*2;let s=this.aEndAngle-this.aStartAngle;const a=Math.abs(s)<Number.EPSILON;for(;s<0;)s+=r;for(;s>r;)s-=r;s<Number.EPSILON&&(a?s=0:s=r),this.aClockwise===!0&&!a&&(s===r?s=-r:s=s-r);const o=this.aStartAngle+e*s;let l=this.aX+this.xRadius*Math.cos(o),c=this.aY+this.yRadius*Math.sin(o);if(this.aRotation!==0){const d=Math.cos(this.aRotation),u=Math.sin(this.aRotation),h=l-this.aX,f=c-this.aY;l=h*d-f*u+this.aX,c=h*u+f*d+this.aY}return i.set(l,c)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){const e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}}class Ng extends Pd{constructor(e,t,i,r,s,a){super(e,t,i,i,r,s,a),this.isArcCurve=!0,this.type="ArcCurve"}}function Ld(){let n=0,e=0,t=0,i=0;function r(s,a,o,l){n=s,e=o,t=-3*s+3*a-2*o-l,i=2*s-2*a+o+l}return{initCatmullRom:function(s,a,o,l,c){r(a,o,c*(o-s),c*(l-a))},initNonuniformCatmullRom:function(s,a,o,l,c,d,u){let h=(a-s)/c-(o-s)/(c+d)+(o-a)/d,f=(o-a)/d-(l-a)/(d+u)+(l-o)/u;h*=d,f*=d,r(a,o,h,f)},calc:function(s){const a=s*s,o=a*s;return n+e*s+t*a+i*o}}}const ku=new P,$u=new P,Fl=new Ld,Bl=new Ld,kl=new Ld;class Dg extends yi{constructor(e=[],t=!1,i="centripetal",r=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=t,this.curveType=i,this.tension=r}getPoint(e,t=new P){const i=t,r=this.points,s=r.length,a=(s-(this.closed?0:1))*e;let o=Math.floor(a),l=a-o;this.closed?o+=o>0?0:(Math.floor(Math.abs(o)/s)+1)*s:l===0&&o===s-1&&(o=s-2,l=1);let c,d;this.closed||o>0?c=r[(o-1)%s]:($u.subVectors(r[0],r[1]).add(r[0]),c=$u);const u=r[o%s],h=r[(o+1)%s];if(this.closed||o+2<s?d=r[(o+2)%s]:(ku.subVectors(r[s-1],r[s-2]).add(r[s-1]),d=ku),this.curveType==="centripetal"||this.curveType==="chordal"){const f=this.curveType==="chordal"?.5:.25;let p=Math.pow(c.distanceToSquared(u),f),v=Math.pow(u.distanceToSquared(h),f),m=Math.pow(h.distanceToSquared(d),f);v<1e-4&&(v=1),p<1e-4&&(p=v),m<1e-4&&(m=v),Fl.initNonuniformCatmullRom(c.x,u.x,h.x,d.x,p,v,m),Bl.initNonuniformCatmullRom(c.y,u.y,h.y,d.y,p,v,m),kl.initNonuniformCatmullRom(c.z,u.z,h.z,d.z,p,v,m)}else this.curveType==="catmullrom"&&(Fl.initCatmullRom(c.x,u.x,h.x,d.x,this.tension),Bl.initCatmullRom(c.y,u.y,h.y,d.y,this.tension),kl.initCatmullRom(c.z,u.z,h.z,d.z,this.tension));return i.set(Fl.calc(l),Bl.calc(l),kl.calc(l)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const r=e.points[t];this.points.push(r.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){const r=this.points[t];e.points.push(r.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const r=e.points[t];this.points.push(new P().fromArray(r))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}}function zu(n,e,t,i,r){const s=(i-e)*.5,a=(r-t)*.5,o=n*n,l=n*o;return(2*t-2*i+s+a)*l+(-3*t+3*i-2*s-a)*o+s*n+t}function Ug(n,e){const t=1-n;return t*t*e}function Og(n,e){return 2*(1-n)*n*e}function Fg(n,e){return n*n*e}function Gs(n,e,t,i){return Ug(n,e)+Og(n,t)+Fg(n,i)}function Bg(n,e){const t=1-n;return t*t*t*e}function kg(n,e){const t=1-n;return 3*t*t*n*e}function $g(n,e){return 3*(1-n)*n*n*e}function zg(n,e){return n*n*n*e}function Vs(n,e,t,i,r){return Bg(n,e)+kg(n,t)+$g(n,i)+zg(n,r)}class gf extends yi{constructor(e=new le,t=new le,i=new le,r=new le){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=e,this.v1=t,this.v2=i,this.v3=r}getPoint(e,t=new le){const i=t,r=this.v0,s=this.v1,a=this.v2,o=this.v3;return i.set(Vs(e,r.x,s.x,a.x,o.x),Vs(e,r.y,s.y,a.y,o.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class Hg extends yi{constructor(e=new P,t=new P,i=new P,r=new P){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=t,this.v2=i,this.v3=r}getPoint(e,t=new P){const i=t,r=this.v0,s=this.v1,a=this.v2,o=this.v3;return i.set(Vs(e,r.x,s.x,a.x,o.x),Vs(e,r.y,s.y,a.y,o.y),Vs(e,r.z,s.z,a.z,o.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class vf extends yi{constructor(e=new le,t=new le){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=e,this.v2=t}getPoint(e,t=new le){const i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new le){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Gg extends yi{constructor(e=new P,t=new P){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=e,this.v2=t}getPoint(e,t=new P){const i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new P){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class yf extends yi{constructor(e=new le,t=new le,i=new le){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new le){const i=t,r=this.v0,s=this.v1,a=this.v2;return i.set(Gs(e,r.x,s.x,a.x),Gs(e,r.y,s.y,a.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Vg extends yi{constructor(e=new P,t=new P,i=new P){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new P){const i=t,r=this.v0,s=this.v1,a=this.v2;return i.set(Gs(e,r.x,s.x,a.x),Gs(e,r.y,s.y,a.y),Gs(e,r.z,s.z,a.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class _f extends yi{constructor(e=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=e}getPoint(e,t=new le){const i=t,r=this.points,s=(r.length-1)*e,a=Math.floor(s),o=s-a,l=r[a===0?a:a-1],c=r[a],d=r[a>r.length-2?r.length-1:a+1],u=r[a>r.length-3?r.length-1:a+2];return i.set(zu(o,l.x,c.x,d.x,u.x),zu(o,l.y,c.y,d.y,u.y)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const r=e.points[t];this.points.push(r.clone())}return this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){const r=this.points[t];e.points.push(r.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const r=e.points[t];this.points.push(new le().fromArray(r))}return this}}var zc=Object.freeze({__proto__:null,ArcCurve:Ng,CatmullRomCurve3:Dg,CubicBezierCurve:gf,CubicBezierCurve3:Hg,EllipseCurve:Pd,LineCurve:vf,LineCurve3:Gg,QuadraticBezierCurve:yf,QuadraticBezierCurve3:Vg,SplineCurve:_f});class Wg extends yi{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(e){this.curves.push(e)}closePath(){const e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){const i=e.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new zc[i](t,e))}return this}getPoint(e,t){const i=e*this.getLength(),r=this.getCurveLengths();let s=0;for(;s<r.length;){if(r[s]>=i){const a=r[s]-i,o=this.curves[s],l=o.getLength(),c=l===0?0:1-a/l;return o.getPointAt(c,t)}s++}return null}getLength(){const e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;const e=[];let t=0;for(let i=0,r=this.curves.length;i<r;i++)t+=this.curves[i].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){const t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){const t=[];let i;for(let r=0,s=this.curves;r<s.length;r++){const a=s[r],o=a.isEllipseCurve?e*2:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?e*a.points.length:e,l=a.getPoints(o);for(let c=0;c<l.length;c++){const d=l[c];i&&i.equals(d)||(t.push(d),i=d)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){const r=e.curves[t];this.curves.push(r.clone())}return this.autoClose=e.autoClose,this}toJSON(){const e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,i=this.curves.length;t<i;t++){const r=this.curves[t];e.curves.push(r.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){const r=e.curves[t];this.curves.push(new zc[r.type]().fromJSON(r))}return this}}class Hu extends Wg{constructor(e){super(),this.type="Path",this.currentPoint=new le,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,i=e.length;t<i;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){const i=new vf(this.currentPoint.clone(),new le(e,t));return this.curves.push(i),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,i,r){const s=new yf(this.currentPoint.clone(),new le(e,t),new le(i,r));return this.curves.push(s),this.currentPoint.set(i,r),this}bezierCurveTo(e,t,i,r,s,a){const o=new gf(this.currentPoint.clone(),new le(e,t),new le(i,r),new le(s,a));return this.curves.push(o),this.currentPoint.set(s,a),this}splineThru(e){const t=[this.currentPoint.clone()].concat(e),i=new _f(t);return this.curves.push(i),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,i,r,s,a){const o=this.currentPoint.x,l=this.currentPoint.y;return this.absarc(e+o,t+l,i,r,s,a),this}absarc(e,t,i,r,s,a){return this.absellipse(e,t,i,i,r,s,a),this}ellipse(e,t,i,r,s,a,o,l){const c=this.currentPoint.x,d=this.currentPoint.y;return this.absellipse(e+c,t+d,i,r,s,a,o,l),this}absellipse(e,t,i,r,s,a,o,l){const c=new Pd(e,t,i,r,s,a,o,l);if(this.curves.length>0){const u=c.getPoint(0);u.equals(this.currentPoint)||this.lineTo(u.x,u.y)}this.curves.push(c);const d=c.getPoint(1);return this.currentPoint.copy(d),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){const e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}}class xf extends Hu{constructor(e){super(e),this.uuid=ui(),this.type="Shape",this.holes=[]}getPointsHoles(e){const t=[];for(let i=0,r=this.holes.length;i<r;i++)t[i]=this.holes[i].getPoints(e);return t}extractPoints(e){return{shape:this.getPoints(e),holes:this.getPointsHoles(e)}}copy(e){super.copy(e),this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){const r=e.holes[t];this.holes.push(r.clone())}return this}toJSON(){const e=super.toJSON();e.uuid=this.uuid,e.holes=[];for(let t=0,i=this.holes.length;t<i;t++){const r=this.holes[t];e.holes.push(r.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.uuid=e.uuid,this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){const r=e.holes[t];this.holes.push(new Hu().fromJSON(r))}return this}}function Xg(n,e,t=2){const i=e&&e.length,r=i?e[0]*t:n.length;let s=bf(n,0,r,t,!0);const a=[];if(!s||s.next===s.prev)return a;let o,l,c;if(i&&(s=Jg(n,e,s,t)),n.length>80*t){o=n[0],l=n[1];let d=o,u=l;for(let h=t;h<r;h+=t){const f=n[h],p=n[h+1];f<o&&(o=f),p<l&&(l=p),f>d&&(d=f),p>u&&(u=p)}c=Math.max(d-o,u-l),c=c!==0?32767/c:0}return ra(s,a,t,o,l,c,0),a}function bf(n,e,t,i,r){let s;if(r===lv(n,e,t,i)>0)for(let a=e;a<t;a+=i)s=Gu(a/i|0,n[a],n[a+1],s);else for(let a=t-i;a>=e;a-=i)s=Gu(a/i|0,n[a],n[a+1],s);return s&&cs(s,s.next)&&(aa(s),s=s.next),s}function xr(n,e){if(!n)return n;e||(e=n);let t=n,i;do if(i=!1,!t.steiner&&(cs(t,t.next)||Ct(t.prev,t,t.next)===0)){if(aa(t),t=e=t.prev,t===t.next)break;i=!0}else t=t.next;while(i||t!==e);return e}function ra(n,e,t,i,r,s,a){if(!n)return;!a&&s&&nv(n,i,r,s);let o=n;for(;n.prev!==n.next;){const l=n.prev,c=n.next;if(s?Yg(n,i,r,s):qg(n)){e.push(l.i,n.i,c.i),aa(n),n=c.next,o=c.next;continue}if(n=c,n===o){a?a===1?(n=Zg(xr(n),e),ra(n,e,t,i,r,s,2)):a===2&&Kg(n,e,t,i,r,s):ra(xr(n),e,t,i,r,s,1);break}}}function qg(n){const e=n.prev,t=n,i=n.next;if(Ct(e,t,i)>=0)return!1;const r=e.x,s=t.x,a=i.x,o=e.y,l=t.y,c=i.y,d=Math.min(r,s,a),u=Math.min(o,l,c),h=Math.max(r,s,a),f=Math.max(o,l,c);let p=i.next;for(;p!==e;){if(p.x>=d&&p.x<=h&&p.y>=u&&p.y<=f&&Fs(r,o,s,l,a,c,p.x,p.y)&&Ct(p.prev,p,p.next)>=0)return!1;p=p.next}return!0}function Yg(n,e,t,i){const r=n.prev,s=n,a=n.next;if(Ct(r,s,a)>=0)return!1;const o=r.x,l=s.x,c=a.x,d=r.y,u=s.y,h=a.y,f=Math.min(o,l,c),p=Math.min(d,u,h),v=Math.max(o,l,c),m=Math.max(d,u,h),g=Hc(f,p,e,t,i),x=Hc(v,m,e,t,i);let E=n.prevZ,b=n.nextZ;for(;E&&E.z>=g&&b&&b.z<=x;){if(E.x>=f&&E.x<=v&&E.y>=p&&E.y<=m&&E!==r&&E!==a&&Fs(o,d,l,u,c,h,E.x,E.y)&&Ct(E.prev,E,E.next)>=0||(E=E.prevZ,b.x>=f&&b.x<=v&&b.y>=p&&b.y<=m&&b!==r&&b!==a&&Fs(o,d,l,u,c,h,b.x,b.y)&&Ct(b.prev,b,b.next)>=0))return!1;b=b.nextZ}for(;E&&E.z>=g;){if(E.x>=f&&E.x<=v&&E.y>=p&&E.y<=m&&E!==r&&E!==a&&Fs(o,d,l,u,c,h,E.x,E.y)&&Ct(E.prev,E,E.next)>=0)return!1;E=E.prevZ}for(;b&&b.z<=x;){if(b.x>=f&&b.x<=v&&b.y>=p&&b.y<=m&&b!==r&&b!==a&&Fs(o,d,l,u,c,h,b.x,b.y)&&Ct(b.prev,b,b.next)>=0)return!1;b=b.nextZ}return!0}function Zg(n,e){let t=n;do{const i=t.prev,r=t.next.next;!cs(i,r)&&Mf(i,t,t.next,r)&&sa(i,r)&&sa(r,i)&&(e.push(i.i,t.i,r.i),aa(t),aa(t.next),t=n=r),t=t.next}while(t!==n);return xr(t)}function Kg(n,e,t,i,r,s){let a=n;do{let o=a.next.next;for(;o!==a.prev;){if(a.i!==o.i&&sv(a,o)){let l=wf(a,o);a=xr(a,a.next),l=xr(l,l.next),ra(a,e,t,i,r,s,0),ra(l,e,t,i,r,s,0);return}o=o.next}a=a.next}while(a!==n)}function Jg(n,e,t,i){const r=[];for(let s=0,a=e.length;s<a;s++){const o=e[s]*i,l=s<a-1?e[s+1]*i:n.length,c=bf(n,o,l,i,!1);c===c.next&&(c.steiner=!0),r.push(rv(c))}r.sort(jg);for(let s=0;s<r.length;s++)t=Qg(r[s],t);return t}function jg(n,e){let t=n.x-e.x;if(t===0&&(t=n.y-e.y,t===0)){const i=(n.next.y-n.y)/(n.next.x-n.x),r=(e.next.y-e.y)/(e.next.x-e.x);t=i-r}return t}function Qg(n,e){const t=ev(n,e);if(!t)return e;const i=wf(t,n);return xr(i,i.next),xr(t,t.next)}function ev(n,e){let t=e;const i=n.x,r=n.y;let s=-1/0,a;if(cs(n,t))return t;do{if(cs(n,t.next))return t.next;if(r<=t.y&&r>=t.next.y&&t.next.y!==t.y){const u=t.x+(r-t.y)*(t.next.x-t.x)/(t.next.y-t.y);if(u<=i&&u>s&&(s=u,a=t.x<t.next.x?t:t.next,u===i))return a}t=t.next}while(t!==e);if(!a)return null;const o=a,l=a.x,c=a.y;let d=1/0;t=a;do{if(i>=t.x&&t.x>=l&&i!==t.x&&Sf(r<c?i:s,r,l,c,r<c?s:i,r,t.x,t.y)){const u=Math.abs(r-t.y)/(i-t.x);sa(t,n)&&(u<d||u===d&&(t.x>a.x||t.x===a.x&&tv(a,t)))&&(a=t,d=u)}t=t.next}while(t!==o);return a}function tv(n,e){return Ct(n.prev,n,e.prev)<0&&Ct(e.next,n,n.next)<0}function nv(n,e,t,i){let r=n;do r.z===0&&(r.z=Hc(r.x,r.y,e,t,i)),r.prevZ=r.prev,r.nextZ=r.next,r=r.next;while(r!==n);r.prevZ.nextZ=null,r.prevZ=null,iv(r)}function iv(n){let e,t=1;do{let i=n,r;n=null;let s=null;for(e=0;i;){e++;let a=i,o=0;for(let c=0;c<t&&(o++,a=a.nextZ,!!a);c++);let l=t;for(;o>0||l>0&&a;)o!==0&&(l===0||!a||i.z<=a.z)?(r=i,i=i.nextZ,o--):(r=a,a=a.nextZ,l--),s?s.nextZ=r:n=r,r.prevZ=s,s=r;i=a}s.nextZ=null,t*=2}while(e>1);return n}function Hc(n,e,t,i,r){return n=(n-t)*r|0,e=(e-i)*r|0,n=(n|n<<8)&16711935,n=(n|n<<4)&252645135,n=(n|n<<2)&858993459,n=(n|n<<1)&1431655765,e=(e|e<<8)&16711935,e=(e|e<<4)&252645135,e=(e|e<<2)&858993459,e=(e|e<<1)&1431655765,n|e<<1}function rv(n){let e=n,t=n;do(e.x<t.x||e.x===t.x&&e.y<t.y)&&(t=e),e=e.next;while(e!==n);return t}function Sf(n,e,t,i,r,s,a,o){return(r-a)*(e-o)>=(n-a)*(s-o)&&(n-a)*(i-o)>=(t-a)*(e-o)&&(t-a)*(s-o)>=(r-a)*(i-o)}function Fs(n,e,t,i,r,s,a,o){return!(n===a&&e===o)&&Sf(n,e,t,i,r,s,a,o)}function sv(n,e){return n.next.i!==e.i&&n.prev.i!==e.i&&!av(n,e)&&(sa(n,e)&&sa(e,n)&&ov(n,e)&&(Ct(n.prev,n,e.prev)||Ct(n,e.prev,e))||cs(n,e)&&Ct(n.prev,n,n.next)>0&&Ct(e.prev,e,e.next)>0)}function Ct(n,e,t){return(e.y-n.y)*(t.x-e.x)-(e.x-n.x)*(t.y-e.y)}function cs(n,e){return n.x===e.x&&n.y===e.y}function Mf(n,e,t,i){const r=Ya(Ct(n,e,t)),s=Ya(Ct(n,e,i)),a=Ya(Ct(t,i,n)),o=Ya(Ct(t,i,e));return!!(r!==s&&a!==o||r===0&&qa(n,t,e)||s===0&&qa(n,i,e)||a===0&&qa(t,n,i)||o===0&&qa(t,e,i))}function qa(n,e,t){return e.x<=Math.max(n.x,t.x)&&e.x>=Math.min(n.x,t.x)&&e.y<=Math.max(n.y,t.y)&&e.y>=Math.min(n.y,t.y)}function Ya(n){return n>0?1:n<0?-1:0}function av(n,e){let t=n;do{if(t.i!==n.i&&t.next.i!==n.i&&t.i!==e.i&&t.next.i!==e.i&&Mf(t,t.next,n,e))return!0;t=t.next}while(t!==n);return!1}function sa(n,e){return Ct(n.prev,n,n.next)<0?Ct(n,e,n.next)>=0&&Ct(n,n.prev,e)>=0:Ct(n,e,n.prev)<0||Ct(n,n.next,e)<0}function ov(n,e){let t=n,i=!1;const r=(n.x+e.x)/2,s=(n.y+e.y)/2;do t.y>s!=t.next.y>s&&t.next.y!==t.y&&r<(t.next.x-t.x)*(s-t.y)/(t.next.y-t.y)+t.x&&(i=!i),t=t.next;while(t!==n);return i}function wf(n,e){const t=Gc(n.i,n.x,n.y),i=Gc(e.i,e.x,e.y),r=n.next,s=e.prev;return n.next=e,e.prev=n,t.next=r,r.prev=t,i.next=t,t.prev=i,s.next=i,i.prev=s,i}function Gu(n,e,t,i){const r=Gc(n,e,t);return i?(r.next=i.next,r.prev=i,i.next.prev=r,i.next=r):(r.prev=r,r.next=r),r}function aa(n){n.next.prev=n.prev,n.prev.next=n.next,n.prevZ&&(n.prevZ.nextZ=n.nextZ),n.nextZ&&(n.nextZ.prevZ=n.prevZ)}function Gc(n,e,t){return{i:n,x:e,y:t,prev:null,next:null,z:0,prevZ:null,nextZ:null,steiner:!1}}function lv(n,e,t,i){let r=0;for(let s=e,a=t-i;s<t;s+=i)r+=(n[a]-n[s])*(n[s+1]+n[a+1]),a=s;return r}class cv{static triangulate(e,t,i=2){return Xg(e,t,i)}}class Jr{static area(e){const t=e.length;let i=0;for(let r=t-1,s=0;s<t;r=s++)i+=e[r].x*e[s].y-e[s].x*e[r].y;return i*.5}static isClockWise(e){return Jr.area(e)<0}static triangulateShape(e,t){const i=[],r=[],s=[];Vu(e),Wu(i,e);let a=e.length;t.forEach(Vu);for(let l=0;l<t.length;l++)r.push(a),a+=t[l].length,Wu(i,t[l]);const o=cv.triangulate(i,r);for(let l=0;l<o.length;l+=3)s.push(o.slice(l,l+3));return s}}function Vu(n){const e=n.length;e>2&&n[e-1].equals(n[0])&&n.pop()}function Wu(n,e){for(let t=0;t<e.length;t++)n.push(e[t].x),n.push(e[t].y)}class Nd extends Ot{constructor(e=new xf([new le(.5,.5),new le(-.5,.5),new le(-.5,-.5),new le(.5,-.5)]),t={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:e,options:t},e=Array.isArray(e)?e:[e];const i=this,r=[],s=[];for(let o=0,l=e.length;o<l;o++){const c=e[o];a(c)}this.setAttribute("position",new bt(r,3)),this.setAttribute("uv",new bt(s,2)),this.computeVertexNormals();function a(o){const l=[],c=t.curveSegments!==void 0?t.curveSegments:12,d=t.steps!==void 0?t.steps:1,u=t.depth!==void 0?t.depth:1;let h=t.bevelEnabled!==void 0?t.bevelEnabled:!0,f=t.bevelThickness!==void 0?t.bevelThickness:.2,p=t.bevelSize!==void 0?t.bevelSize:f-.1,v=t.bevelOffset!==void 0?t.bevelOffset:0,m=t.bevelSegments!==void 0?t.bevelSegments:3;const g=t.extrudePath,x=t.UVGenerator!==void 0?t.UVGenerator:dv;let E,b=!1,w,S,T,y;if(g){E=g.getSpacedPoints(d),b=!0,h=!1;const te=g.isCatmullRomCurve3?g.closed:!1;w=g.computeFrenetFrames(d,te),S=new P,T=new P,y=new P}h||(m=0,f=0,p=0,v=0);const A=o.extractPoints(c);let C=A.shape;const L=A.holes;if(!Jr.isClockWise(C)){C=C.reverse();for(let te=0,se=L.length;te<se;te++){const ae=L[te];Jr.isClockWise(ae)&&(L[te]=ae.reverse())}}function B(te){const ae=10000000000000001e-36;let oe=te[0];for(let ue=1;ue<=te.length;ue++){const Fe=ue%te.length,Ue=te[Fe],Ge=Ue.x-oe.x,Xe=Ue.y-oe.y,D=Ge*Ge+Xe*Xe,ht=Math.max(Math.abs(Ue.x),Math.abs(Ue.y),Math.abs(oe.x),Math.abs(oe.y)),nt=ae*ht*ht;if(D<=nt){te.splice(Fe,1),ue--;continue}oe=Ue}}B(C),L.forEach(B);const N=L.length,U=C;for(let te=0;te<N;te++){const se=L[te];C=C.concat(se)}function V(te,se,ae){return se||st("ExtrudeGeometry: vec does not exist"),te.clone().addScaledVector(se,ae)}const $=C.length;function ie(te,se,ae){let oe,ue,Fe;const Ue=te.x-se.x,Ge=te.y-se.y,Xe=ae.x-te.x,D=ae.y-te.y,ht=Ue*Ue+Ge*Ge,nt=Ue*D-Ge*Xe;if(Math.abs(nt)>Number.EPSILON){const R=Math.sqrt(ht),_=Math.sqrt(Xe*Xe+D*D),k=se.x-Ge/R,G=se.y+Ue/R,q=ae.x-D/_,ce=ae.y+Xe/_,de=((q-k)*D-(ce-G)*Xe)/(Ue*D-Ge*Xe);oe=k+Ue*de-te.x,ue=G+Ge*de-te.y;const Y=oe*oe+ue*ue;if(Y<=2)return new le(oe,ue);Fe=Math.sqrt(Y/2)}else{let R=!1;Ue>Number.EPSILON?Xe>Number.EPSILON&&(R=!0):Ue<-Number.EPSILON?Xe<-Number.EPSILON&&(R=!0):Math.sign(Ge)===Math.sign(D)&&(R=!0),R?(oe=-Ge,ue=Ue,Fe=Math.sqrt(ht)):(oe=Ue,ue=Ge,Fe=Math.sqrt(ht/2))}return new le(oe/Fe,ue/Fe)}const X=[];for(let te=0,se=U.length,ae=se-1,oe=te+1;te<se;te++,ae++,oe++)ae===se&&(ae=0),oe===se&&(oe=0),X[te]=ie(U[te],U[ae],U[oe]);const Q=[];let ne,Pe=X.concat();for(let te=0,se=N;te<se;te++){const ae=L[te];ne=[];for(let oe=0,ue=ae.length,Fe=ue-1,Ue=oe+1;oe<ue;oe++,Fe++,Ue++)Fe===ue&&(Fe=0),Ue===ue&&(Ue=0),ne[oe]=ie(ae[oe],ae[Fe],ae[Ue]);Q.push(ne),Pe=Pe.concat(ne)}let Ee;if(m===0)Ee=Jr.triangulateShape(U,L);else{const te=[],se=[];for(let ae=0;ae<m;ae++){const oe=ae/m,ue=f*Math.cos(oe*Math.PI/2),Fe=p*Math.sin(oe*Math.PI/2)+v;for(let Ue=0,Ge=U.length;Ue<Ge;Ue++){const Xe=V(U[Ue],X[Ue],Fe);ye(Xe.x,Xe.y,-ue),oe===0&&te.push(Xe)}for(let Ue=0,Ge=N;Ue<Ge;Ue++){const Xe=L[Ue];ne=Q[Ue];const D=[];for(let ht=0,nt=Xe.length;ht<nt;ht++){const R=V(Xe[ht],ne[ht],Fe);ye(R.x,R.y,-ue),oe===0&&D.push(R)}oe===0&&se.push(D)}}Ee=Jr.triangulateShape(te,se)}const ut=Ee.length,tt=p+v;for(let te=0;te<$;te++){const se=h?V(C[te],Pe[te],tt):C[te];b?(T.copy(w.normals[0]).multiplyScalar(se.x),S.copy(w.binormals[0]).multiplyScalar(se.y),y.copy(E[0]).add(T).add(S),ye(y.x,y.y,y.z)):ye(se.x,se.y,0)}for(let te=1;te<=d;te++)for(let se=0;se<$;se++){const ae=h?V(C[se],Pe[se],tt):C[se];b?(T.copy(w.normals[te]).multiplyScalar(ae.x),S.copy(w.binormals[te]).multiplyScalar(ae.y),y.copy(E[te]).add(T).add(S),ye(y.x,y.y,y.z)):ye(ae.x,ae.y,u/d*te)}for(let te=m-1;te>=0;te--){const se=te/m,ae=f*Math.cos(se*Math.PI/2),oe=p*Math.sin(se*Math.PI/2)+v;for(let ue=0,Fe=U.length;ue<Fe;ue++){const Ue=V(U[ue],X[ue],oe);ye(Ue.x,Ue.y,u+ae)}for(let ue=0,Fe=L.length;ue<Fe;ue++){const Ue=L[ue];ne=Q[ue];for(let Ge=0,Xe=Ue.length;Ge<Xe;Ge++){const D=V(Ue[Ge],ne[Ge],oe);b?ye(D.x,D.y+E[d-1].y,E[d-1].x+ae):ye(D.x,D.y,u+ae)}}}lt(),Z();function lt(){const te=r.length/3;if(h){let se=0,ae=$*se;for(let oe=0;oe<ut;oe++){const ue=Ee[oe];ze(ue[2]+ae,ue[1]+ae,ue[0]+ae)}se=d+m*2,ae=$*se;for(let oe=0;oe<ut;oe++){const ue=Ee[oe];ze(ue[0]+ae,ue[1]+ae,ue[2]+ae)}}else{for(let se=0;se<ut;se++){const ae=Ee[se];ze(ae[2],ae[1],ae[0])}for(let se=0;se<ut;se++){const ae=Ee[se];ze(ae[0]+$*d,ae[1]+$*d,ae[2]+$*d)}}i.addGroup(te,r.length/3-te,0)}function Z(){const te=r.length/3;let se=0;ee(U,se),se+=U.length;for(let ae=0,oe=L.length;ae<oe;ae++){const ue=L[ae];ee(ue,se),se+=ue.length}i.addGroup(te,r.length/3-te,1)}function ee(te,se){let ae=te.length;for(;--ae>=0;){const oe=ae;let ue=ae-1;ue<0&&(ue=te.length-1);for(let Fe=0,Ue=d+m*2;Fe<Ue;Fe++){const Ge=$*Fe,Xe=$*(Fe+1),D=se+oe+Ge,ht=se+ue+Ge,nt=se+ue+Xe,R=se+oe+Xe;Se(D,ht,nt,R)}}}function ye(te,se,ae){l.push(te),l.push(se),l.push(ae)}function ze(te,se,ae){He(te),He(se),He(ae);const oe=r.length/3,ue=x.generateTopUV(i,r,oe-3,oe-2,oe-1);mt(ue[0]),mt(ue[1]),mt(ue[2])}function Se(te,se,ae,oe){He(te),He(se),He(oe),He(se),He(ae),He(oe);const ue=r.length/3,Fe=x.generateSideWallUV(i,r,ue-6,ue-3,ue-2,ue-1);mt(Fe[0]),mt(Fe[1]),mt(Fe[3]),mt(Fe[1]),mt(Fe[2]),mt(Fe[3])}function He(te){r.push(l[te*3+0]),r.push(l[te*3+1]),r.push(l[te*3+2])}function mt(te){s.push(te.x),s.push(te.y)}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON(),t=this.parameters.shapes,i=this.parameters.options;return uv(t,i,e)}static fromJSON(e,t){const i=[];for(let s=0,a=e.shapes.length;s<a;s++){const o=t[e.shapes[s]];i.push(o)}const r=e.options.extrudePath;return r!==void 0&&(e.options.extrudePath=new zc[r.type]().fromJSON(r)),new Nd(i,e.options)}}const dv={generateTopUV:function(n,e,t,i,r){const s=e[t*3],a=e[t*3+1],o=e[i*3],l=e[i*3+1],c=e[r*3],d=e[r*3+1];return[new le(s,a),new le(o,l),new le(c,d)]},generateSideWallUV:function(n,e,t,i,r,s){const a=e[t*3],o=e[t*3+1],l=e[t*3+2],c=e[i*3],d=e[i*3+1],u=e[i*3+2],h=e[r*3],f=e[r*3+1],p=e[r*3+2],v=e[s*3],m=e[s*3+1],g=e[s*3+2];return Math.abs(o-d)<Math.abs(a-c)?[new le(a,1-l),new le(c,1-u),new le(h,1-p),new le(v,1-g)]:[new le(o,1-l),new le(d,1-u),new le(f,1-p),new le(m,1-g)]}};function uv(n,e,t){if(t.shapes=[],Array.isArray(n))for(let i=0,r=n.length;i<r;i++){const s=n[i];t.shapes.push(s.uuid)}else t.shapes.push(n.uuid);return t.options=Object.assign({},e),e.extrudePath!==void 0&&(t.options.extrudePath=e.extrudePath.toJSON()),t}class Wo extends Ot{constructor(e=1,t=1,i=1,r=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:i,heightSegments:r};const s=e/2,a=t/2,o=Math.floor(i),l=Math.floor(r),c=o+1,d=l+1,u=e/o,h=t/l,f=[],p=[],v=[],m=[];for(let g=0;g<d;g++){const x=g*h-a;for(let E=0;E<c;E++){const b=E*u-s;p.push(b,-x,0),v.push(0,0,1),m.push(E/o),m.push(1-g/l)}}for(let g=0;g<l;g++)for(let x=0;x<o;x++){const E=x+c*g,b=x+c*(g+1),w=x+1+c*(g+1),S=x+1+c*g;f.push(E,b,S),f.push(b,w,S)}this.setIndex(f),this.setAttribute("position",new bt(p,3)),this.setAttribute("normal",new bt(v,3)),this.setAttribute("uv",new bt(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Wo(e.width,e.height,e.widthSegments,e.heightSegments)}}class Xo extends Ot{constructor(e=1,t=32,i=16,r=0,s=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:i,phiStart:r,phiLength:s,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),i=Math.max(2,Math.floor(i));const l=Math.min(a+o,Math.PI);let c=0;const d=[],u=new P,h=new P,f=[],p=[],v=[],m=[];for(let g=0;g<=i;g++){const x=[],E=g/i,b=a+E*o,w=e*Math.cos(b),S=Math.sqrt(e*e-w*w);let T=0;g===0&&a===0?T=.5/t:g===i&&l===Math.PI&&(T=-.5/t);for(let y=0;y<=t;y++){const A=y/t,C=r+A*s;u.x=-S*Math.cos(C),u.y=w,u.z=S*Math.sin(C),p.push(u.x,u.y,u.z),h.copy(u).normalize(),v.push(h.x,h.y,h.z),m.push(A+T,1-E),x.push(c++)}d.push(x)}for(let g=0;g<i;g++)for(let x=0;x<t;x++){const E=d[g][x+1],b=d[g][x],w=d[g+1][x],S=d[g+1][x+1];(g!==0||a>0)&&f.push(E,b,S),(g!==i-1||l<Math.PI)&&f.push(b,w,S)}this.setIndex(f),this.setAttribute("position",new bt(p,3)),this.setAttribute("normal",new bt(v,3)),this.setAttribute("uv",new bt(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Xo(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class Dd extends Ot{constructor(e=1,t=.4,i=12,r=48,s=Math.PI*2,a=0,o=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:i,tubularSegments:r,arc:s,thetaStart:a,thetaLength:o},i=Math.floor(i),r=Math.floor(r);const l=[],c=[],d=[],u=[],h=new P,f=new P,p=new P;for(let v=0;v<=i;v++){const m=a+v/i*o;for(let g=0;g<=r;g++){const x=g/r*s;f.x=(e+t*Math.cos(m))*Math.cos(x),f.y=(e+t*Math.cos(m))*Math.sin(x),f.z=t*Math.sin(m),c.push(f.x,f.y,f.z),h.x=e*Math.cos(x),h.y=e*Math.sin(x),p.subVectors(f,h).normalize(),d.push(p.x,p.y,p.z),u.push(g/r),u.push(v/i)}}for(let v=1;v<=i;v++)for(let m=1;m<=r;m++){const g=(r+1)*v+m-1,x=(r+1)*(v-1)+m-1,E=(r+1)*(v-1)+m,b=(r+1)*v+m;l.push(g,x,b),l.push(x,E,b)}this.setIndex(l),this.setAttribute("position",new bt(c,3)),this.setAttribute("normal",new bt(d,3)),this.setAttribute("uv",new bt(u,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Dd(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc,e.thetaStart,e.thetaLength)}}function ds(n){const e={};for(const t in n){e[t]={};for(const i in n[t]){const r=n[t][i];if(Xu(r))r.isRenderTargetTexture?(ke("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][i]=null):e[t][i]=r.clone();else if(Array.isArray(r))if(Xu(r[0])){const s=[];for(let a=0,o=r.length;a<o;a++)s[a]=r[a].clone();e[t][i]=s}else e[t][i]=r.slice();else e[t][i]=r}}return e}function dn(n){const e={};for(let t=0;t<n.length;t++){const i=ds(n[t]);for(const r in i)e[r]=i[r]}return e}function Xu(n){return n&&(n.isColor||n.isMatrix3||n.isMatrix4||n.isVector2||n.isVector3||n.isVector4||n.isTexture||n.isQuaternion)}function hv(n){const e=[];for(let t=0;t<n.length;t++)e.push(n[t].clone());return e}function Ef(n){const e=n.getRenderTarget();return e===null?n.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:at.workingColorSpace}const fv={clone:ds,merge:dn};var pv=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,mv=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class gi extends er{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=pv,this.fragmentShader=mv,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=ds(e.uniforms),this.uniformsGroups=hv(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const r in this.uniforms){const a=this.uniforms[r].value;a&&a.isTexture?t.uniforms[r]={type:"t",value:a.toJSON(e).uuid}:a&&a.isColor?t.uniforms[r]={type:"c",value:a.getHex()}:a&&a.isVector2?t.uniforms[r]={type:"v2",value:a.toArray()}:a&&a.isVector3?t.uniforms[r]={type:"v3",value:a.toArray()}:a&&a.isVector4?t.uniforms[r]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?t.uniforms[r]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?t.uniforms[r]={type:"m4",value:a.toArray()}:t.uniforms[r]={value:a}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const i={};for(const r in this.extensions)this.extensions[r]===!0&&(i[r]=!0);return Object.keys(i).length>0&&(t.extensions=i),t}fromJSON(e,t){if(super.fromJSON(e,t),e.uniforms!==void 0)for(const i in e.uniforms){const r=e.uniforms[i];switch(this.uniforms[i]={},r.type){case"t":this.uniforms[i].value=t[r.value]||null;break;case"c":this.uniforms[i].value=new Qe().setHex(r.value);break;case"v2":this.uniforms[i].value=new le().fromArray(r.value);break;case"v3":this.uniforms[i].value=new P().fromArray(r.value);break;case"v4":this.uniforms[i].value=new Rt().fromArray(r.value);break;case"m3":this.uniforms[i].value=new qe().fromArray(r.value);break;case"m4":this.uniforms[i].value=new yt().fromArray(r.value);break;default:this.uniforms[i].value=r.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(const i in e.extensions)this.extensions[i]=e.extensions[i];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}}class gv extends gi{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class qu extends er{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new Qe(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Qe(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=kc,this.normalScale=new le(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Ji,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class vv extends er{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Pm,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class yv extends er{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}class Tf extends Gt{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new Qe(e),this.intensity=t}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,t}}class _v extends Tf{constructor(e,t,i){super(e,i),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Gt.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Qe(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}toJSON(e){const t=super.toJSON(e);return t.object.groundColor=this.groundColor.getHex(),t}}const $l=new yt,Yu=new P,Zu=new P;class xv{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new le(512,512),this.mapType=Tn,this.map=null,this.mapPass=null,this.matrix=new yt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Ad,this._frameExtents=new le(1,1),this._viewportCount=1,this._viewports=[new Rt(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera;Yu.setFromMatrixPosition(e.matrixWorld),t.position.copy(Yu),Zu.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(Zu),t.updateMatrixWorld(),this._updateMatrix(t,this.matrix,this._frustum)}_updateMatrix(e,t,i,r){$l.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),i.setFromProjectionMatrix($l,e.coordinateSystem,e.reversedDepth);const s=this._frameExtents,a=r?r.z/s.x:1,o=r?r.w/s.y:1,l=r?r.x/s.x:0,c=r?r.y/s.y:0;e.coordinateSystem===ta||e.reversedDepth?t.set(.5*a,0,0,.5*a+l,0,.5*o,0,.5*o+c,0,0,1,0,0,0,0,1):t.set(.5*a,0,0,.5*a+l,0,.5*o,0,.5*o+c,0,0,.5,.5,0,0,0,1),t.multiply($l)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this.biasNode=e.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return e.intensity=this.intensity,e.bias=this.bias,e.normalBias=this.normalBias,e.radius=this.radius,e.blurSamples=this.blurSamples,e.mapSize=this.mapSize.toArray(),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}const Za=new P,Ka=new ms,ei=new P;class Af extends Gt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new yt,this.projectionMatrix=new yt,this.projectionMatrixInverse=new yt,this.coordinateSystem=li,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(Za,Ka,ei),ei.x===1&&ei.y===1&&ei.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Za,Ka,ei.set(1,1,1)).invert()}updateWorldMatrix(e,t,i=!1){super.updateWorldMatrix(e,t,i),this.matrixWorld.decompose(Za,Ka,ei),ei.x===1&&ei.y===1&&ei.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Za,Ka,ei.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const Gi=new P,Ku=new le,Ju=new le;class Gn extends Af{constructor(e=50,t=1,i=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=i,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=na*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(zs*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return na*2*Math.atan(Math.tan(zs*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,i){Gi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Gi.x,Gi.y).multiplyScalar(-e/Gi.z),Gi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),i.set(Gi.x,Gi.y).multiplyScalar(-e/Gi.z)}getViewSize(e,t){return this.getViewBounds(e,Ku,Ju),t.subVectors(Ju,Ku)}setViewOffset(e,t,i,r,s,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=r,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(zs*.5*this.fov)/this.zoom,i=2*t,r=this.aspect*i,s=-.5*r;const a=this.view;if(this.view!==null&&this.view.enabled){const l=a.fullWidth,c=a.fullHeight;s+=a.offsetX*r/l,t-=a.offsetY*i/c,r*=a.width/l,i*=a.height/c}const o=this.filmOffset;o!==0&&(s+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+r,t,t-i,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}class ma extends Af{constructor(e=-1,t=1,i=1,r=-1,s=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=i,this.bottom=r,this.near=s,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,i,r,s,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=r,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,r=(this.top+this.bottom)/2;let s=i-e,a=i+e,o=r+t,l=r-t;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,d=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=c*this.view.offsetX,a=s+c*this.view.width,o-=d*this.view.offsetY,l=o-d*this.view.height}this.projectionMatrix.makeOrthographic(s,a,o,l,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}class bv extends xv{constructor(){super(new ma(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class Sv extends Tf{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Gt.DEFAULT_UP),this.updateMatrix(),this.target=new Gt,this.shadow=new bv}dispose(){super.dispose(),this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}toJSON(e){const t=super.toJSON(e);return t.object.shadow=this.shadow.toJSON(),t.object.target=this.target.uuid,t}}const Gr=-90,Vr=1;class Mv extends Gt{constructor(e,t,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;const r=new Gn(Gr,Vr,e,t);r.layers=this.layers,this.add(r);const s=new Gn(Gr,Vr,e,t);s.layers=this.layers,this.add(s);const a=new Gn(Gr,Vr,e,t);a.layers=this.layers,this.add(a);const o=new Gn(Gr,Vr,e,t);o.layers=this.layers,this.add(o);const l=new Gn(Gr,Vr,e,t);l.layers=this.layers,this.add(l);const c=new Gn(Gr,Vr,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[i,r,s,a,o,l]=t;for(const c of t)this.remove(c);if(e===li)i.up.set(0,1,0),i.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===ta)i.up.set(0,-1,0),i.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:i,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[s,a,o,l,c,d]=this.children,u=e.getRenderTarget(),h=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),p=e.xr.enabled;e.xr.enabled=!1;const v=i.texture.generateMipmaps;i.texture.generateMipmaps=!1;let m=!1;e.isWebGLRenderer===!0?m=e.state.buffers.depth.getReversed():m=e.reversedDepthBuffer,e.setRenderTarget(i,0,r),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,s),e.setRenderTarget(i,1,r),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,a),e.setRenderTarget(i,2,r),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,o),e.setRenderTarget(i,3,r),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,l),e.setRenderTarget(i,4,r),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,c),i.texture.generateMipmaps=v,e.setRenderTarget(i,5,r),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,d),e.setRenderTarget(u,h,f),e.xr.enabled=p,i.texture.needsPMREMUpdate=!0}}class wv extends Gn{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}const ju=new yt;class Ev{constructor(e,t,i=0,r=1/0){this.ray=new Vo(e,t),this.near=i,this.far=r,this.camera=null,this.layers=new Td,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,t.projectionMatrix.elements[14]).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):st("Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return ju.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(ju),this}intersectObject(e,t=!0,i=[]){return Vc(e,this,i,t),i.sort(Qu),i}intersectObjects(e,t=!0,i=[]){for(let r=0,s=e.length;r<s;r++)Vc(e[r],this,i,t);return i.sort(Qu),i}}function Qu(n,e){return n.distance-e.distance}function Vc(n,e,t,i){let r=!0;if(n.layers.test(e.layers)&&n.raycast(e,t)===!1&&(r=!1),r===!0&&i===!0){const s=n.children;for(let a=0,o=s.length;a<o;a++)Vc(s[a],e,t,!0)}}class Rf{static{Rf.prototype.isMatrix2=!0}constructor(e,t,i,r){this.elements=[1,0,0,1],e!==void 0&&this.set(e,t,i,r)}identity(){return this.set(1,0,0,1),this}fromArray(e,t=0){for(let i=0;i<4;i++)this.elements[i]=e[i+t];return this}set(e,t,i,r){const s=this.elements;return s[0]=e,s[2]=t,s[1]=i,s[3]=r,this}}function eh(n,e,t,i){const r=Tv(i);switch(t){case tf:return n*e;case rf:return n*e/r.components*r.byteLength;case _d:return n*e/r.components*r.byteLength;case yr:return n*e*2/r.components*r.byteLength;case xd:return n*e*2/r.components*r.byteLength;case nf:return n*e*3/r.components*r.byteLength;case Wn:return n*e*4/r.components*r.byteLength;case bd:return n*e*4/r.components*r.byteLength;case ao:case oo:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*8;case lo:case co:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*16;case dc:case hc:return Math.max(n,16)*Math.max(e,8)/4;case cc:case uc:return Math.max(n,8)*Math.max(e,8)/2;case fc:case pc:case gc:case vc:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*8;case mc:case wo:case yc:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*16;case _c:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*16;case xc:return Math.floor((n+4)/5)*Math.floor((e+3)/4)*16;case bc:return Math.floor((n+4)/5)*Math.floor((e+4)/5)*16;case Sc:return Math.floor((n+5)/6)*Math.floor((e+4)/5)*16;case Mc:return Math.floor((n+5)/6)*Math.floor((e+5)/6)*16;case wc:return Math.floor((n+7)/8)*Math.floor((e+4)/5)*16;case Ec:return Math.floor((n+7)/8)*Math.floor((e+5)/6)*16;case Tc:return Math.floor((n+7)/8)*Math.floor((e+7)/8)*16;case Ac:return Math.floor((n+9)/10)*Math.floor((e+4)/5)*16;case Rc:return Math.floor((n+9)/10)*Math.floor((e+5)/6)*16;case Cc:return Math.floor((n+9)/10)*Math.floor((e+7)/8)*16;case Ic:return Math.floor((n+9)/10)*Math.floor((e+9)/10)*16;case Pc:return Math.floor((n+11)/12)*Math.floor((e+9)/10)*16;case Lc:return Math.floor((n+11)/12)*Math.floor((e+11)/12)*16;case Nc:case Dc:case Uc:return Math.ceil(n/4)*Math.ceil(e/4)*16;case Oc:case Fc:return Math.ceil(n/4)*Math.ceil(e/4)*8;case Eo:case Bc:return Math.ceil(n/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function Tv(n){switch(n){case Tn:case Jh:return{byteLength:1,components:1};case Qs:case jh:case mi:return{byteLength:2,components:1};case vd:case yd:return{byteLength:2,components:4};case pi:case gd:case oi:return{byteLength:4,components:1};case Qh:case ef:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${n}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:pd}}));typeof window<"u"&&(window.__THREE__?ke("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=pd);/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function Cf(){let n=null,e=!1,t=null,i=null;function r(s,a){i=n.requestAnimationFrame(r),t(s,a)}return{start:function(){e!==!0&&t!==null&&n!==null&&(i=n.requestAnimationFrame(r),e=!0)},stop:function(){n!==null&&n.cancelAnimationFrame(i),e=!1},setAnimationLoop:function(s){t=s},setContext:function(s){n=s}}}function Av(n){const e=new WeakMap;function t(o,l){const c=o.array,d=o.usage,u=c.byteLength,h=n.createBuffer();n.bindBuffer(l,h),n.bufferData(l,c,d),o.onUploadCallback();let f;if(c instanceof Float32Array)f=n.FLOAT;else if(typeof Float16Array<"u"&&c instanceof Float16Array)f=n.HALF_FLOAT;else if(c instanceof Uint16Array)o.isFloat16BufferAttribute?f=n.HALF_FLOAT:f=n.UNSIGNED_SHORT;else if(c instanceof Int16Array)f=n.SHORT;else if(c instanceof Uint32Array)f=n.UNSIGNED_INT;else if(c instanceof Int32Array)f=n.INT;else if(c instanceof Int8Array)f=n.BYTE;else if(c instanceof Uint8Array)f=n.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)f=n.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:h,type:f,bytesPerElement:c.BYTES_PER_ELEMENT,version:o.version,size:u}}function i(o,l,c){const d=l.array,u=l.updateRanges;if(n.bindBuffer(c,o),u.length===0)n.bufferSubData(c,0,d);else{u.sort((f,p)=>f.start-p.start);let h=0;for(let f=1;f<u.length;f++){const p=u[h],v=u[f];v.start<=p.start+p.count+1?p.count=Math.max(p.count,v.start+v.count-p.start):(++h,u[h]=v)}u.length=h+1;for(let f=0,p=u.length;f<p;f++){const v=u[f];n.bufferSubData(c,v.start*d.BYTES_PER_ELEMENT,d,v.start,v.count)}l.clearUpdateRanges()}l.onUploadCallback()}function r(o){return o.isInterleavedBufferAttribute&&(o=o.data),e.get(o)}function s(o){o.isInterleavedBufferAttribute&&(o=o.data);const l=e.get(o);l&&(n.deleteBuffer(l.buffer),e.delete(o))}function a(o,l){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){const d=e.get(o);(!d||d.version<o.version)&&e.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}const c=e.get(o);if(c===void 0)e.set(o,t(o,l));else if(c.version<o.version){if(c.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");i(c.buffer,o,l),c.version=o.version}}return{get:r,remove:s,update:a}}var Rv=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Cv=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Iv=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Pv=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Lv=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Nv=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Dv=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Uv=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Ov=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,Fv=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Bv=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,kv=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,$v=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,zv=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Hv=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Gv=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Vv=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Wv=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Xv=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,qv=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,Yv=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,Zv=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,Kv=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,Jv=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,jv=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Qv=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,e0=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,t0=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,n0=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,i0=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,r0="gl_FragColor = linearToOutputTexel( gl_FragColor );",s0=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,a0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,o0=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,l0=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,c0=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,d0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,u0=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,h0=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,f0=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,p0=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,m0=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,g0=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,v0=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,y0=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,_0=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,x0=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureCubeUV( envMap, envMapRotation * retroVec, roughness );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_CUBE_UV
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,b0=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,S0=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,M0=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,w0=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,E0=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,T0=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,A0=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,R0=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,C0=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,I0=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,P0=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,L0=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,N0=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,D0=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,U0=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,O0=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,F0=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,B0=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,k0=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,$0=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,z0=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,H0=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,G0=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,V0=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,W0=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,X0=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,q0=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Y0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Z0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,K0=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,J0=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,j0=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Q0=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,ey=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,ty=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,ny=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,iy=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,ry=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,sy=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,ay=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,oy=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,ly=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,cy=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,dy=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,uy=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,hy=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,fy=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,py=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,my=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,gy=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,vy=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,yy=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,_y=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,xy=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,by=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Sy=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,My=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,wy=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Ey=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Ty=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Ay=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Ry=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Cy=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Iy=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Py=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Ly=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Ny=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Dy=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Uy=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Oy=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Fy=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,By=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,ky=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,$y=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,zy=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Hy=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Gy=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Vy=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Wy=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Xy=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,qy=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Yy=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Zy=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Ky=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Jy=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,jy=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Qy=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,e_=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,t_=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,n_=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,i_=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,r_=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,s_=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,a_=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,o_=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,je={alphahash_fragment:Rv,alphahash_pars_fragment:Cv,alphamap_fragment:Iv,alphamap_pars_fragment:Pv,alphatest_fragment:Lv,alphatest_pars_fragment:Nv,aomap_fragment:Dv,aomap_pars_fragment:Uv,batching_pars_vertex:Ov,batching_vertex:Fv,begin_vertex:Bv,beginnormal_vertex:kv,bsdfs:$v,iridescence_fragment:zv,bumpmap_pars_fragment:Hv,clipping_planes_fragment:Gv,clipping_planes_pars_fragment:Vv,clipping_planes_pars_vertex:Wv,clipping_planes_vertex:Xv,color_fragment:qv,color_pars_fragment:Yv,color_pars_vertex:Zv,color_vertex:Kv,common:Jv,cube_uv_reflection_fragment:jv,defaultnormal_vertex:Qv,displacementmap_pars_vertex:e0,displacementmap_vertex:t0,emissivemap_fragment:n0,emissivemap_pars_fragment:i0,colorspace_fragment:r0,colorspace_pars_fragment:s0,envmap_fragment:a0,envmap_common_pars_fragment:o0,envmap_pars_fragment:l0,envmap_pars_vertex:c0,envmap_physical_pars_fragment:x0,envmap_vertex:d0,fog_vertex:u0,fog_pars_vertex:h0,fog_fragment:f0,fog_pars_fragment:p0,gradientmap_pars_fragment:m0,lightmap_pars_fragment:g0,lights_lambert_fragment:v0,lights_lambert_pars_fragment:y0,lights_pars_begin:_0,lights_toon_fragment:b0,lights_toon_pars_fragment:S0,lights_phong_fragment:M0,lights_phong_pars_fragment:w0,lights_physical_fragment:E0,lights_physical_pars_fragment:T0,lights_fragment_begin:A0,lights_fragment_maps:R0,lights_fragment_end:C0,lightprobes_pars_fragment:I0,logdepthbuf_fragment:P0,logdepthbuf_pars_fragment:L0,logdepthbuf_pars_vertex:N0,logdepthbuf_vertex:D0,map_fragment:U0,map_pars_fragment:O0,map_particle_fragment:F0,map_particle_pars_fragment:B0,metalnessmap_fragment:k0,metalnessmap_pars_fragment:$0,morphinstance_vertex:z0,morphcolor_vertex:H0,morphnormal_vertex:G0,morphtarget_pars_vertex:V0,morphtarget_vertex:W0,normal_fragment_begin:X0,normal_fragment_maps:q0,normal_pars_fragment:Y0,normal_pars_vertex:Z0,normal_vertex:K0,normalmap_pars_fragment:J0,clearcoat_normal_fragment_begin:j0,clearcoat_normal_fragment_maps:Q0,clearcoat_pars_fragment:ey,iridescence_pars_fragment:ty,opaque_fragment:ny,packing:iy,premultiplied_alpha_fragment:ry,project_vertex:sy,dithering_fragment:ay,dithering_pars_fragment:oy,roughnessmap_fragment:ly,roughnessmap_pars_fragment:cy,shadowmap_pars_fragment:dy,shadowmap_pars_vertex:uy,shadowmap_vertex:hy,shadowmask_pars_fragment:fy,skinbase_vertex:py,skinning_pars_vertex:my,skinning_vertex:gy,skinnormal_vertex:vy,specularmap_fragment:yy,specularmap_pars_fragment:_y,tonemapping_fragment:xy,tonemapping_pars_fragment:by,transmission_fragment:Sy,transmission_pars_fragment:My,uv_pars_fragment:wy,uv_pars_vertex:Ey,uv_vertex:Ty,worldpos_vertex:Ay,background_vert:Ry,background_frag:Cy,backgroundCube_vert:Iy,backgroundCube_frag:Py,cube_vert:Ly,cube_frag:Ny,depth_vert:Dy,depth_frag:Uy,distance_vert:Oy,distance_frag:Fy,equirect_vert:By,equirect_frag:ky,linedashed_vert:$y,linedashed_frag:zy,meshbasic_vert:Hy,meshbasic_frag:Gy,meshlambert_vert:Vy,meshlambert_frag:Wy,meshmatcap_vert:Xy,meshmatcap_frag:qy,meshnormal_vert:Yy,meshnormal_frag:Zy,meshphong_vert:Ky,meshphong_frag:Jy,meshphysical_vert:jy,meshphysical_frag:Qy,meshtoon_vert:e_,meshtoon_frag:t_,points_vert:n_,points_frag:i_,shadow_vert:r_,shadow_frag:s_,sprite_vert:a_,sprite_frag:o_},ve={common:{diffuse:{value:new Qe(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new qe},alphaMap:{value:null},alphaMapTransform:{value:new qe},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new qe}},envmap:{envMap:{value:null},envMapRotation:{value:new qe},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new qe}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new qe}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new qe},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new qe},normalScale:{value:new le(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new qe},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new qe}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new qe}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new qe}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Qe(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new P},probesMax:{value:new P},probesResolution:{value:new P}},points:{diffuse:{value:new Qe(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new qe},alphaTest:{value:0},uvTransform:{value:new qe}},sprite:{diffuse:{value:new Qe(16777215)},opacity:{value:1},center:{value:new le(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new qe},alphaMap:{value:null},alphaMapTransform:{value:new qe},alphaTest:{value:0}}},si={basic:{uniforms:dn([ve.common,ve.specularmap,ve.envmap,ve.aomap,ve.lightmap,ve.fog]),vertexShader:je.meshbasic_vert,fragmentShader:je.meshbasic_frag},lambert:{uniforms:dn([ve.common,ve.specularmap,ve.envmap,ve.aomap,ve.lightmap,ve.emissivemap,ve.bumpmap,ve.normalmap,ve.displacementmap,ve.fog,ve.lights,{emissive:{value:new Qe(0)},envMapIntensity:{value:1}}]),vertexShader:je.meshlambert_vert,fragmentShader:je.meshlambert_frag},phong:{uniforms:dn([ve.common,ve.specularmap,ve.envmap,ve.aomap,ve.lightmap,ve.emissivemap,ve.bumpmap,ve.normalmap,ve.displacementmap,ve.fog,ve.lights,{emissive:{value:new Qe(0)},specular:{value:new Qe(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:je.meshphong_vert,fragmentShader:je.meshphong_frag},standard:{uniforms:dn([ve.common,ve.envmap,ve.aomap,ve.lightmap,ve.emissivemap,ve.bumpmap,ve.normalmap,ve.displacementmap,ve.roughnessmap,ve.metalnessmap,ve.fog,ve.lights,{emissive:{value:new Qe(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:je.meshphysical_vert,fragmentShader:je.meshphysical_frag},toon:{uniforms:dn([ve.common,ve.aomap,ve.lightmap,ve.emissivemap,ve.bumpmap,ve.normalmap,ve.displacementmap,ve.gradientmap,ve.fog,ve.lights,{emissive:{value:new Qe(0)}}]),vertexShader:je.meshtoon_vert,fragmentShader:je.meshtoon_frag},matcap:{uniforms:dn([ve.common,ve.bumpmap,ve.normalmap,ve.displacementmap,ve.fog,{matcap:{value:null}}]),vertexShader:je.meshmatcap_vert,fragmentShader:je.meshmatcap_frag},points:{uniforms:dn([ve.points,ve.fog]),vertexShader:je.points_vert,fragmentShader:je.points_frag},dashed:{uniforms:dn([ve.common,ve.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:je.linedashed_vert,fragmentShader:je.linedashed_frag},depth:{uniforms:dn([ve.common,ve.displacementmap]),vertexShader:je.depth_vert,fragmentShader:je.depth_frag},normal:{uniforms:dn([ve.common,ve.bumpmap,ve.normalmap,ve.displacementmap,{opacity:{value:1}}]),vertexShader:je.meshnormal_vert,fragmentShader:je.meshnormal_frag},sprite:{uniforms:dn([ve.sprite,ve.fog]),vertexShader:je.sprite_vert,fragmentShader:je.sprite_frag},background:{uniforms:{uvTransform:{value:new qe},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:je.background_vert,fragmentShader:je.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new qe}},vertexShader:je.backgroundCube_vert,fragmentShader:je.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:je.cube_vert,fragmentShader:je.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:je.equirect_vert,fragmentShader:je.equirect_frag},distance:{uniforms:dn([ve.common,ve.displacementmap,{referencePosition:{value:new P},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:je.distance_vert,fragmentShader:je.distance_frag},shadow:{uniforms:dn([ve.lights,ve.fog,{color:{value:new Qe(0)},opacity:{value:1}}]),vertexShader:je.shadow_vert,fragmentShader:je.shadow_frag}};si.physical={uniforms:dn([si.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new qe},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new qe},clearcoatNormalScale:{value:new le(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new qe},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new qe},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new qe},sheen:{value:0},sheenColor:{value:new Qe(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new qe},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new qe},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new qe},transmissionSamplerSize:{value:new le},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new qe},attenuationDistance:{value:0},attenuationColor:{value:new Qe(0)},specularColor:{value:new Qe(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new qe},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new qe},anisotropyVector:{value:new le},anisotropyMap:{value:null},anisotropyMapTransform:{value:new qe}}]),vertexShader:je.meshphysical_vert,fragmentShader:je.meshphysical_frag};const Ja={r:0,b:0,g:0},l_=new yt,If=new qe;If.set(-1,0,0,0,1,0,0,0,1);function c_(n,e,t,i,r,s){const a=new Qe(0);let o=r===!0?0:1,l,c,d=null,u=0,h=null;function f(x){let E=x.isScene===!0?x.background:null;if(E&&E.isTexture){const b=x.backgroundBlurriness>0;E=e.get(E,b)}return E}function p(x){let E=!1;const b=f(x);b===null?m(a,o):b&&b.isColor&&(m(b,1),E=!0);const w=n.xr.getEnvironmentBlendMode();w==="additive"?t.buffers.color.setClear(0,0,0,1,s):w==="alpha-blend"&&t.buffers.color.setClear(0,0,0,0,s),(n.autoClear||E)&&(t.buffers.depth.setTest(!0),t.buffers.depth.setMask(!0),t.buffers.color.setMask(!0),n.clear(n.autoClearColor,n.autoClearDepth,n.autoClearStencil))}function v(x,E){const b=f(E);b&&(b.isCubeTexture||b.mapping===Go)?(c===void 0&&(c=new Un(new gs(1,1,1),new gi({name:"BackgroundCubeMaterial",uniforms:ds(si.backgroundCube.uniforms),vertexShader:si.backgroundCube.vertexShader,fragmentShader:si.backgroundCube.fragmentShader,side:vn,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),c.geometry.deleteAttribute("uv"),c.onBeforeRender=function(w,S,T){this.matrixWorld.copyPosition(T.matrixWorld)},Object.defineProperty(c.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(c)),c.material.uniforms.envMap.value=b,c.material.uniforms.backgroundBlurriness.value=E.backgroundBlurriness,c.material.uniforms.backgroundIntensity.value=E.backgroundIntensity,c.material.uniforms.backgroundRotation.value.setFromMatrix4(l_.makeRotationFromEuler(E.backgroundRotation)).transpose(),b.isCubeTexture&&b.isRenderTargetTexture===!1&&c.material.uniforms.backgroundRotation.value.premultiply(If),c.material.toneMapped=at.getTransfer(b.colorSpace)!==gt,(d!==b||u!==b.version||h!==n.toneMapping)&&(c.material.needsUpdate=!0,d=b,u=b.version,h=n.toneMapping),c.layers.enableAll(),x.unshift(c,c.geometry,c.material,0,0,null)):b&&b.isTexture&&(l===void 0&&(l=new Un(new Wo(2,2),new gi({name:"BackgroundMaterial",uniforms:ds(si.background.uniforms),vertexShader:si.background.vertexShader,fragmentShader:si.background.fragmentShader,side:gr,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(l)),l.material.uniforms.t2D.value=b,l.material.uniforms.backgroundIntensity.value=E.backgroundIntensity,l.material.toneMapped=at.getTransfer(b.colorSpace)!==gt,b.matrixAutoUpdate===!0&&b.updateMatrix(),l.material.uniforms.uvTransform.value.copy(b.matrix),(d!==b||u!==b.version||h!==n.toneMapping)&&(l.material.needsUpdate=!0,d=b,u=b.version,h=n.toneMapping),l.layers.enableAll(),x.unshift(l,l.geometry,l.material,0,0,null))}function m(x,E){x.getRGB(Ja,Ef(n)),t.buffers.color.setClear(Ja.r,Ja.g,Ja.b,E,s)}function g(){c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0),l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0)}return{getClearColor:function(){return a},setClearColor:function(x,E=1){a.set(x),o=E,m(a,o)},getClearAlpha:function(){return o},setClearAlpha:function(x){o=x,m(a,o)},render:p,addToRenderList:v,dispose:g}}function d_(n,e){const t=n.getParameter(n.MAX_VERTEX_ATTRIBS),i={},r=h(null);let s=r,a=!1;function o(L,I,B,N,U){let V=!1;const $=u(L,N,B,I);s!==$&&(s=$,c(s.object)),V=f(L,N,B,U),V&&p(L,N,B,U),U!==null&&e.update(U,n.ELEMENT_ARRAY_BUFFER),(V||a)&&(a=!1,b(L,I,B,N),U!==null&&n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,e.get(U).buffer))}function l(){return n.createVertexArray()}function c(L){return n.bindVertexArray(L)}function d(L){return n.deleteVertexArray(L)}function u(L,I,B,N){const U=N.wireframe===!0;let V=i[I.id];V===void 0&&(V={},i[I.id]=V);const $=L.isInstancedMesh===!0?L.id:0;let ie=V[$];ie===void 0&&(ie={},V[$]=ie);let X=ie[B.id];X===void 0&&(X={},ie[B.id]=X);let Q=X[U];return Q===void 0&&(Q=h(l()),X[U]=Q),Q}function h(L){const I=[],B=[],N=[];for(let U=0;U<t;U++)I[U]=0,B[U]=0,N[U]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:I,enabledAttributes:B,attributeDivisors:N,object:L,attributes:{},index:null}}function f(L,I,B,N){const U=s.attributes,V=I.attributes;let $=0;const ie=B.getAttributes();for(const X in ie)if(ie[X].location>=0){const ne=U[X];let Pe=V[X];if(Pe===void 0&&(X==="instanceMatrix"&&L.instanceMatrix&&(Pe=L.instanceMatrix),X==="instanceColor"&&L.instanceColor&&(Pe=L.instanceColor)),ne===void 0||ne.attribute!==Pe||Pe&&ne.data!==Pe.data)return!0;$++}return s.attributesNum!==$||s.index!==N}function p(L,I,B,N){const U={},V=I.attributes;let $=0;const ie=B.getAttributes();for(const X in ie)if(ie[X].location>=0){let ne=V[X];ne===void 0&&(X==="instanceMatrix"&&L.instanceMatrix&&(ne=L.instanceMatrix),X==="instanceColor"&&L.instanceColor&&(ne=L.instanceColor));const Pe={};Pe.attribute=ne,ne&&ne.data&&(Pe.data=ne.data),U[X]=Pe,$++}s.attributes=U,s.attributesNum=$,s.index=N}function v(){const L=s.newAttributes;for(let I=0,B=L.length;I<B;I++)L[I]=0}function m(L){g(L,0)}function g(L,I){const B=s.newAttributes,N=s.enabledAttributes,U=s.attributeDivisors;B[L]=1,N[L]===0&&(n.enableVertexAttribArray(L),N[L]=1),U[L]!==I&&(n.vertexAttribDivisor(L,I),U[L]=I)}function x(){const L=s.newAttributes,I=s.enabledAttributes;for(let B=0,N=I.length;B<N;B++)I[B]!==L[B]&&(n.disableVertexAttribArray(B),I[B]=0)}function E(L,I,B,N,U,V,$){$===!0?n.vertexAttribIPointer(L,I,B,U,V):n.vertexAttribPointer(L,I,B,N,U,V)}function b(L,I,B,N){v();const U=N.attributes,V=B.getAttributes(),$=I.defaultAttributeValues;for(const ie in V){const X=V[ie];if(X.location>=0){let Q=U[ie];if(Q===void 0&&(ie==="instanceMatrix"&&L.instanceMatrix&&(Q=L.instanceMatrix),ie==="instanceColor"&&L.instanceColor&&(Q=L.instanceColor)),Q!==void 0){const ne=Q.normalized,Pe=Q.itemSize,Ee=e.get(Q);if(Ee===void 0)continue;const ut=Ee.buffer,tt=Ee.type,lt=Ee.bytesPerElement,Z=tt===n.INT||tt===n.UNSIGNED_INT||Q.gpuType===gd;if(Q.isInterleavedBufferAttribute){const ee=Q.data,ye=ee.stride,ze=Q.offset;if(ee.isInstancedInterleavedBuffer){for(let Se=0;Se<X.locationSize;Se++)g(X.location+Se,ee.meshPerAttribute);L.isInstancedMesh!==!0&&N._maxInstanceCount===void 0&&(N._maxInstanceCount=ee.meshPerAttribute*ee.count)}else for(let Se=0;Se<X.locationSize;Se++)m(X.location+Se);n.bindBuffer(n.ARRAY_BUFFER,ut);for(let Se=0;Se<X.locationSize;Se++)E(X.location+Se,Pe/X.locationSize,tt,ne,ye*lt,(ze+Pe/X.locationSize*Se)*lt,Z)}else{if(Q.isInstancedBufferAttribute){for(let ee=0;ee<X.locationSize;ee++)g(X.location+ee,Q.meshPerAttribute);L.isInstancedMesh!==!0&&N._maxInstanceCount===void 0&&(N._maxInstanceCount=Q.meshPerAttribute*Q.count)}else for(let ee=0;ee<X.locationSize;ee++)m(X.location+ee);n.bindBuffer(n.ARRAY_BUFFER,ut);for(let ee=0;ee<X.locationSize;ee++)E(X.location+ee,Pe/X.locationSize,tt,ne,Pe*lt,Pe/X.locationSize*ee*lt,Z)}}else if($!==void 0){const ne=$[ie];if(ne!==void 0)switch(ne.length){case 2:n.vertexAttrib2fv(X.location,ne);break;case 3:n.vertexAttrib3fv(X.location,ne);break;case 4:n.vertexAttrib4fv(X.location,ne);break;default:n.vertexAttrib1fv(X.location,ne)}}}}x()}function w(){A();for(const L in i){const I=i[L];for(const B in I){const N=I[B];for(const U in N){const V=N[U];for(const $ in V)d(V[$].object),delete V[$];delete N[U]}}delete i[L]}}function S(L){if(i[L.id]===void 0)return;const I=i[L.id];for(const B in I){const N=I[B];for(const U in N){const V=N[U];for(const $ in V)d(V[$].object),delete V[$];delete N[U]}}delete i[L.id]}function T(L){for(const I in i){const B=i[I];for(const N in B){const U=B[N];if(U[L.id]===void 0)continue;const V=U[L.id];for(const $ in V)d(V[$].object),delete V[$];delete U[L.id]}}}function y(L){for(const I in i){const B=i[I],N=L.isInstancedMesh===!0?L.id:0,U=B[N];if(U!==void 0){for(const V in U){const $=U[V];for(const ie in $)d($[ie].object),delete $[ie];delete U[V]}delete B[N],Object.keys(B).length===0&&delete i[I]}}}function A(){C(),a=!0,s!==r&&(s=r,c(s.object))}function C(){r.geometry=null,r.program=null,r.wireframe=!1}return{setup:o,reset:A,resetDefaultState:C,dispose:w,releaseStatesOfGeometry:S,releaseStatesOfObject:y,releaseStatesOfProgram:T,initAttributes:v,enableAttribute:m,disableUnusedAttributes:x}}function u_(n,e,t){let i;function r(l){i=l}function s(l,c){n.drawArrays(i,l,c),t.update(c,i,1)}function a(l,c,d){d!==0&&(n.drawArraysInstanced(i,l,c,d),t.update(c,i,d))}function o(l,c,d){if(d===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(i,l,0,c,0,d);let h=0;for(let f=0;f<d;f++)h+=c[f];t.update(h,i,1)}this.setMode=r,this.render=s,this.renderInstances=a,this.renderMultiDraw=o}function h_(n,e,t,i){let r;function s(){if(r!==void 0)return r;if(e.has("EXT_texture_filter_anisotropic")===!0){const T=e.get("EXT_texture_filter_anisotropic");r=n.getParameter(T.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else r=0;return r}function a(T){return!(T!==Wn&&i.convert(T)!==n.getParameter(n.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(T){const y=T===mi&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(T!==Tn&&T!==oi&&!y&&i.convert(T)!==n.getParameter(n.IMPLEMENTATION_COLOR_READ_TYPE))}function l(T){if(T==="highp"){if(n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.HIGH_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.HIGH_FLOAT).precision>0)return"highp";T="mediump"}return T==="mediump"&&n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.MEDIUM_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=t.precision!==void 0?t.precision:"highp";const d=l(c);d!==c&&(ke("WebGLRenderer:",c,"not supported, using",d,"instead."),c=d);const u=t.logarithmicDepthBuffer===!0,h=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control");t.reversedDepthBuffer===!0&&h===!1&&ke("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");const f=n.getParameter(n.MAX_TEXTURE_IMAGE_UNITS),p=n.getParameter(n.MAX_VERTEX_TEXTURE_IMAGE_UNITS),v=n.getParameter(n.MAX_TEXTURE_SIZE),m=n.getParameter(n.MAX_CUBE_MAP_TEXTURE_SIZE),g=n.getParameter(n.MAX_VERTEX_ATTRIBS),x=n.getParameter(n.MAX_VERTEX_UNIFORM_VECTORS),E=n.getParameter(n.MAX_VARYING_VECTORS),b=n.getParameter(n.MAX_FRAGMENT_UNIFORM_VECTORS),w=n.getParameter(n.MAX_SAMPLES),S=n.getParameter(n.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:s,getMaxPrecision:l,textureFormatReadable:a,textureTypeReadable:o,precision:c,logarithmicDepthBuffer:u,reversedDepthBuffer:h,maxTextures:f,maxVertexTextures:p,maxTextureSize:v,maxCubemapSize:m,maxAttributes:g,maxVertexUniforms:x,maxVaryings:E,maxFragmentUniforms:b,maxSamples:w,samples:S}}function f_(n){const e=this;let t=null,i=0,r=!1,s=!1;const a=new Yi,o=new qe,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,h){const f=u.length!==0||h||i!==0||r;return r=h,i=u.length,f},this.beginShadows=function(){s=!0,d(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(u,h){t=d(u,h,0)},this.setState=function(u,h,f){const p=u.clippingPlanes,v=u.clipIntersection,m=u.clipShadows,g=n.get(u);if(!r||p===null||p.length===0||s&&!m)s?d(null):c();else{const x=s?0:i,E=x*4;let b=g.clippingState||null;l.value=b,b=d(p,h,E,f);for(let w=0;w!==E;++w)b[w]=t[w];g.clippingState=b,this.numIntersection=v?this.numPlanes:0,this.numPlanes+=x}};function c(){l.value!==t&&(l.value=t,l.needsUpdate=i>0),e.numPlanes=i,e.numIntersection=0}function d(u,h,f,p){const v=u!==null?u.length:0;let m=null;if(v!==0){if(m=l.value,p!==!0||m===null){const g=f+v*4,x=h.matrixWorldInverse;o.getNormalMatrix(x),(m===null||m.length<g)&&(m=new Float32Array(g));for(let E=0,b=f;E!==v;++E,b+=4)a.copy(u[E]).applyMatrix4(x,o),a.normal.toArray(m,b),m[b+3]=a.constant}l.value=m,l.needsUpdate=!0}return e.numPlanes=v,e.numIntersection=0,m}}const jr=4,p_=6,m_=20,g_=256,Cs=new ma,th=new Qe;let zl=null,Hl=0,Gl=0,Vl=!1;const v_=new P,lr=new P;class nh{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,t=0,i=.1,r=100,s={}){const{size:a=256,position:o=v_}=s;zl=this._renderer.getRenderTarget(),Hl=this._renderer.getActiveCubeFace(),Gl=this._renderer.getActiveMipmapLevel(),Vl=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(a);const l=this._allocateTargets();return l.depthBuffer=!0,this._sceneToCubeUV(e,i,r,l,o),t>0&&this._blur(l,0,0,t),this._applyPMREM(l),this._cleanup(l),l}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=sh(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=rh(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(zl,Hl,Gl),this._renderer.xr.enabled=Vl,e.scissorTest=!1,Wr(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===vr||e.mapping===ls?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),zl=this._renderer.getRenderTarget(),Hl=this._renderer.getActiveCubeFace(),Gl=this._renderer.getActiveMipmapLevel(),Vl=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const i=t||this._allocateTargets();return this._textureToCubeUV(e,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,i={magFilter:sn,minFilter:sn,generateMipmaps:!1,type:mi,format:Wn,colorSpace:To,depthBuffer:!1},r=ih(e,t,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=ih(e,t,i);const{_lodMax:s}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods}=y_(s)),this._blurMaterial=x_(s,e,t),this._ggxMaterial=__(s,e,t)}return r}_compileMaterial(e){const t=new Un(new Ot,e);this._renderer.compile(t,Cs)}_sceneToCubeUV(e,t,i,r,s){const l=new Gn(90,1,t,i),c=[1,-1,1,1,1,1],d=[1,1,1,-1,-1,-1],u=this._renderer,h=u.autoClear,f=u.toneMapping;u.getClearColor(th),u.toneMapping=di,u.autoClear=!1,u.state.buffers.depth.getReversed()&&(u.setRenderTarget(r),u.clearDepth(),u.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new Un(new gs,new Po({name:"PMREM.Background",side:vn,depthWrite:!1,depthTest:!1})));const v=this._backgroundBox,m=v.material;let g=!1;const x=e.background;x?x.isColor&&(m.color.copy(x),e.background=null,g=!0):(m.color.copy(th),g=!0);for(let E=0;E<6;E++){const b=E%3;b===0?(l.up.set(0,c[E],0),l.position.set(s.x,s.y,s.z),l.lookAt(s.x+d[E],s.y,s.z)):b===1?(l.up.set(0,0,c[E]),l.position.set(s.x,s.y,s.z),l.lookAt(s.x,s.y+d[E],s.z)):(l.up.set(0,c[E],0),l.position.set(s.x,s.y,s.z),l.lookAt(s.x,s.y,s.z+d[E]));const w=this._cubeSize;Wr(r,b*w,E>2?w:0,w,w),u.setRenderTarget(r),g&&u.render(v,l),u.render(e,l)}u.toneMapping=f,u.autoClear=h,e.background=x}_textureToCubeUV(e,t){const i=this._renderer,r=e.mapping===vr||e.mapping===ls;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=sh()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=rh());const s=r?this._cubemapMaterial:this._equirectMaterial,a=this._lodMeshes[0];a.material=s;const o=s.uniforms;o.envMap.value=e;const l=this._cubeSize;Wr(t,0,0,3*l,2*l),i.setRenderTarget(t),i.render(a,Cs)}_applyPMREM(e){const t=this._renderer,i=t.autoClear;t.autoClear=!1;const r=this._lodMeshes.length;for(let s=1;s<r;s++)this._applyGGXFilter(e,s-1,s);t.autoClear=i}_applyGGXFilter(e,t,i){const r=this._renderer,s=this._pingPongRenderTarget,a=this._ggxMaterial,o=this._lodMeshes[i];o.material=a;const l=a.uniforms,c=i/(this._lodMeshes.length-1),d=t/(this._lodMeshes.length-1),u=Math.sqrt(c*c-d*d),h=c*1.25,f=u*h,{_lodMax:p}=this,v=this._sizeLods[i],m=3*v*(i>p-jr?i-p+jr:0),g=4*(this._cubeSize-v);l.envMap.value=e.texture,l.roughness.value=f,l.mipInt.value=p-t,Wr(s,m,g,3*v,2*v),r.setRenderTarget(s),r.render(o,Cs),l.envMap.value=s.texture,l.roughness.value=0,l.mipInt.value=p-i,Wr(e,m,g,3*v,2*v),r.setRenderTarget(e),r.render(o,Cs)}_blur(e,t,i,r){const s=this._pingPongRenderTarget,a=Math.min(r,Math.PI)/Math.SQRT2;this._blurPass(e,s,t,i,a),this._blurPass(s,e,i,i,a)}_blurPass(e,t,i,r,s){const a=this._renderer,o=this._blurMaterial,l=this._lodMeshes[r];l.material=o;const c=o.uniforms;c.envMap.value=e.texture,c.sigma.value=s,c.mipInt.value=this._lodMax-i;const d=this._sizeLods[r],u=3*d*(r>this._lodMax-jr?r-this._lodMax+jr:0),h=4*(this._cubeSize-d);Wr(t,u,h,3*d,2*d),a.setRenderTarget(t),a.render(l,Cs)}}function y_(n){const e=[],t=[];let i=n;const r=n-jr+1+p_;for(let s=0;s<r;s++){const a=Math.pow(2,i);e.push(a);const o=1/(a-2),l=-o,c=1+o,d=[l,l,c,l,c,c,l,l,c,c,l,c],u=6,h=6,f=3,p=new Float32Array(f*h*u),v=new Float32Array(f*h*u);for(let g=0;g<u;g++){const x=g%3*2/3-1,E=g>2?0:-1,b=[x,E,0,x+2/3,E,0,x+2/3,E+1,0,x,E,0,x+2/3,E+1,0,x,E+1,0];p.set(b,f*h*g);for(let w=0;w<h;w++){const S=d[w*2]*2-1,T=d[w*2+1]*2-1;g===0?lr.set(1,T,S):g===1?lr.set(-S,1,-T):g===2?lr.set(-S,T,1):g===3?lr.set(-1,T,-S):g===4?lr.set(-S,-1,T):lr.set(S,T,-1),lr.toArray(v,(g*h+w)*f)}}const m=new Ot;m.setAttribute("position",new hi(p,f)),m.setAttribute("outputDirection",new hi(v,f)),t.push(new Un(m,null)),i>jr&&i--}return{lodMeshes:t,sizeLods:e}}function ih(n,e,t){const i=new Xn(n,e,t);return i.texture.mapping=Go,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function Wr(n,e,t,i,r){n.viewport.set(e,t,i,r),n.scissor.set(e,t,i,r)}function __(n,e,t){return new gi({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:g_,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:qo(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Ai,depthTest:!1,depthWrite:!1})}function x_(n,e,t){return new gi({name:"SphericalGaussianBlur",defines:{SAMPLES:m_,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},sigma:{value:0},mipInt:{value:0}},vertexShader:qo(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float sigma;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359
			#define GOLDEN_ANGLE 2.39996322973

			void main() {

				if ( sigma == 0.0 ) {

					gl_FragColor = vec4( bilinearCubeUV( envMap, vOutputDirection, mipInt ), 1.0 );
					return;

				}

				vec3 outputDirection = normalize( vOutputDirection );

				vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
				vec3 tangent = normalize( cross( up, outputDirection ) );
				vec3 bitangent = cross( outputDirection, tangent );

				// Truncate the kernel at three standard deviations or at the antipode.
				float thetaMax = min( 3.0 * sigma, PI );
				float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

				vec3 accumColor = vec3( 0.0 );
				float accumWeight = 0.0;

				for ( int i = 0; i < SAMPLES; i ++ ) {

					// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
					float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
					float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
					float phi = float( i ) * GOLDEN_ANGLE;

					vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
					vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

					// Correct the planar sample density to solid angle.
					float weight = sin( theta ) / theta;

					accumColor += weight * bilinearCubeUV( envMap, sampleDirection, mipInt );
					accumWeight += weight;

				}

				gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

			}
		`,blending:Ai,depthTest:!1,depthWrite:!1})}function rh(){return new gi({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:qo(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Ai,depthTest:!1,depthWrite:!1})}function sh(){return new gi({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:qo(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Ai,depthTest:!1,depthWrite:!1})}function qo(){return`

		precision mediump float;
		precision mediump int;

		attribute vec3 outputDirection;

		varying vec3 vOutputDirection;

		void main() {

			vOutputDirection = outputDirection;
			gl_Position = vec4( position, 1.0 );

		}
	`}class Pf extends Xn{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const i={width:e,height:e,depth:1},r=[i,i,i,i,i,i];this.texture=new pf(r),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new gs(5,5,5),s=new gi({name:"CubemapFromEquirect",uniforms:ds(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:vn,blending:Ai});s.uniforms.tEquirect.value=t;const a=new Un(r,s),o=t.minFilter;return t.minFilter===ur&&(t.minFilter=sn),new Mv(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t=!0,i=!0,r=!0){const s=e.getRenderTarget();for(let a=0;a<6;a++)e.setRenderTarget(this,a),e.clear(t,i,r);e.setRenderTarget(s)}}function b_(n){let e=new WeakMap,t=new WeakMap,i=null;function r(h,f=!1){return h==null?null:f?a(h):s(h)}function s(h){if(h&&h.isTexture){const f=h.mapping;if(f===cl||f===dl)if(e.has(h)){const p=e.get(h).texture;return o(p,h.mapping)}else{const p=h.image;if(p&&p.height>0){const v=new Pf(p.height);return v.fromEquirectangularTexture(n,h),e.set(h,v),h.addEventListener("dispose",c),o(v.texture,h.mapping)}else return null}}return h}function a(h){if(h&&h.isTexture){const f=h.mapping,p=f===cl||f===dl,v=f===vr||f===ls;if(p||v){let m=t.get(h);const g=m!==void 0?m.texture.pmremVersion:0;if(h.isRenderTargetTexture&&h.pmremVersion!==g)return i===null&&(i=new nh(n)),m=p?i.fromEquirectangular(h,m):i.fromCubemap(h,m),m.texture.pmremVersion=h.pmremVersion,t.set(h,m),m.texture;if(m!==void 0)return m.texture;{const x=h.image;return p&&x&&x.height>0||v&&x&&l(x)?(i===null&&(i=new nh(n)),m=p?i.fromEquirectangular(h):i.fromCubemap(h),m.texture.pmremVersion=h.pmremVersion,t.set(h,m),h.addEventListener("dispose",d),m.texture):null}}}return h}function o(h,f){return f===cl?h.mapping=vr:f===dl&&(h.mapping=ls),h}function l(h){let f=0;const p=6;for(let v=0;v<p;v++)h[v]!==void 0&&f++;return f===p}function c(h){const f=h.target;f.removeEventListener("dispose",c);const p=e.get(f);p!==void 0&&(e.delete(f),p.dispose())}function d(h){const f=h.target;f.removeEventListener("dispose",d);const p=t.get(f);p!==void 0&&(t.delete(f),p.dispose())}function u(){e=new WeakMap,t=new WeakMap,i!==null&&(i.dispose(),i=null)}return{get:r,dispose:u}}function S_(n){const e={};function t(i){if(e[i]!==void 0)return e[i];const r=n.getExtension(i);return e[i]=r,r}return{has:function(i){return t(i)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(i){const r=t(i);return r===null&&ns("WebGLRenderer: "+i+" extension not supported."),r}}}function M_(n,e,t,i){const r={},s=new WeakMap;function a(u){const h=u.target;h.index!==null&&e.remove(h.index);for(const p in h.attributes)e.remove(h.attributes[p]);h.removeEventListener("dispose",a),delete r[h.id];const f=s.get(h);f&&(e.remove(f),s.delete(h)),i.releaseStatesOfGeometry(h),h.isInstancedBufferGeometry===!0&&delete h._maxInstanceCount,t.memory.geometries--}function o(u,h){return r[h.id]===!0||(h.addEventListener("dispose",a),r[h.id]=!0,t.memory.geometries++),h}function l(u){const h=u.attributes;for(const f in h)e.update(h[f],n.ARRAY_BUFFER)}function c(u){const h=[],f=u.index,p=u.attributes.position;let v=0;if(p===void 0)return;if(f!==null){const x=f.array;v=f.version;for(let E=0,b=x.length;E<b;E+=3){const w=x[E+0],S=x[E+1],T=x[E+2];h.push(w,S,S,T,T,w)}}else{const x=p.array;v=p.version;for(let E=0,b=x.length/3-1;E<b;E+=3){const w=E+0,S=E+1,T=E+2;h.push(w,S,S,T,T,w)}}const m=new(p.count>=65535?uf:df)(h,1);m.version=v;const g=s.get(u);g&&e.remove(g),s.set(u,m)}function d(u){const h=s.get(u);if(h){const f=u.index;f!==null&&h.version<f.version&&c(u)}else c(u);return s.get(u)}return{get:o,update:l,getWireframeAttribute:d}}function w_(n,e,t){let i;function r(u){i=u}let s,a;function o(u){s=u.type,a=u.bytesPerElement}function l(u,h){n.drawElements(i,h,s,u*a),t.update(h,i,1)}function c(u,h,f){f!==0&&(n.drawElementsInstanced(i,h,s,u*a,f),t.update(h,i,f))}function d(u,h,f){if(f===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(i,h,0,s,u,0,f);let v=0;for(let m=0;m<f;m++)v+=h[m];t.update(v,i,1)}this.setMode=r,this.setIndex=o,this.render=l,this.renderInstances=c,this.renderMultiDraw=d}function E_(n){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function i(s,a,o){switch(t.calls++,a){case n.TRIANGLES:t.triangles+=o*(s/3);break;case n.LINES:t.lines+=o*(s/2);break;case n.LINE_STRIP:t.lines+=o*(s-1);break;case n.LINE_LOOP:t.lines+=o*s;break;case n.POINTS:t.points+=o*s;break;default:st("WebGLInfo: Unknown draw mode:",a);break}}function r(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:r,update:i}}function T_(n,e,t){const i=new WeakMap,r=new Rt;function s(a,o,l){const c=a.morphTargetInfluences,d=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,u=d!==void 0?d.length:0;let h=i.get(o);if(h===void 0||h.count!==u){let C=function(){y.dispose(),i.delete(o),o.removeEventListener("dispose",C)};var f=C;h!==void 0&&h.texture.dispose();const p=o.morphAttributes.position!==void 0,v=o.morphAttributes.normal!==void 0,m=o.morphAttributes.color!==void 0,g=o.morphAttributes.position||[],x=o.morphAttributes.normal||[],E=o.morphAttributes.color||[];let b=0;p===!0&&(b=1),v===!0&&(b=2),m===!0&&(b=3);let w=o.attributes.position.count*b,S=1;w>e.maxTextureSize&&(S=Math.ceil(w/e.maxTextureSize),w=e.maxTextureSize);const T=new Float32Array(w*S*4*u),y=new of(T,w,S,u);y.type=oi,y.needsUpdate=!0;const A=b*4;for(let L=0;L<u;L++){const I=g[L],B=x[L],N=E[L],U=w*S*4*L;for(let V=0;V<I.count;V++){const $=V*A;p===!0&&(r.fromBufferAttribute(I,V),T[U+$+0]=r.x,T[U+$+1]=r.y,T[U+$+2]=r.z,T[U+$+3]=0),v===!0&&(r.fromBufferAttribute(B,V),T[U+$+4]=r.x,T[U+$+5]=r.y,T[U+$+6]=r.z,T[U+$+7]=0),m===!0&&(r.fromBufferAttribute(N,V),T[U+$+8]=r.x,T[U+$+9]=r.y,T[U+$+10]=r.z,T[U+$+11]=N.itemSize===4?r.w:1)}}h={count:u,texture:y,size:new le(w,S)},i.set(o,h),o.addEventListener("dispose",C)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)l.getUniforms().setValue(n,"morphTexture",a.morphTexture,t);else{let p=0;for(let m=0;m<c.length;m++)p+=c[m];const v=o.morphTargetsRelative?1:1-p;l.getUniforms().setValue(n,"morphTargetBaseInfluence",v),l.getUniforms().setValue(n,"morphTargetInfluences",c)}l.getUniforms().setValue(n,"morphTargetsTexture",h.texture,t),l.getUniforms().setValue(n,"morphTargetsTextureSize",h.size)}return{update:s}}function A_(n,e,t,i,r){let s=new WeakMap;function a(c){const d=r.render.frame,u=c.geometry,h=e.get(c,u);if(s.get(h)!==d&&(e.update(h),s.set(h,d)),c.isInstancedMesh&&(c.hasEventListener("dispose",l)===!1&&c.addEventListener("dispose",l),s.get(c)!==d&&(t.update(c.instanceMatrix,n.ARRAY_BUFFER),c.instanceColor!==null&&t.update(c.instanceColor,n.ARRAY_BUFFER),s.set(c,d))),c.isSkinnedMesh){const f=c.skeleton;s.get(f)!==d&&(f.update(),s.set(f,d))}return h}function o(){s=new WeakMap}function l(c){const d=c.target;d.removeEventListener("dispose",l),i.releaseStatesOfObject(d),t.remove(d.instanceMatrix),d.instanceColor!==null&&t.remove(d.instanceColor)}return{update:a,dispose:o}}const R_={[Vh]:"LINEAR_TONE_MAPPING",[Wh]:"REINHARD_TONE_MAPPING",[Xh]:"CINEON_TONE_MAPPING",[md]:"ACES_FILMIC_TONE_MAPPING",[Yh]:"AGX_TONE_MAPPING",[Zh]:"NEUTRAL_TONE_MAPPING",[qh]:"CUSTOM_TONE_MAPPING"};function C_(n,e,t,i,r,s){const a=new Xn(e,t,{type:n,depthBuffer:r,stencilBuffer:s,samples:i?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1});let o=null,l=null;const c=new Ot;c.setAttribute("position",new bt([-1,3,0,-1,-1,0,3,-1,0],3)),c.setAttribute("uv",new bt([0,2,0,0,2,0],2));const d=new gv({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),u=new Un(c,d),h=new ma(-1,1,1,-1,0,1);let f=null,p=null,v=!1,m,g=null,x=[],E=!1;this.setSize=function(b,w){a.setSize(b,w),o!==null&&o.setSize(b,w),l!==null&&l.setSize(b,w);for(let S=0;S<x.length;S++){const T=x[S];T.setSize&&T.setSize(b,w)}},this.setEffects=function(b){x=b,E=x.length>0&&x[0].isRenderPass===!0;const w=a.width,S=a.height;x.length>0&&o===null&&(o=new Xn(w,S,{type:mi,depthBuffer:!1,stencilBuffer:!1}),l=new Xn(w,S,{type:mi,depthBuffer:!1,stencilBuffer:!1}));for(let T=0;T<x.length;T++){const y=x[T];y.setSize&&y.setSize(w,S)}},this.begin=function(b,w){if(v||b.toneMapping===di&&x.length===0)return!1;if(g=w,w!==null){const S=w.width,T=w.height;(a.width!==S||a.height!==T)&&this.setSize(S,T)}return E===!1&&b.setRenderTarget(a),m=b.toneMapping,b.toneMapping=di,!0},this.hasRenderPass=function(){return E},this.end=function(b,w){b.toneMapping=m,v=!0;let S=a,T=o;for(let y=0;y<x.length;y++){const A=x[y];A.enabled!==!1&&(A.render(b,T,S,w),A.needsSwap!==!1&&(S=T,T=T===o?l:o))}if(f!==b.outputColorSpace||p!==b.toneMapping){f=b.outputColorSpace,p=b.toneMapping,d.defines={},at.getTransfer(f)===gt&&(d.defines.SRGB_TRANSFER="");const y=R_[p];y&&(d.defines[y]=""),d.needsUpdate=!0}d.uniforms.tDiffuse.value=S.texture,b.setRenderTarget(g),b.render(u,h),g=null,v=!1},this.isCompositing=function(){return v},this.dispose=function(){a.dispose(),o!==null&&o.dispose(),l!==null&&l.dispose(),c.dispose(),d.dispose()}}const Lf=new an,Wc=new ia(1,1),Nf=new of,Df=new ug,Uf=new pf,ah=[],oh=[],lh=new Float32Array(16),ch=new Float32Array(9),dh=new Float32Array(4);function vs(n,e,t){const i=n[0];if(i<=0||i>0)return n;const r=e*t;let s=ah[r];if(s===void 0&&(s=new Float32Array(r),ah[r]=s),e!==0){i.toArray(s,0);for(let a=1,o=0;a!==e;++a)o+=t,n[a].toArray(s,o)}return s}function Xt(n,e){if(n.length!==e.length)return!1;for(let t=0,i=n.length;t<i;t++)if(n[t]!==e[t])return!1;return!0}function qt(n,e){for(let t=0,i=e.length;t<i;t++)n[t]=e[t]}function Yo(n,e){let t=oh[e];t===void 0&&(t=new Int32Array(e),oh[e]=t);for(let i=0;i!==e;++i)t[i]=n.allocateTextureUnit();return t}function I_(n,e){const t=this.cache;t[0]!==e&&(n.uniform1f(this.addr,e),t[0]=e)}function P_(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Xt(t,e))return;n.uniform2fv(this.addr,e),qt(t,e)}}function L_(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(n.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Xt(t,e))return;n.uniform3fv(this.addr,e),qt(t,e)}}function N_(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Xt(t,e))return;n.uniform4fv(this.addr,e),qt(t,e)}}function D_(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(Xt(t,e))return;n.uniformMatrix2fv(this.addr,!1,e),qt(t,e)}else{if(Xt(t,i))return;dh.set(i),n.uniformMatrix2fv(this.addr,!1,dh),qt(t,i)}}function U_(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(Xt(t,e))return;n.uniformMatrix3fv(this.addr,!1,e),qt(t,e)}else{if(Xt(t,i))return;ch.set(i),n.uniformMatrix3fv(this.addr,!1,ch),qt(t,i)}}function O_(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(Xt(t,e))return;n.uniformMatrix4fv(this.addr,!1,e),qt(t,e)}else{if(Xt(t,i))return;lh.set(i),n.uniformMatrix4fv(this.addr,!1,lh),qt(t,i)}}function F_(n,e){const t=this.cache;t[0]!==e&&(n.uniform1i(this.addr,e),t[0]=e)}function B_(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Xt(t,e))return;n.uniform2iv(this.addr,e),qt(t,e)}}function k_(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Xt(t,e))return;n.uniform3iv(this.addr,e),qt(t,e)}}function $_(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Xt(t,e))return;n.uniform4iv(this.addr,e),qt(t,e)}}function z_(n,e){const t=this.cache;t[0]!==e&&(n.uniform1ui(this.addr,e),t[0]=e)}function H_(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Xt(t,e))return;n.uniform2uiv(this.addr,e),qt(t,e)}}function G_(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Xt(t,e))return;n.uniform3uiv(this.addr,e),qt(t,e)}}function V_(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Xt(t,e))return;n.uniform4uiv(this.addr,e),qt(t,e)}}function W_(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r);let s;this.type===n.SAMPLER_2D_SHADOW?(Wc.compareFunction=t.isReversedDepthBuffer()?Md:Sd,s=Wc):s=Lf,t.setTexture2D(e||s,r)}function X_(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTexture3D(e||Df,r)}function q_(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTextureCube(e||Uf,r)}function Y_(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTexture2DArray(e||Nf,r)}function Z_(n){switch(n){case 5126:return I_;case 35664:return P_;case 35665:return L_;case 35666:return N_;case 35674:return D_;case 35675:return U_;case 35676:return O_;case 5124:case 35670:return F_;case 35667:case 35671:return B_;case 35668:case 35672:return k_;case 35669:case 35673:return $_;case 5125:return z_;case 36294:return H_;case 36295:return G_;case 36296:return V_;case 35678:case 36198:case 36298:case 36306:case 35682:return W_;case 35679:case 36299:case 36307:return X_;case 35680:case 36300:case 36308:case 36293:return q_;case 36289:case 36303:case 36311:case 36292:return Y_}}function K_(n,e){n.uniform1fv(this.addr,e)}function J_(n,e){const t=vs(e,this.size,2);n.uniform2fv(this.addr,t)}function j_(n,e){const t=vs(e,this.size,3);n.uniform3fv(this.addr,t)}function Q_(n,e){const t=vs(e,this.size,4);n.uniform4fv(this.addr,t)}function ex(n,e){const t=vs(e,this.size,4);n.uniformMatrix2fv(this.addr,!1,t)}function tx(n,e){const t=vs(e,this.size,9);n.uniformMatrix3fv(this.addr,!1,t)}function nx(n,e){const t=vs(e,this.size,16);n.uniformMatrix4fv(this.addr,!1,t)}function ix(n,e){n.uniform1iv(this.addr,e)}function rx(n,e){n.uniform2iv(this.addr,e)}function sx(n,e){n.uniform3iv(this.addr,e)}function ax(n,e){n.uniform4iv(this.addr,e)}function ox(n,e){n.uniform1uiv(this.addr,e)}function lx(n,e){n.uniform2uiv(this.addr,e)}function cx(n,e){n.uniform3uiv(this.addr,e)}function dx(n,e){n.uniform4uiv(this.addr,e)}function ux(n,e,t){const i=this.cache,r=e.length,s=Yo(t,r);Xt(i,s)||(n.uniform1iv(this.addr,s),qt(i,s));let a;this.type===n.SAMPLER_2D_SHADOW?a=Wc:a=Lf;for(let o=0;o!==r;++o)t.setTexture2D(e[o]||a,s[o])}function hx(n,e,t){const i=this.cache,r=e.length,s=Yo(t,r);Xt(i,s)||(n.uniform1iv(this.addr,s),qt(i,s));for(let a=0;a!==r;++a)t.setTexture3D(e[a]||Df,s[a])}function fx(n,e,t){const i=this.cache,r=e.length,s=Yo(t,r);Xt(i,s)||(n.uniform1iv(this.addr,s),qt(i,s));for(let a=0;a!==r;++a)t.setTextureCube(e[a]||Uf,s[a])}function px(n,e,t){const i=this.cache,r=e.length,s=Yo(t,r);Xt(i,s)||(n.uniform1iv(this.addr,s),qt(i,s));for(let a=0;a!==r;++a)t.setTexture2DArray(e[a]||Nf,s[a])}function mx(n){switch(n){case 5126:return K_;case 35664:return J_;case 35665:return j_;case 35666:return Q_;case 35674:return ex;case 35675:return tx;case 35676:return nx;case 5124:case 35670:return ix;case 35667:case 35671:return rx;case 35668:case 35672:return sx;case 35669:case 35673:return ax;case 5125:return ox;case 36294:return lx;case 36295:return cx;case 36296:return dx;case 35678:case 36198:case 36298:case 36306:case 35682:return ux;case 35679:case 36299:case 36307:return hx;case 35680:case 36300:case 36308:case 36293:return fx;case 36289:case 36303:case 36311:case 36292:return px}}class gx{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.setValue=Z_(t.type)}}class vx{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=mx(t.type)}}class yx{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,i){const r=this.seq;for(let s=0,a=r.length;s!==a;++s){const o=r[s];o.setValue(e,t[o.id],i)}}}const Wl=/(\w+)(\])?(\[|\.)?/g;function uh(n,e){n.seq.push(e),n.map[e.id]=e}function _x(n,e,t){const i=n.name,r=i.length;for(Wl.lastIndex=0;;){const s=Wl.exec(i),a=Wl.lastIndex;let o=s[1];const l=s[2]==="]",c=s[3];if(l&&(o=o|0),c===void 0||c==="["&&a+2===r){uh(t,c===void 0?new gx(o,n,e):new vx(o,n,e));break}else{let u=t.map[o];u===void 0&&(u=new yx(o),uh(t,u)),t=u}}}class ho{constructor(e,t){this.seq=[],this.map={};const i=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let a=0;a<i;++a){const o=e.getActiveUniform(t,a),l=e.getUniformLocation(t,o.name);_x(o,l,this)}const r=[],s=[];for(const a of this.seq)a.type===e.SAMPLER_2D_SHADOW||a.type===e.SAMPLER_CUBE_SHADOW||a.type===e.SAMPLER_2D_ARRAY_SHADOW?r.push(a):s.push(a);r.length>0&&(this.seq=r.concat(s))}setValue(e,t,i,r){const s=this.map[t];s!==void 0&&s.setValue(e,i,r)}setOptional(e,t,i){const r=t[i];r!==void 0&&this.setValue(e,i,r)}static upload(e,t,i,r){for(let s=0,a=t.length;s!==a;++s){const o=t[s],l=i[o.id];l.needsUpdate!==!1&&o.setValue(e,l.value,r)}}static seqWithValue(e,t){const i=[];for(let r=0,s=e.length;r!==s;++r){const a=e[r];a.id in t&&i.push(a)}return i}}function hh(n,e,t){const i=n.createShader(e);return n.shaderSource(i,t),n.compileShader(i),i}const xx=37297;let bx=0;function Sx(n,e){const t=n.split(`
`),i=[],r=Math.max(e-6,0),s=Math.min(e+6,t.length);for(let a=r;a<s;a++){const o=a+1;i.push(`${o===e?">":" "} ${o}: ${t[a]}`)}return i.join(`
`)}const fh=new qe;function Mx(n){at._getMatrix(fh,at.workingColorSpace,n);const e=`mat3( ${fh.elements.map(t=>t.toFixed(4))} )`;switch(at.getTransfer(n)){case Ao:return[e,"LinearTransferOETF"];case gt:return[e,"sRGBTransferOETF"];default:return ke("WebGLProgram: Unsupported color space: ",n),[e,"LinearTransferOETF"]}}function ph(n,e,t){const i=n.getShaderParameter(e,n.COMPILE_STATUS),s=(n.getShaderInfoLog(e)||"").trim();if(i&&s==="")return"";const a=/ERROR: 0:(\d+)/.exec(s);if(a){const o=parseInt(a[1]);return t.toUpperCase()+`

`+s+`

`+Sx(n.getShaderSource(e),o)}else return s}function wx(n,e){const t=Mx(e);return[`vec4 ${n}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}const Ex={[Vh]:"Linear",[Wh]:"Reinhard",[Xh]:"Cineon",[md]:"ACESFilmic",[Yh]:"AgX",[Zh]:"Neutral",[qh]:"Custom"};function Tx(n,e){const t=Ex[e];return t===void 0?(ke("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+n+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+n+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const ja=new P;function Ax(){at.getLuminanceCoefficients(ja);const n=ja.x.toFixed(4),e=ja.y.toFixed(4),t=ja.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${n}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function Rx(n){return[n.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",n.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Bs).join(`
`)}function Cx(n){const e=[];for(const t in n){const i=n[t];i!==!1&&e.push("#define "+t+" "+i)}return e.join(`
`)}function Ix(n,e){const t={},i=n.getProgramParameter(e,n.ACTIVE_ATTRIBUTES);for(let r=0;r<i;r++){const s=n.getActiveAttrib(e,r),a=s.name;let o=1;s.type===n.FLOAT_MAT2&&(o=2),s.type===n.FLOAT_MAT3&&(o=3),s.type===n.FLOAT_MAT4&&(o=4),t[a]={type:s.type,location:n.getAttribLocation(e,a),locationSize:o}}return t}function Bs(n){return n!==""}function mh(n,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return n.replace(/NUM_SUN_LIGHTS/g,e.numSunLights).replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,e.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function gh(n,e){return n.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const Px=/^[ \t]*#include +<([\w\d./]+)>/gm;function Xc(n){return n.replace(Px,Nx)}const Lx=new Map;function Nx(n,e){let t=je[e];if(t===void 0){const i=Lx.get(e);if(i!==void 0)t=je[i],ke('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,i);else throw new Error("THREE.WebGLProgram: Can not resolve #include <"+e+">")}return Xc(t)}const Dx=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function vh(n){return n.replace(Dx,Ux)}function Ux(n,e,t,i){let r="";for(let s=parseInt(e);s<parseInt(t);s++)r+=i.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return r}function yh(n){let e=`precision ${n.precision} float;
	precision ${n.precision} int;
	precision ${n.precision} sampler2D;
	precision ${n.precision} samplerCube;
	precision ${n.precision} sampler3D;
	precision ${n.precision} sampler2DArray;
	precision ${n.precision} sampler2DShadow;
	precision ${n.precision} samplerCubeShadow;
	precision ${n.precision} sampler2DArrayShadow;
	precision ${n.precision} isampler2D;
	precision ${n.precision} isampler3D;
	precision ${n.precision} isamplerCube;
	precision ${n.precision} isampler2DArray;
	precision ${n.precision} usampler2D;
	precision ${n.precision} usampler3D;
	precision ${n.precision} usamplerCube;
	precision ${n.precision} usampler2DArray;
	`;return n.precision==="highp"?e+=`
#define HIGH_PRECISION`:n.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:n.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}const Ox={[ks]:"SHADOWMAP_TYPE_PCF",[Os]:"SHADOWMAP_TYPE_VSM"};function Fx(n){return Ox[n.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const Bx={[vr]:"ENVMAP_TYPE_CUBE",[ls]:"ENVMAP_TYPE_CUBE",[Go]:"ENVMAP_TYPE_CUBE_UV"};function kx(n){return n.envMap===!1?"ENVMAP_TYPE_CUBE":Bx[n.envMapMode]||"ENVMAP_TYPE_CUBE"}const $x={[ls]:"ENVMAP_MODE_REFRACTION"};function zx(n){return n.envMap===!1?"ENVMAP_MODE_REFLECTION":$x[n.envMapMode]||"ENVMAP_MODE_REFLECTION"}const Hx={[Gh]:"ENVMAP_BLENDING_MULTIPLY",[Rm]:"ENVMAP_BLENDING_MIX",[Cm]:"ENVMAP_BLENDING_ADD"};function Gx(n){return n.envMap===!1?"ENVMAP_BLENDING_NONE":Hx[n.combine]||"ENVMAP_BLENDING_NONE"}function Vx(n){const e=n.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,i=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:i,maxMip:t}}function Wx(n,e,t,i){const r=n.getContext(),s=t.defines;let a=t.vertexShader,o=t.fragmentShader;const l=Fx(t),c=kx(t),d=zx(t),u=Gx(t),h=Vx(t),f=Rx(t),p=Cx(s),v=r.createProgram();let m,g,x=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(m=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p].filter(Bs).join(`
`),m.length>0&&(m+=`
`),g=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p].filter(Bs).join(`
`),g.length>0&&(g+=`
`)):(m=[yh(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+d:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexNormals?"#define HAS_NORMAL":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Bs).join(`
`),g=[yh(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+d:"",t.envMap?"#define "+u:"",h?"#define CUBEUV_TEXEL_WIDTH "+h.texelWidth:"",h?"#define CUBEUV_TEXEL_HEIGHT "+h.texelHeight:"",h?"#define CUBEUV_MAX_MIP "+h.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.retroreflection?"#define USE_RETROREFLECTION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas||t.batchingColor?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==di?"#define TONE_MAPPING":"",t.toneMapping!==di?je.tonemapping_pars_fragment:"",t.toneMapping!==di?Tx("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",je.colorspace_pars_fragment,wx("linearToOutputTexel",t.outputColorSpace),Ax(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Bs).join(`
`)),a=Xc(a),a=mh(a,t),a=gh(a,t),o=Xc(o),o=mh(o,t),o=gh(o,t),a=vh(a),o=vh(o),t.isRawShaderMaterial!==!0&&(x=`#version 300 es
`,m=[f,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,g=["#define varying in",t.glslVersion===pu?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===pu?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+g);const E=x+m+a,b=x+g+o,w=hh(r,r.VERTEX_SHADER,E),S=hh(r,r.FRAGMENT_SHADER,b);r.attachShader(v,w),r.attachShader(v,S),t.index0AttributeName!==void 0?r.bindAttribLocation(v,0,t.index0AttributeName):t.hasPositionAttribute===!0&&r.bindAttribLocation(v,0,"position"),r.linkProgram(v);function T(L){if(n.debug.checkShaderErrors){const I=r.getProgramInfoLog(v)||"",B=r.getShaderInfoLog(w)||"",N=r.getShaderInfoLog(S)||"",U=I.trim(),V=B.trim(),$=N.trim();let ie=!0,X=!0;if(r.getProgramParameter(v,r.LINK_STATUS)===!1)if(ie=!1,typeof n.debug.onShaderError=="function")n.debug.onShaderError(r,v,w,S);else{const Q=ph(r,w,"vertex"),ne=ph(r,S,"fragment");st("WebGLProgram: Shader Error "+r.getError()+" - VALIDATE_STATUS "+r.getProgramParameter(v,r.VALIDATE_STATUS)+`

Material Name: `+L.name+`
Material Type: `+L.type+`

Program Info Log: `+U+`
`+Q+`
`+ne)}else U!==""?ke("WebGLProgram: Program Info Log:",U):(V===""||$==="")&&(X=!1);X&&(L.diagnostics={runnable:ie,programLog:U,vertexShader:{log:V,prefix:m},fragmentShader:{log:$,prefix:g}})}r.deleteShader(w),r.deleteShader(S),y=new ho(r,v),A=Ix(r,v)}let y;this.getUniforms=function(){return y===void 0&&T(this),y};let A;this.getAttributes=function(){return A===void 0&&T(this),A};let C=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return C===!1&&(C=r.getProgramParameter(v,xx)),C},this.destroy=function(){i.releaseStatesOfProgram(this),r.deleteProgram(v),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=bx++,this.cacheKey=e,this.usedTimes=1,this.program=v,this.vertexShader=w,this.fragmentShader=S,this}let Xx=0;class qx{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,i){const r=this._getShaderCacheForMaterial(e);return r.has(t)===!1&&(r.add(t),t.usedTimes++),r.has(i)===!1&&(r.add(i),i.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const i of t)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let i=t.get(e);return i===void 0&&(i=new Set,t.set(e,i)),i}_getShaderStage(e){const t=this.shaderCache;let i=t.get(e);return i===void 0&&(i=new Yx(e),t.set(e,i)),i}}class Yx{constructor(e){this.id=Xx++,this.code=e,this.usedTimes=0}}function Zx(n){return n===yr||n===wo||n===Eo}function Kx(n,e,t,i,r,s){const a=new Td,o=new qx,l=new Set,c=[],d=new Map,u=i.logarithmicDepthBuffer;let h=i.precision;const f={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function p(y){return l.add(y),y===0?"uv":`uv${y}`}function v(y,A,C,L,I,B){const N=L.fog,U=I.geometry,V=y.isMeshStandardMaterial||y.isMeshLambertMaterial||y.isMeshPhongMaterial?L.environment:null,$=y.isMeshStandardMaterial||y.isMeshLambertMaterial&&!y.envMap||y.isMeshPhongMaterial&&!y.envMap,ie=e.get(y.envMap||V,$),X=ie&&ie.mapping===Go?ie.image.height:null,Q=f[y.type];y.precision!==null&&(h=i.getMaxPrecision(y.precision),h!==y.precision&&ke("WebGLProgram.getParameters:",y.precision,"not supported, using",h,"instead."));const ne=U.morphAttributes.position||U.morphAttributes.normal||U.morphAttributes.color,Pe=ne!==void 0?ne.length:0;let Ee=0;U.morphAttributes.position!==void 0&&(Ee=1),U.morphAttributes.normal!==void 0&&(Ee=2),U.morphAttributes.color!==void 0&&(Ee=3);let ut,tt,lt,Z;if(Q){const Mt=si[Q];ut=Mt.vertexShader,tt=Mt.fragmentShader}else{ut=y.vertexShader,tt=y.fragmentShader;const Mt=o.getVertexShaderStage(y),ft=o.getFragmentShaderStage(y);o.update(y,Mt,ft),lt=Mt.id,Z=ft.id}const ee=n.getRenderTarget(),ye=n.state.buffers.depth.getReversed(),ze=I.isInstancedMesh===!0,Se=I.isBatchedMesh===!0,He=!!y.map,mt=!!y.matcap,te=!!ie,se=!!y.aoMap,ae=!!y.lightMap,oe=!!y.bumpMap&&y.wireframe===!1,ue=!!y.normalMap,Fe=!!y.displacementMap,Ue=!!y.emissiveMap,Ge=!!y.metalnessMap,Xe=!!y.roughnessMap,D=y.anisotropy>0,ht=y.clearcoat>0,nt=y.dispersion>0,R=y.retroreflectivity>0,_=y.iridescence>0,k=y.sheen>0,G=y.transmission>0,q=D&&!!y.anisotropyMap,ce=ht&&!!y.clearcoatMap,de=ht&&!!y.clearcoatNormalMap,Y=ht&&!!y.clearcoatRoughnessMap,j=_&&!!y.iridescenceMap,he=_&&!!y.iridescenceThicknessMap,Le=k&&!!y.sheenColorMap,ge=k&&!!y.sheenRoughnessMap,fe=!!y.specularMap,Ne=!!y.specularColorMap,Be=!!y.specularIntensityMap,Ze=G&&!!y.transmissionMap,F=G&&!!y.thicknessMap,pe=!!y.gradientMap,K=!!y.alphaMap,me=y.alphaTest>0,be=!!y.alphaHash,re=!!y.extensions;let De=di;y.toneMapped&&(ee===null||ee.isXRRenderTarget===!0)&&(De=n.toneMapping);const Ce={shaderID:Q,shaderType:y.type,shaderName:y.name,vertexShader:ut,fragmentShader:tt,defines:y.defines,customVertexShaderID:lt,customFragmentShaderID:Z,isRawShaderMaterial:y.isRawShaderMaterial===!0,glslVersion:y.glslVersion,precision:h,batching:Se,batchingColor:Se&&I._colorsTexture!==null,instancing:ze,instancingColor:ze&&I.instanceColor!==null,instancingMorph:ze&&I.morphTexture!==null,outputColorSpace:ee===null?n.outputColorSpace:ee.isXRRenderTarget===!0?ee.texture.colorSpace:at.workingColorSpace,alphaToCoverage:!!y.alphaToCoverage,map:He,matcap:mt,envMap:te,envMapMode:te&&ie.mapping,envMapCubeUVHeight:X,aoMap:se,lightMap:ae,bumpMap:oe,normalMap:ue,displacementMap:Fe,emissiveMap:Ue,normalMapObjectSpace:ue&&y.normalMapType===Lm,normalMapTangentSpace:ue&&y.normalMapType===kc,packedNormalMap:ue&&y.normalMapType===kc&&Zx(y.normalMap.format),metalnessMap:Ge,roughnessMap:Xe,anisotropy:D,anisotropyMap:q,clearcoat:ht,clearcoatMap:ce,clearcoatNormalMap:de,clearcoatRoughnessMap:Y,dispersion:nt,retroreflection:R,iridescence:_,iridescenceMap:j,iridescenceThicknessMap:he,sheen:k,sheenColorMap:Le,sheenRoughnessMap:ge,specularMap:fe,specularColorMap:Ne,specularIntensityMap:Be,transmission:G,transmissionMap:Ze,thicknessMap:F,gradientMap:pe,opaque:y.transparent===!1&&y.blending===$s&&y.alphaToCoverage===!1,alphaMap:K,alphaTest:me,alphaHash:be,combine:y.combine,mapUv:He&&p(y.map.channel),aoMapUv:se&&p(y.aoMap.channel),lightMapUv:ae&&p(y.lightMap.channel),bumpMapUv:oe&&p(y.bumpMap.channel),normalMapUv:ue&&p(y.normalMap.channel),displacementMapUv:Fe&&p(y.displacementMap.channel),emissiveMapUv:Ue&&p(y.emissiveMap.channel),metalnessMapUv:Ge&&p(y.metalnessMap.channel),roughnessMapUv:Xe&&p(y.roughnessMap.channel),anisotropyMapUv:q&&p(y.anisotropyMap.channel),clearcoatMapUv:ce&&p(y.clearcoatMap.channel),clearcoatNormalMapUv:de&&p(y.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Y&&p(y.clearcoatRoughnessMap.channel),iridescenceMapUv:j&&p(y.iridescenceMap.channel),iridescenceThicknessMapUv:he&&p(y.iridescenceThicknessMap.channel),sheenColorMapUv:Le&&p(y.sheenColorMap.channel),sheenRoughnessMapUv:ge&&p(y.sheenRoughnessMap.channel),specularMapUv:fe&&p(y.specularMap.channel),specularColorMapUv:Ne&&p(y.specularColorMap.channel),specularIntensityMapUv:Be&&p(y.specularIntensityMap.channel),transmissionMapUv:Ze&&p(y.transmissionMap.channel),thicknessMapUv:F&&p(y.thicknessMap.channel),alphaMapUv:K&&p(y.alphaMap.channel),vertexTangents:!!U.attributes.tangent&&(ue||D),vertexNormals:!!U.attributes.normal,vertexColors:y.vertexColors,vertexAlphas:y.vertexColors===!0&&!!U.attributes.color&&U.attributes.color.itemSize===4,pointsUvs:I.isPoints===!0&&!!U.attributes.uv&&(He||K),fog:!!N,useFog:y.fog===!0,fogExp2:!!N&&N.isFogExp2,flatShading:y.wireframe===!1&&(y.flatShading===!0||U.attributes.normal===void 0&&ue===!1&&(y.isMeshLambertMaterial||y.isMeshPhongMaterial||y.isMeshStandardMaterial||y.isMeshPhysicalMaterial)),sizeAttenuation:y.sizeAttenuation===!0,logarithmicDepthBuffer:u,reversedDepthBuffer:ye,skinning:I.isSkinnedMesh===!0,hasPositionAttribute:U.attributes.position!==void 0,morphTargets:U.morphAttributes.position!==void 0,morphNormals:U.morphAttributes.normal!==void 0,morphColors:U.morphAttributes.color!==void 0,morphTargetsCount:Pe,morphTextureStride:Ee,numSunLights:A.sun.length,numDirLights:A.directional.length,numPointLights:A.point.length,numSpotLights:A.spot.length,numSpotLightMaps:A.spotLightMap.length,numRectAreaLights:A.rectArea.length,numHemiLights:A.hemi.length,numSunLightShadows:A.sunShadowMap.length,numDirLightShadows:A.directionalShadowMap.length,numPointLightShadows:A.pointShadowMap.length,numSpotLightShadows:A.spotShadowMap.length,numSpotLightShadowsWithMaps:A.numSpotLightShadowsWithMaps,numLightProbes:A.numLightProbes,numLightProbeGrids:B.length,numClippingPlanes:s.numPlanes,numClipIntersection:s.numIntersection,dithering:y.dithering,shadowMapEnabled:n.shadowMap.enabled&&C.length>0,shadowMapType:n.shadowMap.type,toneMapping:De,decodeVideoTexture:He&&y.map.isVideoTexture===!0&&at.getTransfer(y.map.colorSpace)===gt,decodeVideoTextureEmissive:Ue&&y.emissiveMap.isVideoTexture===!0&&at.getTransfer(y.emissiveMap.colorSpace)===gt,premultipliedAlpha:y.premultipliedAlpha,doubleSided:y.side===Ei,flipSided:y.side===vn,useDepthPacking:y.depthPacking>=0,depthPacking:y.depthPacking||0,index0AttributeName:y.index0AttributeName,extensionClipCullDistance:re&&y.extensions.clipCullDistance===!0&&t.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(re&&y.extensions.multiDraw===!0||Se)&&t.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:t.has("KHR_parallel_shader_compile"),customProgramCacheKey:y.customProgramCacheKey()};return Ce.vertexUv1s=l.has(1),Ce.vertexUv2s=l.has(2),Ce.vertexUv3s=l.has(3),l.clear(),Ce}function m(y){const A=[];if(y.shaderID?A.push(y.shaderID):(A.push(y.customVertexShaderID),A.push(y.customFragmentShaderID)),y.defines!==void 0)for(const C in y.defines)A.push(C),A.push(y.defines[C]);return y.isRawShaderMaterial===!1&&(g(A,y),x(A,y),A.push(n.outputColorSpace)),A.push(y.customProgramCacheKey),A.join()}function g(y,A){y.push(A.precision),y.push(A.outputColorSpace),y.push(A.envMapMode),y.push(A.envMapCubeUVHeight),y.push(A.mapUv),y.push(A.alphaMapUv),y.push(A.lightMapUv),y.push(A.aoMapUv),y.push(A.bumpMapUv),y.push(A.normalMapUv),y.push(A.displacementMapUv),y.push(A.emissiveMapUv),y.push(A.metalnessMapUv),y.push(A.roughnessMapUv),y.push(A.anisotropyMapUv),y.push(A.clearcoatMapUv),y.push(A.clearcoatNormalMapUv),y.push(A.clearcoatRoughnessMapUv),y.push(A.iridescenceMapUv),y.push(A.iridescenceThicknessMapUv),y.push(A.sheenColorMapUv),y.push(A.sheenRoughnessMapUv),y.push(A.specularMapUv),y.push(A.specularColorMapUv),y.push(A.specularIntensityMapUv),y.push(A.transmissionMapUv),y.push(A.thicknessMapUv),y.push(A.combine),y.push(A.fogExp2),y.push(A.sizeAttenuation),y.push(A.morphTargetsCount),y.push(A.morphAttributeCount),y.push(A.numSunLights),y.push(A.numDirLights),y.push(A.numPointLights),y.push(A.numSpotLights),y.push(A.numSpotLightMaps),y.push(A.numHemiLights),y.push(A.numRectAreaLights),y.push(A.numSunLightShadows),y.push(A.numDirLightShadows),y.push(A.numPointLightShadows),y.push(A.numSpotLightShadows),y.push(A.numSpotLightShadowsWithMaps),y.push(A.numLightProbes),y.push(A.shadowMapType),y.push(A.toneMapping),y.push(A.numClippingPlanes),y.push(A.numClipIntersection),y.push(A.depthPacking)}function x(y,A){a.disableAll(),A.instancing&&a.enable(0),A.instancingColor&&a.enable(1),A.instancingMorph&&a.enable(2),A.matcap&&a.enable(3),A.envMap&&a.enable(4),A.normalMapObjectSpace&&a.enable(5),A.normalMapTangentSpace&&a.enable(6),A.clearcoat&&a.enable(7),A.iridescence&&a.enable(8),A.alphaTest&&a.enable(9),A.vertexColors&&a.enable(10),A.vertexAlphas&&a.enable(11),A.vertexUv1s&&a.enable(12),A.vertexUv2s&&a.enable(13),A.vertexUv3s&&a.enable(14),A.vertexTangents&&a.enable(15),A.anisotropy&&a.enable(16),A.alphaHash&&a.enable(17),A.batching&&a.enable(18),A.dispersion&&a.enable(19),A.retroreflection&&a.enable(24),A.batchingColor&&a.enable(20),A.gradientMap&&a.enable(21),A.packedNormalMap&&a.enable(22),A.vertexNormals&&a.enable(23),y.push(a.mask),a.disableAll(),A.fog&&a.enable(0),A.useFog&&a.enable(1),A.flatShading&&a.enable(2),A.logarithmicDepthBuffer&&a.enable(3),A.reversedDepthBuffer&&a.enable(4),A.skinning&&a.enable(5),A.morphTargets&&a.enable(6),A.morphNormals&&a.enable(7),A.morphColors&&a.enable(8),A.premultipliedAlpha&&a.enable(9),A.shadowMapEnabled&&a.enable(10),A.doubleSided&&a.enable(11),A.flipSided&&a.enable(12),A.useDepthPacking&&a.enable(13),A.dithering&&a.enable(14),A.transmission&&a.enable(15),A.sheen&&a.enable(16),A.opaque&&a.enable(17),A.pointsUvs&&a.enable(18),A.decodeVideoTexture&&a.enable(19),A.decodeVideoTextureEmissive&&a.enable(20),A.alphaToCoverage&&a.enable(21),A.numLightProbeGrids>0&&a.enable(22),A.hasPositionAttribute&&a.enable(23),y.push(a.mask)}function E(y){const A=f[y.type];let C;if(A){const L=si[A];C=fv.clone(L.uniforms)}else C=y.uniforms;return C}function b(y,A){let C=d.get(A);return C!==void 0?++C.usedTimes:(C=new Wx(n,A,y,r),c.push(C),d.set(A,C)),C}function w(y){if(--y.usedTimes===0){const A=c.indexOf(y);c[A]=c[c.length-1],c.pop(),d.delete(y.cacheKey),y.destroy()}}function S(y){o.remove(y)}function T(){o.dispose()}return{getParameters:v,getProgramCacheKey:m,getUniforms:E,acquireProgram:b,releaseProgram:w,releaseShaderCache:S,programs:c,dispose:T}}function Jx(){let n=new WeakMap;function e(a){return n.has(a)}function t(a){let o=n.get(a);return o===void 0&&(o={},n.set(a,o)),o}function i(a){n.delete(a)}function r(a,o,l){n.get(a)[o]=l}function s(){n=new WeakMap}return{has:e,get:t,remove:i,update:r,dispose:s}}function jx(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.material.id!==e.material.id?n.material.id-e.material.id:n.materialVariant!==e.materialVariant?n.materialVariant-e.materialVariant:n.z!==e.z?n.z-e.z:n.id-e.id}function _h(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.z!==e.z?e.z-n.z:n.id-e.id}function xh(){const n=[];let e=0;const t=[],i=[],r=[];function s(){e=0,t.length=0,i.length=0,r.length=0}function a(h){let f=0;return h.isInstancedMesh&&(f+=2),h.isSkinnedMesh&&(f+=1),f}function o(h,f,p,v,m,g){let x=n[e];return x===void 0?(x={id:h.id,object:h,geometry:f,material:p,materialVariant:a(h),groupOrder:v,renderOrder:h.renderOrder,z:m,group:g},n[e]=x):(x.id=h.id,x.object=h,x.geometry=f,x.material=p,x.materialVariant=a(h),x.groupOrder=v,x.renderOrder=h.renderOrder,x.z=m,x.group=g),e++,x}function l(h,f,p,v,m,g,x){x.reversedDepth===!0&&(m=-m);const E=o(h,f,p,v,m,g);p.transmission>0?i.push(E):p.transparent===!0?r.push(E):t.push(E)}function c(h,f,p,v,m,g){const x=o(h,f,p,v,m,g);p.transmission>0?i.unshift(x):p.transparent===!0?r.unshift(x):t.unshift(x)}function d(h,f){t.length>1&&t.sort(h||jx),i.length>1&&i.sort(f||_h),r.length>1&&r.sort(f||_h)}function u(){for(let h=e,f=n.length;h<f;h++){const p=n[h];if(p.id===null)break;p.id=null,p.object=null,p.geometry=null,p.material=null,p.group=null}}return{opaque:t,transmissive:i,transparent:r,init:s,push:l,unshift:c,finish:u,sort:d}}function Qx(){let n=new WeakMap;function e(i,r){const s=n.get(i);let a;return s===void 0?(a=new xh,n.set(i,[a])):r>=s.length?(a=new xh,s.push(a)):a=s[r],a}function t(){n=new WeakMap}return{get:e,dispose:t}}function eb(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"SunLight":case"DirectionalLight":t={direction:new P,color:new Qe};break;case"SpotLight":t={position:new P,direction:new P,color:new Qe,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new P,color:new Qe,distance:0,decay:0};break;case"HemisphereLight":t={direction:new P,skyColor:new Qe,groundColor:new Qe};break;case"RectAreaLight":t={color:new Qe,position:new P,halfWidth:new P,halfHeight:new P};break}return n[e.id]=t,t}}}function tb(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"SunLight":case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new le};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new le};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new le,shadowCameraNear:1,shadowCameraFar:1e3};break}return n[e.id]=t,t}}}let nb=0;function ib(n,e){return(e.castShadow?2:0)-(n.castShadow?2:0)+(e.map?1:0)-(n.map?1:0)}function rb(n){const e=new eb,t=tb(),i={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)i.probe.push(new P);const r=new P,s=new yt,a=new yt;function o(c){let d=0,u=0,h=0;for(let I=0;I<9;I++)i.probe[I].set(0,0,0);let f=0,p=0,v=0,m=0,g=0,x=0,E=0,b=0,w=0,S=0,T=0,y=0,A=0,C=0;c.sort(ib);for(let I=0,B=c.length;I<B;I++){const N=c[I],U=N.color,V=N.intensity,$=N.distance;let ie=null;if(N.shadow&&N.shadow.map&&(N.shadow.map.texture.format===yr?ie=N.shadow.map.texture:ie=N.shadow.map.depthTexture||N.shadow.map.texture),N.isAmbientLight)d+=U.r*V,u+=U.g*V,h+=U.b*V;else if(N.isLightProbe){for(let X=0;X<9;X++)i.probe[X].addScaledVector(N.sh.coefficients[X],V);C++}else if(N.isSunLight){const X=e.get(N);if(X.color.copy(N.color).multiplyScalar(N.intensity),N.castShadow){const Q=N.shadow,ne=t.get(N);ne.shadowIntensity=Q.intensity,ne.shadowBias=Q.bias,ne.shadowNormalBias=Q.normalBias,ne.shadowRadius=Q.radius,ne.shadowMapSize.copy(Q.mapSize).multiply(Q.getFrameExtents()),i.sunShadow[p]=ne,i.sunShadowMap[p]=ie;const Pe=Q.getViewportCount();for(let Ee=0;Ee<Pe;Ee++)i.sunShadowMatrix[v+Ee]=Q.getMatrix(Ee),i.sunShadowCascade[v+Ee]=Q._cascadeData[Ee];v+=Pe,p++}i.sun[f]=X,f++}else if(N.isDirectionalLight){const X=e.get(N);if(X.color.copy(N.color).multiplyScalar(N.intensity),N.castShadow){const Q=N.shadow,ne=t.get(N);ne.shadowIntensity=Q.intensity,ne.shadowBias=Q.bias,ne.shadowNormalBias=Q.normalBias,ne.shadowRadius=Q.radius,ne.shadowMapSize=Q.mapSize,i.directionalShadow[m]=ne,i.directionalShadowMap[m]=ie,i.directionalShadowMatrix[m]=N.shadow.matrix,w++}i.directional[m]=X,m++}else if(N.isSpotLight){const X=e.get(N);X.position.setFromMatrixPosition(N.matrixWorld),X.color.copy(U).multiplyScalar(V),X.distance=$,X.coneCos=Math.cos(N.angle),X.penumbraCos=Math.cos(N.angle*(1-N.penumbra)),X.decay=N.decay,i.spot[x]=X;const Q=N.shadow;if(N.map&&(i.spotLightMap[y]=N.map,y++,Q.updateMatrices(N),N.castShadow&&A++),i.spotLightMatrix[x]=Q.matrix,N.castShadow){const ne=t.get(N);ne.shadowIntensity=Q.intensity,ne.shadowBias=Q.bias,ne.shadowNormalBias=Q.normalBias,ne.shadowRadius=Q.radius,ne.shadowMapSize=Q.mapSize,i.spotShadow[x]=ne,i.spotShadowMap[x]=ie,T++}x++}else if(N.isRectAreaLight){const X=e.get(N);X.color.copy(U).multiplyScalar(V),X.halfWidth.set(N.width*.5,0,0),X.halfHeight.set(0,N.height*.5,0),i.rectArea[E]=X,E++}else if(N.isPointLight){const X=e.get(N);if(X.color.copy(N.color).multiplyScalar(N.intensity),X.distance=N.distance,X.decay=N.decay,N.castShadow){const Q=N.shadow,ne=t.get(N);ne.shadowIntensity=Q.intensity,ne.shadowBias=Q.bias,ne.shadowNormalBias=Q.normalBias,ne.shadowRadius=Q.radius,ne.shadowMapSize=Q.mapSize,ne.shadowCameraNear=Q.camera.near,ne.shadowCameraFar=Q.camera.far,i.pointShadow[g]=ne,i.pointShadowMap[g]=ie,i.pointShadowMatrix[g]=N.shadow.matrix,S++}i.point[g]=X,g++}else if(N.isHemisphereLight){const X=e.get(N);X.skyColor.copy(N.color).multiplyScalar(V),X.groundColor.copy(N.groundColor).multiplyScalar(V),i.hemi[b]=X,b++}}E>0&&(n.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=ve.LTC_FLOAT_1,i.rectAreaLTC2=ve.LTC_FLOAT_2):(i.rectAreaLTC1=ve.LTC_HALF_1,i.rectAreaLTC2=ve.LTC_HALF_2)),i.ambient[0]=d,i.ambient[1]=u,i.ambient[2]=h;const L=i.hash;(L.sunLength!==f||L.directionalLength!==m||L.pointLength!==g||L.spotLength!==x||L.rectAreaLength!==E||L.hemiLength!==b||L.numSunShadows!==p||L.numDirectionalShadows!==w||L.numPointShadows!==S||L.numSpotShadows!==T||L.numSpotMaps!==y||L.numLightProbes!==C)&&(i.sun.length=f,i.directional.length=m,i.spot.length=x,i.rectArea.length=E,i.point.length=g,i.hemi.length=b,i.sunShadow.length=p,i.sunShadowMap.length=p,i.sunShadowMatrix.length=v,i.sunShadowCascade.length=v,i.directionalShadow.length=w,i.directionalShadowMap.length=w,i.directionalShadowMatrix.length=w,i.pointShadow.length=S,i.pointShadowMap.length=S,i.pointShadowMatrix.length=S,i.spotShadow.length=T,i.spotShadowMap.length=T,i.spotLightMatrix.length=T+y-A,i.spotLightMap.length=y,i.numSpotLightShadowsWithMaps=A,i.numLightProbes=C,L.sunLength=f,L.directionalLength=m,L.pointLength=g,L.spotLength=x,L.rectAreaLength=E,L.hemiLength=b,L.numSunShadows=p,L.numDirectionalShadows=w,L.numPointShadows=S,L.numSpotShadows=T,L.numSpotMaps=y,L.numLightProbes=C,i.version=nb++)}function l(c,d){let u=0,h=0,f=0,p=0,v=0,m=0;const g=d.matrixWorldInverse;for(let x=0,E=c.length;x<E;x++){const b=c[x];if(b.isSunLight){const w=i.sun[u];w.direction.setFromMatrixPosition(b.matrixWorld),w.direction.transformDirection(g),u++}else if(b.isDirectionalLight){const w=i.directional[h];w.direction.setFromMatrixPosition(b.matrixWorld),r.setFromMatrixPosition(b.target.matrixWorld),w.direction.sub(r),w.direction.transformDirection(g),h++}else if(b.isSpotLight){const w=i.spot[p];w.position.setFromMatrixPosition(b.matrixWorld),w.position.applyMatrix4(g),w.direction.setFromMatrixPosition(b.matrixWorld),r.setFromMatrixPosition(b.target.matrixWorld),w.direction.sub(r),w.direction.transformDirection(g),p++}else if(b.isRectAreaLight){const w=i.rectArea[v];w.position.setFromMatrixPosition(b.matrixWorld),w.position.applyMatrix4(g),a.identity(),s.copy(b.matrixWorld),s.premultiply(g),a.extractRotation(s),w.halfWidth.set(b.width*.5,0,0),w.halfHeight.set(0,b.height*.5,0),w.halfWidth.applyMatrix4(a),w.halfHeight.applyMatrix4(a),v++}else if(b.isPointLight){const w=i.point[f];w.position.setFromMatrixPosition(b.matrixWorld),w.position.applyMatrix4(g),f++}else if(b.isHemisphereLight){const w=i.hemi[m];w.direction.setFromMatrixPosition(b.matrixWorld),w.direction.transformDirection(g),m++}}}return{setup:o,setupView:l,state:i}}function bh(n){const e=new rb(n),t=[],i=[],r=[];function s(h){u.camera=h,t.length=0,i.length=0,r.length=0}function a(h){t.push(h)}function o(h){i.push(h)}function l(h){r.push(h)}function c(){e.setup(t)}function d(h){e.setupView(t,h)}const u={lightsArray:t,shadowsArray:i,lightProbeGridArray:r,camera:null,lights:e,transmissionRenderTarget:{},textureUnits:0};return{init:s,state:u,setupLights:c,setupLightsView:d,pushLight:a,pushShadow:o,pushLightProbeGrid:l}}function sb(n){let e=new WeakMap;function t(r,s=0){const a=e.get(r);let o;return a===void 0?(o=new bh(n),e.set(r,[o])):s>=a.length?(o=new bh(n),a.push(o)):o=a[s],o}function i(){e=new WeakMap}return{get:t,dispose:i}}const ab=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,ob=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,lb=[new P(1,0,0),new P(-1,0,0),new P(0,1,0),new P(0,-1,0),new P(0,0,1),new P(0,0,-1)],cb=[new P(0,-1,0),new P(0,-1,0),new P(0,0,1),new P(0,0,-1),new P(0,-1,0),new P(0,-1,0)],Sh=new yt,Is=new P,Xl=new P;function db(n,e,t){let i=new Ad;const r=new le,s=new le,a=new Rt,o=new vv,l=new yv,c={},d=t.maxTextureSize,u={[gr]:vn,[vn]:gr,[Ei]:Ei},h=new gi({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new le},radius:{value:4}},vertexShader:ab,fragmentShader:ob}),f=h.clone();f.defines.HORIZONTAL_PASS=1;const p=new Ot;p.setAttribute("position",new hi(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const v=new Un(p,h),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=ks;let g=this.type;this.render=function(S,T,y){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||S.length===0)return;this.type===cm&&(ke("WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead."),this.type=ks);const A=n.getRenderTarget(),C=n.getActiveCubeFace(),L=n.getActiveMipmapLevel(),I=n.state;I.setBlending(Ai),I.buffers.depth.getReversed()===!0?I.buffers.color.setClear(0,0,0,0):I.buffers.color.setClear(1,1,1,1),I.buffers.depth.setTest(!0),I.setScissorTest(!1);const B=g!==this.type;B&&T.traverse(function(N){N.material&&(Array.isArray(N.material)?N.material.forEach(U=>U.needsUpdate=!0):N.material.needsUpdate=!0)});for(let N=0,U=S.length;N<U;N++){const V=S[N],$=V.shadow;if($===void 0){ke("WebGLShadowMap:",V,"has no shadow.");continue}if($.autoUpdate===!1&&$.needsUpdate===!1)continue;r.copy($.mapSize);const ie=$.getFrameExtents();r.multiply(ie),s.copy($.mapSize),(r.x>d||r.y>d)&&(r.x>d&&(s.x=Math.floor(d/ie.x),r.x=s.x*ie.x,$.mapSize.x=s.x),r.y>d&&(s.y=Math.floor(d/ie.y),r.y=s.y*ie.y,$.mapSize.y=s.y));const X=n.state.buffers.depth.getReversed();if($.camera._reversedDepth=X,$.map===null||B===!0){if($.map!==null&&($.map.depthTexture!==null&&($.map.depthTexture.dispose(),$.map.depthTexture=null),$.map.dispose()),this.type===Os){if(V.isPointLight){ke("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}$.map=new Xn(r.x,r.y,{format:yr,type:mi,minFilter:sn,magFilter:sn,generateMipmaps:!1}),$.map.texture.name=V.name+".shadowMap",$.map.depthTexture=new ia(r.x,r.y,oi),$.map.depthTexture.name=V.name+".shadowMapDepth",$.map.depthTexture.format=Li,$.map.depthTexture.compareFunction=null,$.map.depthTexture.minFilter=Jt,$.map.depthTexture.magFilter=Jt}else V.isPointLight?($.map=new Pf(r.x),$.map.depthTexture=new Lg(r.x,pi)):($.map=new Xn(r.x,r.y),$.map.depthTexture=new ia(r.x,r.y,pi)),$.map.depthTexture.name=V.name+".shadowMap",$.map.depthTexture.format=Li,this.type===ks?($.map.depthTexture.compareFunction=X?Md:Sd,$.map.depthTexture.minFilter=sn,$.map.depthTexture.magFilter=sn):($.map.depthTexture.compareFunction=null,$.map.depthTexture.minFilter=Jt,$.map.depthTexture.magFilter=Jt);$.camera.updateProjectionMatrix()}$.map.isWebGLCubeRenderTarget!==!0&&($.map.width!==r.x||$.map.height!==r.y)&&$.map.setSize(r.x,r.y);const Q=$.map.isWebGLCubeRenderTarget?6:$.getViewportCount();V.isPointLight!==!0&&$.updateMatrices(V,y);for(let ne=0;ne<Q;ne++){const Pe=$.getCamera(ne);if(V.isPointLight){const Ee=$.camera,ut=$.matrix,tt=V.distance||Ee.far;tt!==Ee.far&&(Ee.far=tt,Ee.updateProjectionMatrix()),Is.setFromMatrixPosition(V.matrixWorld),Ee.position.copy(Is),Xl.copy(Ee.position),Xl.add(lb[ne]),Ee.up.copy(cb[ne]),Ee.lookAt(Xl),Ee.updateMatrixWorld(),ut.makeTranslation(-Is.x,-Is.y,-Is.z),Sh.multiplyMatrices(Ee.projectionMatrix,Ee.matrixWorldInverse),$._frustum.setFromProjectionMatrix(Sh,Ee.coordinateSystem,Ee.reversedDepth)}if($.map.isWebGLCubeRenderTarget)n.setRenderTarget($.map,ne),n.clear();else{ne===0&&(n.setRenderTarget($.map),n.clear());const Ee=$.getViewport(ne);a.set(s.x*Ee.x,s.y*Ee.y,s.x*Ee.z,s.y*Ee.w),I.viewport(a)}i=$.getFrustum(ne),b(T,y,Pe,V,this.type)}$.isPointLightShadow!==!0&&this.type===Os&&x($,y),$.needsUpdate=!1}g=this.type,m.needsUpdate=!1,n.setRenderTarget(A,C,L)};function x(S,T){const y=e.update(v);h.defines.VSM_SAMPLES!==S.blurSamples&&(h.defines.VSM_SAMPLES=S.blurSamples,f.defines.VSM_SAMPLES=S.blurSamples,h.needsUpdate=!0,f.needsUpdate=!0),S.mapPass===null?S.mapPass=new Xn(r.x,r.y,{format:yr,type:mi}):(S.mapPass.width!==S.map.width||S.mapPass.height!==S.map.height)&&S.mapPass.setSize(S.map.width,S.map.height),h.uniforms.shadow_pass.value=S.map.depthTexture,h.uniforms.resolution.value.set(S.map.width,S.map.height),h.uniforms.radius.value=S.radius,n.setRenderTarget(S.mapPass),n.clear(),n.renderBufferDirect(T,null,y,h,v,null),f.uniforms.shadow_pass.value=S.mapPass.texture,f.uniforms.resolution.value.set(S.map.width,S.map.height),f.uniforms.radius.value=S.radius,n.setRenderTarget(S.map),n.clear(),n.renderBufferDirect(T,null,y,f,v,null)}function E(S,T,y,A){let C=null;const L=y.isPointLight===!0?S.customDistanceMaterial:S.customDepthMaterial;if(L!==void 0)C=L;else if(C=y.isPointLight===!0?l:o,n.localClippingEnabled&&T.clipShadows===!0&&Array.isArray(T.clippingPlanes)&&T.clippingPlanes.length!==0||T.displacementMap&&T.displacementScale!==0||T.alphaMap&&T.alphaTest>0||T.map&&T.alphaTest>0||T.alphaToCoverage===!0){const I=C.uuid,B=T.uuid;let N=c[I];N===void 0&&(N={},c[I]=N);let U=N[B];U===void 0&&(U=C.clone(),N[B]=U,T.addEventListener("dispose",w)),C=U}if(C.visible=T.visible,C.wireframe=T.wireframe,A===Os?C.side=T.shadowSide!==null?T.shadowSide:T.side:C.side=T.shadowSide!==null?T.shadowSide:u[T.side],C.alphaMap=T.alphaMap,C.alphaTest=T.alphaToCoverage===!0?.5:T.alphaTest,C.map=T.map,C.clipShadows=T.clipShadows,C.clippingPlanes=T.clippingPlanes,C.clipIntersection=T.clipIntersection,C.displacementMap=T.displacementMap,C.displacementScale=T.displacementScale,C.displacementBias=T.displacementBias,C.wireframeLinewidth=T.wireframeLinewidth,C.linewidth=T.linewidth,y.isPointLight===!0&&C.isMeshDistanceMaterial===!0){const I=n.properties.get(C);I.light=y}return C}function b(S,T,y,A,C){if(S.visible===!1)return;if(S.layers.test(T.layers)&&(S.isMesh||S.isLine||S.isPoints)&&(S.castShadow||S.receiveShadow&&C===Os)&&(!S.frustumCulled||S.intersectsFrustum(i))){S.modelViewMatrix.multiplyMatrices(y.matrixWorldInverse,S.matrixWorld);const B=e.update(S),N=S.material;if(Array.isArray(N)){const U=B.groups;for(let V=0,$=U.length;V<$;V++){const ie=U[V],X=N[ie.materialIndex];if(X&&X.visible){const Q=E(S,X,A,C);S.onBeforeShadow(n,S,T,y,B,Q,ie),n.renderBufferDirect(y,null,B,Q,S,ie),S.onAfterShadow(n,S,T,y,B,Q,ie)}}}else if(N.visible){const U=E(S,N,A,C);S.onBeforeShadow(n,S,T,y,B,U,null),n.renderBufferDirect(y,null,B,U,S,null),S.onAfterShadow(n,S,T,y,B,U,null)}}const I=S.children;for(let B=0,N=I.length;B<N;B++)b(I[B],T,y,A,C)}function w(S){S.target.removeEventListener("dispose",w);for(const y in c){const A=c[y],C=S.target.uuid;C in A&&(A[C].dispose(),delete A[C])}}}function ub(n,e){function t(){let F=!1;const pe=new Rt;let K=null;const me=new Rt(0,0,0,0);return{setMask:function(be){K!==be&&!F&&(n.colorMask(be,be,be,be),K=be)},setLocked:function(be){F=be},setClear:function(be,re,De,Ce,Mt){Mt===!0&&(be*=Ce,re*=Ce,De*=Ce),pe.set(be,re,De,Ce),me.equals(pe)===!1&&(n.clearColor(be,re,De,Ce),me.copy(pe))},reset:function(){F=!1,K=null,me.set(-1,0,0,0)}}}function i(){let F=!1,pe=!1,K=null,me=null,be=null;return{setReversed:function(re){if(pe!==re){const De=e.get("EXT_clip_control");re?De.clipControlEXT(De.LOWER_LEFT_EXT,De.ZERO_TO_ONE_EXT):De.clipControlEXT(De.LOWER_LEFT_EXT,De.NEGATIVE_ONE_TO_ONE_EXT),pe=re;const Ce=be;be=null,this.setClear(Ce)}},getReversed:function(){return pe},setTest:function(re){re?ee(n.DEPTH_TEST):ye(n.DEPTH_TEST)},setMask:function(re){K!==re&&!F&&(n.depthMask(re),K=re)},setFunc:function(re){if(pe&&(re=Gm[re]),me!==re){switch(re){case ec:n.depthFunc(n.NEVER);break;case tc:n.depthFunc(n.ALWAYS);break;case nc:n.depthFunc(n.LESS);break;case js:n.depthFunc(n.LEQUAL);break;case ic:n.depthFunc(n.EQUAL);break;case rc:n.depthFunc(n.GEQUAL);break;case sc:n.depthFunc(n.GREATER);break;case ac:n.depthFunc(n.NOTEQUAL);break;default:n.depthFunc(n.LEQUAL)}me=re}},setLocked:function(re){F=re},setClear:function(re){be!==re&&(be=re,pe&&(re=1-re),n.clearDepth(re))},reset:function(){F=!1,K=null,me=null,be=null,pe=!1}}}function r(){let F=!1,pe=null,K=null,me=null,be=null,re=null,De=null,Ce=null,Mt=null;return{setTest:function(ft){F||(ft?ee(n.STENCIL_TEST):ye(n.STENCIL_TEST))},setMask:function(ft){pe!==ft&&!F&&(n.stencilMask(ft),pe=ft)},setFunc:function(ft,Bn,jn){(K!==ft||me!==Bn||be!==jn)&&(n.stencilFunc(ft,Bn,jn),K=ft,me=Bn,be=jn)},setOp:function(ft,Bn,jn){(re!==ft||De!==Bn||Ce!==jn)&&(n.stencilOp(ft,Bn,jn),re=ft,De=Bn,Ce=jn)},setLocked:function(ft){F=ft},setClear:function(ft){Mt!==ft&&(n.clearStencil(ft),Mt=ft)},reset:function(){F=!1,pe=null,K=null,me=null,be=null,re=null,De=null,Ce=null,Mt=null}}}const s=new t,a=new i,o=new r,l=new WeakMap,c=new WeakMap;let d={},u={},h={},f=new WeakMap,p=[],v=null,m=!1,g=null,x=null,E=null,b=null,w=null,S=null,T=null,y=new Qe(0,0,0),A=0,C=!1,L=null,I=null,B=null,N=null,U=null;const V=n.getParameter(n.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let $=!1,ie=0;const X=n.getParameter(n.VERSION);X.indexOf("WebGL")!==-1?(ie=parseFloat(/^WebGL (\d)/.exec(X)[1]),$=ie>=1):X.indexOf("OpenGL ES")!==-1&&(ie=parseFloat(/^OpenGL ES (\d)/.exec(X)[1]),$=ie>=2);let Q=null,ne={};const Pe=n.getParameter(n.SCISSOR_BOX),Ee=n.getParameter(n.VIEWPORT),ut=new Rt().fromArray(Pe),tt=new Rt().fromArray(Ee);function lt(F,pe,K,me){const be=new Uint8Array(4),re=n.createTexture();n.bindTexture(F,re),n.texParameteri(F,n.TEXTURE_MIN_FILTER,n.NEAREST),n.texParameteri(F,n.TEXTURE_MAG_FILTER,n.NEAREST);for(let De=0;De<K;De++)F===n.TEXTURE_3D||F===n.TEXTURE_2D_ARRAY?n.texImage3D(pe,0,n.RGBA,1,1,me,0,n.RGBA,n.UNSIGNED_BYTE,be):n.texImage2D(pe+De,0,n.RGBA,1,1,0,n.RGBA,n.UNSIGNED_BYTE,be);return re}const Z={};Z[n.TEXTURE_2D]=lt(n.TEXTURE_2D,n.TEXTURE_2D,1),Z[n.TEXTURE_CUBE_MAP]=lt(n.TEXTURE_CUBE_MAP,n.TEXTURE_CUBE_MAP_POSITIVE_X,6),Z[n.TEXTURE_2D_ARRAY]=lt(n.TEXTURE_2D_ARRAY,n.TEXTURE_2D_ARRAY,1,1),Z[n.TEXTURE_3D]=lt(n.TEXTURE_3D,n.TEXTURE_3D,1,1),s.setClear(0,0,0,1),a.setClear(1),o.setClear(0),ee(n.DEPTH_TEST),a.setFunc(js),oe(!1),ue(uu),ee(n.CULL_FACE),se(Ai);function ee(F){d[F]!==!0&&(n.enable(F),d[F]=!0)}function ye(F){d[F]!==!1&&(n.disable(F),d[F]=!1)}function ze(F,pe){return h[F]!==pe?(n.bindFramebuffer(F,pe),h[F]=pe,F===n.DRAW_FRAMEBUFFER&&(h[n.FRAMEBUFFER]=pe),F===n.FRAMEBUFFER&&(h[n.DRAW_FRAMEBUFFER]=pe),!0):!1}function Se(F,pe){let K=p,me=!1;if(F){K=f.get(pe),K===void 0&&(K=[],f.set(pe,K));const be=F.textures;if(K.length!==be.length||K[0]!==n.COLOR_ATTACHMENT0){for(let re=0,De=be.length;re<De;re++)K[re]=n.COLOR_ATTACHMENT0+re;K.length=be.length,me=!0}}else K[0]!==n.BACK&&(K[0]=n.BACK,me=!0);me&&n.drawBuffers(K)}function He(F){return v!==F?(n.useProgram(F),v=F,!0):!1}const mt={[Yr]:n.FUNC_ADD,[um]:n.FUNC_SUBTRACT,[hm]:n.FUNC_REVERSE_SUBTRACT};mt[fm]=n.MIN,mt[pm]=n.MAX;const te={[mm]:n.ZERO,[gm]:n.ONE,[vm]:n.SRC_COLOR,[zh]:n.SRC_ALPHA,[Mm]:n.SRC_ALPHA_SATURATE,[bm]:n.DST_COLOR,[_m]:n.DST_ALPHA,[ym]:n.ONE_MINUS_SRC_COLOR,[Hh]:n.ONE_MINUS_SRC_ALPHA,[Sm]:n.ONE_MINUS_DST_COLOR,[xm]:n.ONE_MINUS_DST_ALPHA,[wm]:n.CONSTANT_COLOR,[Em]:n.ONE_MINUS_CONSTANT_COLOR,[Tm]:n.CONSTANT_ALPHA,[Am]:n.ONE_MINUS_CONSTANT_ALPHA};function se(F,pe,K,me,be,re,De,Ce,Mt,ft){if(F===Ai){m===!0&&(ye(n.BLEND),m=!1);return}if(m===!1&&(ee(n.BLEND),m=!0),F!==dm){if(F!==g||ft!==C){if((x!==Yr||w!==Yr)&&(n.blendEquation(n.FUNC_ADD),x=Yr,w=Yr),ft)switch(F){case $s:n.blendFuncSeparate(n.ONE,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case Kr:n.blendFunc(n.ONE,n.ONE);break;case hu:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case fu:n.blendFuncSeparate(n.DST_COLOR,n.ONE_MINUS_SRC_ALPHA,n.ZERO,n.ONE);break;default:st("WebGLState: Invalid blending: ",F);break}else switch(F){case $s:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case Kr:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE,n.ONE,n.ONE);break;case hu:st("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case fu:st("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:st("WebGLState: Invalid blending: ",F);break}E=null,b=null,S=null,T=null,y.set(0,0,0),A=0,g=F,C=ft}return}be=be||pe,re=re||K,De=De||me,(pe!==x||be!==w)&&(n.blendEquationSeparate(mt[pe],mt[be]),x=pe,w=be),(K!==E||me!==b||re!==S||De!==T)&&(n.blendFuncSeparate(te[K],te[me],te[re],te[De]),E=K,b=me,S=re,T=De),(Ce.equals(y)===!1||Mt!==A)&&(n.blendColor(Ce.r,Ce.g,Ce.b,Mt),y.copy(Ce),A=Mt),g=F,C=!1}function ae(F,pe){F.side===Ei?ye(n.CULL_FACE):ee(n.CULL_FACE);let K=F.side===vn;pe&&(K=!K),oe(K),F.blending===$s&&F.transparent===!1?se(Ai):se(F.blending,F.blendEquation,F.blendSrc,F.blendDst,F.blendEquationAlpha,F.blendSrcAlpha,F.blendDstAlpha,F.blendColor,F.blendAlpha,F.premultipliedAlpha),a.setFunc(F.depthFunc),a.setTest(F.depthTest),a.setMask(F.depthWrite),s.setMask(F.colorWrite);const me=F.stencilWrite;o.setTest(me),me&&(o.setMask(F.stencilWriteMask),o.setFunc(F.stencilFunc,F.stencilRef,F.stencilFuncMask),o.setOp(F.stencilFail,F.stencilZFail,F.stencilZPass)),Ue(F.polygonOffset,F.polygonOffsetFactor,F.polygonOffsetUnits),F.alphaToCoverage===!0?ee(n.SAMPLE_ALPHA_TO_COVERAGE):ye(n.SAMPLE_ALPHA_TO_COVERAGE)}function oe(F){L!==F&&(F?n.frontFace(n.CW):n.frontFace(n.CCW),L=F)}function ue(F){F!==om?(ee(n.CULL_FACE),F!==I&&(F===uu?n.cullFace(n.BACK):F===lm?n.cullFace(n.FRONT):n.cullFace(n.FRONT_AND_BACK))):ye(n.CULL_FACE),I=F}function Fe(F){F!==B&&($&&n.lineWidth(F),B=F)}function Ue(F,pe,K){F?(ee(n.POLYGON_OFFSET_FILL),(N!==pe||U!==K)&&(N=pe,U=K,a.getReversed()&&(pe=-pe),n.polygonOffset(pe,K))):ye(n.POLYGON_OFFSET_FILL)}function Ge(F){F?ee(n.SCISSOR_TEST):ye(n.SCISSOR_TEST)}function Xe(F){F===void 0&&(F=n.TEXTURE0+V-1),Q!==F&&(n.activeTexture(F),Q=F)}function D(F,pe,K){K===void 0&&(Q===null?K=n.TEXTURE0+V-1:K=Q);let me=ne[K];me===void 0&&(me={type:void 0,texture:void 0},ne[K]=me),(me.type!==F||me.texture!==pe)&&(Q!==K&&(n.activeTexture(K),Q=K),n.bindTexture(F,pe||Z[F]),me.type=F,me.texture=pe)}function ht(){const F=ne[Q];F!==void 0&&F.type!==void 0&&(n.bindTexture(F.type,null),F.type=void 0,F.texture=void 0)}function nt(){try{n.compressedTexImage2D(...arguments)}catch(F){st("WebGLState:",F)}}function R(){try{n.compressedTexImage3D(...arguments)}catch(F){st("WebGLState:",F)}}function _(){try{n.texSubImage2D(...arguments)}catch(F){st("WebGLState:",F)}}function k(){try{n.texSubImage3D(...arguments)}catch(F){st("WebGLState:",F)}}function G(){try{n.compressedTexSubImage2D(...arguments)}catch(F){st("WebGLState:",F)}}function q(){try{n.compressedTexSubImage3D(...arguments)}catch(F){st("WebGLState:",F)}}function ce(){try{n.texStorage2D(...arguments)}catch(F){st("WebGLState:",F)}}function de(){try{n.texStorage3D(...arguments)}catch(F){st("WebGLState:",F)}}function Y(){try{n.texImage2D(...arguments)}catch(F){st("WebGLState:",F)}}function j(){try{n.texImage3D(...arguments)}catch(F){st("WebGLState:",F)}}function he(F){return u[F]!==void 0?u[F]:n.getParameter(F)}function Le(F,pe){u[F]!==pe&&(n.pixelStorei(F,pe),u[F]=pe)}function ge(F){ut.equals(F)===!1&&(n.scissor(F.x,F.y,F.z,F.w),ut.copy(F))}function fe(F){tt.equals(F)===!1&&(n.viewport(F.x,F.y,F.z,F.w),tt.copy(F))}function Ne(F,pe){let K=c.get(pe);K===void 0&&(K=new WeakMap,c.set(pe,K));let me=K.get(F);me===void 0&&(me=n.getUniformBlockIndex(pe,F.name),K.set(F,me))}function Be(F,pe){const me=c.get(pe).get(F);l.get(pe)!==me&&(n.uniformBlockBinding(pe,me,F.__bindingPointIndex),l.set(pe,me))}function Ze(){n.disable(n.BLEND),n.disable(n.CULL_FACE),n.disable(n.DEPTH_TEST),n.disable(n.POLYGON_OFFSET_FILL),n.disable(n.SCISSOR_TEST),n.disable(n.STENCIL_TEST),n.disable(n.SAMPLE_ALPHA_TO_COVERAGE),n.blendEquation(n.FUNC_ADD),n.blendFunc(n.ONE,n.ZERO),n.blendFuncSeparate(n.ONE,n.ZERO,n.ONE,n.ZERO),n.blendColor(0,0,0,0),n.colorMask(!0,!0,!0,!0),n.clearColor(0,0,0,0),n.depthMask(!0),n.depthFunc(n.LESS),a.setReversed(!1),n.clearDepth(1),n.stencilMask(4294967295),n.stencilFunc(n.ALWAYS,0,4294967295),n.stencilOp(n.KEEP,n.KEEP,n.KEEP),n.clearStencil(0),n.cullFace(n.BACK),n.frontFace(n.CCW),n.polygonOffset(0,0),n.activeTexture(n.TEXTURE0),n.bindFramebuffer(n.FRAMEBUFFER,null),n.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),n.bindFramebuffer(n.READ_FRAMEBUFFER,null),n.useProgram(null),n.lineWidth(1),n.scissor(0,0,n.canvas.width,n.canvas.height),n.viewport(0,0,n.canvas.width,n.canvas.height),n.pixelStorei(n.PACK_ALIGNMENT,4),n.pixelStorei(n.UNPACK_ALIGNMENT,4),n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,!1),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,n.BROWSER_DEFAULT_WEBGL),n.pixelStorei(n.PACK_ROW_LENGTH,0),n.pixelStorei(n.PACK_SKIP_PIXELS,0),n.pixelStorei(n.PACK_SKIP_ROWS,0),n.pixelStorei(n.UNPACK_ROW_LENGTH,0),n.pixelStorei(n.UNPACK_IMAGE_HEIGHT,0),n.pixelStorei(n.UNPACK_SKIP_PIXELS,0),n.pixelStorei(n.UNPACK_SKIP_ROWS,0),n.pixelStorei(n.UNPACK_SKIP_IMAGES,0),d={},u={},Q=null,ne={},h={},f=new WeakMap,p=[],v=null,m=!1,g=null,x=null,E=null,b=null,w=null,S=null,T=null,y=new Qe(0,0,0),A=0,C=!1,L=null,I=null,B=null,N=null,U=null,ut.set(0,0,n.canvas.width,n.canvas.height),tt.set(0,0,n.canvas.width,n.canvas.height),s.reset(),a.reset(),o.reset()}return{buffers:{color:s,depth:a,stencil:o},enable:ee,disable:ye,bindFramebuffer:ze,drawBuffers:Se,useProgram:He,setBlending:se,setMaterial:ae,setFlipSided:oe,setCullFace:ue,setLineWidth:Fe,setPolygonOffset:Ue,setScissorTest:Ge,activeTexture:Xe,bindTexture:D,unbindTexture:ht,compressedTexImage2D:nt,compressedTexImage3D:R,texImage2D:Y,texImage3D:j,pixelStorei:Le,getParameter:he,updateUBOMapping:Ne,uniformBlockBinding:Be,texStorage2D:ce,texStorage3D:de,texSubImage2D:_,texSubImage3D:k,compressedTexSubImage2D:G,compressedTexSubImage3D:q,scissor:ge,viewport:fe,reset:Ze}}function hb(n,e,t,i,r,s,a){const o=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new le,d=new WeakMap,u=new Set;let h;const f=new WeakMap;let p=!1;try{p=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function v(R,_){return p?new OffscreenCanvas(R,_):Ro("canvas")}function m(R,_,k){let G=1;const q=nt(R);if((q.width>k||q.height>k)&&(G=k/Math.max(q.width,q.height)),G<1)if(typeof HTMLImageElement<"u"&&R instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&R instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&R instanceof ImageBitmap||typeof VideoFrame<"u"&&R instanceof VideoFrame){const ce=Math.floor(G*q.width),de=Math.floor(G*q.height);h===void 0&&(h=v(ce,de));const Y=_?v(ce,de):h;return Y.width=ce,Y.height=de,Y.getContext("2d").drawImage(R,0,0,ce,de),ke("WebGLRenderer: Texture has been resized from ("+q.width+"x"+q.height+") to ("+ce+"x"+de+")."),Y}else return"data"in R&&ke("WebGLRenderer: Image in DataTexture is too big ("+q.width+"x"+q.height+")."),R;return R}function g(R){return R.generateMipmaps}function x(R){n.generateMipmap(R)}function E(R){return R.isWebGLCubeRenderTarget?n.TEXTURE_CUBE_MAP:R.isWebGL3DRenderTarget?n.TEXTURE_3D:R.isWebGLArrayRenderTarget||R.isCompressedArrayTexture?n.TEXTURE_2D_ARRAY:n.TEXTURE_2D}function b(R,_,k,G,q,ce=!1){if(R!==null){if(n[R]!==void 0)return n[R];ke("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+R+"'")}let de;G&&(de=e.get("EXT_texture_norm16"),de||ke("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let Y=_;if(_===n.RED&&(k===n.FLOAT&&(Y=n.R32F),k===n.HALF_FLOAT&&(Y=n.R16F),k===n.UNSIGNED_BYTE&&(Y=n.R8),k===n.UNSIGNED_SHORT&&de&&(Y=de.R16_EXT),k===n.SHORT&&de&&(Y=de.R16_SNORM_EXT)),_===n.RED_INTEGER&&(k===n.UNSIGNED_BYTE&&(Y=n.R8UI),k===n.UNSIGNED_SHORT&&(Y=n.R16UI),k===n.UNSIGNED_INT&&(Y=n.R32UI),k===n.BYTE&&(Y=n.R8I),k===n.SHORT&&(Y=n.R16I),k===n.INT&&(Y=n.R32I)),_===n.RG&&(k===n.FLOAT&&(Y=n.RG32F),k===n.HALF_FLOAT&&(Y=n.RG16F),k===n.UNSIGNED_BYTE&&(Y=n.RG8),k===n.UNSIGNED_SHORT&&de&&(Y=de.RG16_EXT),k===n.SHORT&&de&&(Y=de.RG16_SNORM_EXT)),_===n.RG_INTEGER&&(k===n.UNSIGNED_BYTE&&(Y=n.RG8UI),k===n.UNSIGNED_SHORT&&(Y=n.RG16UI),k===n.UNSIGNED_INT&&(Y=n.RG32UI),k===n.BYTE&&(Y=n.RG8I),k===n.SHORT&&(Y=n.RG16I),k===n.INT&&(Y=n.RG32I)),_===n.RGB_INTEGER&&(k===n.UNSIGNED_BYTE&&(Y=n.RGB8UI),k===n.UNSIGNED_SHORT&&(Y=n.RGB16UI),k===n.UNSIGNED_INT&&(Y=n.RGB32UI),k===n.BYTE&&(Y=n.RGB8I),k===n.SHORT&&(Y=n.RGB16I),k===n.INT&&(Y=n.RGB32I)),_===n.RGBA_INTEGER&&(k===n.UNSIGNED_BYTE&&(Y=n.RGBA8UI),k===n.UNSIGNED_SHORT&&(Y=n.RGBA16UI),k===n.UNSIGNED_INT&&(Y=n.RGBA32UI),k===n.BYTE&&(Y=n.RGBA8I),k===n.SHORT&&(Y=n.RGBA16I),k===n.INT&&(Y=n.RGBA32I)),_===n.RGB&&(k===n.UNSIGNED_SHORT&&de&&(Y=de.RGB16_EXT),k===n.SHORT&&de&&(Y=de.RGB16_SNORM_EXT),k===n.UNSIGNED_INT_5_9_9_9_REV&&(Y=n.RGB9_E5),k===n.UNSIGNED_INT_10F_11F_11F_REV&&(Y=n.R11F_G11F_B10F)),_===n.RGBA){const j=ce?Ao:at.getTransfer(q);k===n.FLOAT&&(Y=n.RGBA32F),k===n.HALF_FLOAT&&(Y=n.RGBA16F),k===n.UNSIGNED_BYTE&&(Y=j===gt?n.SRGB8_ALPHA8:n.RGBA8),k===n.UNSIGNED_SHORT&&de&&(Y=de.RGBA16_EXT),k===n.SHORT&&de&&(Y=de.RGBA16_SNORM_EXT),k===n.UNSIGNED_SHORT_4_4_4_4&&(Y=n.RGBA4),k===n.UNSIGNED_SHORT_5_5_5_1&&(Y=n.RGB5_A1)}return(Y===n.R16F||Y===n.R32F||Y===n.RG16F||Y===n.RG32F||Y===n.RGBA16F||Y===n.RGBA32F)&&e.get("EXT_color_buffer_float"),Y}function w(R,_){let k;return R?_===null||_===pi||_===ea?k=n.DEPTH24_STENCIL8:_===oi?k=n.DEPTH32F_STENCIL8:_===Qs&&(k=n.DEPTH24_STENCIL8,ke("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):_===null||_===pi||_===ea?k=n.DEPTH_COMPONENT24:_===oi?k=n.DEPTH_COMPONENT32F:_===Qs&&(k=n.DEPTH_COMPONENT16),k}function S(R,_){return g(R)===!0||R.isFramebufferTexture&&R.minFilter!==Jt&&R.minFilter!==sn?Math.log2(Math.max(_.width,_.height))+1:R.mipmaps!==void 0&&R.mipmaps.length>0?R.mipmaps.length:R.isCompressedTexture&&Array.isArray(R.image)?_.mipmaps.length:1}function T(R){const _=R.target;_.removeEventListener("dispose",T),A(_),_.isVideoTexture&&d.delete(_),_.isHTMLTexture&&u.delete(_)}function y(R){const _=R.target;_.removeEventListener("dispose",y),L(_)}function A(R){const _=i.get(R);if(_.__webglInit===void 0)return;const k=R.source,G=f.get(k);if(G){const q=G[_.__cacheKey];q.usedTimes--,q.usedTimes===0&&C(R),Object.keys(G).length===0&&f.delete(k)}i.remove(R)}function C(R){const _=i.get(R);n.deleteTexture(_.__webglTexture);const k=R.source,G=f.get(k);delete G[_.__cacheKey],a.memory.textures--}function L(R){const _=i.get(R);if(R.depthTexture&&(R.depthTexture.dispose(),i.remove(R.depthTexture)),R.isWebGLCubeRenderTarget)for(let G=0;G<6;G++){if(Array.isArray(_.__webglFramebuffer[G]))for(let q=0;q<_.__webglFramebuffer[G].length;q++)n.deleteFramebuffer(_.__webglFramebuffer[G][q]);else n.deleteFramebuffer(_.__webglFramebuffer[G]);_.__webglDepthbuffer&&n.deleteRenderbuffer(_.__webglDepthbuffer[G])}else{if(Array.isArray(_.__webglFramebuffer))for(let G=0;G<_.__webglFramebuffer.length;G++)n.deleteFramebuffer(_.__webglFramebuffer[G]);else n.deleteFramebuffer(_.__webglFramebuffer);if(_.__webglDepthbuffer&&n.deleteRenderbuffer(_.__webglDepthbuffer),_.__webglMultisampledFramebuffer&&n.deleteFramebuffer(_.__webglMultisampledFramebuffer),_.__webglColorRenderbuffer)for(let G=0;G<_.__webglColorRenderbuffer.length;G++)_.__webglColorRenderbuffer[G]&&n.deleteRenderbuffer(_.__webglColorRenderbuffer[G]);_.__webglDepthRenderbuffer&&n.deleteRenderbuffer(_.__webglDepthRenderbuffer)}const k=R.textures;for(let G=0,q=k.length;G<q;G++){const ce=i.get(k[G]);ce.__webglTexture&&(n.deleteTexture(ce.__webglTexture),a.memory.textures--),i.remove(k[G])}i.remove(R)}let I=0;function B(){I=0}function N(){return I}function U(R){I=R}function V(){const R=I;return R>=r.maxTextures&&ke("WebGLTextures: Trying to use "+(R+1)+" texture units while this GPU supports only "+r.maxTextures),I+=1,R}function $(R){const _=[];return _.push(R.wrapS),_.push(R.wrapT),_.push(R.wrapR||0),_.push(R.magFilter),_.push(R.minFilter),_.push(R.anisotropy),_.push(R.internalFormat),_.push(R.format),_.push(R.type),_.push(R.generateMipmaps),_.push(R.premultiplyAlpha),_.push(R.flipY),_.push(R.unpackAlignment),_.push(R.colorSpace),_.join()}function ie(R,_){const k=i.get(R);if(R.isVideoTexture&&D(R),R.isRenderTargetTexture===!1&&R.isExternalTexture!==!0&&R.version>0&&k.__version!==R.version){const G=R.image;if(G===null)ke("WebGLRenderer: Texture marked for update but no image data found.");else if(G.complete===!1)ke("WebGLRenderer: Texture marked for update but image is incomplete");else{ye(k,R,_);return}}else R.isExternalTexture&&(k.__webglTexture=R.sourceTexture?R.sourceTexture:null);t.bindTexture(n.TEXTURE_2D,k.__webglTexture,n.TEXTURE0+_)}function X(R,_){const k=i.get(R);if(R.isRenderTargetTexture===!1&&R.version>0&&k.__version!==R.version){ye(k,R,_);return}else R.isExternalTexture&&(k.__webglTexture=R.sourceTexture?R.sourceTexture:null);t.bindTexture(n.TEXTURE_2D_ARRAY,k.__webglTexture,n.TEXTURE0+_)}function Q(R,_){const k=i.get(R);if(R.isRenderTargetTexture===!1&&R.version>0&&k.__version!==R.version){ye(k,R,_);return}t.bindTexture(n.TEXTURE_3D,k.__webglTexture,n.TEXTURE0+_)}function ne(R,_){const k=i.get(R);if(R.isCubeDepthTexture!==!0&&R.version>0&&k.__version!==R.version){ze(k,R,_);return}t.bindTexture(n.TEXTURE_CUBE_MAP,k.__webglTexture,n.TEXTURE0+_)}const Pe={[oc]:n.REPEAT,[Ti]:n.CLAMP_TO_EDGE,[lc]:n.MIRRORED_REPEAT},Ee={[Jt]:n.NEAREST,[Im]:n.NEAREST_MIPMAP_NEAREST,[Sa]:n.NEAREST_MIPMAP_LINEAR,[sn]:n.LINEAR,[ul]:n.LINEAR_MIPMAP_NEAREST,[ur]:n.LINEAR_MIPMAP_LINEAR},ut={[Dm]:n.NEVER,[km]:n.ALWAYS,[Um]:n.LESS,[Sd]:n.LEQUAL,[Om]:n.EQUAL,[Md]:n.GEQUAL,[Fm]:n.GREATER,[Bm]:n.NOTEQUAL};function tt(R,_){if(_.type===oi&&e.has("OES_texture_float_linear")===!1&&(_.magFilter===sn||_.magFilter===ul||_.magFilter===Sa||_.magFilter===ur||_.minFilter===sn||_.minFilter===ul||_.minFilter===Sa||_.minFilter===ur)&&ke("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),n.texParameteri(R,n.TEXTURE_WRAP_S,Pe[_.wrapS]),n.texParameteri(R,n.TEXTURE_WRAP_T,Pe[_.wrapT]),(R===n.TEXTURE_3D||R===n.TEXTURE_2D_ARRAY)&&n.texParameteri(R,n.TEXTURE_WRAP_R,Pe[_.wrapR]),n.texParameteri(R,n.TEXTURE_MAG_FILTER,Ee[_.magFilter]),n.texParameteri(R,n.TEXTURE_MIN_FILTER,Ee[_.minFilter]),_.compareFunction&&(n.texParameteri(R,n.TEXTURE_COMPARE_MODE,n.COMPARE_REF_TO_TEXTURE),n.texParameteri(R,n.TEXTURE_COMPARE_FUNC,ut[_.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(_.magFilter===Jt||_.minFilter!==Sa&&_.minFilter!==ur||_.type===oi&&e.has("OES_texture_float_linear")===!1)return;if(_.anisotropy>1||i.get(_).__currentAnisotropy){const k=e.get("EXT_texture_filter_anisotropic");n.texParameterf(R,k.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(_.anisotropy,r.getMaxAnisotropy())),i.get(_).__currentAnisotropy=_.anisotropy}}}function lt(R,_){let k=!1;R.__webglInit===void 0&&(R.__webglInit=!0,_.addEventListener("dispose",T));const G=_.source;let q=f.get(G);q===void 0&&(q={},f.set(G,q));const ce=$(_);if(ce!==R.__cacheKey){q[ce]===void 0&&(q[ce]={texture:n.createTexture(),usedTimes:0},a.memory.textures++,k=!0),q[ce].usedTimes++;const de=q[R.__cacheKey];de!==void 0&&(q[R.__cacheKey].usedTimes--,de.usedTimes===0&&C(_)),R.__cacheKey=ce,R.__webglTexture=q[ce].texture}return k}function Z(R,_,k){return Math.floor(Math.floor(R/k)/_)}function ee(R,_,k,G){const ce=R.updateRanges;if(ce.length===0)t.texSubImage2D(n.TEXTURE_2D,0,0,0,_.width,_.height,k,G,_.data);else{ce.sort((Le,ge)=>Le.start-ge.start);let de=0;for(let Le=1;Le<ce.length;Le++){const ge=ce[de],fe=ce[Le],Ne=ge.start+ge.count,Be=Z(fe.start,_.width,4),Ze=Z(ge.start,_.width,4);fe.start<=Ne+1&&Be===Ze&&Z(fe.start+fe.count-1,_.width,4)===Be?ge.count=Math.max(ge.count,fe.start+fe.count-ge.start):(++de,ce[de]=fe)}ce.length=de+1;const Y=t.getParameter(n.UNPACK_ROW_LENGTH),j=t.getParameter(n.UNPACK_SKIP_PIXELS),he=t.getParameter(n.UNPACK_SKIP_ROWS);t.pixelStorei(n.UNPACK_ROW_LENGTH,_.width);for(let Le=0,ge=ce.length;Le<ge;Le++){const fe=ce[Le],Ne=Math.floor(fe.start/4),Be=Math.ceil(fe.count/4),Ze=Ne%_.width,F=Math.floor(Ne/_.width),pe=Be,K=1;t.pixelStorei(n.UNPACK_SKIP_PIXELS,Ze),t.pixelStorei(n.UNPACK_SKIP_ROWS,F),t.texSubImage2D(n.TEXTURE_2D,0,Ze,F,pe,K,k,G,_.data)}R.clearUpdateRanges(),t.pixelStorei(n.UNPACK_ROW_LENGTH,Y),t.pixelStorei(n.UNPACK_SKIP_PIXELS,j),t.pixelStorei(n.UNPACK_SKIP_ROWS,he)}}function ye(R,_,k){let G=n.TEXTURE_2D;(_.isDataArrayTexture||_.isCompressedArrayTexture)&&(G=n.TEXTURE_2D_ARRAY),_.isData3DTexture&&(G=n.TEXTURE_3D);const q=lt(R,_),ce=_.source;t.bindTexture(G,R.__webglTexture,n.TEXTURE0+k);const de=i.get(ce);if(ce.version!==de.__version||q===!0){if(t.activeTexture(n.TEXTURE0+k),(typeof ImageBitmap<"u"&&_.image instanceof ImageBitmap)===!1){const K=at.getPrimaries(at.workingColorSpace),me=_.colorSpace===Zi?null:at.getPrimaries(_.colorSpace),be=_.colorSpace===Zi||K===me?n.NONE:n.BROWSER_DEFAULT_WEBGL;t.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,_.flipY),t.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),t.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,be)}t.pixelStorei(n.UNPACK_ALIGNMENT,_.unpackAlignment);let j=m(_.image,!1,r.maxTextureSize);j=ht(_,j);const he=s.convert(_.format,_.colorSpace),Le=s.convert(_.type);let ge=b(_.internalFormat,he,Le,_.normalized,_.colorSpace,_.isVideoTexture);tt(G,_);let fe;const Ne=_.mipmaps,Be=_.isVideoTexture!==!0,Ze=de.__version===void 0||q===!0,F=ce.dataReady,pe=S(_,j);if(_.isDepthTexture)ge=w(_.format===hr,_.type),Ze&&(Be?t.texStorage2D(n.TEXTURE_2D,1,ge,j.width,j.height):t.texImage2D(n.TEXTURE_2D,0,ge,j.width,j.height,0,he,Le,null));else if(_.isDataTexture)if(Ne.length>0){Be&&Ze&&t.texStorage2D(n.TEXTURE_2D,pe,ge,Ne[0].width,Ne[0].height);for(let K=0,me=Ne.length;K<me;K++)fe=Ne[K],Be?F&&t.texSubImage2D(n.TEXTURE_2D,K,0,0,fe.width,fe.height,he,Le,fe.data):t.texImage2D(n.TEXTURE_2D,K,ge,fe.width,fe.height,0,he,Le,fe.data);_.generateMipmaps=!1}else Be?(Ze&&t.texStorage2D(n.TEXTURE_2D,pe,ge,j.width,j.height),F&&ee(_,j,he,Le)):t.texImage2D(n.TEXTURE_2D,0,ge,j.width,j.height,0,he,Le,j.data);else if(_.isCompressedTexture)if(_.isCompressedArrayTexture){Be&&Ze&&t.texStorage3D(n.TEXTURE_2D_ARRAY,pe,ge,Ne[0].width,Ne[0].height,j.depth);for(let K=0,me=Ne.length;K<me;K++)if(fe=Ne[K],_.format!==Wn)if(he!==null)if(Be){if(F)if(_.layerUpdates.size>0){const be=eh(fe.width,fe.height,_.format,_.type);for(const re of _.layerUpdates){const De=fe.data.subarray(re*be/fe.data.BYTES_PER_ELEMENT,(re+1)*be/fe.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,K,0,0,re,fe.width,fe.height,1,he,De)}}else t.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,K,0,0,0,fe.width,fe.height,j.depth,he,fe.data)}else t.compressedTexImage3D(n.TEXTURE_2D_ARRAY,K,ge,fe.width,fe.height,j.depth,0,fe.data,0,0);else ke("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Be?F&&t.texSubImage3D(n.TEXTURE_2D_ARRAY,K,0,0,0,fe.width,fe.height,j.depth,he,Le,fe.data):t.texImage3D(n.TEXTURE_2D_ARRAY,K,ge,fe.width,fe.height,j.depth,0,he,Le,fe.data);_.layerUpdates.size>0&&_.clearLayerUpdates()}else{Be&&Ze&&t.texStorage2D(n.TEXTURE_2D,pe,ge,Ne[0].width,Ne[0].height);for(let K=0,me=Ne.length;K<me;K++)fe=Ne[K],_.format!==Wn?he!==null?Be?F&&t.compressedTexSubImage2D(n.TEXTURE_2D,K,0,0,fe.width,fe.height,he,fe.data):t.compressedTexImage2D(n.TEXTURE_2D,K,ge,fe.width,fe.height,0,fe.data):ke("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Be?F&&t.texSubImage2D(n.TEXTURE_2D,K,0,0,fe.width,fe.height,he,Le,fe.data):t.texImage2D(n.TEXTURE_2D,K,ge,fe.width,fe.height,0,he,Le,fe.data)}else if(_.isDataArrayTexture)if(Be){if(Ze&&t.texStorage3D(n.TEXTURE_2D_ARRAY,pe,ge,j.width,j.height,j.depth),F)if(_.layerUpdates.size>0){const K=eh(j.width,j.height,_.format,_.type);for(const me of _.layerUpdates){const be=j.data.subarray(me*K/j.data.BYTES_PER_ELEMENT,(me+1)*K/j.data.BYTES_PER_ELEMENT);t.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,me,j.width,j.height,1,he,Le,be)}_.clearLayerUpdates()}else t.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,0,j.width,j.height,j.depth,he,Le,j.data)}else t.texImage3D(n.TEXTURE_2D_ARRAY,0,ge,j.width,j.height,j.depth,0,he,Le,j.data);else if(_.isData3DTexture)Be?(Ze&&t.texStorage3D(n.TEXTURE_3D,pe,ge,j.width,j.height,j.depth),F&&t.texSubImage3D(n.TEXTURE_3D,0,0,0,0,j.width,j.height,j.depth,he,Le,j.data)):t.texImage3D(n.TEXTURE_3D,0,ge,j.width,j.height,j.depth,0,he,Le,j.data);else if(_.isFramebufferTexture){if(Ze)if(Be)t.texStorage2D(n.TEXTURE_2D,pe,ge,j.width,j.height);else{let K=j.width,me=j.height;for(let be=0;be<pe;be++)t.texImage2D(n.TEXTURE_2D,be,ge,K,me,0,he,Le,null),K>>=1,me>>=1}}else if(_.isHTMLTexture){if("texElementImage2D"in n){const K=n.canvas;if(K.hasAttribute("layoutsubtree")||K.setAttribute("layoutsubtree","true"),j.parentNode!==K){K.appendChild(j),u.add(_),K.onpaint=me=>{const be=me.changedElements;for(const re of u)be.includes(re.image)&&(re.needsUpdate=!0)},K.requestPaint();return}if(n.texElementImage2D.length===3)n.texElementImage2D(n.TEXTURE_2D,n.RGBA8,j);else{const be=n.RGBA,re=n.RGBA,De=n.UNSIGNED_BYTE;n.texElementImage2D(n.TEXTURE_2D,0,be,re,De,j)}n.texParameteri(n.TEXTURE_2D,n.TEXTURE_MIN_FILTER,n.LINEAR),n.texParameteri(n.TEXTURE_2D,n.TEXTURE_WRAP_S,n.CLAMP_TO_EDGE),n.texParameteri(n.TEXTURE_2D,n.TEXTURE_WRAP_T,n.CLAMP_TO_EDGE)}}else if(Ne.length>0){if(Be&&Ze){const K=nt(Ne[0]);t.texStorage2D(n.TEXTURE_2D,pe,ge,K.width,K.height)}for(let K=0,me=Ne.length;K<me;K++)fe=Ne[K],Be?F&&t.texSubImage2D(n.TEXTURE_2D,K,0,0,he,Le,fe):t.texImage2D(n.TEXTURE_2D,K,ge,he,Le,fe);_.generateMipmaps=!1}else if(Be){if(Ze){const K=nt(j);t.texStorage2D(n.TEXTURE_2D,pe,ge,K.width,K.height)}F&&t.texSubImage2D(n.TEXTURE_2D,0,0,0,he,Le,j)}else t.texImage2D(n.TEXTURE_2D,0,ge,he,Le,j);g(_)&&x(G),de.__version=ce.version,_.onUpdate&&_.onUpdate(_)}R.__version=_.version}function ze(R,_,k){if(_.image.length!==6)return;const G=lt(R,_),q=_.source;t.bindTexture(n.TEXTURE_CUBE_MAP,R.__webglTexture,n.TEXTURE0+k);const ce=i.get(q);if(q.version!==ce.__version||G===!0){t.activeTexture(n.TEXTURE0+k);const de=at.getPrimaries(at.workingColorSpace),Y=_.colorSpace===Zi?null:at.getPrimaries(_.colorSpace),j=_.colorSpace===Zi||de===Y?n.NONE:n.BROWSER_DEFAULT_WEBGL;t.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,_.flipY),t.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),t.pixelStorei(n.UNPACK_ALIGNMENT,_.unpackAlignment),t.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,j);const he=_.isCompressedTexture||_.image[0].isCompressedTexture,Le=_.image[0]&&_.image[0].isDataTexture,ge=[];for(let re=0;re<6;re++)!he&&!Le?ge[re]=m(_.image[re],!0,r.maxCubemapSize):ge[re]=Le?_.image[re].image:_.image[re],ge[re]=ht(_,ge[re]);const fe=ge[0],Ne=s.convert(_.format,_.colorSpace),Be=s.convert(_.type),Ze=b(_.internalFormat,Ne,Be,_.normalized,_.colorSpace),F=_.isVideoTexture!==!0,pe=ce.__version===void 0||G===!0,K=q.dataReady;let me=S(_,fe);tt(n.TEXTURE_CUBE_MAP,_);let be;if(he){F&&pe&&t.texStorage2D(n.TEXTURE_CUBE_MAP,me,Ze,fe.width,fe.height);for(let re=0;re<6;re++){be=ge[re].mipmaps;for(let De=0;De<be.length;De++){const Ce=be[De];_.format!==Wn?Ne!==null?F?K&&t.compressedTexSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+re,De,0,0,Ce.width,Ce.height,Ne,Ce.data):t.compressedTexImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+re,De,Ze,Ce.width,Ce.height,0,Ce.data):ke("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):F?K&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+re,De,0,0,Ce.width,Ce.height,Ne,Be,Ce.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+re,De,Ze,Ce.width,Ce.height,0,Ne,Be,Ce.data)}}}else{if(be=_.mipmaps,F&&pe){be.length>0&&me++;const re=nt(ge[0]);t.texStorage2D(n.TEXTURE_CUBE_MAP,me,Ze,re.width,re.height)}for(let re=0;re<6;re++)if(Le){F?K&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+re,0,0,0,ge[re].width,ge[re].height,Ne,Be,ge[re].data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+re,0,Ze,ge[re].width,ge[re].height,0,Ne,Be,ge[re].data);for(let De=0;De<be.length;De++){const Mt=be[De].image[re].image;F?K&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+re,De+1,0,0,Mt.width,Mt.height,Ne,Be,Mt.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+re,De+1,Ze,Mt.width,Mt.height,0,Ne,Be,Mt.data)}}else{F?K&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+re,0,0,0,Ne,Be,ge[re]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+re,0,Ze,Ne,Be,ge[re]);for(let De=0;De<be.length;De++){const Ce=be[De];F?K&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+re,De+1,0,0,Ne,Be,Ce.image[re]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+re,De+1,Ze,Ne,Be,Ce.image[re])}}}g(_)&&x(n.TEXTURE_CUBE_MAP),ce.__version=q.version,_.onUpdate&&_.onUpdate(_)}R.__version=_.version}function Se(R,_,k,G,q,ce){const de=s.convert(k.format,k.colorSpace),Y=s.convert(k.type),j=b(k.internalFormat,de,Y,k.normalized,k.colorSpace),he=i.get(_),Le=i.get(k);if(Le.__renderTarget=_,!he.__hasExternalTextures){const ge=Math.max(1,_.width>>ce),fe=Math.max(1,_.height>>ce);q===n.TEXTURE_3D||q===n.TEXTURE_2D_ARRAY?t.texImage3D(q,ce,j,ge,fe,_.depth,0,de,Y,null):t.texImage2D(q,ce,j,ge,fe,0,de,Y,null)}t.bindFramebuffer(n.FRAMEBUFFER,R),Xe(_)?o.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,G,q,Le.__webglTexture,0,Ge(_)):(q===n.TEXTURE_2D||q>=n.TEXTURE_CUBE_MAP_POSITIVE_X&&q<=n.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&n.framebufferTexture2D(n.FRAMEBUFFER,G,q,Le.__webglTexture,ce),t.bindFramebuffer(n.FRAMEBUFFER,null)}function He(R,_,k){if(n.bindRenderbuffer(n.RENDERBUFFER,R),_.depthBuffer){const G=_.depthTexture,q=G&&G.isDepthTexture?G.type:null,ce=w(_.stencilBuffer,q),de=_.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT;Xe(_)?o.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,Ge(_),ce,_.width,_.height):k?n.renderbufferStorageMultisample(n.RENDERBUFFER,Ge(_),ce,_.width,_.height):n.renderbufferStorage(n.RENDERBUFFER,ce,_.width,_.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,de,n.RENDERBUFFER,R)}else{const G=_.textures;for(let q=0;q<G.length;q++){const ce=G[q],de=s.convert(ce.format,ce.colorSpace),Y=s.convert(ce.type),j=b(ce.internalFormat,de,Y,ce.normalized,ce.colorSpace);Xe(_)?o.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,Ge(_),j,_.width,_.height):k?n.renderbufferStorageMultisample(n.RENDERBUFFER,Ge(_),j,_.width,_.height):n.renderbufferStorage(n.RENDERBUFFER,j,_.width,_.height)}}n.bindRenderbuffer(n.RENDERBUFFER,null)}function mt(R,_,k){const G=_.isWebGLCubeRenderTarget===!0;if(t.bindFramebuffer(n.FRAMEBUFFER,R),!(_.depthTexture&&_.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");const q=i.get(_.depthTexture);if(q.__renderTarget=_,(!q.__webglTexture||_.depthTexture.image.width!==_.width||_.depthTexture.image.height!==_.height)&&(_.depthTexture.image.width=_.width,_.depthTexture.image.height=_.height,_.depthTexture.needsUpdate=!0),G){if(q.__webglInit===void 0&&(q.__webglInit=!0,_.depthTexture.addEventListener("dispose",T)),q.__webglTexture===void 0){q.__webglTexture=n.createTexture(),t.bindTexture(n.TEXTURE_CUBE_MAP,q.__webglTexture),tt(n.TEXTURE_CUBE_MAP,_.depthTexture);const he=s.convert(_.depthTexture.format),Le=s.convert(_.depthTexture.type);let ge;_.depthTexture.format===Li?ge=n.DEPTH_COMPONENT24:_.depthTexture.format===hr&&(ge=n.DEPTH24_STENCIL8);for(let fe=0;fe<6;fe++)n.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,ge,_.width,_.height,0,he,Le,null)}}else ie(_.depthTexture,0);const ce=q.__webglTexture,de=Ge(_),Y=G?n.TEXTURE_CUBE_MAP_POSITIVE_X+k:n.TEXTURE_2D,j=_.depthTexture.format===hr?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT;if(_.depthTexture.format===Li)Xe(_)?o.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,j,Y,ce,0,de):n.framebufferTexture2D(n.FRAMEBUFFER,j,Y,ce,0);else if(_.depthTexture.format===hr)Xe(_)?o.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,j,Y,ce,0,de):n.framebufferTexture2D(n.FRAMEBUFFER,j,Y,ce,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function te(R){const _=i.get(R),k=R.isWebGLCubeRenderTarget===!0;if(_.__boundDepthTexture!==R.depthTexture){const G=R.depthTexture;if(_.__depthDisposeCallback&&_.__depthDisposeCallback(),G){const q=()=>{delete _.__boundDepthTexture,delete _.__depthDisposeCallback,G.removeEventListener("dispose",q)};G.addEventListener("dispose",q),_.__depthDisposeCallback=q}_.__boundDepthTexture=G}if(R.depthTexture&&!_.__autoAllocateDepthBuffer)if(k)for(let G=0;G<6;G++)mt(_.__webglFramebuffer[G],R,G);else{const G=R.texture.mipmaps;G&&G.length>0?mt(_.__webglFramebuffer[0],R,0):mt(_.__webglFramebuffer,R,0)}else if(k){_.__webglDepthbuffer=[];for(let G=0;G<6;G++)if(t.bindFramebuffer(n.FRAMEBUFFER,_.__webglFramebuffer[G]),_.__webglDepthbuffer[G]===void 0)_.__webglDepthbuffer[G]=n.createRenderbuffer(),He(_.__webglDepthbuffer[G],R,!1);else{const q=R.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,ce=_.__webglDepthbuffer[G];n.bindRenderbuffer(n.RENDERBUFFER,ce),n.framebufferRenderbuffer(n.FRAMEBUFFER,q,n.RENDERBUFFER,ce)}}else{const G=R.texture.mipmaps;if(G&&G.length>0?t.bindFramebuffer(n.FRAMEBUFFER,_.__webglFramebuffer[0]):t.bindFramebuffer(n.FRAMEBUFFER,_.__webglFramebuffer),_.__webglDepthbuffer===void 0)_.__webglDepthbuffer=n.createRenderbuffer(),He(_.__webglDepthbuffer,R,!1);else{const q=R.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,ce=_.__webglDepthbuffer;n.bindRenderbuffer(n.RENDERBUFFER,ce),n.framebufferRenderbuffer(n.FRAMEBUFFER,q,n.RENDERBUFFER,ce)}}t.bindFramebuffer(n.FRAMEBUFFER,null)}function se(R,_,k){const G=i.get(R);_!==void 0&&Se(G.__webglFramebuffer,R,R.texture,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,0),k!==void 0&&te(R)}function ae(R){const _=R.texture,k=i.get(R),G=i.get(_);R.addEventListener("dispose",y);const q=R.textures,ce=R.isWebGLCubeRenderTarget===!0,de=q.length>1;if(de||(G.__webglTexture===void 0&&(G.__webglTexture=n.createTexture()),G.__version=_.version,a.memory.textures++),ce){k.__webglFramebuffer=[];for(let Y=0;Y<6;Y++)if(_.mipmaps&&_.mipmaps.length>0){k.__webglFramebuffer[Y]=[];for(let j=0;j<_.mipmaps.length;j++)k.__webglFramebuffer[Y][j]=n.createFramebuffer()}else k.__webglFramebuffer[Y]=n.createFramebuffer()}else{if(_.mipmaps&&_.mipmaps.length>0){k.__webglFramebuffer=[];for(let Y=0;Y<_.mipmaps.length;Y++)k.__webglFramebuffer[Y]=n.createFramebuffer()}else k.__webglFramebuffer=n.createFramebuffer();if(de)for(let Y=0,j=q.length;Y<j;Y++){const he=i.get(q[Y]);he.__webglTexture===void 0&&(he.__webglTexture=n.createTexture(),a.memory.textures++)}if(R.samples>0&&Xe(R)===!1){k.__webglMultisampledFramebuffer=n.createFramebuffer(),k.__webglColorRenderbuffer=[],t.bindFramebuffer(n.FRAMEBUFFER,k.__webglMultisampledFramebuffer);for(let Y=0;Y<q.length;Y++){const j=q[Y];k.__webglColorRenderbuffer[Y]=n.createRenderbuffer(),n.bindRenderbuffer(n.RENDERBUFFER,k.__webglColorRenderbuffer[Y]);const he=s.convert(j.format,j.colorSpace),Le=s.convert(j.type),ge=b(j.internalFormat,he,Le,j.normalized,j.colorSpace,R.isXRRenderTarget===!0),fe=Ge(R);n.renderbufferStorageMultisample(n.RENDERBUFFER,fe,ge,R.width,R.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+Y,n.RENDERBUFFER,k.__webglColorRenderbuffer[Y])}n.bindRenderbuffer(n.RENDERBUFFER,null),R.depthBuffer&&(k.__webglDepthRenderbuffer=n.createRenderbuffer(),He(k.__webglDepthRenderbuffer,R,!0)),t.bindFramebuffer(n.FRAMEBUFFER,null)}}if(ce){t.bindTexture(n.TEXTURE_CUBE_MAP,G.__webglTexture),tt(n.TEXTURE_CUBE_MAP,_);for(let Y=0;Y<6;Y++)if(_.mipmaps&&_.mipmaps.length>0)for(let j=0;j<_.mipmaps.length;j++)Se(k.__webglFramebuffer[Y][j],R,_,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+Y,j);else Se(k.__webglFramebuffer[Y],R,_,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+Y,0);g(_)&&x(n.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(de){for(let Y=0,j=q.length;Y<j;Y++){const he=q[Y],Le=i.get(he);let ge=n.TEXTURE_2D;(R.isWebGL3DRenderTarget||R.isWebGLArrayRenderTarget)&&(ge=R.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY),t.bindTexture(ge,Le.__webglTexture),tt(ge,he),Se(k.__webglFramebuffer,R,he,n.COLOR_ATTACHMENT0+Y,ge,0),g(he)&&x(ge)}t.unbindTexture()}else{let Y=n.TEXTURE_2D;if((R.isWebGL3DRenderTarget||R.isWebGLArrayRenderTarget)&&(Y=R.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY),t.bindTexture(Y,G.__webglTexture),tt(Y,_),_.mipmaps&&_.mipmaps.length>0)for(let j=0;j<_.mipmaps.length;j++)Se(k.__webglFramebuffer[j],R,_,n.COLOR_ATTACHMENT0,Y,j);else Se(k.__webglFramebuffer,R,_,n.COLOR_ATTACHMENT0,Y,0);g(_)&&x(Y),t.unbindTexture()}R.depthBuffer&&te(R)}function oe(R){const _=R.textures;for(let k=0,G=_.length;k<G;k++){const q=_[k];if(g(q)){const ce=E(R),de=i.get(q).__webglTexture;t.bindTexture(ce,de),x(ce),t.unbindTexture()}}}const ue=[],Fe=[];function Ue(R){if(R.samples>0){if(Xe(R)===!1){const _=R.textures,k=R.width,G=R.height;let q=n.COLOR_BUFFER_BIT;const ce=R.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,de=i.get(R),Y=_.length>1;if(Y)for(let he=0;he<_.length;he++)t.bindFramebuffer(n.FRAMEBUFFER,de.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+he,n.RENDERBUFFER,null),t.bindFramebuffer(n.FRAMEBUFFER,de.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+he,n.TEXTURE_2D,null,0);t.bindFramebuffer(n.READ_FRAMEBUFFER,de.__webglMultisampledFramebuffer);const j=R.texture.mipmaps;j&&j.length>0?t.bindFramebuffer(n.DRAW_FRAMEBUFFER,de.__webglFramebuffer[0]):t.bindFramebuffer(n.DRAW_FRAMEBUFFER,de.__webglFramebuffer);for(let he=0;he<_.length;he++){if(R.resolveDepthBuffer&&(R.depthBuffer&&(q|=n.DEPTH_BUFFER_BIT),R.stencilBuffer&&R.resolveStencilBuffer&&(q|=n.STENCIL_BUFFER_BIT)),Y){n.framebufferRenderbuffer(n.READ_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.RENDERBUFFER,de.__webglColorRenderbuffer[he]);const Le=i.get(_[he]).__webglTexture;n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,Le,0)}n.blitFramebuffer(0,0,k,G,0,0,k,G,q,n.NEAREST),l===!0&&(ue.length=0,Fe.length=0,ue.push(n.COLOR_ATTACHMENT0+he),R.depthBuffer&&R.storeMultisampledDepthBuffer===!1&&(ue.push(ce),Fe.push(ce),n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,Fe)),n.invalidateFramebuffer(n.READ_FRAMEBUFFER,ue))}if(t.bindFramebuffer(n.READ_FRAMEBUFFER,null),t.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),Y)for(let he=0;he<_.length;he++){t.bindFramebuffer(n.FRAMEBUFFER,de.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+he,n.RENDERBUFFER,de.__webglColorRenderbuffer[he]);const Le=i.get(_[he]).__webglTexture;t.bindFramebuffer(n.FRAMEBUFFER,de.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+he,n.TEXTURE_2D,Le,0)}t.bindFramebuffer(n.DRAW_FRAMEBUFFER,de.__webglMultisampledFramebuffer)}else if(R.depthBuffer&&R.storeMultisampledDepthBuffer===!1&&l){const _=R.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT;n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,[_])}}}function Ge(R){return Math.min(r.maxSamples,R.samples)}function Xe(R){const _=i.get(R);return R.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&_.__useRenderToTexture!==!1}function D(R){const _=a.render.frame;d.get(R)!==_&&(d.set(R,_),R.update())}function ht(R,_){const k=R.colorSpace,G=R.format,q=R.type;return R.isCompressedTexture===!0||R.isVideoTexture===!0||k!==To&&k!==Zi&&(at.getTransfer(k)===gt?(G!==Wn||q!==Tn)&&ke("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):st("WebGLTextures: Unsupported texture color space:",k)),_}function nt(R){return typeof HTMLImageElement<"u"&&R instanceof HTMLImageElement?(c.width=R.naturalWidth||R.width,c.height=R.naturalHeight||R.height):typeof VideoFrame<"u"&&R instanceof VideoFrame?(c.width=R.displayWidth,c.height=R.displayHeight):(c.width=R.width,c.height=R.height),c}this.allocateTextureUnit=V,this.resetTextureUnits=B,this.getTextureUnits=N,this.setTextureUnits=U,this.setTexture2D=ie,this.setTexture2DArray=X,this.setTexture3D=Q,this.setTextureCube=ne,this.rebindTextures=se,this.setupRenderTarget=ae,this.updateRenderTargetMipmap=oe,this.updateMultisampleRenderTarget=Ue,this.setupDepthRenderbuffer=te,this.setupFrameBufferTexture=Se,this.useMultisampledRTT=Xe,this.isReversedDepthBuffer=function(){return t.buffers.depth.getReversed()}}function fb(n,e){function t(i,r=Zi){let s;const a=at.getTransfer(r);if(i===Tn)return n.UNSIGNED_BYTE;if(i===vd)return n.UNSIGNED_SHORT_4_4_4_4;if(i===yd)return n.UNSIGNED_SHORT_5_5_5_1;if(i===Qh)return n.UNSIGNED_INT_5_9_9_9_REV;if(i===ef)return n.UNSIGNED_INT_10F_11F_11F_REV;if(i===Jh)return n.BYTE;if(i===jh)return n.SHORT;if(i===Qs)return n.UNSIGNED_SHORT;if(i===gd)return n.INT;if(i===pi)return n.UNSIGNED_INT;if(i===oi)return n.FLOAT;if(i===mi)return n.HALF_FLOAT;if(i===tf)return n.ALPHA;if(i===nf)return n.RGB;if(i===Wn)return n.RGBA;if(i===Li)return n.DEPTH_COMPONENT;if(i===hr)return n.DEPTH_STENCIL;if(i===rf)return n.RED;if(i===_d)return n.RED_INTEGER;if(i===yr)return n.RG;if(i===xd)return n.RG_INTEGER;if(i===bd)return n.RGBA_INTEGER;if(i===ao||i===oo||i===lo||i===co)if(a===gt)if(s=e.get("WEBGL_compressed_texture_s3tc_srgb"),s!==null){if(i===ao)return s.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(i===oo)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(i===lo)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(i===co)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(s=e.get("WEBGL_compressed_texture_s3tc"),s!==null){if(i===ao)return s.COMPRESSED_RGB_S3TC_DXT1_EXT;if(i===oo)return s.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(i===lo)return s.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(i===co)return s.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(i===cc||i===dc||i===uc||i===hc)if(s=e.get("WEBGL_compressed_texture_pvrtc"),s!==null){if(i===cc)return s.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(i===dc)return s.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(i===uc)return s.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(i===hc)return s.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(i===fc||i===pc||i===mc||i===gc||i===vc||i===wo||i===yc)if(s=e.get("WEBGL_compressed_texture_etc"),s!==null){if(i===fc||i===pc)return a===gt?s.COMPRESSED_SRGB8_ETC2:s.COMPRESSED_RGB8_ETC2;if(i===mc)return a===gt?s.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:s.COMPRESSED_RGBA8_ETC2_EAC;if(i===gc)return s.COMPRESSED_R11_EAC;if(i===vc)return s.COMPRESSED_SIGNED_R11_EAC;if(i===wo)return s.COMPRESSED_RG11_EAC;if(i===yc)return s.COMPRESSED_SIGNED_RG11_EAC}else return null;if(i===_c||i===xc||i===bc||i===Sc||i===Mc||i===wc||i===Ec||i===Tc||i===Ac||i===Rc||i===Cc||i===Ic||i===Pc||i===Lc)if(s=e.get("WEBGL_compressed_texture_astc"),s!==null){if(i===_c)return a===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:s.COMPRESSED_RGBA_ASTC_4x4_KHR;if(i===xc)return a===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:s.COMPRESSED_RGBA_ASTC_5x4_KHR;if(i===bc)return a===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:s.COMPRESSED_RGBA_ASTC_5x5_KHR;if(i===Sc)return a===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:s.COMPRESSED_RGBA_ASTC_6x5_KHR;if(i===Mc)return a===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:s.COMPRESSED_RGBA_ASTC_6x6_KHR;if(i===wc)return a===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:s.COMPRESSED_RGBA_ASTC_8x5_KHR;if(i===Ec)return a===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:s.COMPRESSED_RGBA_ASTC_8x6_KHR;if(i===Tc)return a===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:s.COMPRESSED_RGBA_ASTC_8x8_KHR;if(i===Ac)return a===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:s.COMPRESSED_RGBA_ASTC_10x5_KHR;if(i===Rc)return a===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:s.COMPRESSED_RGBA_ASTC_10x6_KHR;if(i===Cc)return a===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:s.COMPRESSED_RGBA_ASTC_10x8_KHR;if(i===Ic)return a===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:s.COMPRESSED_RGBA_ASTC_10x10_KHR;if(i===Pc)return a===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:s.COMPRESSED_RGBA_ASTC_12x10_KHR;if(i===Lc)return a===gt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:s.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(i===Nc||i===Dc||i===Uc)if(s=e.get("EXT_texture_compression_bptc"),s!==null){if(i===Nc)return a===gt?s.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:s.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(i===Dc)return s.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(i===Uc)return s.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(i===Oc||i===Fc||i===Eo||i===Bc)if(s=e.get("EXT_texture_compression_rgtc"),s!==null){if(i===Oc)return s.COMPRESSED_RED_RGTC1_EXT;if(i===Fc)return s.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(i===Eo)return s.COMPRESSED_RED_GREEN_RGTC2_EXT;if(i===Bc)return s.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return i===ea?n.UNSIGNED_INT_24_8:n[i]!==void 0?n[i]:null}return{convert:t}}const pb=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,mb=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class gb{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){const i=new mf(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=i}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,i=new gi({vertexShader:pb,fragmentShader:mb,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new Un(new Wo(20,20),i)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class vb extends Er{constructor(e,t){super();const i=this;let r=null,s=1,a=null,o="local-floor",l=1,c=null,d=null,u=null,h=null,f=null,p=null;const v=typeof XRWebGLBinding<"u",m=new gb,g={},x=t.getContextAttributes();let E=null,b=null;const w=[],S=[],T=new le;let y=null,A=null;const C=new Gn;C.viewport=new Rt;const L=new Gn;L.viewport=new Rt;const I=[C,L],B=new wv;let N=null,U=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Z){let ee=w[Z];return ee===void 0&&(ee=new _l,w[Z]=ee),ee.getTargetRaySpace()},this.getControllerGrip=function(Z){let ee=w[Z];return ee===void 0&&(ee=new _l,w[Z]=ee),ee.getGripSpace()},this.getHand=function(Z){let ee=w[Z];return ee===void 0&&(ee=new _l,w[Z]=ee),ee.getHandSpace()};function V(Z){const ee=S.indexOf(Z.inputSource);if(ee===-1)return;const ye=w[ee];ye!==void 0&&(ye.update(Z.inputSource,Z.frame,c||a),ye.dispatchEvent({type:Z.type,data:Z.inputSource}))}function $(){r.removeEventListener("select",V),r.removeEventListener("selectstart",V),r.removeEventListener("selectend",V),r.removeEventListener("squeeze",V),r.removeEventListener("squeezestart",V),r.removeEventListener("squeezeend",V),r.removeEventListener("end",$),r.removeEventListener("inputsourceschange",ie);for(let Z=0;Z<w.length;Z++){const ee=S[Z];ee!==null&&(S[Z]=null,w[Z].disconnect(ee))}N=null,U=null,m.reset();for(const Z in g)delete g[Z];if(e.setRenderTarget(E),f=null,h=null,u=null,r=null,b=null,lt.stop(),i.isPresenting=!1,e.setPixelRatio(y),e.setSize(T.width,T.height,!1),A!==null){const Z=A.camera;Z.fov=A.fov,Z.zoom=A.zoom,Z.updateProjectionMatrix(),A=null}i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Z){s=Z,i.isPresenting===!0&&ke("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Z){o=Z,i.isPresenting===!0&&ke("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(Z){c=Z},this.getBaseLayer=function(){return h!==null?h:f},this.getBinding=function(){return u===null&&v&&(u=new XRWebGLBinding(r,t)),u},this.getFrame=function(){return p},this.getSession=function(){return r},this.setSession=async function(Z){if(r=Z,r!==null){if(E=e.getRenderTarget(),r.addEventListener("select",V),r.addEventListener("selectstart",V),r.addEventListener("selectend",V),r.addEventListener("squeeze",V),r.addEventListener("squeezestart",V),r.addEventListener("squeezeend",V),r.addEventListener("end",$),r.addEventListener("inputsourceschange",ie),x.xrCompatible!==!0&&await t.makeXRCompatible(),y=e.getPixelRatio(),e.getSize(T),v&&"createProjectionLayer"in XRWebGLBinding.prototype){let ye=null,ze=null,Se=null;x.depth&&(Se=x.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,ye=x.stencil?hr:Li,ze=x.stencil?ea:pi);const He={colorFormat:t.RGBA8,depthFormat:Se,scaleFactor:s};u=this.getBinding(),h=u.createProjectionLayer(He),r.updateRenderState({layers:[h]}),e.setPixelRatio(1),e.setSize(h.textureWidth,h.textureHeight,!1),b=new Xn(h.textureWidth,h.textureHeight,{format:Wn,type:Tn,depthTexture:new ia(h.textureWidth,h.textureHeight,ze,void 0,void 0,void 0,void 0,void 0,void 0,ye),stencilBuffer:x.stencil,colorSpace:e.outputColorSpace,samples:x.antialias?4:0,resolveDepthBuffer:h.ignoreDepthValues===!1,resolveStencilBuffer:h.ignoreDepthValues===!1,storeMultisampledDepthBuffer:h.ignoreDepthValues===!1,storeMultisampledStencilBuffer:h.ignoreDepthValues===!1})}else{const ye={antialias:x.antialias,alpha:!0,depth:x.depth,stencil:x.stencil,framebufferScaleFactor:s};f=new XRWebGLLayer(r,t,ye),r.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),b=new Xn(f.framebufferWidth,f.framebufferHeight,{format:Wn,type:Tn,colorSpace:e.outputColorSpace,stencilBuffer:x.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1,storeMultisampledDepthBuffer:f.ignoreDepthValues===!1,storeMultisampledStencilBuffer:f.ignoreDepthValues===!1})}b.isXRRenderTarget=!0,this.setFoveation(l),c=null,a=await r.requestReferenceSpace(o),lt.setContext(r),lt.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function ie(Z){for(let ee=0;ee<Z.removed.length;ee++){const ye=Z.removed[ee],ze=S.indexOf(ye);ze>=0&&(S[ze]=null,w[ze].disconnect(ye))}for(let ee=0;ee<Z.added.length;ee++){const ye=Z.added[ee];let ze=S.indexOf(ye);if(ze===-1){for(let He=0;He<w.length;He++)if(He>=S.length){S.push(ye),ze=He;break}else if(S[He]===null){S[He]=ye,ze=He;break}if(ze===-1)break}const Se=w[ze];Se&&Se.connect(ye)}}const X=new P,Q=new P;function ne(Z,ee,ye){X.setFromMatrixPosition(ee.matrixWorld),Q.setFromMatrixPosition(ye.matrixWorld);const ze=X.distanceTo(Q),Se=ee.projectionMatrix.elements,He=ye.projectionMatrix.elements,mt=Se[14]/(Se[10]-1),te=Se[14]/(Se[10]+1),se=(Se[9]+1)/Se[5],ae=(Se[9]-1)/Se[5],oe=(Se[8]-1)/Se[0],ue=(He[8]+1)/He[0],Fe=mt*oe,Ue=mt*ue,Ge=ze/(-oe+ue),Xe=Ge*-oe;if(ee.matrixWorld.decompose(Z.position,Z.quaternion,Z.scale),Z.translateX(Xe),Z.translateZ(Ge),Z.matrixWorld.compose(Z.position,Z.quaternion,Z.scale),Z.matrixWorldInverse.copy(Z.matrixWorld).invert(),Se[10]===-1)Z.projectionMatrix.copy(ee.projectionMatrix),Z.projectionMatrixInverse.copy(ee.projectionMatrixInverse);else{const D=mt+Ge,ht=te+Ge,nt=Fe-Xe,R=Ue+(ze-Xe),_=se*te/ht*D,k=ae*te/ht*D;Z.projectionMatrix.makePerspective(nt,R,_,k,D,ht),Z.projectionMatrixInverse.copy(Z.projectionMatrix).invert()}}function Pe(Z,ee){ee===null?Z.matrixWorld.copy(Z.matrix):Z.matrixWorld.multiplyMatrices(ee.matrixWorld,Z.matrix),Z.matrixWorldInverse.copy(Z.matrixWorld).invert()}this.updateCamera=function(Z){if(r===null)return;let ee=Z.near,ye=Z.far;m.texture!==null&&(m.depthNear>0&&(ee=m.depthNear),m.depthFar>0&&(ye=m.depthFar)),B.near=L.near=C.near=ee,B.far=L.far=C.far=ye,(N!==B.near||U!==B.far)&&(r.updateRenderState({depthNear:B.near,depthFar:B.far}),N=B.near,U=B.far),B.layers.mask=Z.layers.mask|6,C.layers.mask=B.layers.mask&-5,L.layers.mask=B.layers.mask&-3;const ze=Z.parent,Se=B.cameras;Pe(B,ze);for(let He=0;He<Se.length;He++)Pe(Se[He],ze);Se.length===2?ne(B,C,L):B.projectionMatrix.copy(C.projectionMatrix),A===null&&Z.isPerspectiveCamera&&(A={camera:Z,fov:Z.fov,zoom:Z.zoom}),Ee(Z,B,ze)};function Ee(Z,ee,ye){ye===null?Z.matrix.copy(ee.matrixWorld):(Z.matrix.copy(ye.matrixWorld),Z.matrix.invert(),Z.matrix.multiply(ee.matrixWorld)),Z.matrix.decompose(Z.position,Z.quaternion,Z.scale),Z.updateMatrixWorld(!0),Z.projectionMatrix.copy(ee.projectionMatrix),Z.projectionMatrixInverse.copy(ee.projectionMatrixInverse),Z.isPerspectiveCamera&&(Z.fov=na*2*Math.atan(1/Z.projectionMatrix.elements[5]),Z.zoom=1)}this.getCamera=function(){return B},this.getFoveation=function(){if(!(h===null&&f===null))return l},this.setFoveation=function(Z){l=Z,h!==null&&(h.fixedFoveation=Z),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=Z)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(B)},this.getCameraTexture=function(Z){return g[Z]};let ut=null;function tt(Z,ee){if(d=ee.getViewerPose(c||a),p=ee,d!==null){const ye=d.views;f!==null&&(e.setRenderTargetFramebuffer(b,f.framebuffer),e.setRenderTarget(b));let ze=!1;ye.length!==B.cameras.length&&(B.cameras.length=0,ze=!0);for(let te=0;te<ye.length;te++){const se=ye[te];let ae=null;if(f!==null)ae=f.getViewport(se);else{const ue=u.getViewSubImage(h,se);ae=ue.viewport,te===0&&(e.setRenderTargetTextures(b,ue.colorTexture,ue.depthStencilTexture),e.setRenderTarget(b))}let oe=I[te];oe===void 0&&(oe=new Gn,oe.layers.enable(te),oe.viewport=new Rt,I[te]=oe),oe.matrix.fromArray(se.transform.matrix),oe.matrix.decompose(oe.position,oe.quaternion,oe.scale),oe.projectionMatrix.fromArray(se.projectionMatrix),oe.projectionMatrixInverse.copy(oe.projectionMatrix).invert(),oe.viewport.set(ae.x,ae.y,ae.width,ae.height),te===0&&(B.matrix.copy(oe.matrix),B.matrix.decompose(B.position,B.quaternion,B.scale)),ze===!0&&B.cameras.push(oe)}const Se=r.enabledFeatures;if(Se&&Se.includes("depth-sensing")&&r.depthUsage=="gpu-optimized"&&v){u=i.getBinding();const te=u.getDepthInformation(ye[0]);te&&te.isValid&&te.texture&&m.init(te,r.renderState)}if(Se&&Se.includes("camera-access")&&v){e.state.unbindTexture(),u=i.getBinding();for(let te=0;te<ye.length;te++){const se=ye[te].camera;if(se){let ae=g[se];ae||(ae=new mf,g[se]=ae);const oe=u.getCameraImage(se);ae.sourceTexture=oe}}}}for(let ye=0;ye<w.length;ye++){const ze=S[ye],Se=w[ye];ze!==null&&Se!==void 0&&Se.update(ze,ee,c||a)}ut&&ut(Z,ee),ee.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:ee}),p=null}const lt=new Cf;lt.setAnimationLoop(tt),this.setAnimationLoop=function(Z){ut=Z},this.dispose=function(){}}}const yb=new yt,Of=new qe;Of.set(-1,0,0,0,1,0,0,0,1);function _b(n,e){function t(m,g){m.matrixAutoUpdate===!0&&m.updateMatrix(),g.value.copy(m.matrix)}function i(m,g){g.color.getRGB(m.fogColor.value,Ef(n)),g.isFog?(m.fogNear.value=g.near,m.fogFar.value=g.far):g.isFogExp2&&(m.fogDensity.value=g.density)}function r(m,g,x,E,b){g.isNodeMaterial?g.uniformsNeedUpdate=!1:g.isMeshBasicMaterial?s(m,g):g.isMeshLambertMaterial?(s(m,g),g.envMap&&(m.envMapIntensity.value=g.envMapIntensity)):g.isMeshToonMaterial?(s(m,g),u(m,g)):g.isMeshPhongMaterial?(s(m,g),d(m,g),g.envMap&&(m.envMapIntensity.value=g.envMapIntensity)):g.isMeshStandardMaterial?(s(m,g),h(m,g),g.isMeshPhysicalMaterial&&f(m,g,b)):g.isMeshMatcapMaterial?(s(m,g),p(m,g)):g.isMeshDepthMaterial?s(m,g):g.isMeshDistanceMaterial?(s(m,g),v(m,g)):g.isMeshNormalMaterial?s(m,g):g.isLineBasicMaterial?(a(m,g),g.isLineDashedMaterial&&o(m,g)):g.isPointsMaterial?l(m,g,x,E):g.isSpriteMaterial?c(m,g):g.isShadowMaterial?(m.color.value.copy(g.color),m.opacity.value=g.opacity):g.isShaderMaterial&&(g.uniformsNeedUpdate=!1)}function s(m,g){m.opacity.value=g.opacity,g.color&&m.diffuse.value.copy(g.color),g.emissive&&m.emissive.value.copy(g.emissive).multiplyScalar(g.emissiveIntensity),g.map&&(m.map.value=g.map,t(g.map,m.mapTransform)),g.alphaMap&&(m.alphaMap.value=g.alphaMap,t(g.alphaMap,m.alphaMapTransform)),g.bumpMap&&(m.bumpMap.value=g.bumpMap,t(g.bumpMap,m.bumpMapTransform),m.bumpScale.value=g.bumpScale,g.side===vn&&(m.bumpScale.value*=-1)),g.normalMap&&(m.normalMap.value=g.normalMap,t(g.normalMap,m.normalMapTransform),m.normalScale.value.copy(g.normalScale),g.side===vn&&m.normalScale.value.negate()),g.displacementMap&&(m.displacementMap.value=g.displacementMap,t(g.displacementMap,m.displacementMapTransform),m.displacementScale.value=g.displacementScale,m.displacementBias.value=g.displacementBias),g.emissiveMap&&(m.emissiveMap.value=g.emissiveMap,t(g.emissiveMap,m.emissiveMapTransform)),g.specularMap&&(m.specularMap.value=g.specularMap,t(g.specularMap,m.specularMapTransform)),g.alphaTest>0&&(m.alphaTest.value=g.alphaTest);const x=e.get(g),E=x.envMap,b=x.envMapRotation;E&&(m.envMap.value=E,m.envMapRotation.value.setFromMatrix4(yb.makeRotationFromEuler(b)).transpose(),E.isCubeTexture&&E.isRenderTargetTexture===!1&&m.envMapRotation.value.premultiply(Of),m.reflectivity.value=g.reflectivity,m.ior.value=g.ior,m.refractionRatio.value=g.refractionRatio),g.lightMap&&(m.lightMap.value=g.lightMap,m.lightMapIntensity.value=g.lightMapIntensity,t(g.lightMap,m.lightMapTransform)),g.aoMap&&(m.aoMap.value=g.aoMap,m.aoMapIntensity.value=g.aoMapIntensity,t(g.aoMap,m.aoMapTransform))}function a(m,g){m.diffuse.value.copy(g.color),m.opacity.value=g.opacity,g.map&&(m.map.value=g.map,t(g.map,m.mapTransform))}function o(m,g){m.dashSize.value=g.dashSize,m.totalSize.value=g.dashSize+g.gapSize,m.scale.value=g.scale}function l(m,g,x,E){m.diffuse.value.copy(g.color),m.opacity.value=g.opacity,m.size.value=g.size*x,m.scale.value=E*.5,g.map&&(m.map.value=g.map,t(g.map,m.uvTransform)),g.alphaMap&&(m.alphaMap.value=g.alphaMap,t(g.alphaMap,m.alphaMapTransform)),g.alphaTest>0&&(m.alphaTest.value=g.alphaTest)}function c(m,g){m.diffuse.value.copy(g.color),m.opacity.value=g.opacity,m.rotation.value=g.rotation,g.map&&(m.map.value=g.map,t(g.map,m.mapTransform)),g.alphaMap&&(m.alphaMap.value=g.alphaMap,t(g.alphaMap,m.alphaMapTransform)),g.alphaTest>0&&(m.alphaTest.value=g.alphaTest)}function d(m,g){m.specular.value.copy(g.specular),m.shininess.value=Math.max(g.shininess,1e-4)}function u(m,g){g.gradientMap&&(m.gradientMap.value=g.gradientMap)}function h(m,g){m.metalness.value=g.metalness,g.metalnessMap&&(m.metalnessMap.value=g.metalnessMap,t(g.metalnessMap,m.metalnessMapTransform)),m.roughness.value=g.roughness,g.roughnessMap&&(m.roughnessMap.value=g.roughnessMap,t(g.roughnessMap,m.roughnessMapTransform)),g.envMap&&(m.envMapIntensity.value=g.envMapIntensity)}function f(m,g,x){m.ior.value=g.ior,g.sheen>0&&(m.sheenColor.value.copy(g.sheenColor).multiplyScalar(g.sheen),m.sheenRoughness.value=g.sheenRoughness,g.sheenColorMap&&(m.sheenColorMap.value=g.sheenColorMap,t(g.sheenColorMap,m.sheenColorMapTransform)),g.sheenRoughnessMap&&(m.sheenRoughnessMap.value=g.sheenRoughnessMap,t(g.sheenRoughnessMap,m.sheenRoughnessMapTransform))),g.clearcoat>0&&(m.clearcoat.value=g.clearcoat,m.clearcoatRoughness.value=g.clearcoatRoughness,g.clearcoatMap&&(m.clearcoatMap.value=g.clearcoatMap,t(g.clearcoatMap,m.clearcoatMapTransform)),g.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=g.clearcoatRoughnessMap,t(g.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),g.clearcoatNormalMap&&(m.clearcoatNormalMap.value=g.clearcoatNormalMap,t(g.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(g.clearcoatNormalScale),g.side===vn&&m.clearcoatNormalScale.value.negate())),g.dispersion>0&&(m.dispersion.value=g.dispersion),g.retroreflectivity>0&&(m.retroreflectivity.value=g.retroreflectivity),g.iridescence>0&&(m.iridescence.value=g.iridescence,m.iridescenceIOR.value=g.iridescenceIOR,m.iridescenceThicknessMinimum.value=g.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=g.iridescenceThicknessRange[1],g.iridescenceMap&&(m.iridescenceMap.value=g.iridescenceMap,t(g.iridescenceMap,m.iridescenceMapTransform)),g.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=g.iridescenceThicknessMap,t(g.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),g.transmission>0&&(m.transmission.value=g.transmission,m.transmissionSamplerMap.value=x.texture,m.transmissionSamplerSize.value.set(x.width,x.height),g.transmissionMap&&(m.transmissionMap.value=g.transmissionMap,t(g.transmissionMap,m.transmissionMapTransform)),m.thickness.value=g.thickness,g.thicknessMap&&(m.thicknessMap.value=g.thicknessMap,t(g.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=g.attenuationDistance,m.attenuationColor.value.copy(g.attenuationColor)),g.anisotropy>0&&(m.anisotropyVector.value.set(g.anisotropy*Math.cos(g.anisotropyRotation),g.anisotropy*Math.sin(g.anisotropyRotation)),g.anisotropyMap&&(m.anisotropyMap.value=g.anisotropyMap,t(g.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=g.specularIntensity,m.specularColor.value.copy(g.specularColor),g.specularColorMap&&(m.specularColorMap.value=g.specularColorMap,t(g.specularColorMap,m.specularColorMapTransform)),g.specularIntensityMap&&(m.specularIntensityMap.value=g.specularIntensityMap,t(g.specularIntensityMap,m.specularIntensityMapTransform))}function p(m,g){g.matcap&&(m.matcap.value=g.matcap)}function v(m,g){const x=e.get(g).light;m.referencePosition.value.setFromMatrixPosition(x.matrixWorld),m.nearDistance.value=x.shadow.camera.near,m.farDistance.value=x.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:r}}function xb(n,e,t,i){let r={},s={},a=[];const o=n.getParameter(n.MAX_UNIFORM_BUFFER_BINDINGS);function l(b,w){const S=w.program;i.uniformBlockBinding(b,S)}function c(b,w){let S=r[b.id];S===void 0&&(m(b),S=d(b),r[b.id]=S,b.addEventListener("dispose",x));const T=w.program;i.updateUBOMapping(b,T);const y=e.render.frame;s[b.id]!==y&&(h(b),s[b.id]=y)}function d(b){const w=u();b.__bindingPointIndex=w;const S=n.createBuffer(),T=b.__size,y=b.usage;return n.bindBuffer(n.UNIFORM_BUFFER,S),n.bufferData(n.UNIFORM_BUFFER,T,y),n.bindBuffer(n.UNIFORM_BUFFER,null),n.bindBufferBase(n.UNIFORM_BUFFER,w,S),S}function u(){for(let b=0;b<o;b++)if(a.indexOf(b)===-1)return a.push(b),b;return st("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function h(b){const w=r[b.id],S=b.uniforms,T=b.__cache;n.bindBuffer(n.UNIFORM_BUFFER,w);for(let y=0,A=S.length;y<A;y++){const C=S[y];if(Array.isArray(C))for(let L=0,I=C.length;L<I;L++)f(C[L],y,L,T);else f(C,y,0,T)}n.bindBuffer(n.UNIFORM_BUFFER,null)}function f(b,w,S,T){if(v(b,w,S,T)===!0){const y=b.__offset,A=b.value;if(Array.isArray(A)){let C=0;for(let L=0;L<A.length;L++){const I=A[L],B=g(I);p(I,b.__data,C),typeof I!="number"&&typeof I!="boolean"&&!I.isMatrix3&&!ArrayBuffer.isView(I)&&(C+=B.storage/Float32Array.BYTES_PER_ELEMENT)}}else p(A,b.__data,0);n.bufferSubData(n.UNIFORM_BUFFER,y,b.__data)}}function p(b,w,S){typeof b=="number"||typeof b=="boolean"?w[0]=b:b.isMatrix3?(w[0]=b.elements[0],w[1]=b.elements[1],w[2]=b.elements[2],w[3]=0,w[4]=b.elements[3],w[5]=b.elements[4],w[6]=b.elements[5],w[7]=0,w[8]=b.elements[6],w[9]=b.elements[7],w[10]=b.elements[8],w[11]=0):ArrayBuffer.isView(b)?w.set(new b.constructor(b.buffer,b.byteOffset,w.length)):b.toArray(w,S)}function v(b,w,S,T){const y=b.value,A=w+"_"+S;if(T[A]===void 0)return typeof y=="number"||typeof y=="boolean"?T[A]=y:ArrayBuffer.isView(y)?T[A]=y.slice():T[A]=y.clone(),!0;{const C=T[A];if(typeof y=="number"||typeof y=="boolean"){if(C!==y)return T[A]=y,!0}else{if(ArrayBuffer.isView(y))return!0;if(C.equals(y)===!1)return C.copy(y),!0}}return!1}function m(b){const w=b.uniforms;let S=0;const T=16;for(let A=0,C=w.length;A<C;A++){const L=Array.isArray(w[A])?w[A]:[w[A]];for(let I=0,B=L.length;I<B;I++){const N=L[I],U=Array.isArray(N.value)?N.value:[N.value];for(let V=0,$=U.length;V<$;V++){const ie=U[V],X=g(ie),Q=S%T,ne=Q%X.boundary,Pe=Q+ne;S+=ne,Pe!==0&&T-Pe<X.storage&&(S+=T-Pe),N.__data=new Float32Array(X.storage/Float32Array.BYTES_PER_ELEMENT),N.__offset=S,S+=X.storage}}}const y=S%T;return y>0&&(S+=T-y),b.__size=S,b.__cache={},this}function g(b){const w={boundary:0,storage:0};return typeof b=="number"||typeof b=="boolean"?(w.boundary=4,w.storage=4):b.isVector2?(w.boundary=8,w.storage=8):b.isVector3||b.isColor?(w.boundary=16,w.storage=12):b.isVector4?(w.boundary=16,w.storage=16):b.isMatrix3?(w.boundary=48,w.storage=48):b.isMatrix4?(w.boundary=64,w.storage=64):b.isTexture?ke("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(b)?(w.boundary=16,w.storage=b.byteLength):ke("WebGLRenderer: Unsupported uniform value type.",b),w}function x(b){const w=b.target;w.removeEventListener("dispose",x);const S=a.indexOf(w.__bindingPointIndex);a.splice(S,1),n.deleteBuffer(r[w.id]),delete r[w.id],delete s[w.id]}function E(){for(const b in r)n.deleteBuffer(r[b]);a=[],r={},s={}}return{bind:l,update:c,dispose:E}}const bb=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let ti=null;function Sb(){return ti===null&&(ti=new Ag(bb,16,16,yr,mi),ti.name="DFG_LUT",ti.minFilter=sn,ti.magFilter=sn,ti.wrapS=Ti,ti.wrapT=Ti,ti.generateMipmaps=!1,ti.needsUpdate=!0),ti}class Ff{constructor(e={}){const{canvas:t=zm(),context:i=null,depth:r=!0,stencil:s=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:d="default",failIfMajorPerformanceCaveat:u=!1,reversedDepthBuffer:h=!1,outputBufferType:f=Tn}=e;this.isWebGLRenderer=!0;let p;if(i!==null){if(typeof WebGLRenderingContext<"u"&&i instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");p=i.getContextAttributes().alpha}else p=a;const v=f,m=new Set([bd,xd,_d]),g=new Set([Tn,pi,Qs,ea,vd,yd]),x=new Uint32Array(4),E=new Int32Array(4),b=new P;let w=null,S=null;const T=[],y=[];let A=null;this.domElement=t,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=di,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const C=this;let L=!1,I=null,B=null,N=null,U=null;this._outputColorSpace=hn;let V=0,$=0,ie=null,X=-1,Q=null;const ne=new Rt,Pe=new Rt;let Ee=null;const ut=new Qe(0);let tt=0,lt=t.width,Z=t.height,ee=1,ye=null,ze=null;const Se=new Rt(0,0,lt,Z),He=new Rt(0,0,lt,Z);let mt=!1;const te=new Ad;let se=!1,ae=!1;const oe=new yt,ue=new P,Fe=new Rt,Ue={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Ge=!1;function Xe(){return ie===null?ee:1}let D=i;function ht(M,O){return t.getContext(M,O)}let nt,R,_,k,G,q,ce,de,Y,j,he,Le,ge,fe,Ne,Be,Ze,F,pe,K,me,be,re;try{const M={alpha:!0,depth:r,stencil:s,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:d,failIfMajorPerformanceCaveat:u};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${pd}`),t.addEventListener("webglcontextlost",Mt,!1),t.addEventListener("webglcontextrestored",ft,!1),t.addEventListener("webglcontextcreationerror",Bn,!1),D===null){const O="webgl2";if(D=ht(O,M),D===null)throw ht(O)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}De()}catch(M){throw t.removeEventListener("webglcontextlost",Mt,!1),t.removeEventListener("webglcontextrestored",ft,!1),t.removeEventListener("webglcontextcreationerror",Bn,!1),st("WebGLRenderer: "+M.message),M}function De(){nt=new S_(D),nt.init(),me=new fb(D,nt),R=new h_(D,nt,e,me),_=new ub(D,nt),R.reversedDepthBuffer&&h&&_.buffers.depth.setReversed(!0),B=D.createFramebuffer(),N=D.createFramebuffer(),U=D.createFramebuffer(),k=new E_(D),G=new Jx,q=new hb(D,nt,_,G,R,me,k),ce=new b_(C),de=new Av(D),be=new d_(D,de),Y=new M_(D,de,k,be),j=new A_(D,Y,de,be,k),F=new T_(D,R,q),Ne=new f_(G),he=new Kx(C,ce,nt,R,be,Ne),Le=new _b(C,G),ge=new Qx,fe=new sb(nt),Ze=new c_(C,ce,_,j,p,l),Be=new db(C,j,R),re=new xb(D,k,R,_),pe=new u_(D,nt,k),K=new w_(D,nt,k),k.programs=he.programs,C.capabilities=R,C.extensions=nt,C.properties=G,C.renderLists=ge,C.shadowMap=Be,C.state=_,C.info=k}v!==Tn&&(A=new C_(v,t.width,t.height,o,r,s));const Ce=new vb(C,D);this.xr=Ce,this.getContext=function(){return D},this.getContextAttributes=function(){return D.getContextAttributes()},this.forceContextLoss=function(){const M=nt.get("WEBGL_lose_context");M&&M.loseContext()},this.forceContextRestore=function(){const M=nt.get("WEBGL_lose_context");M&&M.restoreContext()},this.getPixelRatio=function(){return ee},this.setPixelRatio=function(M){M!==void 0&&(ee=M,this.setSize(lt,Z,!1))},this.getSize=function(M){return M.set(lt,Z)},this.setSize=function(M,O,W=!0){if(Ce.isPresenting){ke("WebGLRenderer: Can't change size while VR device is presenting.");return}lt=M,Z=O,t.width=Math.floor(M*ee),t.height=Math.floor(O*ee),W===!0&&(t.style.width=M+"px",t.style.height=O+"px"),A!==null&&A.setSize(t.width,t.height),this.setViewport(0,0,M,O)},this.getDrawingBufferSize=function(M){return M.set(lt*ee,Z*ee).floor()},this.setDrawingBufferSize=function(M,O,W){lt=M,Z=O,ee=W,t.width=Math.floor(M*W),t.height=Math.floor(O*W),this.setViewport(0,0,M,O)},this.setEffects=function(M){if(v===Tn){st("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(M){for(let O=0;O<M.length;O++)if(M[O].isOutputPass===!0){ke("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}A.setEffects(M||[])},this.getCurrentViewport=function(M){return M.copy(ne)},this.getViewport=function(M){return M.copy(Se)},this.setViewport=function(M,O,W,z){M.isVector4?Se.set(M.x,M.y,M.z,M.w):Se.set(M,O,W,z),_.viewport(ne.copy(Se).multiplyScalar(ee).round())},this.getScissor=function(M){return M.copy(He)},this.setScissor=function(M,O,W,z){M.isVector4?He.set(M.x,M.y,M.z,M.w):He.set(M,O,W,z),_.scissor(Pe.copy(He).multiplyScalar(ee).round())},this.getScissorTest=function(){return mt},this.setScissorTest=function(M){_.setScissorTest(mt=M)},this.setOpaqueSort=function(M){ye=M},this.setTransparentSort=function(M){ze=M},this.getClearColor=function(M){return M.copy(Ze.getClearColor())},this.setClearColor=function(){Ze.setClearColor(...arguments)},this.getClearAlpha=function(){return Ze.getClearAlpha()},this.setClearAlpha=function(){Ze.setClearAlpha(...arguments)},this.clear=function(M=!0,O=!0,W=!0){let z=0;if(M){let H=!1;if(ie!==null){const xe=ie.texture.format;H=m.has(xe)}if(H){const xe=ie.texture.type,we=g.has(xe),_e=Ze.getClearColor(),Te=Ze.getClearAlpha(),Ie=_e.r,Je=_e.g,it=_e.b;we?(x[0]=Ie,x[1]=Je,x[2]=it,x[3]=Te,D.clearBufferuiv(D.COLOR,0,x)):(E[0]=Ie,E[1]=Je,E[2]=it,E[3]=Te,D.clearBufferiv(D.COLOR,0,E))}else z|=D.COLOR_BUFFER_BIT}O&&(z|=D.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),W&&(z|=D.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),z!==0&&D.clear(z)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(M){M.setRenderer(this),I=M},this.dispose=function(){t.removeEventListener("webglcontextlost",Mt,!1),t.removeEventListener("webglcontextrestored",ft,!1),t.removeEventListener("webglcontextcreationerror",Bn,!1),Ze.dispose(),ge.dispose(),fe.dispose(),G.dispose(),ce.dispose(),j.dispose(),be.dispose(),re.dispose(),he.dispose(),Ce.dispose(),Ce.removeEventListener("sessionstart",nu),Ce.removeEventListener("sessionend",iu),ir.stop()};function Mt(M){M.preventDefault(),Co("WebGLRenderer: Context Lost."),L=!0}function ft(){Co("WebGLRenderer: Context Restored."),L=!1;const M=k.autoReset,O=Be.enabled,W=Be.autoUpdate,z=Be.needsUpdate,H=Be.type;De(),k.autoReset=M,Be.enabled=O,Be.autoUpdate=W,Be.needsUpdate=z,Be.type=H}function Bn(M){st("WebGLRenderer: A WebGL context could not be created. Reason: ",M.statusMessage)}function jn(M){const O=M.target;O.removeEventListener("dispose",jn),em(O)}function em(M){tm(M),G.remove(M)}function tm(M){const O=G.get(M).programs;O!==void 0&&(O.forEach(function(W){he.releaseProgram(W)}),M.isShaderMaterial&&he.releaseShaderCache(M))}this.renderBufferDirect=function(M,O,W,z,H,xe){O===null&&(O=Ue);const we=H.isMesh&&H.matrixWorld.determinantAffine()<0,_e=rm(M,O,W,z,H);_.setMaterial(z,we);let Te=W.index,Ie=1;if(z.wireframe===!0){if(Te=Y.getWireframeAttribute(W),Te===void 0)return;Ie=2}const Je=W.drawRange,it=W.attributes.position;let Ae=Je.start*Ie,pt=(Je.start+Je.count)*Ie;xe!==null&&(Ae=Math.max(Ae,xe.start*Ie),pt=Math.min(pt,(xe.start+xe.count)*Ie)),Te!==null?(Ae=Math.max(Ae,0),pt=Math.min(pt,Te.count)):it!=null&&(Ae=Math.max(Ae,0),pt=Math.min(pt,it.count));const Bt=pt-Ae;if(Bt<0||Bt===1/0)return;be.setup(H,z,_e,W,Te);let Et,St=pe;if(Te!==null&&(Et=de.get(Te),St=K,St.setIndex(Et)),H.isMesh)z.wireframe===!0?(_.setLineWidth(z.wireframeLinewidth*Xe()),St.setMode(D.LINES)):St.setMode(D.TRIANGLES);else if(H.isLine){let tn=z.linewidth;tn===void 0&&(tn=1),_.setLineWidth(tn*Xe()),H.isLineSegments?St.setMode(D.LINES):H.isLineLoop?St.setMode(D.LINE_LOOP):St.setMode(D.LINE_STRIP)}else H.isPoints?St.setMode(D.POINTS):H.isSprite&&St.setMode(D.TRIANGLES);if(H.isBatchedMesh)if(nt.get("WEBGL_multi_draw"))St.renderMultiDraw(H._multiDrawStarts,H._multiDrawCounts,H._multiDrawCount);else{const tn=H._multiDrawStarts,Me=H._multiDrawCounts,ln=H._multiDrawCount,ct=Te?de.get(Te).bytesPerElement:1,Cn=G.get(z).currentProgram.getUniforms();for(let Qn=0;Qn<ln;Qn++)Cn.setValue(D,"_gl_DrawID",Qn),St.render(tn[Qn]/ct,Me[Qn])}else if(H.isInstancedMesh)St.renderInstances(Ae,Bt,H.count);else if(W.isInstancedBufferGeometry){const tn=W._maxInstanceCount!==void 0?W._maxInstanceCount:1/0,Me=Math.min(W.instanceCount,tn);St.renderInstances(Ae,Bt,Me)}else St.render(Ae,Bt)};function tu(M,O,W,z){I!==null&&M.isNodeMaterial&&I.setObject(z,M),se===!0&&Ne.setState(M,W,!1),M.transparent===!0&&M.side===Ei&&M.forceSinglePass===!1?(M.side=vn,M.needsUpdate=!0,ba(M,O,z),M.side=gr,M.needsUpdate=!0,ba(M,O,z),M.side=Ei):ba(M,O,z)}this.compile=function(M,O,W=null){W===null&&(W=M),I!==null&&I.renderStart(M,O,W),S=fe.get(W),S.init(O),y.push(S),W.traverseVisible(function(H){H.isLight&&H.layers.test(O.layers)&&(S.pushLight(H),H.castShadow&&S.pushShadow(H))}),M!==W&&M.traverseVisible(function(H){H.isLight&&H.layers.test(O.layers)&&(S.pushLight(H),H.castShadow&&S.pushShadow(H))}),S.setupLights(),I!==null&&I.updateLights(S.state.lightsArray),ae=this.localClippingEnabled,se=Ne.init(this.clippingPlanes,ae),se===!0&&Ne.setGlobalState(this.clippingPlanes,O),I!==null&&Be.render(S.state.shadowsArray,W,O);const z=new Set;return M.traverse(function(H){if(!(H.isMesh||H.isPoints||H.isLine||H.isSprite))return;const xe=H.material;if(xe)if(Array.isArray(xe))for(let we=0;we<xe.length;we++){const _e=xe[we];tu(_e,W,O,H),z.add(_e)}else tu(xe,W,O,H),z.add(xe)}),S=y.pop(),I!==null&&I.renderEnd(),z},this.compileAsync=function(M,O,W=null){const z=this.compile(M,O,W);return new Promise(H=>{function xe(){if(z.forEach(function(we){const Te=G.get(we).currentProgram;(Te===void 0||Te.isReady())&&z.delete(we)}),z.size===0){H(M);return}setTimeout(xe,10)}nt.get("KHR_parallel_shader_compile")!==null?xe():setTimeout(xe,10)})};let ol=null;function nm(M){ol&&ol(M)}function nu(){ir.stop()}function iu(){ir.start()}const ir=new Cf;ir.setAnimationLoop(nm),typeof self<"u"&&ir.setContext(self),this.setAnimationLoop=function(M){ol=M,Ce.setAnimationLoop(M),M===null?ir.stop():ir.start()},Ce.addEventListener("sessionstart",nu),Ce.addEventListener("sessionend",iu),this.render=function(M,O){if(O!==void 0&&O.isCamera!==!0){st("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(L===!0)return;I!==null&&I.renderStart(M,O);const W=Ce.enabled===!0&&Ce.isPresenting===!0,z=A!==null&&(ie===null||W)&&A.begin(C,ie);if(M.matrixWorldAutoUpdate===!0&&M.updateMatrixWorld(),O.parent===null&&O.matrixWorldAutoUpdate===!0&&O.updateMatrixWorld(),Ce.enabled===!0&&Ce.isPresenting===!0&&(A===null||A.isCompositing()===!1)&&(Ce.cameraAutoUpdate===!0&&Ce.updateCamera(O),O=Ce.getCamera()),M.isScene===!0&&M.onBeforeRender(C,M,O,ie),S=fe.get(M,y.length),S.init(O),S.state.textureUnits=q.getTextureUnits(),y.push(S),oe.multiplyMatrices(O.projectionMatrix,O.matrixWorldInverse),te.setFromProjectionMatrix(oe,li,O.reversedDepth),ae=this.localClippingEnabled,se=Ne.init(this.clippingPlanes,ae),w=ge.get(M,T.length),w.init(),T.push(w),Ce.enabled===!0&&Ce.isPresenting===!0){const we=C.xr.getDepthSensingMesh();we!==null&&ll(we,O,-1/0,C.sortObjects)}ll(M,O,0,C.sortObjects),w.finish(),I!==null&&I.updateLights(S.state.lightsArray),C.sortObjects===!0&&w.sort(ye,ze),Ge=Ce.enabled===!1||Ce.isPresenting===!1||Ce.hasDepthSensing()===!1,Ge&&Ze.addToRenderList(w,M),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),se===!0&&Ne.beginShadows();const H=S.state.shadowsArray;if(Be.render(H,M,O),se===!0&&Ne.endShadows(),(z&&A.hasRenderPass())===!1){const we=w.opaque,_e=w.transmissive;if(S.setupLights(),O.isArrayCamera){const Te=O.cameras;if(_e.length>0)for(let Ie=0,Je=Te.length;Ie<Je;Ie++){const it=Te[Ie];su(we,_e,M,it)}Ge&&Ze.render(M);for(let Ie=0,Je=Te.length;Ie<Je;Ie++){const it=Te[Ie];ru(w,M,it,it.viewport)}}else _e.length>0&&su(we,_e,M,O),Ge&&Ze.render(M),ru(w,M,O)}ie!==null&&$===0&&(q.updateMultisampleRenderTarget(ie),q.updateRenderTargetMipmap(ie)),z&&A.end(C),M.isScene===!0&&M.onAfterRender(C,M,O),be.resetDefaultState(),X=-1,Q=null,y.pop(),y.length>0?(S=y[y.length-1],q.setTextureUnits(S.state.textureUnits),se===!0&&Ne.setGlobalState(C.clippingPlanes,S.state.camera)):S=null,T.pop(),T.length>0?w=T[T.length-1]:w=null,I!==null&&I.renderEnd()};function ll(M,O,W,z){if(M.visible===!1)return;if(M.layers.test(O.layers)){if(M.isGroup)W=M.renderOrder;else if(M.isLOD)M.autoUpdate===!0&&M.update(O);else if(M.isLightProbeGrid)S.pushLightProbeGrid(M);else if(M.isLight)S.pushLight(M),M.castShadow&&S.pushShadow(M);else if(M.isSprite){if(!M.frustumCulled||M.intersectsFrustum(te)){z&&Fe.setFromMatrixPosition(M.matrixWorld).applyMatrix4(oe);const we=j.update(M),_e=M.material;_e.visible&&w.push(M,we,_e,W,Fe.z,null,O)}}else if((M.isMesh||M.isLine||M.isPoints)&&(!M.frustumCulled||M.intersectsFrustum(te))){const we=j.update(M),_e=M.material;if(z&&(M.boundingSphere!==void 0?(M.boundingSphere===null&&M.computeBoundingSphere(),Fe.copy(M.boundingSphere.center)):(we.boundingSphere===null&&we.computeBoundingSphere(),Fe.copy(we.boundingSphere.center)),Fe.applyMatrix4(M.matrixWorld).applyMatrix4(oe)),Array.isArray(_e)){const Te=we.groups;for(let Ie=0,Je=Te.length;Ie<Je;Ie++){const it=Te[Ie],Ae=_e[it.materialIndex];Ae&&Ae.visible&&w.push(M,we,Ae,W,Fe.z,it,O)}}else _e.visible&&w.push(M,we,_e,W,Fe.z,null,O)}}const xe=M.children;for(let we=0,_e=xe.length;we<_e;we++)ll(xe[we],O,W,z)}function ru(M,O,W,z){const{opaque:H,transmissive:xe,transparent:we}=M;S.setupLightsView(W),se===!0&&Ne.setGlobalState(C.clippingPlanes,W),z&&_.viewport(ne.copy(z)),H.length>0&&xa(H,O,W),xe.length>0&&xa(xe,O,W),we.length>0&&xa(we,O,W),_.buffers.depth.setTest(!0),_.buffers.depth.setMask(!0),_.buffers.color.setMask(!0),_.setPolygonOffset(!1)}function su(M,O,W,z){if((W.isScene===!0?W.overrideMaterial:null)!==null)return;if(S.state.transmissionRenderTarget[z.id]===void 0){const Ae=nt.has("EXT_color_buffer_half_float")||nt.has("EXT_color_buffer_float");S.state.transmissionRenderTarget[z.id]=new Xn(1,1,{generateMipmaps:!0,type:Ae?mi:Tn,minFilter:ur,samples:Math.max(4,R.samples),stencilBuffer:s,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:at.workingColorSpace})}const xe=S.state.transmissionRenderTarget[z.id],we=z.viewport||ne;xe.setSize(we.z*C.transmissionResolutionScale,we.w*C.transmissionResolutionScale);const _e=C.getRenderTarget(),Te=C.getActiveCubeFace(),Ie=C.getActiveMipmapLevel();C.setRenderTarget(xe),C.getClearColor(ut),tt=C.getClearAlpha(),tt<1&&C.setClearColor(16777215,.5),C.clear(),Ge&&Ze.render(W);const Je=C.toneMapping;C.toneMapping=di;const it=z.viewport;if(z.viewport!==void 0&&(z.viewport=void 0),S.setupLightsView(z),se===!0&&Ne.setGlobalState(C.clippingPlanes,z),xa(M,W,z),q.updateMultisampleRenderTarget(xe),q.updateRenderTargetMipmap(xe),nt.has("WEBGL_multisampled_render_to_texture")===!1){let Ae=!1;for(let pt=0,Bt=O.length;pt<Bt;pt++){const Et=O[pt],{object:St,geometry:tn,material:Me,group:ln}=Et;if(Me.side===Ei&&St.layers.test(z.layers)){const ct=Me.side;Me.side=vn,Me.needsUpdate=!0,au(St,W,z,tn,Me,ln),Me.side=ct,Me.needsUpdate=!0,Ae=!0}}Ae===!0&&(q.updateMultisampleRenderTarget(xe),q.updateRenderTargetMipmap(xe))}C.setRenderTarget(_e,Te,Ie),C.setClearColor(ut,tt),it!==void 0&&(z.viewport=it),C.toneMapping=Je}function xa(M,O,W){const z=O.isScene===!0?O.overrideMaterial:null;for(let H=0,xe=M.length;H<xe;H++){const we=M[H],{object:_e,geometry:Te,group:Ie}=we;let Je=we.material;Je.allowOverride===!0&&z!==null&&(Je=z),_e.layers.test(W.layers)&&au(_e,O,W,Te,Je,Ie)}}function au(M,O,W,z,H,xe){I!==null&&H.isNodeMaterial&&I.setObject(M,H),M.onBeforeRender(C,O,W,z,H,xe),M.modelViewMatrix.multiplyMatrices(W.matrixWorldInverse,M.matrixWorld),M.normalMatrix.getNormalMatrix(M.modelViewMatrix),H.onBeforeRender(C,O,W,z,M,xe),H.transparent===!0&&H.side===Ei&&H.forceSinglePass===!1?(H.side=vn,H.needsUpdate=!0,C.renderBufferDirect(W,O,z,H,M,xe),H.side=gr,H.needsUpdate=!0,C.renderBufferDirect(W,O,z,H,M,xe),H.side=Ei):C.renderBufferDirect(W,O,z,H,M,xe),M.onAfterRender(C,O,W,z,H,xe)}function ba(M,O,W){O.isScene!==!0&&(O=Ue);const z=G.get(M),H=S.state.lights,xe=S.state.shadowsArray,we=H.state.version,_e=he.getParameters(M,H.state,xe,O,W,S.state.lightProbeGridArray),Te=he.getProgramCacheKey(_e);let Ie=z.programs;z.environment=M.isMeshStandardMaterial||M.isMeshLambertMaterial||M.isMeshPhongMaterial?O.environment:null,z.fog=O.fog;const Je=M.isMeshStandardMaterial||M.isMeshLambertMaterial&&!M.envMap||M.isMeshPhongMaterial&&!M.envMap;z.envMap=ce.get(M.envMap||z.environment,Je),z.envMapRotation=z.environment!==null&&M.envMap===null?O.environmentRotation:M.envMapRotation,Ie===void 0&&(M.addEventListener("dispose",jn),Ie=new Map,z.programs=Ie);let it=Ie.get(Te);if(it!==void 0){if(z.currentProgram===it&&z.lightsStateVersion===we)return lu(M,_e),it}else _e.uniforms=he.getUniforms(M),I!==null&&M.isNodeMaterial&&I.build(M,W,_e),M.onBeforeCompile(_e,C),it=he.acquireProgram(_e,Te),Ie.set(Te,it),z.uniforms=_e.uniforms;const Ae=z.uniforms;return(!M.isShaderMaterial&&!M.isRawShaderMaterial||M.clipping===!0)&&(Ae.clippingPlanes=Ne.uniform),lu(M,_e),z.needsLights=am(M),z.lightsStateVersion=we,z.needsLights&&(Ae.ambientLightColor.value=H.state.ambient,Ae.lightProbe.value=H.state.probe,Ae.sunLights.value=H.state.sun,Ae.sunLightShadows.value=H.state.sunShadow,Ae.directionalLights.value=H.state.directional,Ae.directionalLightShadows.value=H.state.directionalShadow,Ae.spotLights.value=H.state.spot,Ae.spotLightShadows.value=H.state.spotShadow,Ae.rectAreaLights.value=H.state.rectArea,Ae.ltc_1.value=H.state.rectAreaLTC1,Ae.ltc_2.value=H.state.rectAreaLTC2,Ae.pointLights.value=H.state.point,Ae.pointLightShadows.value=H.state.pointShadow,Ae.hemisphereLights.value=H.state.hemi,Ae.sunShadowMatrix.value=H.state.sunShadowMatrix,Ae.sunShadowCascade.value=H.state.sunShadowCascade,Ae.directionalShadowMatrix.value=H.state.directionalShadowMatrix,Ae.spotLightMatrix.value=H.state.spotLightMatrix,Ae.spotLightMap.value=H.state.spotLightMap,Ae.pointShadowMatrix.value=H.state.pointShadowMatrix),z.lightProbeGrid=S.state.lightProbeGridArray.length>0,z.currentProgram=it,z.uniformsList=null,it}function ou(M){if(M.uniformsList===null){const O=M.currentProgram.getUniforms();M.uniformsList=ho.seqWithValue(O.seq,M.uniforms)}return M.uniformsList}function lu(M,O){const W=G.get(M);W.outputColorSpace=O.outputColorSpace,W.batching=O.batching,W.batchingColor=O.batchingColor,W.instancing=O.instancing,W.instancingColor=O.instancingColor,W.instancingMorph=O.instancingMorph,W.skinning=O.skinning,W.morphTargets=O.morphTargets,W.morphNormals=O.morphNormals,W.morphColors=O.morphColors,W.morphTargetsCount=O.morphTargetsCount,W.numClippingPlanes=O.numClippingPlanes,W.numIntersection=O.numClipIntersection,W.vertexAlphas=O.vertexAlphas,W.vertexTangents=O.vertexTangents,W.toneMapping=O.toneMapping}function im(M,O){if(M.length===0)return null;if(M.length===1)return M[0].texture!==null?M[0]:null;b.setFromMatrixPosition(O.matrixWorld);for(let W=0,z=M.length;W<z;W++){const H=M[W];if(H.texture!==null&&H.boundingBox.containsPoint(b))return H}return null}function rm(M,O,W,z,H){O.isScene!==!0&&(O=Ue),q.resetTextureUnits();const xe=O.fog,we=z.isMeshStandardMaterial||z.isMeshLambertMaterial||z.isMeshPhongMaterial?O.environment:null,_e=ie===null?C.outputColorSpace:ie.isXRRenderTarget===!0?ie.texture.colorSpace:at.workingColorSpace,Te=z.isMeshStandardMaterial||z.isMeshLambertMaterial&&!z.envMap||z.isMeshPhongMaterial&&!z.envMap,Ie=ce.get(z.envMap||we,Te),Je=z.vertexColors===!0&&!!W.attributes.color&&W.attributes.color.itemSize===4,it=!!W.attributes.tangent&&(!!z.normalMap||z.anisotropy>0),Ae=!!W.morphAttributes.position,pt=!!W.morphAttributes.normal,Bt=!!W.morphAttributes.color;let Et=di;z.toneMapped&&(ie===null||ie.isXRRenderTarget===!0)&&(Et=C.toneMapping);const St=W.morphAttributes.position||W.morphAttributes.normal||W.morphAttributes.color,tn=St!==void 0?St.length:0,Me=G.get(z),ln=S.state.lights;if(se===!0&&(ae===!0||M!==Q)){const wt=M===Q&&z.id===X;Ne.setState(z,M,wt)}let ct=!1;z.version===Me.__version?(Me.needsLights&&Me.lightsStateVersion!==ln.state.version||Me.outputColorSpace!==_e||H.isBatchedMesh&&Me.batching===!1||!H.isBatchedMesh&&Me.batching===!0||H.isBatchedMesh&&Me.batchingColor===!0&&H._colorsTexture===null||H.isBatchedMesh&&Me.batchingColor===!1&&H._colorsTexture!==null||H.isInstancedMesh&&Me.instancing===!1||!H.isInstancedMesh&&Me.instancing===!0||H.isSkinnedMesh&&Me.skinning===!1||!H.isSkinnedMesh&&Me.skinning===!0||H.isInstancedMesh&&Me.instancingColor===!0&&H.instanceColor===null||H.isInstancedMesh&&Me.instancingColor===!1&&H.instanceColor!==null||H.isInstancedMesh&&Me.instancingMorph===!0&&H.morphTexture===null||H.isInstancedMesh&&Me.instancingMorph===!1&&H.morphTexture!==null||Me.envMap!==Ie||z.fog===!0&&Me.fog!==xe||Me.numClippingPlanes!==void 0&&(Me.numClippingPlanes!==Ne.numPlanes||Me.numIntersection!==Ne.numIntersection)||Me.vertexAlphas!==Je||Me.vertexTangents!==it||Me.morphTargets!==Ae||Me.morphNormals!==pt||Me.morphColors!==Bt||Me.toneMapping!==Et||Me.morphTargetsCount!==tn||!!Me.lightProbeGrid!=S.state.lightProbeGridArray.length>0)&&(ct=!0):(ct=!0,Me.__version=z.version);let Cn=Me.currentProgram;ct===!0&&(Cn=ba(z,O,H),I&&z.isNodeMaterial&&I.onUpdateProgram(z,Cn,Me));let Qn=!1,Oi=!1,Ar=!1;const _t=Cn.getUniforms(),Dt=Me.uniforms;if(_.useProgram(Cn.program)&&(Qn=!0,Oi=!0,Ar=!0),z.id!==X&&(X=z.id,Oi=!0),Me.needsLights){const wt=im(S.state.lightProbeGridArray,H);Me.lightProbeGrid!==wt&&(Me.lightProbeGrid=wt,Oi=!0)}if(Qn||Q!==M){_.buffers.depth.getReversed()&&M.reversedDepth!==!0&&(M._reversedDepth=!0,M.updateProjectionMatrix()),_t.setValue(D,"projectionMatrix",M.projectionMatrix),_t.setValue(D,"viewMatrix",M.matrixWorldInverse);const Bi=_t.map.cameraPosition;Bi!==void 0&&Bi.setValue(D,ue.setFromMatrixPosition(M.matrixWorld)),R.logarithmicDepthBuffer&&_t.setValue(D,"logDepthBufFC",2/(Math.log(M.far+1)/Math.LN2)),(z.isMeshPhongMaterial||z.isMeshToonMaterial||z.isMeshLambertMaterial||z.isMeshBasicMaterial||z.isMeshStandardMaterial||z.isShaderMaterial)&&_t.setValue(D,"isOrthographic",M.isOrthographicCamera===!0),Q!==M&&(Q=M,Oi=!0,Ar=!0)}if(Me.needsLights&&(ln.state.sunShadowMap.length>0&&_t.setValue(D,"sunShadowMap",ln.state.sunShadowMap,q),ln.state.directionalShadowMap.length>0&&_t.setValue(D,"directionalShadowMap",ln.state.directionalShadowMap,q),ln.state.spotShadowMap.length>0&&_t.setValue(D,"spotShadowMap",ln.state.spotShadowMap,q),ln.state.pointShadowMap.length>0&&_t.setValue(D,"pointShadowMap",ln.state.pointShadowMap,q)),H.isSkinnedMesh){_t.setOptional(D,H,"bindMatrix"),_t.setOptional(D,H,"bindMatrixInverse");const wt=H.skeleton;wt&&(wt.boneTexture===null&&wt.computeBoneTexture(),_t.setValue(D,"boneTexture",wt.boneTexture,q))}H.isBatchedMesh&&(_t.setOptional(D,H,"batchingTexture"),_t.setValue(D,"batchingTexture",H._matricesTexture,q),_t.setOptional(D,H,"batchingIdTexture"),_t.setValue(D,"batchingIdTexture",H._indirectTexture,q),_t.setOptional(D,H,"batchingColorTexture"),H._colorsTexture!==null&&_t.setValue(D,"batchingColorTexture",H._colorsTexture,q));const Fi=W.morphAttributes;if((Fi.position!==void 0||Fi.normal!==void 0||Fi.color!==void 0)&&F.update(H,W,Cn),(Oi||Me.receiveShadow!==H.receiveShadow)&&(Me.receiveShadow=H.receiveShadow,_t.setValue(D,"receiveShadow",H.receiveShadow)),(z.isMeshStandardMaterial||z.isMeshLambertMaterial||z.isMeshPhongMaterial)&&z.envMap===null&&O.environment!==null&&(Dt.envMapIntensity.value=O.environmentIntensity),Dt.dfgLUT!==void 0&&(Dt.dfgLUT.value=Sb()),Oi){if(_t.setValue(D,"toneMappingExposure",C.toneMappingExposure),Me.needsLights&&sm(Dt,Ar),xe&&z.fog===!0&&Le.refreshFogUniforms(Dt,xe),Le.refreshMaterialUniforms(Dt,z,ee,Z,S.state.transmissionRenderTarget[M.id]),Me.needsLights&&Me.lightProbeGrid){const wt=Me.lightProbeGrid;Dt.probesSH.value=wt.texture,Dt.probesMin.value.copy(wt.boundingBox.min),Dt.probesMax.value.copy(wt.boundingBox.max),Dt.probesResolution.value.copy(wt.resolution)}ho.upload(D,ou(Me),Dt,q)}if(z.isShaderMaterial&&z.uniformsNeedUpdate===!0&&(ho.upload(D,ou(Me),Dt,q),z.uniformsNeedUpdate=!1),z.isSpriteMaterial&&_t.setValue(D,"center",H.center),_t.setValue(D,"modelViewMatrix",H.modelViewMatrix),_t.setValue(D,"normalMatrix",H.normalMatrix),_t.setValue(D,"modelMatrix",H.matrixWorld),z.uniformsGroups!==void 0){const wt=z.uniformsGroups;for(let Bi=0,Rr=wt.length;Bi<Rr;Bi++){const du=wt[Bi];re.update(du,Cn),re.bind(du,Cn)}}return Cn}function sm(M,O){M.ambientLightColor.needsUpdate=O,M.lightProbe.needsUpdate=O,M.sunLights.needsUpdate=O,M.sunLightShadows.needsUpdate=O,M.directionalLights.needsUpdate=O,M.directionalLightShadows.needsUpdate=O,M.pointLights.needsUpdate=O,M.pointLightShadows.needsUpdate=O,M.spotLights.needsUpdate=O,M.spotLightShadows.needsUpdate=O,M.rectAreaLights.needsUpdate=O,M.hemisphereLights.needsUpdate=O}function am(M){return M.isMeshLambertMaterial||M.isMeshToonMaterial||M.isMeshPhongMaterial||M.isMeshStandardMaterial||M.isShadowMaterial||M.isShaderMaterial&&M.lights===!0}this.getActiveCubeFace=function(){return V},this.getActiveMipmapLevel=function(){return $},this.getRenderTarget=function(){return ie},this.setRenderTargetTextures=function(M,O,W){const z=G.get(M);z.__autoAllocateDepthBuffer=M.resolveDepthBuffer===!1,z.__autoAllocateDepthBuffer===!1&&(z.__useRenderToTexture=!1),G.get(M.texture).__webglTexture=O,G.get(M.depthTexture).__webglTexture=z.__autoAllocateDepthBuffer?void 0:W,z.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(M,O){const W=G.get(M);W.__webglFramebuffer=O,W.__useDefaultFramebuffer=O===void 0},this.setRenderTarget=function(M,O=0,W=0){ie=M,V=O,$=W;let z=null,H=!1,xe=!1;if(M){const _e=G.get(M);if(_e.__useDefaultFramebuffer!==void 0){_.bindFramebuffer(D.FRAMEBUFFER,_e.__webglFramebuffer),ne.copy(M.viewport),Pe.copy(M.scissor),Ee=M.scissorTest,_.viewport(ne),_.scissor(Pe),_.setScissorTest(Ee),X=-1;return}else if(_e.__webglFramebuffer===void 0)q.setupRenderTarget(M);else if(_e.__hasExternalTextures)q.rebindTextures(M,G.get(M.texture).__webglTexture,G.get(M.depthTexture).__webglTexture);else if(M.depthBuffer){const Je=M.depthTexture;if(_e.__boundDepthTexture!==Je){if(Je!==null&&G.has(Je)&&(M.width!==Je.image.width||M.height!==Je.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");q.setupDepthRenderbuffer(M)}}const Te=M.texture;(Te.isData3DTexture||Te.isDataArrayTexture||Te.isCompressedArrayTexture)&&(xe=!0);const Ie=G.get(M).__webglFramebuffer;M.isWebGLCubeRenderTarget?(Array.isArray(Ie[O])?z=Ie[O][W]:z=Ie[O],H=!0):M.samples>0&&q.useMultisampledRTT(M)===!1?z=G.get(M).__webglMultisampledFramebuffer:Array.isArray(Ie)?z=Ie[W]:z=Ie,ne.copy(M.viewport),Pe.copy(M.scissor),Ee=M.scissorTest}else ne.copy(Se).multiplyScalar(ee).floor(),Pe.copy(He).multiplyScalar(ee).floor(),Ee=mt;if(W!==0&&(z=B),_.bindFramebuffer(D.FRAMEBUFFER,z)&&_.drawBuffers(M,z),_.viewport(ne),_.scissor(Pe),_.setScissorTest(Ee),H){const _e=G.get(M.texture);D.framebufferTexture2D(D.FRAMEBUFFER,D.COLOR_ATTACHMENT0,D.TEXTURE_CUBE_MAP_POSITIVE_X+O,_e.__webglTexture,W)}else if(xe){const _e=O;for(let Te=0;Te<M.textures.length;Te++){const Ie=G.get(M.textures[Te]);D.framebufferTextureLayer(D.FRAMEBUFFER,D.COLOR_ATTACHMENT0+Te,Ie.__webglTexture,W,_e)}}else if(M!==null&&W!==0){const _e=G.get(M.texture);D.framebufferTexture2D(D.FRAMEBUFFER,D.COLOR_ATTACHMENT0,D.TEXTURE_2D,_e.__webglTexture,W)}X=-1};function cu(M){const O=G.get(M);return(O.__readFormat!==M.format||O.__readType!==M.type)&&(O.__readFormat=M.format,O.__readType=M.type,O.__formatReadable=R.textureFormatReadable(M.format),O.__typeReadable=R.textureTypeReadable(M.type)),O}this.readRenderTargetPixels=function(M,O,W,z,H,xe,we,_e=0){if(!(M&&M.isWebGLRenderTarget)){st("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Te=G.get(M).__webglFramebuffer;if(M.isWebGLCubeRenderTarget&&we!==void 0&&(Te=Te[we]),Te){_.bindFramebuffer(D.FRAMEBUFFER,Te);try{const Ie=M.textures[_e],Je=Ie.format,it=Ie.type;M.textures.length>1&&D.readBuffer(D.COLOR_ATTACHMENT0+_e);const Ae=cu(Ie);if(Ae.__formatReadable===!1){st("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(Ae.__typeReadable===!1){st("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}O>=0&&O<=M.width-z&&W>=0&&W<=M.height-H&&D.readPixels(O,W,z,H,me.convert(Je),me.convert(it),xe)}finally{const Ie=ie!==null?G.get(ie).__webglFramebuffer:null;_.bindFramebuffer(D.FRAMEBUFFER,Ie)}}},this.readRenderTargetPixelsAsync=async function(M,O,W,z,H,xe,we,_e=0){if(!(M&&M.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Te=G.get(M).__webglFramebuffer;if(M.isWebGLCubeRenderTarget&&we!==void 0&&(Te=Te[we]),Te)if(O>=0&&O<=M.width-z&&W>=0&&W<=M.height-H){_.bindFramebuffer(D.FRAMEBUFFER,Te);const Ie=M.textures[_e],Je=Ie.format,it=Ie.type;M.textures.length>1&&D.readBuffer(D.COLOR_ATTACHMENT0+_e);const Ae=cu(Ie);if(Ae.__formatReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(Ae.__typeReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const pt=D.createBuffer();D.bindBuffer(D.PIXEL_PACK_BUFFER,pt),D.bufferData(D.PIXEL_PACK_BUFFER,xe.byteLength,D.STREAM_READ),D.readPixels(O,W,z,H,me.convert(Je),me.convert(it),0),D.bindBuffer(D.PIXEL_PACK_BUFFER,null);const Bt=ie!==null?G.get(ie).__webglFramebuffer:null;_.bindFramebuffer(D.FRAMEBUFFER,Bt);const Et=D.fenceSync(D.SYNC_GPU_COMMANDS_COMPLETE,0);return D.flush(),await Hm(D,Et,4),D.bindBuffer(D.PIXEL_PACK_BUFFER,pt),D.getBufferSubData(D.PIXEL_PACK_BUFFER,0,xe),D.bindBuffer(D.PIXEL_PACK_BUFFER,null),D.deleteBuffer(pt),D.deleteSync(Et),xe}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(M,O=null,W=0){const z=Math.pow(2,-W),H=Math.floor(M.image.width*z),xe=Math.floor(M.image.height*z),we=O!==null?O.x:0,_e=O!==null?O.y:0;q.setTexture2D(M,0),D.copyTexSubImage2D(D.TEXTURE_2D,W,0,0,we,_e,H,xe),_.unbindTexture()},this.copyTextureToTexture=function(M,O,W=null,z=null,H=0,xe=0){let we,_e,Te,Ie,Je,it,Ae,pt,Bt;const Et=M.isCompressedTexture?M.mipmaps[xe]:M.image;if(W!==null)we=W.max.x-W.min.x,_e=W.max.y-W.min.y,Te=W.isBox3?W.max.z-W.min.z:1,Ie=W.min.x,Je=W.min.y,it=W.isBox3?W.min.z:0;else{const Dt=Math.pow(2,-H);we=Math.floor(Et.width*Dt),_e=Math.floor(Et.height*Dt),M.isDataArrayTexture?Te=Et.depth:M.isData3DTexture?Te=Math.floor(Et.depth*Dt):Te=1,Ie=0,Je=0,it=0}z!==null?(Ae=z.x,pt=z.y,Bt=z.z):(Ae=0,pt=0,Bt=0);const St=me.convert(O.format),tn=me.convert(O.type);let Me;O.isData3DTexture?(q.setTexture3D(O,0),Me=D.TEXTURE_3D):O.isDataArrayTexture||O.isCompressedArrayTexture?(q.setTexture2DArray(O,0),Me=D.TEXTURE_2D_ARRAY):(q.setTexture2D(O,0),Me=D.TEXTURE_2D),_.activeTexture(D.TEXTURE0),_.pixelStorei(D.UNPACK_FLIP_Y_WEBGL,O.flipY),_.pixelStorei(D.UNPACK_PREMULTIPLY_ALPHA_WEBGL,O.premultiplyAlpha),_.pixelStorei(D.UNPACK_ALIGNMENT,O.unpackAlignment);const ln=_.getParameter(D.UNPACK_ROW_LENGTH),ct=_.getParameter(D.UNPACK_IMAGE_HEIGHT),Cn=_.getParameter(D.UNPACK_SKIP_PIXELS),Qn=_.getParameter(D.UNPACK_SKIP_ROWS),Oi=_.getParameter(D.UNPACK_SKIP_IMAGES);_.pixelStorei(D.UNPACK_ROW_LENGTH,Et.width),_.pixelStorei(D.UNPACK_IMAGE_HEIGHT,Et.height),_.pixelStorei(D.UNPACK_SKIP_PIXELS,Ie),_.pixelStorei(D.UNPACK_SKIP_ROWS,Je),_.pixelStorei(D.UNPACK_SKIP_IMAGES,it);const Ar=M.isDataArrayTexture||M.isData3DTexture,_t=O.isDataArrayTexture||O.isData3DTexture;if(M.isDepthTexture){const Dt=G.get(M),Fi=G.get(O),wt=G.get(Dt.__renderTarget),Bi=G.get(Fi.__renderTarget);_.bindFramebuffer(D.READ_FRAMEBUFFER,wt.__webglFramebuffer),_.bindFramebuffer(D.DRAW_FRAMEBUFFER,Bi.__webglFramebuffer);for(let Rr=0;Rr<Te;Rr++)Ar&&(D.framebufferTextureLayer(D.READ_FRAMEBUFFER,D.COLOR_ATTACHMENT0,G.get(M).__webglTexture,H,it+Rr),D.framebufferTextureLayer(D.DRAW_FRAMEBUFFER,D.COLOR_ATTACHMENT0,G.get(O).__webglTexture,xe,Bt+Rr)),D.blitFramebuffer(Ie,Je,we,_e,Ae,pt,we,_e,D.DEPTH_BUFFER_BIT,D.NEAREST);_.bindFramebuffer(D.READ_FRAMEBUFFER,null),_.bindFramebuffer(D.DRAW_FRAMEBUFFER,null)}else if(H!==0||M.isRenderTargetTexture||G.has(M)){const Dt=G.get(M),Fi=G.get(O);_.bindFramebuffer(D.READ_FRAMEBUFFER,N),_.bindFramebuffer(D.DRAW_FRAMEBUFFER,U);for(let wt=0;wt<Te;wt++)Ar?D.framebufferTextureLayer(D.READ_FRAMEBUFFER,D.COLOR_ATTACHMENT0,Dt.__webglTexture,H,it+wt):D.framebufferTexture2D(D.READ_FRAMEBUFFER,D.COLOR_ATTACHMENT0,D.TEXTURE_2D,Dt.__webglTexture,H),_t?D.framebufferTextureLayer(D.DRAW_FRAMEBUFFER,D.COLOR_ATTACHMENT0,Fi.__webglTexture,xe,Bt+wt):D.framebufferTexture2D(D.DRAW_FRAMEBUFFER,D.COLOR_ATTACHMENT0,D.TEXTURE_2D,Fi.__webglTexture,xe),H!==0?D.blitFramebuffer(Ie,Je,we,_e,Ae,pt,we,_e,D.COLOR_BUFFER_BIT,D.NEAREST):_t?D.copyTexSubImage3D(Me,xe,Ae,pt,Bt+wt,Ie,Je,we,_e):D.copyTexSubImage2D(Me,xe,Ae,pt,Ie,Je,we,_e);_.bindFramebuffer(D.READ_FRAMEBUFFER,null),_.bindFramebuffer(D.DRAW_FRAMEBUFFER,null)}else _t?M.isDataTexture||M.isData3DTexture?D.texSubImage3D(Me,xe,Ae,pt,Bt,we,_e,Te,St,tn,Et.data):O.isCompressedArrayTexture?D.compressedTexSubImage3D(Me,xe,Ae,pt,Bt,we,_e,Te,St,Et.data):D.texSubImage3D(Me,xe,Ae,pt,Bt,we,_e,Te,St,tn,Et):M.isDataTexture?D.texSubImage2D(D.TEXTURE_2D,xe,Ae,pt,we,_e,St,tn,Et.data):M.isCompressedTexture?D.compressedTexSubImage2D(D.TEXTURE_2D,xe,Ae,pt,Et.width,Et.height,St,Et.data):D.texSubImage2D(D.TEXTURE_2D,xe,Ae,pt,we,_e,St,tn,Et);_.pixelStorei(D.UNPACK_ROW_LENGTH,ln),_.pixelStorei(D.UNPACK_IMAGE_HEIGHT,ct),_.pixelStorei(D.UNPACK_SKIP_PIXELS,Cn),_.pixelStorei(D.UNPACK_SKIP_ROWS,Qn),_.pixelStorei(D.UNPACK_SKIP_IMAGES,Oi),xe===0&&O.generateMipmaps&&D.generateMipmap(Me),_.unbindTexture()},this.initRenderTarget=function(M){G.get(M).__webglFramebuffer===void 0&&q.setupRenderTarget(M)},this.initTexture=function(M){M.isCubeTexture?q.setTextureCube(M,0):M.isData3DTexture?q.setTexture3D(M,0):M.isDataArrayTexture||M.isCompressedArrayTexture?q.setTexture2DArray(M,0):q.setTexture2D(M,0),_.unbindTexture()},this.resetState=function(){V=0,$=0,ie=null,_.reset(),be.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return li}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=at._getDrawingBufferColorSpace(e),t.unpackColorSpace=at._getUnpackColorSpace()}}const Ke={player:{id:"player",name:"The Concord",shortName:"Concord",color:"#68d9cd",motto:"Many worlds. One horizon.",trait:"Civic mandate",description:"A federation of survivors, united by a fragile promise. Receives one additional order each turn.",home:"Solace",leader:"First Speaker Mara Voss"},veyr:{id:"veyr",name:"Veyr Consortium",shortName:"Veyr",color:"#e5b665",motto:"Every star has its price.",trait:"Merchant houses",description:"Trade leagues that turn the frontier into opportunity. Earns 25% more credits.",home:"Veyr Prime",leader:"Director Cassian Rook"},khar:{id:"khar",name:"Khar Dominion",shortName:"Khar",color:"#ef7e7a",motto:"The void respects strength.",trait:"War foundries",description:"A martial society forged on hostile worlds. Warships deal 15% more damage.",home:"Kharos",leader:"High Marshal Sera Kade"},choir:{id:"choir",name:"The Luminous Choir",shortName:"Choir",color:"#bca0ef",motto:"The universe remembers.",trait:"Shared consciousness",description:"A communion seeking the intelligence behind the ancient gates. Produces 25% more science.",home:"Lumen",leader:"The Ninth Voice"}},mr={terran:{name:"Terran",color:"#64bbbd",description:"Temperate oceans and broad continental shelves."},arid:{name:"Arid",color:"#d9ac72",description:"Mineral deserts beneath an amber sky."},ocean:{name:"Ocean",color:"#5a93d5",description:"An unbroken sea, rich with unfamiliar life."},ice:{name:"Glacial",color:"#b5dce4",description:"Ancient ice hides a warm subsurface ocean."},volcanic:{name:"Volcanic",color:"#df7259",description:"Restless tectonics expose rich seams of ore."},barren:{name:"Barren",color:"#8b919f",description:"A silent surface, untouched by an atmosphere."}},Tt={logistics:{id:"logistics",name:"Deep-space Logistics",category:"Engineering",cost:55,requires:[],description:"+1 order each turn. Opens automated industry and larger hulls."},ecology:{id:"ecology",name:"Adaptive Biospheres",category:"Society",cost:60,requires:[],description:"Colonize harsh worlds with 30% habitability. Unlocks Habitation Domes."},physics:{id:"physics",name:"Resonance Theory",category:"Physics",cost:60,requires:[],description:"+2 science per colony. The first step toward understanding the gates."},weapons:{id:"weapons",name:"Coherent Lances",category:"Military",cost:70,requires:[],description:"All warships deal 25% more damage."},industry:{id:"industry",name:"Autonomous Industry",category:"Engineering",cost:220,requires:["logistics"],description:"Unlocks Manufactories, which add 6 production per turn."},diplomacy:{id:"diplomacy",name:"Stellar Accords",category:"Society",cost:180,requires:["ecology"],description:"Trade treaties earn +4 additional credits each turn. Unlocks Civic Forums."},shields:{id:"shields",name:"Deflector Fields",category:"Military",cost:220,requires:["physics"],description:"Incoming fleet damage is reduced by 20%. Unlocks Orbital Bastions."},cruisers:{id:"cruisers",name:"Capital Ship Architecture",category:"Military",cost:360,requires:["logistics","weapons"],description:"Unlocks heavily armed cruisers."},terraforming:{id:"terraforming",name:"Worldshaping",category:"Society",cost:600,requires:["ecology","industry"],description:"Colonize any world. All colonies grow 50% faster."},computing:{id:"computing",name:"Quantum Archives",category:"Physics",cost:360,requires:["physics"],description:"Laboratories produce +4 science. Unlocks the final gate technology."},command:{id:"command",name:"Distributed Command",category:"Engineering",cost:500,requires:["logistics","diplomacy"],description:"+2 orders each turn. Warships gain one additional move per turn."},singularity:{id:"singularity",name:"The Asterion Protocol",category:"Physics",cost:1e3,requires:["computing","industry"],description:"Unlocks Asterion Beacons. Align three owned, unblocked beacon worlds for 10 cycles at 60 credits per cycle to achieve transcendence."}},Ye={mine:{id:"mine",name:"Orbital Extractor",icon:"◇",cost:{credits:20,minerals:25},work:24,requires:[],description:"+5 minerals each turn.",minerals:5},lab:{id:"lab",name:"Research Enclave",icon:"✧",cost:{credits:30,minerals:30},work:30,requires:[],description:"+5 science each turn.",science:5},market:{id:"market",name:"Exchange Port",icon:"◈",cost:{credits:25,minerals:20},work:24,requires:[],description:"+7 credits each turn.",credits:7},shipyard:{id:"shipyard",name:"Orbital Shipyard",icon:"⌁",cost:{credits:25,minerals:35},work:32,requires:[],description:"Build ships here. Adds 4 hull to this colony’s shared repair capacity each cycle."},habitat:{id:"habitat",name:"Habitation Domes",icon:"◎",cost:{credits:40,minerals:35},work:36,requires:["ecology"],description:"+4 maximum population and +40% population growth."},factory:{id:"factory",name:"Manufactory",icon:"▥",cost:{credits:35,minerals:45},work:40,requires:["industry"],description:"+6 construction production each turn.",production:6},forum:{id:"forum",name:"Civic Forum",icon:"⌂",cost:{credits:50,minerals:30},work:40,requires:["diplomacy"],description:"+1 order each turn and +3 credits.",credits:3,orders:1},bastion:{id:"bastion",name:"Orbital Bastion",icon:"⛨",cost:{credits:45,minerals:60},work:50,requires:["shields"],description:"+30 colony defense. Invading fleets suffer retaliatory fire.",defense:30},beacon:{id:"beacon",name:"Asterion Beacon",icon:"✦",cost:{credits:180,minerals:180},work:140,requires:["singularity"],description:"A public node of the ancient network. Three owned, unblocked beacons align over 10 cycles at 60 credits per cycle; interruptions lose one cycle of progress."},ancient_observatory:{id:"ancient_observatory",name:"Ancient Observatory",icon:"✧",cost:{credits:80,minerals:40},work:60,requires:["computing"],discovery:"observatory",science:8,description:"+8 science each turn. A unique planetary site; occupies one slot and does not replace a Research Enclave or support an Academy Charter."},lattice_works:{id:"lattice_works",name:"Lattice Works",icon:"❖",cost:{credits:80,minerals:40},work:60,requires:["industry"],discovery:"reef",minerals:4,production:4,description:"+4 minerals and +4 production each turn. A living planetary site; occupies one slot and does not replace charter-supporting infrastructure."}},Re={scout:{id:"scout",name:"Pathfinder",role:"Scout",icon:"△",cost:{credits:20,minerals:20},work:20,requires:[],hp:18,attack:3,moves:2,upkeep:1,description:"Fast exploration vessel. Two jumps per turn; best kept away from combat."},colony:{id:"colony",name:"Colony Ark",role:"Colony ship",icon:"⬡",cost:{credits:45,minerals:55},work:38,requires:[],hp:24,attack:0,moves:1,upkeep:1,description:"Found a new colony on a surveyed, habitable world. Consumed when settling."},frigate:{id:"frigate",name:"Vanguard",role:"Frigate",icon:"▴",cost:{credits:25,minerals:35},work:26,requires:[],hp:34,attack:12,moves:1,upkeep:2,description:"Versatile escort and invasion vessel. Combine frigates into task forces."},cruiser:{id:"cruiser",name:"Sovereign",role:"Cruiser",icon:"◆",cost:{credits:65,minerals:85},work:65,requires:["cruisers"],hp:85,attack:31,moves:1,upkeep:4,description:"Heavy capital ship designed to break fortified systems."}},pn={archive:{id:"archive",name:"The Silent Archive",description:"A moon-sized vault broadcasts a sequence of prime numbers. Its last inhabitants left two gifts, but the failing power core can preserve only one.",choices:[{id:"study",label:"Recover their knowledge",description:"Gain 50 science.",gain:{science:50}},{id:"salvage",label:"Salvage the vault",description:"Gain 65 minerals.",gain:{minerals:65}}]},pilgrims:{id:"pilgrims",name:"A Thousand Sleeping Voices",description:"A drifting ark carries refugees in failing cryopods. Their destination has been dust for centuries.",choices:[{id:"welcome",label:"Bring them home",description:"Spend 20 credits; your capital gains 1 population.",cost:{credits:20},population:1},{id:"supplies",label:"Restore their navigation",description:"Gain 25 science and 15 credits from their grateful archivist.",gain:{science:25,credits:15}}]},forge:{id:"forge",name:"The Hollow Sun",description:"Inside a shattered asteroid, autonomous foundries continue an order issued ten thousand years ago.",choices:[{id:"ore",label:"Redirect the foundries",description:"Gain 85 minerals.",gain:{minerals:85}},{id:"ship",label:"Finish the ancient escort",description:"An intact frigate joins your expedition.",ship:"frigate"}]},garden:{id:"garden",name:"Garden Between Stars",description:"A biosphere of impossible geometry grows beneath the surface. Its caretakers wait for a signal.",choices:[{id:"preserve",label:"Wake the caretakers",description:"Habitability rises by 25 points; gain 20 science.",habitability:25,gain:{science:20}},{id:"harvest",label:"Harvest the exotic compounds",description:"Gain 65 credits and 25 minerals.",gain:{credits:65,minerals:25}}]},echo:{id:"echo",name:"Echo of the First Gate",description:"Your instruments detect a door folded into the fabric of space. For a moment, you hear your own voice answering from the other side.",choices:[{id:"listen",label:"Map the resonance",description:"Gain 75 science.",gain:{science:75}},{id:"reach",label:"Reach through the echo",description:"Chart every star within two jumps of this system.",reveal:2}]},wreck:{id:"wreck",name:"A Banner in the Dark",description:"A forgotten flagship drifts through a field of broken weapons. Its cargo manifests survive alongside a surprisingly intact reactor.",choices:[{id:"credit",label:"Claim the lost treasury",description:"Gain 90 credits.",gain:{credits:90}},{id:"reactor",label:"Study the reactor",description:"Gain 40 science and 30 minerals.",gain:{science:40,minerals:30}}]},observatory:{id:"observatory",name:"The Last Observatory",multiStage:!0,support:"lab",siteId:"ancient_observatory",description:"Beneath a mountain, a ring of mirrors still follows stars that no longer exist. One instrument has stopped moving. Its lens is pointed at your expedition.",matureDescription:"The observatory’s final atlas is complete. Its instruments can preserve the measurements here, or compress their remaining precision into one portable record.",continuation:"Settle this world and operate a Research Enclave for three completed cycles without hostile warships in orbit. Then choose 140 science and 30 credits, or restore an Ancient Observatory for 80 credits, 40 minerals and 60 work. Restoration requires Quantum Archives and one infrastructure slot (or explicit replacement), producing +8 science. The opportunity stays with the world if another empire takes it; progress never expires.",choices:[{id:"salvage",label:"Take the timing core",description:"Gain 65 minerals and 20 science. Exhaust the observatory permanently.",gain:{minerals:65,science:20}},{id:"preserve",label:"Let the observatory finish",description:"Spend 40 credits and 20 minerals to begin restoration research.",cost:{credits:40,minerals:20},requires:["physics"],preserve:!0}],finalChoices:[{id:"restore",label:"Keep the sky here",description:"Commission an Ancient Observatory: 80 credits, 40 minerals, 60 work, one slot; +8 science each turn. Cancelling construction preserves the restoration plan but never reopens salvage.",buildingId:"ancient_observatory"},{id:"harvest",label:"Publish the last atlas",description:"Gain 140 science and 30 credits. Exhaust the observatory permanently.",gain:{science:140,credits:30}}]},reef:{id:"reef",name:"The Patient Reef",multiStage:!0,support:"mine",siteId:"lattice_works",description:"A pale lattice grows through the planet’s crust. Each branch encloses a tool. None contains a weapon. Far below, something waits for permission to continue.",matureDescription:"The reef has learned your machines. Its new chambers contain unfinished bridges and empty workshops. It can grow with this settlement, or surrender one final harvest.",continuation:"Settle this world and operate an Orbital Extractor for three completed cycles without hostile warships in orbit. Then choose 120 minerals and 20 science, or grow Lattice Works for 80 credits, 40 minerals and 60 work. Restoration requires Autonomous Industry and one infrastructure slot (or explicit replacement), producing +4 minerals and +4 production. The opportunity stays with the world if another empire takes it; progress never expires.",choices:[{id:"salvage",label:"Quarry the lattice",description:"Gain 85 minerals. Exhaust the reef permanently.",gain:{minerals:85}},{id:"preserve",label:"Feed the root",description:"Spend 35 credits and 20 minerals to preserve the living structure.",cost:{credits:35,minerals:20},requires:["ecology"],preserve:!0}],finalChoices:[{id:"restore",label:"Grow a living foundry",description:"Commission Lattice Works: 80 credits, 40 minerals, 60 work, one slot; +4 minerals and +4 production each turn. Cancelling construction preserves the restoration plan but never reopens salvage.",buildingId:"lattice_works"},{id:"harvest",label:"Harvest its final bloom",description:"Gain 120 minerals and 20 science. Exhaust the reef permanently.",gain:{minerals:120,science:20}}]}},Mh=["Solace","Veyr Prime","Kharos","Lumen","Meridian","Hesper","Aurelia","Nacre","Caldera","Velorum","Ashfall","Carina","Eidolon","Sable","Ilyra","Kepler","Stillwater","Orison","Cinder","Bellatrix","Sundrift","Thalassa","Ophion","Tethys","Corvus","Elysian","Aster","Nyx","Haven","Aldebaran","Caelum","Vesper","Iona","Halcyon","Antares","Seraph","Peregrine","Morrow","Zenith","Eos","Terminus","Asterion"];function tr(n,e,t){const i=n.systems.find(r=>r.id===t);return!!(i&&(i.owner===e||n.fleets.some(r=>r.owner===e&&r.systemId===t)))}function Ft(n,e,t){const i=new Set(n.systems.filter(r=>r.owner===e).map(r=>r.id));for(const r of n.fleets)r.owner===e&&i.add(r.systemId);return n.fleets.filter(r=>(t===void 0||r.systemId===t)&&(r.owner===e||i.has(r.systemId)))}const ot=Object.freeze({target:10,cost:60,sites:3}),Ud=(n,e)=>n.factions.find(t=>t.id===e),us=(n,e)=>n.systems.filter(t=>t.owner===e&&t.buildings.includes("beacon")),Od=(n,e)=>Number(n.id.slice(1))-Number(e.id.slice(1))||n.id.localeCompare(e.id),Bf=n=>n?.alignment?.progress||0;function kf(n,e){const t=us(n,e.id).sort(Od),i=new Set(t.map(s=>s.id)),r=[...new Set(e.alignment?.sites||[])].filter(s=>i.has(s)).slice(0,ot.sites);for(const s of t)r.length<ot.sites&&!r.includes(s.id)&&r.push(s.id);return r}function ys(n,e="player"){const t=Ud(n,e),i=t?kf(n,t):[],r={factionId:e,progress:Bf(t),target:ot.target,beacons:t?us(n,e).length:0,sites:i,ready:!1,reason:"",cost:ot.cost};if(!t||t.eliminated)r.reason="This empire is no longer active.";else if(!t.techs.includes("singularity"))r.reason="Research the Asterion Protocol.";else if(i.length<ot.sites)r.reason=`Complete Asterion Beacons on three owned worlds (${i.length}/3).`;else{const s=i.filter(a=>Ft(n,e,a).some(o=>o.owner!==e&&t.relations[o.owner]?.status==="war"&&Re[o.type]?.attack>=4));s.length?r.reason=`Hostile warships block alignment at ${s.map(a=>n.systems.find(o=>o.id===a).name).join(", ")}.`:t.credits<ot.cost?r.reason=`Alignment requires ${ot.cost} credits after ordinary income each cycle.`:r.ready=!0}return r}function Zr(n,e,t,i){const r=Ud(n,"player");e.id!=="player"&&!r?.contacts.includes(e.id)||(n.log.unshift({id:n.nextLogId++,turn:n.turn,type:"alignment",text:t,...i?{systemId:i}:{}}),n.log.length=Math.min(n.log.length,160))}function Zo(n){const e=[];for(const t of n.factions)for(const i of us(n,t.id))for(const r of n.factions)r.id!==t.id&&!r.contacts.includes(t.id)||i.knownBy.includes(r.id)||(i.knownBy.push(r.id),r.id==="player"&&t.id!=="player"&&(e.push(i.id),Zr(n,t,`${t.name} broadcasts an Asterion Beacon at ${i.name}. Its location is now charted.`,i.id)));return{revealedToPlayer:e}}function Zn(n,e="player"){const t=Ud(n,e);return t?n.factions.filter(i=>i.id===e||t.contacts.includes(i.id)).map(i=>({factionId:i.id,name:i.name,color:i.color,progress:Bf(i),target:ot.target,beacons:us(n,i.id).length,sites:us(n,i.id).sort(Od).map(r=>({id:r.id,name:r.name,x:r.x,y:r.y,owner:r.owner})),participatingSites:kf(n,i),active:!!i.alignment?.active})):[]}function Mb(n){if(n.winner||n.alignmentUpdatedTurn===n.turn)return{advanced:!1,updates:[]};const{revealedToPlayer:e}=Zo(n),t=[];for(const i of n.factions){const r=i.alignment||{progress:0,sites:[],active:!1,started:!1,reportedBeacons:[]},s=ys(n,i.id),a=us(n,i.id).sort(Od);for(const d of a)!r.reportedBeacons.includes(d.id)&&!e.includes(d.id)&&Zr(n,i,`${i.name} has restored an Asterion Beacon at ${d.name} (${a.length} owned).`,d.id);const o=s.ready?Math.min(ot.target,r.progress+1):Math.max(0,r.progress-1),l=s.ready?ot.cost:0;i.credits-=l,i.alignment={progress:o,sites:s.sites,active:s.ready,started:r.started||s.ready,reportedBeacons:a.map(d=>d.id)};const c=s.sites[0]||r.sites[0];if(s.ready&&!r.started)Zr(n,i,`${i.name} begins Asterion alignment (${o}/${ot.target}). Three beacon worlds must remain operational; each advancing cycle costs ${ot.cost} credits.`,c);else if(s.ready&&!r.active)Zr(n,i,`${i.name} resumes Asterion alignment (${o}/${ot.target}).`,c);else if(!s.ready&&r.active){const d=i.id==="player"?` ${s.reason}`:"";Zr(n,i,`${i.name}’s Asterion alignment is interrupted (${o}/${ot.target}).${d}`,c)}else s.ready&&[5,8,ot.target].includes(o)&&Zr(n,i,`${i.name} reaches ${o}/${ot.target} Asterion alignment.`,c);t.push({factionId:i.id,progress:o,active:s.ready,spent:l})}return n.alignmentUpdatedTurn=n.turn,{advanced:!0,updates:t}}function wb(n){if(!n||!Array.isArray(n.factions)||!Array.isArray(n.systems)||!Number.isSafeInteger(n.turn)||n.turn<1)return!1;const e=new Set(n.systems.map(i=>i?.id)),t=(i,r)=>Array.isArray(i)&&i.length<=r&&new Set(i).size===i.length&&i.every(s=>typeof s=="string"&&e.has(s));if(n.alignmentUpdatedTurn!==void 0&&(!Number.isSafeInteger(n.alignmentUpdatedTurn)||n.alignmentUpdatedTurn<0||n.alignmentUpdatedTurn>n.turn))return!1;for(const i of n.factions){if(!i||typeof i!="object")return!1;const r=i.alignment;if(r!==void 0&&(!r||typeof r!="object"||Array.isArray(r)||!Number.isSafeInteger(r.progress)||r.progress<0||r.progress>ot.target||!t(r.sites,ot.sites)||!t(r.reportedBeacons,n.systems.length)||typeof r.active!="boolean"||typeof r.started!="boolean"||r.progress>0&&!r.started||r.active&&(!r.started||r.progress===0||r.sites.length!==ot.sites)))return!1}return!0}const jt=Object.freeze({extraction:Object.freeze({id:"extraction",name:"Extraction Charter",icon:"◇",support:"mine",description:"Develop native ore deposits. Each level adds 2 plus the world’s ore richness to mineral income."}),academy:Object.freeze({id:"academy",name:"Academy Charter",icon:"✧",support:"lab",description:"Build a center of discovery. Each level adds 2 plus the world’s native science to science income."}),forge:Object.freeze({id:"forge",name:"Forge Charter",icon:"▥",support:"factory",description:"Specialize in shipbuilding. Each level adds production, 10% off military ship mineral costs, and 2 colony repair capacity."}),civic:Object.freeze({id:"civic",name:"Civic Charter",icon:"⌂",support:"forum",description:"Coordinate a mature federation. Each level adds one order and credits based on the population."})}),$f=n=>!!(n&&typeof n.type=="string"&&Object.hasOwn(jt,n.type)&&[1,2].includes(n.level)),Eb=()=>({credits:0,minerals:0,science:0,production:0,orders:0,militaryDiscount:0,repair:0}),fo=(n,e)=>n.charter?.type===e,Tb=(n,e)=>fo(n,e)?Math.min(2,n.charter.level+1):1,Ab=n=>n===2?{credits:300,minerals:100}:{credits:120,minerals:60},Rb=n=>n===2?100:60,zf=n=>n===2?"II":"I";function Fn(n,e){const t=e?.buildings?.length||0,i=Math.min(5,2+Math.floor((e?.population||0)/3));return{used:t,capacity:i,available:Math.max(0,i-t),overCapacity:Math.max(0,t-i)}}function Ni(n,e=n?.charter){const t=Eb();if(!n||!$f(e))return t;const i=e.level;return e.type==="extraction"?t.minerals=(2+n.richness)*i:e.type==="academy"?t.science=(2+n.science)*i:e.type==="forge"?(t.production=(4+Math.floor(n.population/4))*i,t.militaryDiscount=.1*i,t.repair=2*i):e.type==="civic"&&(t.orders=i,t.credits=(2+Math.floor(n.population/2))*i),t}const ql=18;function Hf(n,e="player"){const t=n.factions.find(s=>s.id===e);if(!t)return{total:0,uncapped:0,limit:ql};const i=n.systems.filter(s=>s.owner===e),r=4+i.length+(e==="player"?1:0)+(t.techs.includes("logistics")?1:0)+(t.techs.includes("command")?2:0)+i.reduce((s,a)=>s+a.buildings.reduce((o,l)=>o+(Ye[l].orders||0),0)+Ni(a).orders,0);return{total:Math.min(ql,r),uncapped:r,limit:ql}}function ga(n,e="player",t=0){const i=Hf(n,e),r=Math.max(0,Math.min(i.limit,i.uncapped+t));return{current:i.total,projected:r,nominal:t,change:r-i.total,limit:i.limit}}function _s(n,e,t="player"){const i=n.systems.find(o=>o.id===e),r=n.factions.find(o=>o.id===t),s=Ni(i),a=i?4+i.population+i.buildings.reduce((o,l)=>o+(Ye[l].production||0),0)+s.production:0;return Object.values(jt).map(o=>{const l=i?Tb(i,o.id):1,c=fo(i||{},o.id)&&i.charter.level===2,d=Ab(l),u=Rb(l),h=Ni(i,{type:o.id,level:l}),f=Object.fromEntries(Object.keys(h).map(v=>[v,Math.round((h[v]-s[v])*100)/100]));let p="";return!i||!r||i.owner!==t?p="Requires an owned colony":i.queue?p="Construction already in progress":c?p="Charter already at level II":i.buildings.includes(o.support)?i.population<(l===2?8:4)?p=`Requires population ${l===2?8:4}`:r.techs.includes("logistics")?l===2&&!r.techs.includes("industry")?p=`Requires ${Tt.industry.name}`:r.credits<d.credits||r.minerals<d.minerals?p="Insufficient credits or minerals":r.orders<1&&(p="No orders remaining"):p=`Requires ${Tt.logistics.name}`:p=`Requires ${Ye[o.support].name}`,{...o,charterType:o.id,level:l,name:`${o.name} ${zf(l)}`,kind:"charter",cost:d,work:u,bonuses:h,delta:f,orderEffect:ga(n,t,f.orders),completed:c,switching:!!(i?.charter&&!fo(i,o.id)),promoting:!!(fo(i||{},o.id)&&i.charter.level===1),enabled:!p,reason:p,turns:a>0?Math.ceil(u/a):0}})}function Ko(n){if(!n)return null;if(n.kind==="charter"){const t=jt[n.charterType];return t?{...t,id:n.itemId,name:`${t.name} ${zf(n.charterLevel)}`,kind:"charter",charterType:n.charterType,level:n.charterLevel,cost:{...n.cost},work:n.work,progress:n.progress}:null}const e=(n.kind==="ship"?Re:Ye)[n.itemId];return e?{...e,kind:n.kind,cost:{...n.cost},work:n.work,progress:n.progress,replaceBuildingId:n.replaceBuildingId||null}:null}function Cb(n,e,t){const i={...e.cost};return t==="ship"&&["frigate","cruiser"].includes(e.id)&&(i.minerals=Math.ceil(i.minerals*(1-Ni(n).militaryDiscount))),i}function Ib(n){try{const e=(i,r)=>typeof r=="string"&&Object.hasOwn(i,r);if(n.charter!==void 0&&n.charter!==null&&(!$f(n.charter)||!n.buildings.includes(jt[n.charter.type].support)||Object.keys(n.charter).some(i=>!["type","level"].includes(i))))return!1;const t=n.queue;if(!t)return!0;if(!["building","ship","charter"].includes(t.kind)||!Number.isFinite(t.progress)||t.progress<0||!Number.isFinite(t.work)||t.work<=0||t.progress>=t.work||!t.cost||typeof t.cost!="object"||Array.isArray(t.cost)||!Object.entries(t.cost).every(([i,r])=>["credits","minerals"].includes(i)&&Number.isFinite(r)&&r>=0))return!1;if(t.kind==="charter"){if(!e(jt,t.charterType)||t.itemId!==t.charterType||![1,2].includes(t.charterLevel)||!n.buildings.includes(jt[t.charterType].support)||t.replaceBuildingId!==void 0||!["credits","minerals"].every(i=>Number.isFinite(t.cost[i]))||t.charterLevel===2&&(n.charter?.type!==t.charterType||n.charter.level!==1)||t.charterLevel===1&&n.charter?.type===t.charterType)return!1}else if(!e(t.kind==="ship"?Re:Ye,t.itemId)||t.charterType!==void 0||t.charterLevel!==void 0||t.replaceBuildingId!==void 0&&(t.kind!=="building"||!e(Ye,t.replaceBuildingId)||!n.buildings.includes(t.replaceBuildingId)||t.replaceBuildingId===t.itemId))return!1;return!0}catch{return!1}}const Uo=Object.freeze({dispatches:64,transfers:32}),Gf=["war","peace","trade","trade-notice","trade-ended"],qc=Object.freeze({id:null,name:"Uncontacted civilization",shortName:"Uncontacted",color:null}),Vf=(n,e)=>n.factions.find(t=>t.id===e),hs=(n,e)=>n.id===e||n.contacts.includes(e);function Wf(n){if(n&&typeof n=="object"){for(const e of Object.values(n))Wf(e);Object.freeze(n)}return n}const va=n=>Wf(structuredClone(n));function br(n,e){if(!hs(n,e))return{...qc};const t=Ke[e];return{id:e,name:t.name,shortName:t.shortName,color:t.color}}function Pb(n,e="player"){const t=Vf(n,e);if(!t)return[];const i=n.factions.filter(a=>a.id!==e&&!a.eliminated).sort((a,o)=>a.id.localeCompare(o.id)),r=[];for(let a=0;a<i.length;a++)for(let o=a+1;o<i.length;o++){const l=i[a],c=i[o],d=hs(t,l.id),u=hs(t,c.id);if(!d&&!u)continue;const h=l.relations[c.id],f=h.truceUntil>n.turn?h.truceUntil:null,p=h.trade&&h.tradeEndsAt>n.turn?h.tradeEndsAt:null,v=h.status==="war"?"war":f?"truce":h.trade?"trade":"peace";if(v==="peace"&&!(d&&u))continue;const m=[br(t,l.id),br(t,c.id)];m.sort((g,x)=>+(x.id!==null)-+(g.id!==null)||g.name.localeCompare(x.name)),r.push({key:d&&u?`${l.id}:${c.id}`:null,participants:m,status:v,sinceTurn:["war","truce"].includes(v)&&h.treatyTurn>0?h.treatyTurn:null,truceUntil:f,tradeEndsAt:p})}const s={war:0,truce:1,trade:2,peace:3};return r.sort((a,o)=>s[a.status]-s[o.status]||JSON.stringify(a).localeCompare(JSON.stringify(o))),va(r)}function Lb(n,e="player"){return va(n.publicAffairs?.observers?.[e]?.dispatches||[])}function Fd(n,e="player",t=5){if(!(t===1/0||Number.isFinite(t)&&t>=0))return[];const i=n.publicAffairs?.observers?.[e]?.transfers||[];return va(i.filter(r=>n.turn-r.turn<t))}function Xf(n,e){return n.publicAffairs||={version:1,observers:{}},n.publicAffairs.observers[e]||={nextId:1,dispatches:[],transfers:[]},n.publicAffairs.observers[e]}function qf(n){const[e,t]=n.participants.map(i=>i.name);switch(n.kind){case"war":return`${e} declared war on ${t}.`;case"peace":return`Peace agreed between ${e} and ${t}. Their truce forbids war until cycle ${n.untilTurn}.`;case"trade":return`${e} and ${t} announced a trade agreement. Their borders are open to each other.`;case"trade-notice":return`${e} gave notice to end trade with ${t}. Their trade and mutual border access end on cycle ${n.untilTurn}.`;case"trade-ended":return`Trade between ${e} and ${t} has ended. Their mutual border access is closed.`;case"sovereignty":return`${n.systemName} changed sovereignty from ${e} to ${t}.`;default:return""}}function Yf(n,e,t,i){const r=va({...i,text:qf(i)});return t.dispatches.unshift(r),t.dispatches.length=Math.min(t.dispatches.length,Uo.dispatches),e.id==="player"&&(n.log.unshift({id:n.nextLogId++,turn:n.turn,type:r.kind==="war"?"war":r.kind==="sovereignty"?"sovereignty":"diplomacy",text:r.text,publicAffairId:r.id,...r.targetId?{targetId:r.targetId}:{},...r.systemId?{systemId:r.systemId}:{}}),n.log.length=Math.min(n.log.length,160)),r}function oa(n,{kind:e,firstId:t,secondId:i,untilTurn:r}){if(!Gf.includes(e)||t===i||!Ke[t]||!Ke[i])return[];if(["peace","trade-notice"].includes(e)&&(!Number.isSafeInteger(r)||r<=n.turn))return[];const s=[];for(const a of n.factions){if(a.eliminated||[t,i].includes(a.id)||!hs(a,t)&&!hs(a,i))continue;const o=[br(a,t),br(a,i)],l=Xf(n,a.id);s.push(Yf(n,a,l,{id:l.nextId++,turn:n.turn,kind:e,participants:o,targetId:o.find(c=>c.id!==null).id,...["peace","trade-notice"].includes(e)?{untilTurn:r}:{}}))}return s}function Nb(n,{systemId:e,fromId:t,toId:i,observerIds:r}){const s=n.systems.find(o=>o.id===e);if(!s||t===i||!Ke[t]||!Ke[i]||!Array.isArray(r))return[];const a=[];for(const o of n.factions){if(o.eliminated||!r.includes(o.id)||!s.knownBy.includes(o.id))continue;const l=Xf(n,o.id),c=va({id:l.nextId++,turn:n.turn,systemId:e,systemName:s.name,from:br(o,t),to:br(o,i)});l.transfers.unshift(c),l.transfers.length=Math.min(l.transfers.length,Uo.transfers),a.push(c),![t,i].includes(o.id)&&Yf(n,o,l,{id:c.id,turn:c.turn,kind:"sovereignty",participants:[c.from,c.to],systemId:e,systemName:s.name,targetId:c.to.id||c.from.id})}return a}function Db(n){if(n.publicAffairs===void 0)return!0;try{const e=(s,a)=>s&&typeof s=="object"&&!Array.isArray(s)&&Object.keys(s).sort().join("|")===[...a].sort().join("|"),t=s=>Number.isSafeInteger(s)&&s>0,i=n.publicAffairs;if(!e(i,["version","observers"])||i.version!==1||!i.observers||typeof i.observers!="object"||Array.isArray(i.observers))return!1;const r=Object.entries(i.observers);if(r.length>n.factions.length)return!1;for(const[s,a]of r){const o=Vf(n,s);if(!o||!e(a,["nextId","dispatches","transfers"])||!t(a.nextId)||!Array.isArray(a.dispatches)||a.dispatches.length>Uo.dispatches||!Array.isArray(a.transfers)||a.transfers.length>Uo.transfers)return!1;const l=d=>{if(!e(d,["id","name","shortName","color"]))return!1;if(d.id===null)return Object.keys(qc).every(h=>d[h]===qc[h]);if(!Ke[d.id]||!hs(o,d.id))return!1;const u=br(o,d.id);return Object.keys(u).every(h=>d[h]===u[h])},c=d=>d.every((u,h)=>u&&t(u.id)&&u.id<a.nextId&&t(u.turn)&&u.turn<=n.turn&&(!h||u.id<d[h-1].id&&u.turn<=d[h-1].turn));if(!c(a.dispatches)||!c(a.transfers))return!1;for(const d of a.transfers){if(!e(d,["id","turn","systemId","systemName","from","to"])||!l(d.from)||!l(d.to)||d.to.id===null||d.from.id===d.to.id)return!1;const u=n.systems.find(h=>h.id===d.systemId);if(!u||!u.knownBy.includes(s)||d.systemName!==u.name)return!1}for(const d of a.dispatches){const u=d.kind==="sovereignty",h=["peace","trade-notice"].includes(d.kind),f=["id","turn","kind","text","participants","targetId",...u?["systemId","systemName"]:[],...h?["untilTurn"]:[]];if(!e(d,f)||![...Gf,"sovereignty"].includes(d.kind)||!Array.isArray(d.participants)||d.participants.length!==2||!d.participants.every(l))return!1;const p=d.participants.filter(v=>v.id!==null).map(v=>v.id);if(!p.length||p.includes(s)||new Set(p).size!==p.length||!p.includes(d.targetId)||h&&(!t(d.untilTurn)||d.untilTurn<=d.turn||d.untilTurn>d.turn+120))return!1;if(u){const v=n.systems.find(m=>m.id===d.systemId);if(!v||!v.knownBy.includes(s)||d.systemName!==v.name)return!1}if(d.text!==qf(d))return!1}}return!0}catch{return!1}}const Ve=Object.freeze({peaceCost:60,tradeCost:30,giftCost:35,minimumWarTurns:5,truceTurns:5,offerTurns:3,tradeNoticeTurns:3,tradeOfferQuietTurns:5}),Zf=["war","peace","trade","gift","endTrade","acceptPeace","declinePeace","acceptTrade","declineTrade"],ji=n=>n.kind||"peace",Nt=(n,e)=>n.factions.find(t=>t.id===e),fs=(n,e)=>n.systems.filter(t=>t.owner===e),Yc=n=>Math.max(0,Math.min(100,n)),rs=n=>Math.max(-100,Math.min(100,n)),Yl=n=>({ok:!1,message:n}),Kf=(n,e)=>Nt(n,e)?.name||Ke[e]?.name||e,wh=(n,e)=>n.lanes.flatMap(([t,i])=>t===e?[i]:i===e?[t]:[]),po=n=>n.type==="cruiser"?n.ships*3:n.type==="frigate"?n.ships:0;function Pn(n,e,t,i,r="diplomacy"){e!=="player"&&t!=="player"||(n.log.unshift({id:n.nextLogId++,turn:n.turn,type:r,text:i,targetId:e==="player"?t:e}),n.log.length=Math.min(n.log.length,160))}function Jo(n,e,t){const i=fs(n,e),r=new Set(i.map(d=>d.id)),s=new Set(i.flatMap(d=>wh(n,d.id))),a=Ft(n,e).filter(d=>d.owner===t&&po(d)>0),o=a.filter(d=>r.has(d.systemId)||s.has(d.systemId)),l=i.filter(d=>o.some(u=>u.systemId===d.id||wh(n,d.id).includes(u.systemId)));return{borderCount:n.systems.filter(d=>d.owner===t&&s.has(d.id)&&d.knownBy.includes(e)).length,threatenedColonies:l.length,invadingWeight:a.filter(d=>r.has(d.systemId)).reduce((d,u)=>d+po(u),0),observedWeight:o.reduce((d,u)=>d+po(u),0)}}function Jf(n,e,t){const r=Nt(n,e).relations[t],s=Math.max(0,n.turn-r.treatyTurn),a=Math.max(0,(r.warStartColonies??fs(n,e).length)-fs(n,e).length),o=Jo(n,e,t),l=Math.min(60,s*3)+a*24+Math.min(24,o.threatenedColonies*12)+(o.invadingWeight>0?12:0),c=e==="khar"?48:36,d=s>=Ve.minimumWarTurns&&l>=c,u=[];a&&u.push(`${Kf(n,e)} has lost ${a} colon${a===1?"y":"ies"} since the war began.`),o.threatenedColonies&&u.push("Their colonies face military pressure they can observe."),s>=12&&u.push("The prolonged war increases their willingness to settle."),e==="khar"&&u.push("The Khar Dominion is reluctant to concede a war.");const h=s<Ve.minimumWarTurns?`Peace negotiations open after ${Ve.minimumWarTurns} cycles of war.`:d?u[0]||"They are willing to end the war.":"They refuse these terms for now: war weariness and their observed losses or military pressure are insufficient.";return{accepted:d,reason:h,reasons:u,warAge:s,lostColonies:a}}function jo(n,e){const t=Nt(n,e.from),i=Nt(n,e.to);if(!t||!i||t.eliminated||i.eliminated)return!1;const r=t.relations[e.to];return ji(e)==="trade"?r.status==="peace"&&!r.trade:r.status==="war"}function xs(n,e="player"){return n.winner||!Nt(n,e)||Nt(n,e).eliminated?[]:(n.diplomacyOffers||[]).filter(t=>(t.from===e||t.to===e)&&t.status==="pending"&&n.turn<t.expiresTurn&&jo(n,t)).map(t=>({...t,kind:ji(t)}))}function Ub(n,e,t){const i=Nt(n,e).relations[t].tradeOfferAfter||0,r=(n.diplomacyOffers||[]).filter(s=>ji(s)==="trade"&&s.from===e&&s.to===t&&s.status==="pending"&&n.turn>=s.expiresTurn);return Math.max(i,...r.map(s=>s.expiresTurn+Ve.tradeOfferQuietTurns))}function ni(n,e,t,i=0){return{enabled:n,reason:n?"":e,effect:t,cost:{credits:i,orders:1}}}function Di(n,e="player",t){const i=Nt(n,e),r=Nt(n,t),s=i?.relations?.[t],a=n.winner?"This campaign has ended.":!i||i.eliminated?"This empire is no longer active.":!r||t===e||r.eliminated||!s?"Select an active foreign empire.":i.contacts.includes(t)?i.orders<1?"No orders remaining.":"":"Establish first contact before opening negotiations.";if(!s||!r||!i){const U=Object.fromEntries(Zf.map(V=>[V,ni(!1,a,"")]));return{factionId:e,targetId:t,status:null,actions:U,...U,pendingOffers:[],incomingOffer:null,outgoingOffer:null,incomingTradeOffer:null,outgoingTradeOffer:null}}const o=xs(n,e).filter(U=>U.from===t||U.to===t),l=o.find(U=>U.kind==="peace"&&U.to===e)||null,c=o.find(U=>U.kind==="peace"&&U.from===e)||null,d=o.find(U=>U.kind==="trade"&&U.to===e)||null,u=o.find(U=>U.kind==="trade"&&U.from===e)||null,h=Math.max(s.truceUntil||0,r.relations[e]?.truceUntil||0),f=Math.max(0,h-n.turn),p=s.trade&&s.tradeEndsAt||0,v=p?Math.max(0,p-n.turn):null,m=Math.max(0,n.turn-s.treatyTurn),g=t==="player"&&e!=="player"?"offer":"settlement",x=g,E=x==="offer"?Ub(n,e,t):0,b=s.status==="war"&&g==="settlement"?Jf(n,t,e):null,w=a||(s.status==="war"?"Already at war.":f?`The peace settlement forbids war until turn ${h} (${f} cycles remaining).`:""),S=a||(s.status!=="war"?"Already at peace.":m<Ve.minimumWarTurns?`They will not discuss peace during the first ${Ve.minimumWarTurns} cycles of war.`:c?`A peace offer is pending until turn ${c.expiresTurn}.`:i.credits<Ve.peaceCost?`A peace settlement costs ${Ve.peaceCost} credits.`:b&&!b.accepted?b.reason:""),T=a||(s.status==="war"?"End the war before negotiating trade.":s.trade?p?`Trade is ending on turn ${p}.`:"A trade treaty is already active.":d||u?"A trade offer is awaiting a decision.":E>n.turn?`A new trade proposal may be sent on cycle ${E}.`:s.trust<0?"Trust must be at least zero. A diplomatic gift can improve it.":i.credits<Ve.tradeCost?`A trade treaty costs ${Ve.tradeCost} credits.`:""),y=a||(s.status==="war"?"Diplomatic gifts cannot be sent during war.":i.credits<Ve.giftCost?`A diplomatic gift costs ${Ve.giftCost} credits.`:""),A=a||(s.trade?p?`Cancellation already announced for turn ${p}.`:"":"No active trade treaty."),C=a||(l?s.status!=="war"?"The war has already ended.":"":"No active incoming peace offer."),L=a||(d?"":"No active incoming trade offer."),I="Fleets in each other’s territory withdraw to their nearest owned colony, or a charted neutral system if they have no colony. A fleet with neither destination remains in place with no moves.",B={war:ni(!w,w,s.trade?"Break trade immediately: mutual trust −65; the betrayed empire gains 35 grievance. War opens their borders.":"Declare war: mutual trust −40; the other empire gains 20 grievance. War opens their borders."),peace:{...ni(!S,S,g==="offer"?`Reserve ${Ve.peaceCost} credits for a player decision. The war continues until acceptance. Offer expires on turn ${n.turn+Ve.offerTurns}; refusal or expiry refunds the credits. Acceptance creates a ${Ve.truceTurns}-cycle truce. ${I}`:`Pay ${Ve.peaceCost} credits to end the war. War is forbidden for ${Ve.truceTurns} cycles. ${I}`,Ve.peaceCost),accepted:g==="offer"?null:!!b?.accepted,mode:g,willingness:b},trade:{...ni(!T,T,x==="offer"?`Reserve ${Ve.tradeCost} credits for a trade offer. Borders, income and trust stay unchanged until the player accepts. The reserved treaty fee is consumed on acceptance, or refunded on refusal or expiry.`:"Open borders and earn 6 credits per turn, or 10 with Stellar Accords. Mutual trust +10. Border grievances can still cause cancellation.",Ve.tradeCost),mode:x},gift:ni(!y,y,"Transfer 35 credits; mutual trust +20. Existing border grievances remain.",Ve.giftCost),endTrade:ni(!A,A,`Give ${Ve.tradeNoticeTurns} cycles of notice. Income and access continue until turn ${n.turn+Ve.tradeNoticeTurns}, then both end and visiting fleets withdraw. Mutual trust −5; the other empire gains 5 grievance.`),acceptPeace:ni(!C,C,`Receive ${l?.credits||Ve.peaceCost} credits. End the war and establish a ${Ve.truceTurns}-cycle truce. ${I}`),declinePeace:ni(!C,C,"Continue the war without moving any fleet. The proposer receives its reserved credits back."),acceptTrade:ni(!L,L,`Open borders and begin trade income. Mutual trust +10. The proposer already reserved the ${Ve.tradeCost}-credit treaty fee; acceptance costs you no credits.`),declineTrade:ni(!L,L,"Keep borders closed. The proposer receives its reserved treaty fee back.")},N=Jo(n,e,t);return{factionId:e,targetId:t,status:s.status,trust:s.trust,grievance:s.grievance||0,ourGrievance:s.grievance||0,theirGrievance:r.relations[e].grievance||0,truceUntil:h,truceRemaining:f,tradeEndsAt:p,tradeEndingIn:v,tradeOfferAfter:E,borderCount:N.borderCount,policy:t==="khar"?"Khar frontier rivalry: a shared border increases its grievances by 1 each peaceful cycle. At 24 grievances, a sufficiently strong Khar force may cancel trade with notice and prepare for war.":"New neighboring claims and observed military pressure create grievances. A quiet frontier lets grievances ease.",actions:B,...B,pendingOffers:o,incomingOffer:l,outgoingOffer:c,incomingTradeOffer:d,outgoingTradeOffer:u}}function jf(n,e,t){let i=0,r=0;for(const s of n.fleets.filter(a=>a.owner===e||a.owner===t)){const a=n.systems.find(c=>c.id===s.systemId);if(!a||a.owner!==(s.owner===e?t:e))continue;let o=fs(n,s.owner);o.length||(o=n.systems.filter(c=>!c.owner&&c.knownBy.includes(s.owner)));const l=[...o].sort((c,d)=>Math.hypot(c.x-a.x,c.y-a.y)-Math.hypot(d.x-a.x,d.y-a.y)||c.id.localeCompare(d.id))[0];s.movesLeft=0,l?(s.systemId=l.id,delete s.route,delete s.defenseLead,i++):r++}return{moved:i,stranded:r}}function Qr(n,e,t){if(e.status==="pending"){if(e.status=t,t==="accepted")ji(e)==="peace"&&(Nt(n,e.to).credits+=e.credits);else if(Nt(n,e.from).credits+=e.credits,ji(e)==="trade"){const i=t==="expired"?Math.min(n.turn,e.expiresTurn):n.turn;Qf(n,e.from,e.to,i)}}}function Qf(n,e,t,i=n.turn){if(e!=="player"&&t!=="player")return;const s=Nt(n,e==="player"?t:e).relations.player;s.tradeOfferAfter=Math.max(s.tradeOfferAfter||0,i+Ve.tradeOfferQuietTurns)}function Bd(n){let e=0;for(const t of n.diplomacyOffers||[]){if(t.status!=="pending"||n.turn<t.expiresTurn&&jo(n,t))continue;Qr(n,t,"expired"),e++;const i=ji(t)==="trade";Pn(n,t.from,t.to,`${Kf(n,t.from)}’s ${i?"trade":"peace"} offer expired. Its ${t.credits} reserved credits were returned; ${i?"no treaty was established":"no fleets moved"}.`)}return e}function Eh(n,e,t){const i=Nt(n,e),r=Nt(n,t);for(const a of[i.relations[t],r.relations[e]])a.trade=!0,a.tradeEndsAt=0,a.trust=rs(a.trust+10);const s=`Trade established between ${i.name} and ${r.name}. Borders are open; existing grievances remain.`;return Pn(n,e,t,s),oa(n,{kind:"trade",firstId:e,secondId:t}),s}function Th(n,e,t){const i=Nt(n,e),r=Nt(n,t);for(const a of[i.relations[t],r.relations[e]])a.status="peace",a.trade=!1,a.tradeEndsAt=0,a.trust=-5,a.treatyTurn=n.turn,a.truceUntil=n.turn+Ve.truceTurns,a.grievance=Math.max(0,(a.grievance||0)-15);for(const a of n.diplomacyOffers||[])a.status==="pending"&&[e,t].includes(a.from)&&[e,t].includes(a.to)&&Qr(n,a,"expired");const s=jf(n,e,t);return Pn(n,e,t,`Peace agreed between ${i.name} and ${r.name}. The truce forbids war until turn ${n.turn+Ve.truceTurns}. ${s.moved} fleet${s.moved===1?"":"s"} withdrew.${s.stranded?` ${s.stranded} fleet${s.stranded===1?" has":"s have"} no owned colony or charted neutral withdrawal point and remain in place.`:""}`),oa(n,{kind:"peace",firstId:e,secondId:t,untilTurn:n.turn+Ve.truceTurns}),s}function Ob(n,e={}){const t=e.factionId||"player",i=e.stance;if(!Zf.includes(i))return Yl("Unknown diplomatic proposal.");let r=e.targetId,s=null;if(["acceptPeace","declinePeace","acceptTrade","declineTrade"].includes(i)){const v=i.endsWith("Trade")?"trade":"peace";if(s=(n.diplomacyOffers||[]).find(m=>ji(m)===v&&m.status==="pending"&&m.to===t&&(e.offerId?m.id===e.offerId:m.from===r)),!s||n.turn>=s.expiresTurn||!jo(n,s)||r&&r!==s.from)return Yl(`No matching active incoming ${v} offer.`);r=s.from}const a=Di(n,t,r),o=a.actions[i];if(!o.enabled)return Yl(o.reason);const l=Nt(n,t),c=Nt(n,r),d=l.relations[r],u=c.relations[t];let h=i,f="",p={};if(i==="war"){const v=d.trade;for(const m of[d,u])m.status="war",m.trade=!1,m.tradeEndsAt=0,m.trust=rs(m.trust-(v?65:40)),m.treatyTurn=n.turn,m.truceUntil=0;d.warStartColonies=fs(n,t).length,u.warStartColonies=fs(n,r).length,u.grievance=Yc((u.grievance||0)+(v?35:20)),f=`${l.name} declared war on ${c.name}.${v?" The active trade treaty was broken; the betrayal deepens their grievance.":""}`,Pn(n,t,r,f,"war"),oa(n,{kind:"war",firstId:t,secondId:r})}else if(i==="peace"&&a.peace.mode==="offer")l.credits-=Ve.peaceCost,n.diplomacyOffers||=[],n.nextDiplomacyOfferId||=1,s={id:`peace-${n.nextDiplomacyOfferId++}`,from:t,to:r,createdTurn:n.turn,expiresTurn:n.turn+Ve.offerTurns,credits:Ve.peaceCost,status:"pending",truceTurns:Ve.truceTurns},n.diplomacyOffers.push(s),d.peaceOfferTurn=n.turn,f=`${l.name} offers ${s.credits} credits for peace and a ${s.truceTurns}-cycle truce. Your decision is required before turn ${s.expiresTurn}; the war continues until you accept.`,Pn(n,t,r,f),h="peaceOffered",p.offer=s;else if(i==="peace")l.credits-=Ve.peaceCost,c.credits+=Ve.peaceCost,p.withdrawal=Th(n,t,r),h="peaceAccepted",f=`Peace accepted. The truce lasts until turn ${d.truceUntil}.`;else if(i==="acceptPeace")Qr(n,s,"accepted"),p.withdrawal=Th(n,t,r),h="peaceAccepted",f=`Peace accepted. You receive ${s.credits} credits; war is forbidden until turn ${d.truceUntil}.`,p.offer=s;else if(i==="declinePeace")Qr(n,s,"declined"),f=`${l.name} declined ${c.name}’s peace offer. The war continues.`,Pn(n,t,r,f),h="peaceDeclined",p.offer=s;else if(i==="trade"&&a.trade.mode==="offer")l.credits-=Ve.tradeCost,n.diplomacyOffers||=[],n.nextDiplomacyOfferId||=1,s={id:`trade-${n.nextDiplomacyOfferId++}`,kind:"trade",from:t,to:r,createdTurn:n.turn,expiresTurn:n.turn+Ve.offerTurns,credits:Ve.tradeCost,status:"pending"},n.diplomacyOffers.push(s),f=`${l.name} proposes trade and reserves its ${s.credits}-credit treaty fee. Borders remain closed until you accept. The offer expires on cycle ${s.expiresTurn}.`,Pn(n,t,r,f),h="tradeOffered",p.offer=s;else if(i==="trade")l.credits-=Ve.tradeCost,f=Eh(n,t,r);else if(i==="acceptTrade")Qr(n,s,"accepted"),f=Eh(n,s.from,s.to),h="tradeAccepted",p.offer=s;else if(i==="declineTrade")Qr(n,s,"declined"),f=`${l.name} declined ${c.name}’s trade offer. Borders remain closed.`,Pn(n,t,r,f),h="tradeDeclined",p.offer=s;else if(i==="gift"){l.credits-=Ve.giftCost,c.credits+=Ve.giftCost;for(const v of[d,u])v.trust=rs(v.trust+20);f=`${l.name} sent a 35-credit gift to ${c.name}. Trust improves; border grievances remain.`,Pn(n,t,r,f)}else if(i==="endTrade"){for(const v of[d,u])v.tradeEndsAt=n.turn+Ve.tradeNoticeTurns,v.trust=rs(v.trust-5);u.grievance=Yc((u.grievance||0)+5),f=`${l.name} gave notice to end trade with ${c.name}. Income and open borders continue until turn ${d.tradeEndsAt}, when visiting fleets withdraw.`,Pn(n,t,r,f),h="tradeNotice",oa(n,{kind:"trade-notice",firstId:t,secondId:r,untilTurn:d.tradeEndsAt})}return l.orders--,Bd(n),{ok:!0,message:f,outcome:h,...p}}function Fb(n){if(n.diplomacyUpdatedTurn===n.turn)return{offersExpired:0,treatiesEnded:0};const e=Bd(n);let t=0;for(let i=0;i<n.factions.length;i++)for(let r=i+1;r<n.factions.length;r++){const s=n.factions[i],a=n.factions[r],o=s.relations[a.id],l=a.relations[s.id];if(o.trade&&o.tradeEndsAt&&n.turn>=o.tradeEndsAt){for(const d of[o,l])d.trade=!1,d.tradeEndsAt=0;const c=jf(n,s.id,a.id);Qf(n,s.id,a.id),Pn(n,s.id,a.id,`Trade between ${s.name} and ${a.name} has ended. Trade income and open borders cease; ${c.moved} visiting fleet${c.moved===1?"":"s"} withdrew.`),oa(n,{kind:"trade-ended",firstId:s.id,secondId:a.id}),t++}for(const[c,d,u]of[[s,a,o],[a,s,l]]){if(c.eliminated||d.eliminated||!c.contacts.includes(d.id))continue;const h=Jo(n,c.id,d.id),f=u.lastBorderCount===void 0?0:Math.max(0,h.borderCount-u.lastBorderCount);if(u.lastBorderCount=h.borderCount,u.status==="war")continue;const p=c.id==="khar"&&h.borderCount>0?1:0,v=Math.min(6,h.threatenedColonies*2+Math.floor(h.invadingWeight/2)),m=f*8+v+p,g=u.grievance||0;u.grievance=Yc(g+(m||-1)),m?u.trust=rs(u.trust-Math.min(6,Math.ceil(m/3))):u.trade&&(u.trust=rs(u.trust+1));const x=c.id==="khar"?24:45;g<x&&u.grievance>=x&&Pn(n,c.id,d.id,`${c.name} warns ${d.name}: ${f?"new frontier claims":v?"observed military pressure":"their disputed shared frontier"} have brought grievances to ${u.grievance}. Trade may be cancelled and war preparations may follow.`)}}return n.diplomacyOffers?.length>32&&(n.diplomacyOffers=[...n.diplomacyOffers.filter(i=>i.status!=="pending").slice(-20),...n.diplomacyOffers.filter(i=>i.status==="pending")]),n.diplomacyUpdatedTurn=n.turn,{offersExpired:e,treatiesEnded:t}}function Bb(n,e){const t=Nt(n,e);if(!t||t.eliminated||e==="player"||n.winner||t.orders<1)return[];const i=n.fleets.filter(s=>s.owner===e).reduce((s,a)=>s+po(a),0),r=[];for(const s of[...t.contacts].sort()){const a=Nt(n,s);if(!a||a.eliminated)continue;const o=t.relations[s],l=Di(n,e,s),c=(v,m)=>r.push({type:"diplomacy",factionId:e,targetId:s,stance:v,reason:m});if(o.status==="war"){const v=Jf(n,e,s);v.accepted&&l.peace.enabled&&n.turn-(o.peaceOfferTurn??-100)>=5&&c("peace",v.reason);continue}const d=Jo(n,e,s),u=o.grievance||0,h=e==="khar"?24:45,f=i>=(e==="khar"?4:3)&&i>=d.observedWeight*1.1;u>=h&&(d.borderCount>0||d.threatenedColonies>0)&&f?o.trade&&l.endTrade.enabled?c("endTrade","Frontier grievances outweigh the value of trade. Give notice before closing borders."):!o.trade&&l.war.enabled&&c("war","Unresolved frontier grievances and a prepared fleet make war a credible policy."):l.trade.enabled&&t.credits>110&&u<12&&(e!=="khar"||d.borderCount===0)&&c("trade","Peaceful relations and manageable frontier tensions favor trade.")}return r}function kb(n){if(!n||!Array.isArray(n.factions)||n.factions.some(s=>!s||typeof s.id!="string")||!Number.isSafeInteger(n.turn))return!1;const e=new Set(n.factions.map(s=>s.id)),t=s=>Number.isSafeInteger(s)&&s>=0;if(n.diplomacyUpdatedTurn!==void 0&&(!t(n.diplomacyUpdatedTurn)||n.diplomacyUpdatedTurn>n.turn)||n.nextDiplomacyOfferId!==void 0&&(!t(n.nextDiplomacyOfferId)||n.nextDiplomacyOfferId<1))return!1;for(const s of n.factions){if(!s?.relations||typeof s.relations!="object")return!1;for(const[a,o]of Object.entries(s.relations)){if(!e.has(a)||!o||typeof o!="object")return!1;for(const c of["truceUntil","tradeEndsAt","warStartColonies","peaceOfferTurn","lastBorderCount"])if(o[c]!==void 0&&!t(o[c]))return!1;if(o.tradeOfferAfter!==void 0&&(s.id==="player"||a!=="player"||!t(o.tradeOfferAfter)||o.tradeOfferAfter>n.turn+Ve.tradeOfferQuietTurns)||o.grievance!==void 0&&(!Number.isFinite(o.grievance)||o.grievance<0||o.grievance>100)||o.warStartColonies>n.systems?.length||o.lastBorderCount>n.systems?.length||o.peaceOfferTurn>n.turn)return!1;const l=Nt(n,a)?.relations?.[s.id];if(!l||(o.truceUntil||0)!==(l.truceUntil||0)||(o.tradeEndsAt||0)!==(l.tradeEndsAt||0)||o.tradeEndsAt&&!o.trade||o.status==="war"&&o.truceUntil>n.turn)return!1}}if(n.diplomacyOffers===void 0)return!0;if(!Array.isArray(n.diplomacyOffers)||n.diplomacyOffers.length>100||!Number.isSafeInteger(n.nextDiplomacyOfferId))return!1;const i=new Set,r=new Set;for(const s of n.diplomacyOffers){if(!s||typeof s!="object"||s.kind!==void 0&&!["peace","trade"].includes(s.kind))return!1;const a=ji(s),o=a==="trade";if(typeof s.id!="string"||!(o?/^trade-[1-9]\d*$/:/^peace-[1-9]\d*$/).test(s.id)||i.has(s.id)||!e.has(s.from)||!e.has(s.to)||s.from===s.to||!["pending","accepted","declined","expired"].includes(s.status)||!t(s.createdTurn)||s.createdTurn>n.turn||!t(s.expiresTurn)||s.expiresTurn!==s.createdTurn+Ve.offerTurns||s.credits!==(o?Ve.tradeCost:Ve.peaceCost)||(o?s.to!=="player"||s.from==="player"||s.truceTurns!==void 0:s.truceTurns!==Ve.truceTurns)||Number(s.id.slice(6))>=n.nextDiplomacyOfferId)return!1;if(s.status==="pending"){const l=`${a}:${s.from}:${s.to}`;if(r.has(l)||(o?!jo(n,s):Nt(n,s.from).relations[s.to]?.status!=="war"))return!1;r.add(l)}i.add(s.id)}return!0}const ep=(n,e)=>n.factions.find(t=>t.id===e),on=(n,e)=>n.systems.find(t=>t.id===e),Ci=(n,e)=>n.fleets.find(t=>t.id===e),mn=(n,e)=>e&&n.relations[e]?.status==="war",qn=n=>Re[n.type].attack>3,fn=(n,e)=>n.fleets.filter(t=>t.owner===e.id),Qo=(n,e={})=>Object.entries(e).every(([t,i])=>n[t]>=i),kd=(n,e)=>!e.owner||e.owner===n.id||mn(n,e.owner)||n.relations[e.owner]?.trade,Zc=(n,e)=>n.exploredBy.includes(e.id);function yn(n,e){return An(n,e)*(.45+.55*e.hp/(Re[e.type].hp*e.ships))}function Yn(n,e,t){return Ft(n,e.id,t).filter(i=>mn(e,i.owner))}function Sr(n,e,t){return Yn(n,e,t).reduce((i,r)=>i+yn(n,r),0)}function la(n,e,t,i=null){return fn(n,e).filter(r=>r.systemId===t&&r.id!==i&&qn(r)).reduce((r,s)=>r+yn(n,s),0)}function el(n,e,t){const i=new Set(Qi(n,e.id).map(a=>a.id)),r=new Map([[t,0]]),s=[t];for(let a=0;a<s.length;a++)for(const o of Rn(n,s[a]))!i.has(o)||r.has(o)||!kd(e,on(n,o))||(r.set(o,r.get(s[a])+1),s.push(o));return r}function Ki(n,e,t,i,{peaceful:r=!1,interventionOwner:s=null}={}){if(t.systemId===i)return{path:[i],cost:0};const a=new Set(Qi(n,e.id).map(u=>u.id));if(!a.has(i))return null;const o=new Map([[t.systemId,0]]),l=new Map,c=new Set([t.systemId]),d=yn(n,t);for(;c.size;){const u=[...c].sort((h,f)=>o.get(h)-o.get(f)||h.localeCompare(f))[0];if(c.delete(u),u===i){const h=[u];for(;l.has(h[0]);)h.unshift(l.get(h[0]));return{path:h,cost:o.get(u)}}for(const h of Rn(n,u)){if(!a.has(h))continue;const f=on(n,h);if(!kd(e,f)&&f.owner!==s)continue;const p=Ft(n,e.id,h).filter(E=>mn(e,E.owner)||E.owner===s),v=p.reduce((E,b)=>E+yn(n,b),0);if(p.length&&(r||!qn(t))||v>0&&d<v*1.18)continue;const m=(mn(e,f.owner)||s&&f.owner===s)&&!tr(n,e.id,h),g=v>0?v/Math.max(1,d)*3:0,x=o.get(u)+1+g+(m?r?8:2.5:0);x>=(o.get(h)??1/0)||(o.set(h,x),l.set(h,u),c.add(h))}}return null}function Zl(n,e,t,i){const r=xp(n,t.id,i.id);if(!r)return!1;const s=yn(n,t);if(r.unknown)return!mn(e,i.owner)||s>=30;const a=Sr(n,e,i.id);return a>0?s>=a*1.18:!r.garrison||s>=r.garrison*.38&&t.hp>=Math.max(18,r.garrison*.5)}function Oo(n,e){const t=new Set(Qi(n,e.id).map(i=>i.id));return n.systems.filter(i=>i.owner===e.id).map(i=>{const r=Sr(n,e,i.id),s=Rn(n,i.id).filter(d=>t.has(d)).map(d=>({systemId:d,power:Sr(n,e,d)})).filter(d=>d.power>0).sort((d,u)=>u.power-d.power),a=s.reduce((d,u)=>d+u.power,0),o=(r+a)*1.18,l=la(n,e,i.id),c=(r||a)&&e.alignment?.active&&e.alignment.sites.includes(i.id)?60:0;return{colony:i,here:r,nearby:a,required:o,stationed:l,sourceId:r>0?i.id:s[0]?.systemId||null,urgency:(r?100+r+i.population*2:a?40+a+Math.max(0,o-l)*.3:0)+c}}).filter(i=>i.urgency>0).sort((i,r)=>r.urgency-i.urgency||i.colony.id.localeCompare(r.colony.id))}function $b(n,e,t,i){const r=n.systems.filter(c=>c.owner===e.id&&Sr(n,e,c.id)===0);if(!r.length)return null;const s=i.find(c=>c.sourceId===t?.id);if(s&&!s.here)return s.colony;const a=t?el(n,e,t.id):new Map,o=r.map(c=>({colony:c,score:t?(a.get(c.id)??100)*12-Math.min(10,dt(n,c).defense/10)-(c.buildings.includes("shipyard")?3:0):c.id===e.capitalId?-100:0})).sort((c,d)=>c.score-d.score||c.colony.id.localeCompare(d.colony.id)),l=o.find(c=>c.colony.id===e.strategy?.rallyId);return l&&l.score<=o[0].score+3?l.colony:o[0].colony}function zb(n,e,t){if(t.length)return on(n,t[0].sourceId);const i=$d(n,e);if(i&&mn(e,i.race.factionId))return i.site;const r=Qi(n,e.id).filter(l=>mn(e,l.owner)||Sr(n,e,l.id)>0);if(!r.length)return null;const s=r.find(l=>l.id===e.strategy?.objectiveId);if(s)return s;const a=n.systems.filter(l=>l.owner===e.id).map(l=>el(n,e,l.id)),o=l=>Math.min(...a.map(c=>c.get(l.id)??100),100);return r.sort((l,c)=>o(l)-o(c)||l.id.localeCompare(c.id))[0]}function tp(n,e,t,i,r){if(!r||!qn(r)||r.movesLeft<1||yn(n,r)<30||Ft(n,e.id,i.id).filter(h=>h.owner===t.factionId).reduce((h,f)=>h+yn(n,f),0)*1.18>yn(n,r))return null;const a=Ki(n,e,r,i.id,{interventionOwner:t.factionId});if(!a)return null;const o=a.path.length-1,l=mn(e,t.factionId)?0:1,c=Math.max(0,Math.min(r.movesLeft,e.orders-l)),d=Math.min(It(n,e.id).maxOrders,Re[r.type].moves+(e.techs.includes("command")?1:0)),u=o?o<=c?1:1+Math.ceil((o-c)/d):0;return u<=t.target-t.progress?{race:t,site:i,fleet:r,travel:a,arrivalCycles:u}:null}function $d(n,e,t=!1){const i=e.alignment?.active?e.alignment.progress:-1,r=[];for(const o of Zn(n,e.id)){if(o.factionId===e.id||o.progress<3||o.progress<=i||!mn(e,o.factionId)&&(!t||!Di(n,e.id,o.factionId).war.enabled))continue;const l=new Set(o.participatingSites);for(const c of o.sites.filter(d=>l.has(d.id))){const d=on(n,c.id);for(const u of fn(n,e)){const h=tp(n,e,o,d,u);h&&r.push(h)}}}const s=e.strategy?.expedition,a=o=>+(o.fleet.id===s?.fleetId&&o.race.factionId===s?.targetId&&o.site.id===s?.systemId);return r.sort((o,l)=>l.race.progress-o.race.progress||a(l)-a(o)||o.travel.cost-l.travel.cost||o.site.id.localeCompare(l.site.id))[0]||null}function Hb(n,e,t,i){let r=!1;for(;!n.winner;){const s=Ci(n,t.fleet.id),a=Zn(n,e.id).find(d=>d.factionId===t.race.factionId),o=e.alignment?.active?e.alignment.progress:-1;if(!s||!a||!mn(e,a.factionId)||a.progress<3||a.progress<=o||!a.participatingSites.includes(t.site.id))return{handled:r,active:!1};if(s.systemId===t.site.id&&!Yn(n,e,s.systemId).length)return{handled:!0,active:!0};if(Yn(n,e,s.systemId).length)return{handled:r,active:!1};if(s.movesLeft<1||e.orders<1)return{handled:!0,active:!0};const l=tp(n,e,a,on(n,t.site.id),s);if(!l)return{handled:r,active:!1};const c=i({type:"move",fleetId:s.id,targetId:l.travel.path[1]});if(!c.ok)return{handled:!0,active:!1};if(r=!0,c.combatOccurred||c.combatReports?.length||!Ci(n,s.id))return{handled:!0,active:!!Ci(n,s.id)}}return{handled:r,active:!1}}function Gb(n,e,t,i){if(!e.alignment?.active)return!1;const r=ys(n,e.id).sites.map(o=>on(n,o));if(!r.length)return!1;const a=r.map(o=>({site:o,travel:Ki(n,e,t,o.id,{peaceful:!0}),stationed:la(n,e,o.id,t.id)})).filter(o=>o.travel).sort((o,l)=>o.stationed-l.stationed||o.travel.cost-l.travel.cost||o.site.id.localeCompare(l.site.id))[0];return a?a.site.id===t.systemId?!0:i({type:"move",fleetId:t.id,targetId:a.travel.path[1]}).ok:!1}function Ah(n,e,t,i=null){for(const r of fn(n,e).filter(s=>qn(s)&&s.id!==i))if(Ci(n,r.id))for(;e.orders>1;){const s=fn(n,e).find(a=>a.id!==r.id&&a.id!==i&&a.type===r.type&&a.systemId===r.systemId&&a.ships+r.ships<=12);if(!s||!t({type:"merge",fleetId:r.id,targetFleetId:s.id}).ok)break}}function np(n,e,t,i){const r=Rn(n,t.systemId).map(s=>on(n,s)).filter(s=>s.knownBy.includes(e.id)&&kd(e,s)&&!Yn(n,e,s.id).length);r.sort((s,a)=>(a.owner===e.id?20:a.owner?-5:5)-(s.owner===e.id?20:s.owner?-5:5)||(s.id===e.strategy?.rallyId?-1:a.id===e.strategy?.rallyId?1:s.id.localeCompare(a.id)));for(const s of r){if(t.movesLeft<1||e.orders<1)break;if(i({type:"move",fleetId:t.id,targetId:s.id}).ok)return!0}return!1}function Vb(n,e,t,i=t,r=null){Ah(n,e,t,r?.fleet.id);const s=new Set;for(const f of fn(n,e).filter(qn)){if(e.orders<1||!Ci(n,f.id))break;const p=on(n,f.systemId),v=Sr(n,e,p.id);v>yn(n,f)/1.18&&v>0?(np(n,e,f,t),s.add(f.id)):p.owner===e.id&&f.hp<Re[f.type].hp*f.ships*.7&&e.minerals>=10&&e.orders>1&&(v>0?t:i)({type:"repair",fleetId:f.id})}const a=Oo(n,e),o=zb(n,e,a),l=$d(n,e),c=$b(n,e,o,a),d=o&&fn(n,e).some(f=>qn(f)&&Zl(n,e,f,o)&&Ki(n,e,f,o.id));if(e.strategy={mode:a.length?"defend":o?d?"advance":"assemble":"develop",rallyId:c?.id||null,objectiveId:o?.id||null,turn:n.turn},r&&!a.length&&!s.has(r.fleet.id)){const f=Hb(n,e,r,t);f.handled&&s.add(r.fleet.id),f.active&&(e.strategy.expedition={fleetId:r.fleet.id,targetId:r.race.factionId,systemId:r.site.id})}const u=c?el(n,e,c.id):new Map,h=fn(n,e).filter(qn).sort((f,p)=>yn(n,p)-yn(n,f)||(u.get(p.systemId)??100)-(u.get(f.systemId)??100));for(const f of h){if(!Ci(n,f.id)||s.has(f.id)||f.movesLeft<1||e.orders<1||n.winner)continue;const p=on(n,f.systemId);if(Yn(n,e,p.id).length||mn(e,p.owner)){Zl(n,e,f,p)&&t({type:"attack",fleetId:f.id});continue}const m=a.find(x=>x.colony.id===p.id);if(!(m&&p.id!==c?.id&&la(n,e,p.id)>=m.required&&la(n,e,p.id,f.id)<m.required)&&!(!a.length&&e.alignment?.active&&!l&&Gb(n,e,f,t))){if(o&&Zl(n,e,f,o)){const x=Ki(n,e,f,o.id);if(x?.path.length>1){t({type:"move",fleetId:f.id,targetId:x.path[1]});continue}}if(c&&f.systemId!==c.id){const x=Ki(n,e,f,c.id,{peaceful:!0});x?.path.length>1&&t({type:"move",fleetId:f.id,targetId:x.path[1]})}}}return Ah(n,e,t,e.strategy.expedition?.fleetId),Oo(n,e)}function tl(n,e){const t=Zn(n,e.id).filter(u=>u.active&&u.progress>0),i=It(n,e.id),r=n.systems.filter(u=>u.owner===e.id),s=["logistics","physics","computing","industry","singularity"],a=Math.max(0,s.reduce((u,h)=>u+(e.techs.includes(h)?0:Tt[h].cost),0)-(s.includes(e.research?.techId)?e.research.progress:0)-e.science),o=r.filter(u=>!u.buildings.includes("beacon")).map(u=>Math.ceil(Ye.beacon.work/dt(n,u).production)).sort((u,h)=>u-h),l=Math.max(0,ot.sites-r.length),c=i.beacons>=ot.sites?0:Math.max(o[Math.min(2-i.beacons,o.length-1)]||0,l?Math.ceil(Ye.beacon.work/6):0),d=Math.ceil(a/Math.max(1,i.scienceIncome))+c+l*6+ot.target;return Math.max(0,Math.min(45,il-n.turn,d,...t.map(u=>u.target-u.progress+6)))}function ip(n,e,t){const i=It(n,e.id),r=Math.max(0,Object.values(Tt).filter(s=>!e.techs.includes(s.id)).reduce((s,a)=>s+a.cost,0)-(e.research?.progress||0)-e.science);return{credits:i.creditIncome<(e.alignment?.active?ot.cost:10)?1.3:.6,minerals:i.mineralIncome<i.colonies*6?1.2:.75,science:(e.research?1.1:.65)*(e.id==="choir"?1.25:1)*Math.min(1,r/Math.max(1,i.scienceIncome*tl(n,e))),production:t==="forge"?1.3:.9}}const mo=(n,e)=>Object.entries(e).reduce((t,[i,r])=>t+(n?.[i]||0)*r,0);function Rh(n,e,t,i,r,s=!1){if(t.owner!==e.id||t.buildings.includes(i))return null;const a=Ye[i],o=ip(n,e,r),l=Fn(n,t).available?[null]:nl(n,e,t,i,r),c=u=>({...Ye[u],science:(Ye[u]?.science||0)+(u==="lab"&&e.techs.includes("computing")?4:0)}),d=a.science&&r==="academy"||a.minerals&&["forge","extraction"].includes(r);return l.map(u=>{const f=(s?_a(n,t.id,e.id,u):vi(n,t.id,e.id,u)).find(g=>s?g.buildingId===i:g.id===i);if(!f)return null;const p=Math.max(0,tl(n,e)-Math.ceil(a.work/Math.max(1,dt(n,t).production))),m=(mo(c(i),o)*(d?1.25:1)-mo(c(u),o))*p-mo(f.cost,o)-a.work*.2;return{option:f,replaceBuildingId:u,value:m}}).filter(Boolean).sort((u,h)=>h.value-u.value||String(u.replaceBuildingId).localeCompare(String(h.replaceBuildingId)))[0]||null}function Wb(n,e,t,i,r){if(tl(n,e)<8)return!1;if(!t.owner){const s=e.techs.includes("terraforming")?0:e.techs.includes("ecology")?30:50;return t.habitability>=s&&fn(n,e).some(a=>a.systemId===t.id&&a.type==="colony")}return t.owner!==e.id?!1:t.buildings.includes(i.support)||t.queue?.itemId===i.support||Fn(n,t).available>0||nl(n,e,t,i.support,r).length>0}function Ch(n,e,t){const i=Jn(n,t.id,e.id);return!i||!pn[i.id].multiStage||!["opening","maturing","ready"].includes(i.phase)?0:i.phase==="opening"?.7:1.4}function Xb(n,e,t){const i=e.techs.includes("terraforming")?0:e.techs.includes("ecology")?30:50;return t.owner||t.habitability<i||tl(n,e)<12?!1:fn(n,e).filter(s=>s.type==="colony").some(s=>{const a=Ki(n,e,s,t.id,{peaceful:!0});return a&&a.path.length<=4})?!0:n.systems.filter(s=>s.owner===e.id&&s.buildings.includes("shipyard")).some(s=>(el(n,e,s.id).get(t.id)??1/0)<=3)}function qb(n,e,t){const i=n.systems.filter(a=>a.owner===e.id),r=Hd(n,e,i),s=new Set(fn(n,e).map(a=>a.systemId));for(const a of n.systems.filter(o=>s.has(o.id)||o.owner===e.id)){if(e.orders<=1||n.winner)break;const o=Jn(n,a.id,e.id);if(!o?.canInteract||Yn(n,e,a.id).length)continue;const l=pn[o.id],c=r.get(a.id);if(o.phase==="resolved"){if(o.site?.state==="planned"){const f=Rh(n,e,a,o.site.id,c);f?.value>0&&f.option.enabled&&pr(n,e,f.option.cost)&&t({type:"build",systemId:a.id,itemId:o.site.id,...f.replaceBuildingId?{replaceBuildingId:f.replaceBuildingId}:{}})}continue}if(o.phase==="maturing"){a.buildings.includes(l.support)||fi(n,e,a,[l.support],t,{role:c,replace:!0});continue}const d=_a(n,a.id,e.id);if(o.phase==="opening"&&l.multiStage&&Wb(n,e,a,l,c)){const f=d.find(p=>p.kind==="preserve");f?.enabled&&pr(n,e,f.cost)&&t({type:"anomaly",systemId:a.id,choiceId:f.id}).ok&&a.owner===e.id&&!a.buildings.includes(l.support)&&fi(n,e,a,[l.support],t,{role:c,replace:!0});continue}if(o.phase==="opening"&&l.multiStage&&Xb(n,e,a))continue;if(o.phase==="ready"){const f=Rh(n,e,a,l.siteId,c,!0),p=d.find(v=>v.kind==="resolve");if(f&&f.value>mo(p?.gain,ip(n,e,c))){f.option.enabled&&pr(n,e,f.option.cost)&&t({type:"anomaly",systemId:a.id,choiceId:f.option.id,...f.replaceBuildingId?{replaceBuildingId:f.replaceBuildingId}:{}});continue}}const u=f=>(f.gain?.minerals||0)*(e.minerals<80?1.4:.65)+(f.gain?.science||0)*(e.research?1.1:.65)+(f.gain?.credits||0)*(e.credits<70?1.3:.35)+(f.ship?60:0)+(f.effectsPreview?.population?.amount||0)*30+(f.habitability&&!a.owner&&a.habitability<50?45:0)+(f.reveal?25:0),h=d.filter(f=>f.kind==="resolve"&&f.enabled&&pr(n,e,f.cost)).sort((f,p)=>u(p)-u(f)||f.id.localeCompare(p.id));h[0]&&t({type:"anomaly",systemId:a.id,choiceId:h[0].id})}}function Yb(n,e,t){const i=e.techs.includes("terraforming")?0:e.techs.includes("ecology")?30:50,r=new Set,s=fn(n,e).filter(a=>!qn(a)).sort((a,o)=>a.type===o.type?a.id.localeCompare(o.id):a.type==="colony"?-1:1);for(const a of s){if(!Ci(n,a.id)||e.orders<1||n.winner)continue;let o=on(n,a.systemId);if(Yn(n,e,o.id).length){np(n,e,a,t);continue}if(a.type==="colony"){if(!o.owner&&o.habitability>=i){t({type:"colonize",fleetId:a.id});continue}if(a.movesLeft<1)continue;const d=Qi(n,e.id).filter(h=>!h.owner&&Zc(h,e)&&h.habitability>=i&&!r.has(h.id)&&!Yn(n,e,h.id).length&&!fn(n,e).some(f=>f.type==="colony"&&f.id!==a.id&&f.systemId===h.id)).map(h=>({target:h,route:Ki(n,e,a,h.id,{peaceful:!0})})).filter(h=>h.route).sort((h,f)=>h.route.cost-Ch(n,e,h.target)-(f.route.cost-Ch(n,e,f.target))||f.target.habitability+f.target.richness*5-(h.target.habitability+h.target.richness*5))[0];if(!d)continue;r.add(d.target.id);const u=t({type:"move",fleetId:a.id,targetId:d.route.path[1]});if(!u.ok||u.outcome==="intercepted"||!Ci(n,a.id))continue;o=on(n,a.systemId),!o.owner&&o.habitability>=i&&e.orders>0&&t({type:"colonize",fleetId:a.id})}else for(let l=0;l<2&&a.movesLeft>0&&e.orders>1;l++){const c=Qi(n,e.id).filter(u=>!Zc(u,e)&&!Yn(n,e,u.id).length).map(u=>Ki(n,e,a,u.id,{peaceful:!0})).filter(Boolean).sort((u,h)=>u.cost-h.cost);if(!c[0]||c[0].path.length<2)break;const d=t({type:"move",fleetId:a.id,targetId:c[0].path[1]});if(!d.ok||d.outcome==="intercepted"||!Ci(n,a.id))break}}}function rp(n,e){const t=n.systems.filter(a=>a.owner===e.id),i=t.filter(a=>a.buildings.includes("beacon")||a.queue?.itemId==="beacon").length,r=e.techs.includes("singularity")&&i<3,s=e.alignment?.active||t.filter(a=>a.buildings.includes("beacon")).length>=3;return{credits:(r?Ye.beacon.cost.credits:0)+(s?ot.cost:0),minerals:r?Ye.beacon.cost.minerals:0}}function zd(n,e){return e.techs.includes("singularity")&&It(n,e.id).beacons>=ot.sites&&It(n,e.id).creditIncome<ot.cost}function pr(n,e,t={}){const i=rp(n,e);return Qo(e,t)&&["credits","minerals"].every(r=>!(t[r]>0)||e[r]-t[r]>=i[r])}function Zb(n,e,t){return t.type==="build"?vi(n,t.systemId,e.id,t.replaceBuildingId).find(i=>i.id===t.itemId)?.cost:t.type==="develop"?_s(n,t.systemId,e.id).find(i=>i.charterType===t.charterType)?.cost:t.type==="colonize"?{credits:30,minerals:20}:t.type==="repair"?{minerals:10}:t.type==="anomaly"?_a(n,t.systemId,e.id,t.replaceBuildingId).find(i=>i.id===t.choiceId)?.cost:t.type==="diplomacy"?{credits:Di(n,e.id,t.targetId).actions[t.stance]?.cost?.credits||0}:{}}const sp=n=>Math.max(0,Object.values(Tt).filter(e=>!n.techs.includes(e.id)).reduce((e,t)=>e+t.cost,0)-(n.research?.progress||0)-n.science);function Kb(n,e){const t=Zn(n,e.id).filter(i=>i.active&&i.progress>0);return Math.max(0,Math.min(24,il-n.turn,...t.map(i=>i.target-i.progress+2)))}function Kc(n,e){if(e.kind==="charter")return{...n,queue:null,charter:{type:e.charterType,level:e.charterLevel||e.level}};const t=e.replaceBuildingId;return{...n,queue:null,buildings:[...n.buildings.filter(i=>i!==t),e.itemId||e.id],charter:t===jt[n.charter?.type]?.support?null:n.charter}}function Jb(n,e,t,i,r,s){const a=n.systems.filter(S=>S.owner===e.id),o=Hd(n,e,a);let l=Math.max(0,e.minerals-s.cost.minerals)+i.mineralIncome*t,c=0,d=0;const u=S=>(S.minerals||0)>l?!1:(l-=S.minerals||0,c+=S.credits||0,!0),h=S=>S.queue?Math.ceil((S.queue.work-S.queue.progress)/dt(n,S).production):0,f=new Map(a.map(S=>[S.id,Math.max(0,(t-h(S))*dt(n,S).production-(S.id===r?s.work:0))])),p=(S,T)=>Math.ceil(t-(f.get(S.id)-T)/dt(n,S).production),v=(S,T)=>f.get(S.id)<=T.work||!u(T.cost)?!1:(f.set(S.id,f.get(S.id)-T.work),!0),m=a.filter(S=>S.buildings.includes("beacon")).map(()=>0);if(e.techs.includes("singularity")){for(const S of a.filter(T=>!T.buildings.includes("beacon")).sort((T,y)=>+(y.queue?.itemId==="beacon")-+(T.queue?.itemId==="beacon")||h(T)-h(y)||T.id.localeCompare(y.id))){if(m.length>=ot.sites)break;const T=S.queue?.itemId==="beacon",y=T?h(S):p(S,Ye.beacon.work);y<t&&(T||v(S,Ye.beacon))&&m.push(y)}m.length>=ot.sites&&(c+=ot.cost*Math.min(ot.target+2,Math.max(0,t-Math.max(...m))))}const g=e.techs.includes("cruisers")?"cruiser":"frigate",x=Re[g],E=a.filter(S=>S.queue?.kind==="ship").reduce((S,T)=>S+An(n,{owner:e.id,type:T.queue.itemId,ships:1}),0),b=(e.id==="khar"?26:12)*a.length+(Object.values(e.relations).some(S=>S.status==="war")?50:0)+(e.alignment?.active?36:0);let w=Math.ceil(Math.max(0,b-i.military-E)/An(n,{owner:e.id,type:g,ships:1}));for(const S of a.filter(T=>T.buildings.includes("shipyard"))){const T=vi(n,S.id,e.id).find(y=>y.id===g).cost;for(let y=1;y<=2&&w>0;y++){const A=p(S,x.work);if(A>=t||!v(S,{work:x.work,cost:T}))break;c+=x.upkeep*(t-A),d+=x.upkeep,w--}}for(const S of a){if(S.id===r)continue;const T=S.queue&&S.queue.kind!=="ship"?Kc(S,S.queue):S,y=o.get(S.id),A=jt[y].support;if(y==="academy"&&sp(e)<=i.scienceIncome*(h(S)+6)||y==="civic"&&ga(n,e.id,1).change===0)continue;const C={...n,systems:n.systems.map(I=>I.id===S.id?{...T,queue:null}:I)},L=T.buildings.includes(A)?_s(C,S.id,e.id).find(I=>I.charterType===y):vi(C,S.id,e.id).find(I=>I.id===A);!L||L.completed||L.work/dt(n,T).production+h(S)>=t||L.kind==="charter"&&(T.population<(L.level===2?8:4)||!e.techs.includes("logistics")||L.level===2&&!e.techs.includes("industry"))||L.kind==="building"&&(L.requires.some(I=>!e.techs.includes(I))||!Fn(n,T).available)||v(S,L)}return{credits:c,incomeFloor:d?d+(e.alignment?.active||i.beacons>=ot.sites?65:4):0}}function jb(n,e,t,i){const r=ep(n,e),s=on(n,t);if(!r||s?.owner!==e||!i||!["building","charter"].includes(i.kind))return{worthwhile:!1,reason:"No owned investment"};const a=It(n,e),o=Kb(n,r),l=Math.ceil(i.work/Math.max(1,dt(n,s).production)),c=sp(r),d={credits:0,minerals:0,science:0,production:0,orders:0},u=n.systems.filter(I=>I.owner===e&&I.queue).map(I=>({system:I,turn:Math.ceil((I.queue.work-I.queue.progress)/dt(n,I).production)}));let h={...n,systems:[...n.systems]},f=c,p=c,v=0,m=a.creditIncome,g=0,x=r.research?Math.max(0,Tt[r.research.techId].cost-r.research.progress-r.science):null;for(let I=1;I<=o;I++){const B=It(h,e);m=B.creditIncome-g,v+=m;let N=0;if(I>l){const U={...h,systems:h.systems.map($=>$.id===t?Kc($,i):$)},V=It(U,e);for(const[$,ie]of[["credits","creditIncome"],["minerals","mineralIncome"],["production","production"]])d[$]+=V[ie]-B[ie];d.orders+=ga(h,e,i.orderEffect?.nominal||0).change,N=V.scienceIncome-B.scienceIncome,d.science+=N>=0?Math.min(N,Math.max(0,f-B.scienceIncome)):-Math.min(-N,p)}f=Math.max(0,f-B.scienceIncome-N),p=Math.max(0,p-B.scienceIncome),x!==null&&(x=Math.max(0,x-B.scienceIncome),x===0&&(h={...h,factions:h.factions.map(U=>U.id===e?{...U,techs:[...U.techs,r.research.techId]}:U)},x=null));for(const U of u.filter(V=>V.turn===I))U.system.queue.kind==="ship"?g+=Re[U.system.queue.itemId].upkeep:h={...h,systems:h.systems.map(V=>V.id===U.system.id?Kc(V,U.system.queue):V)}}const E=Jb(n,r,o,a,t,i),b=E.credits,w=E.incomeFloor>0?Math.max(0,E.incomeFloor-m):0,S=Math.max(0,b+i.cost.credits-r.credits-v,w>0?d.credits:0),T=d.credits<0?S>0?d.credits:0:Math.min(d.credits,S),y=S>0?1:.25,A=a.mineralIncome<a.colonies*6?1.5:1,C=T*y+d.minerals*A+d.science*2+d.production*.5+d.orders*12,L=i.cost.credits*y+i.cost.minerals*A+i.work*.2;return{worthwhile:C>L,horizon:o,completion:l,productiveCycles:Math.max(0,o-l),remainingResearch:c,plannedCredits:b,creditNeed:S,incomeShortfall:w,output:d,benefit:C,price:L}}function ap(n,e,t,i){if(!(i.kind==="charter"?["academy","civic"].includes(i.charterType):["lab","market","forum"].includes(i.id)))return!0;const r=Jn(n,t.id,e.id);return r?.phase==="maturing"&&pn[r.id].support===i.id?!0:jb(n,e.id,t.id,i).worthwhile}function nl(n,e,t,i,r,s=!1,a=!1){const o=new Set(["beacon",jt[t.charter?.type]?.support,jt[r]?.support]),l=Jn(n,t.id,e.id);l?.phase==="maturing"&&o.add(pn[l.id].support);const c=n.systems.filter(p=>p.owner===e.id);t.buildings.includes("shipyard")&&(c.filter(p=>p.buildings.includes("shipyard")).length<=1||r==="forge"||t.id===e.strategy?.rallyId)&&o.add("shipyard");const d=It(n,e.id),u=5+Math.floor(t.habitability/25);a&&t.population>=u-1&&o.add("habitat");const h={mine:d.mineralIncome<c.length*6?90:35,lab:50,market:d.creditIncome<(e.alignment?.active?70:12)?90:25,shipyard:40,factory:55,forum:ga(n,e.id,-1).change<0?45:20,habitat:t.population>=dt(n,t).capacity-1?65:10,bastion:Yn(n,e,t.id).length?100:15},f=p=>h[p]||30;return t.buildings.filter(p=>!o.has(p)&&p!==i).filter(p=>s||(p!=="mine"||d.mineralIncome-5>=Math.max(3,c.length*3))&&(p!=="market"||d.creditIncome-7>=(e.alignment?.active?60:3)||a&&i==="habitat"&&t.population>=u-1)).sort((p,v)=>f(p)-f(v)||p.localeCompare(v))}function fi(n,e,t,i,r,{role:s=null,emergency:a=!1,replace:o=!1,incomeRecovery:l=!1}={}){if(e.orders<1||t.queue||t.owner!==e.id)return!1;for(const c of i){let d=vi(n,t.id,e.id).find(p=>p.id===c),u;const h=l&&["market","forum","habitat"].includes(c)&&zd(n,e),f=p=>a||h||ap(n,e,t,p);if(d?.kind==="building"&&!t.buildings.includes(c)&&!Fn(n,t).available&&o)for(const p of nl(n,e,t,c,s,a,l)){const v=vi(n,t.id,e.id,p).find(m=>m.id===c);if(v?.enabled&&f(v)){d=v,u=p;break}}if(!(!d?.enabled||!a&&!h&&c!=="beacon"&&!pr(n,e,d.cost))&&f(d)&&r({type:"build",systemId:t.id,itemId:c,...u?{replaceBuildingId:u}:{}}).ok)return!0}return!1}function Qb(n,e,t,i){for(const{colony:r,required:s,stationed:a}of t){if(e.orders<2||n.winner)break;if(a>=s)continue;const o=["bastion"];r.buildings.includes("shipyard")||o.push("shipyard"),o.push(e.techs.includes("cruisers")?"cruiser":"frigate"),fi(n,e,r,o,i,{emergency:!0,replace:!0})}}function eS(n,e,t,i,r){if(!Object.entries(e.relations).some(([m,g])=>{const x=ep(n,m);return g.status==="war"&&x&&!x.eliminated}))return;const a=An(n,{owner:e.id,type:"frigate",ships:1})*Math.min(6,2+Math.ceil(t.length/2)),o=()=>t.filter(m=>m.queue?.kind==="ship").map(m=>m.queue.itemId),l=()=>fn(n,e).filter(qn).reduce((m,g)=>m+yn(n,g),0)+o().filter(m=>Re[m].attack>3).reduce((m,g)=>m+An(n,{owner:e.id,type:g,ships:1}),0);if(l()>=a)return;const c=It(n,e.id),d=e.alignment?.active||c.beacons>=ot.sites?ot.cost:0,u=(m,g=Re.frigate.upkeep)=>Qo(e,m)&&e.credits-(m.credits||0)>=d&&c.creditIncome-o().reduce((x,E)=>x+Re[E].upkeep,0)-g>=Math.max(4,d),h=new Set(Oo(n,e).map(m=>m.colony.id)),f=m=>Rn(n,m.id).map(g=>on(n,g)).filter(g=>g.knownBy.includes(e.id)&&mn(e,g.owner)).length,p=t.filter(m=>!h.has(m.id)).sort((m,g)=>f(m)-f(g)||dt(n,g).production-dt(n,m).production||m.id.localeCompare(g.id));if(!t.some(m=>m.buildings.includes("shipyard")||m.queue?.itemId==="shipyard")){for(const m of p.filter(g=>!g.queue)){const g=Fn(n,m).available?[null]:nl(n,e,m,"shipyard",i.get(m.id));for(const x of g){const E=vi(n,m.id,e.id,x).find(b=>b.id==="shipyard");if(!(!E?.enabled||!u(E.cost))&&r({type:"build",systemId:m.id,itemId:"shipyard",...x?{replaceBuildingId:x}:{}}).ok)return}}return}let v=0;for(const m of p.filter(g=>!g.queue&&g.buildings.includes("shipyard"))){if(e.orders<1||n.winner||v>=2||l()>=a)break;const g=vi(n,m.id,e.id).find(x=>x.id==="frigate");!g?.enabled||!u(g.cost)||r({type:"build",systemId:m.id,itemId:"frigate"}).ok&&v++}}function Hd(n,e,t){const i=new Map(t.filter(o=>o.charter).map(o=>[o.id,o.charter.type])),r=()=>t.filter(o=>!i.has(o.id)),s=(o,l)=>{const c=r().sort((d,u)=>l(u)-l(d)||d.id.localeCompare(u.id))[0];c&&i.set(c.id,o)},a=o=>Rn(n,o.id).map(l=>on(n,l)).filter(l=>l.knownBy.includes(e.id)&&l.owner&&l.owner!==e.id).length;t.length>=3&&![...i.values()].includes("forge")&&s("forge",o=>dt(n,o).production+(o.buildings.includes("shipyard")?8:0)+a(o)*3+(o.id===e.strategy?.rallyId?4:0)),r().length&&![...i.values()].includes("extraction")&&s("extraction",o=>o.richness*5-o.science+(o.buildings.includes("mine")?2:0)),r().length&&![...i.values()].includes("academy")&&s("academy",o=>o.science*5-o.richness+(o.buildings.includes("lab")?2:0)),t.length>=4&&r().length&&![...i.values()].includes("civic")&&s("civic",o=>o.population*2+o.habitability/20+(o.buildings.includes("forum")?3:0));for(const o of r()){const l=d=>[...i.values()].filter(u=>u===d).length,c=[["extraction",o.richness*2.4-l("extraction")*3],["academy",o.science*2.8+(e.id==="choir"?3:0)-l("academy")*3],["civic",o.population+(e.id==="veyr"?2:0)-l("civic")*4]].sort((d,u)=>u[1]-d[1]||d[0].localeCompare(u[0]));i.set(o.id,c[0][0])}return i}function tS(n,e,t,i,r){if(!e.techs.includes("singularity"))return;const s=()=>t.filter(l=>l.buildings.includes("beacon")||l.queue?.itemId==="beacon").length,a=l=>{const c=dt(n,l),u=Rn(n,l.id).map(h=>on(n,h)).filter(h=>h.knownBy.includes(e.id)&&mn(e,h.owner)).length;return c.production*5+Math.min(c.defense,90)*.2+la(n,e,l.id)*.1-u*18},o=t.filter(l=>!l.queue&&!l.buildings.includes("beacon")&&Sr(n,e,l.id)===0).sort((l,c)=>a(c)-a(l)||l.id.localeCompare(c.id));for(const l of o){const c={...Ye.beacon.cost,credits:Ye.beacon.cost.credits+(e.alignment?.active?ot.cost:0)};if(s()>=3||e.orders<1||!Qo(e,c))break;fi(n,e,l,["beacon"],r,{role:i.get(l.id),replace:!0})}}function nS(n,e,t,i,r){const s={role:i,replace:!0,incomeRecovery:!0};if(!fi(n,e,t,["market"],r,s)){if(!t.charter||t.charter.type==="civic"){const a=_s(n,t.id,e.id).find(o=>o.charterType==="civic");if(a?.enabled&&Qo(e,a.cost)&&r({type:"develop",systemId:t.id,charterType:"civic"}).ok)return}t.population>=dt(n,t).capacity-1&&!t.buildings.includes("habitat")&&fi(n,e,t,["habitat"],r,s)||fi(n,e,t,["forum"],r,s)}}function iS(n,e,t){const i=n.systems.filter(l=>l.owner===e.id),r=Hd(n,e,i);eS(n,e,i,r,t),tS(n,e,i,r,t);const s=e.techs.includes("terraforming")?0:e.techs.includes("ecology")?30:50,a=Qi(n,e.id).some(l=>!l.owner&&Zc(l,e)&&l.habitability>=s),o=Object.values(e.relations).some(l=>l.status==="war");for(const l of i.filter(c=>!c.queue).sort((c,d)=>dt(n,d).production-dt(n,c).production||c.id.localeCompare(d.id))){if(e.orders<1||n.winner)break;const c=It(n,e.id),d=fn(n,e),u=r.get(l.id),h=jt[u].support;if(zd(n,e)){nS(n,e,l,u,t);continue}const f=d.filter(S=>S.type==="colony").length+i.filter(S=>S.queue?.itemId==="colony").length,p=i.reduce((S,T)=>S+(T.queue?.kind==="ship"&&Re[T.queue.itemId]?.attack||0),0),v=(e.id==="khar"?26:12)*i.length+(o?50:0)+(e.alignment?.active?36:0),m=[],g=e.alignment?.active||c.beacons>=3?65:4,x=e.techs.includes("cruisers")?"cruiser":"frigate",E=c.military+p<v&&c.creditIncome>=Re[x].upkeep+g;if(c.creditIncome<g&&m.push("market"),c.mineralIncome<i.length*4&&(u==="extraction"||!Fn(n,l).used)&&m.push("mine"),u==="forge"&&!l.buildings.includes("shipyard")&&m.push("shipyard"),o&&E&&m.push(x),a&&f<Math.min(2,Math.ceil(i.length/3))&&e.minerals>70&&e.credits>65&&m.push("colony"),!d.some(S=>S.type==="scout")&&!i.some(S=>S.queue?.itemId==="scout")&&m.push("scout"),E&&m.push(x),fi(n,e,l,m,t,{role:u,replace:!0}))continue;if(l.buildings.includes(h)){const S=_s(n,l.id,e.id).find(T=>T.charterType===u);if(S?.enabled&&pr(n,e,S.cost)&&e.credits-S.cost.credits>=Math.max(rp(n,e).credits,S.level===2?100:45)&&c.creditIncome>=0&&c.mineralIncome>=i.length*3&&ap(n,e,l,S)&&t({type:"develop",systemId:l.id,charterType:u}).ok)continue}const b=[h];u==="forge"&&b.push("shipyard"),l.population>=dt(n,l).capacity-1&&b.push("habitat");const w=u==="extraction"?["market","factory"]:u==="academy"?["market","habitat"]:u==="forge"?["mine","bastion"]:["market","lab"];fi(n,e,l,b,t,{role:u,replace:!l.buildings.includes(h)})||fi(n,e,l,w,t,{role:u})}}function rS(n,e,t){if(e.orders<1||n.winner)return;const i=new Map;for(const s of fn(n,e))i.has(s.systemId)||i.set(s.systemId,[]),i.get(s.systemId).push(s);const r=[];for(const[s,a]of i){if(a.length<2||a.some(d=>d.defenseLead&&qn(d)))continue;const o=a.filter(qn).sort((d,u)=>u.hp-d.hp||yn(n,u)-yn(n,d)||d.id.localeCompare(u.id))[0];if(!o||o.id===a[0].id)continue;const c=Yn(n,e,s).length>0||mn(e,on(n,s).owner)?0:a.some(d=>d.type==="colony")?1:2;r.push({fleet:o,systemId:s,priority:c})}r.sort((s,a)=>s.priority-a.priority||s.systemId.localeCompare(a.systemId)||s.fleet.id.localeCompare(a.fleet.id)),r.length&&t({type:"leadDefense",fleetId:r[0].fleet.id})}function sS(n,e){if(!e||e.eliminated||n.winner)return;const t=e.id,i=o=>Bo(n,{...o,factionId:t}),r=o=>pr(n,e,Zb(n,e,o))?i(o):{ok:!1,message:"Resources committed to the ancient network."};if(!e.research){const o=t==="khar"?["weapons","logistics","shields","cruisers","industry","physics","ecology","computing","singularity","diplomacy","command","terraforming"]:t==="choir"?["physics","logistics","computing","industry","singularity","ecology","weapons","diplomacy","shields","command","cruisers","terraforming"]:["logistics","ecology","diplomacy","industry","physics","computing","weapons","singularity","command","shields","cruisers","terraforming"];zd(n,e)&&o.unshift("ecology","logistics","diplomacy","industry");const l=rl(n,t),c=o.find(d=>l.some(u=>u.id===d&&u.enabled));c&&i({type:"research",techId:c})}const s=Oo(n,e).length?null:$d(n,e,!0);s&&!mn(e,s.race.factionId)&&i({type:"diplomacy",targetId:s.race.factionId,stance:"war",reason:`An expedition can reach ${s.site.name} before its public Asterion alignment completes.`});for(const o of Bb(n,t)){if(e.orders<2)break;o.stance==="peace"&&s?.race.factionId===o.targetId||r(o)}const a=Vb(n,e,i,r,s);Qb(n,e,a,i),Yb(n,e,r),qb(n,e,r),iS(n,e,i),rS(n,e,i)}const Jc=50,op=160,Kl=n=>Math.round(n*10)/10;function Gd(n){if(n&&typeof n=="object"){for(const e of Object.values(n))Gd(e);Object.freeze(n)}return n}function jc(n,e){return{role:e,fleetId:n.id,owner:n.owner,name:n.name,type:n.type,shipsBefore:n.ships,hullBefore:n.hp,...e==="defender"&&n.defenseLead===!0?{defenseLead:!0}:{}}}function Qc(n,e){return{...n,shipsAfter:e.ships,hullAfter:e.hp}}function lp(n,e){if(!(e.participants.some(r=>r.owner==="player")||e.invasion?.ownerBefore==="player"))return null;n.combatReports||=[],n.nextCombatReportId||=1;const i=Gd(structuredClone({...e,id:n.nextCombatReportId++,turn:n.turn}));return n.combatReports.unshift(i),n.combatReports.length=Math.min(n.combatReports.length,Jc),i}function cp(n,e){return n.combatReports?.find(t=>t.id===e)||null}function Ih(n,e,t){return n.lastBriefing=Gd({turn:n.turn,entries:n.log.filter(i=>i.id>=e).slice(0,op).map(i=>structuredClone(i)),reportIds:(n.combatReports||[]).filter(i=>i.id>=t).map(i=>i.id)}),n.lastBriefing}function Ph(n){return n.map(e=>e.summary).join(" ")}function aS(n){try{const e=new Set(Object.keys(Ke)),t=new Set(n.systems.map(u=>u.id)),i=u=>Number.isInteger(u)&&u>0,r=u=>typeof u=="string"&&u.length>0&&u.length<2e3,s=u=>Number.isFinite(u)&&u>=0,a=(u,h)=>typeof h=="string"&&Object.hasOwn(u,h),o=u=>i(u)&&u<=n.turn,l=n.combatReports!==void 0||n.nextCombatReportId!==void 0;if(l&&(!Array.isArray(n.combatReports)||n.combatReports.length>Jc||!i(n.nextCombatReportId)))return!1;const c=u=>l&&i(u)&&u<n.nextCombatReportId,d=u=>u&&i(u.id)&&u.id<n.nextLogId&&o(u.turn)&&r(u.type)&&r(u.text)&&(u.systemId===void 0||t.has(u.systemId))&&(u.techId===void 0||a(Tt,u.techId))&&(u.targetId===void 0||e.has(u.targetId))&&(u.publicAffairId===void 0||i(u.publicAffairId)&&u.publicAffairId<n.publicAffairs?.observers?.player?.nextId)&&(u.itemId===void 0||a(Ye,u.itemId)||a(Re,u.itemId))&&(u.reportId===void 0||c(u.reportId));if(!n.log.every(d))return!1;if(l){const u=new Set;for(const h of n.combatReports){if(!h||!c(h.id)||u.has(h.id)||!o(h.turn)||!["fleet","invasion"].includes(h.kind)||!t.has(h.systemId)||!r(h.summary)||!Array.isArray(h.participants)||h.participants.length!==(h.kind==="fleet"?2:1))return!1;u.add(h.id);for(const[p,v]of h.participants.entries())if(!v||v.role!==(p===0?"attacker":"defender")||!/^f[1-9][0-9]*$/.test(v.fleetId)||!e.has(v.owner)||!r(v.name)||!a(Re,v.type)||!i(v.shipsBefore)||v.shipsBefore>12||!Number.isInteger(v.shipsAfter)||v.shipsAfter<0||v.shipsAfter>v.shipsBefore||!Number.isFinite(v.hullBefore)||v.hullBefore<=0||v.hullBefore>v.shipsBefore*Re[v.type].hp||!s(v.hullAfter)||v.hullAfter>v.hullBefore||v.hullAfter>v.shipsAfter*Re[v.type].hp||v.shipsAfter===0!=(v.hullAfter===0)||v.defenseLead!==void 0&&(v.defenseLead!==!0||v.role!=="defender"||Re[v.type].attack<4))return!1;const f=h.participants[0];if(h.kind==="fleet"){const p=h.participants[1],v=f.shipsAfter===0&&p.shipsAfter===0?"mutual-destruction":f.shipsAfter===0?"attacker-destroyed":p.shipsAfter===0?"defender-destroyed":"contested";if(h.invasion!==void 0||f.owner===p.owner||f.fleetId===p.fleetId||h.outcome!==v||!h.participants.some(m=>m.owner==="player"))return!1}else{const p=h.invasion;if(!p||!e.has(p.ownerBefore)||!e.has(p.ownerAfter)||p.ownerBefore===f.owner||typeof p.captured!="boolean"||!["defenseBefore","defenseAfter","damage","damageRoll","retaliation"].every(m=>s(p[m]))||!Number.isInteger(p.damageRoll)||p.defenseAfter>p.defenseBefore||p.damage!==Kl(p.defenseBefore-p.defenseAfter)||p.damage!==Kl(Math.min(p.defenseBefore,p.damageRoll))||p.retaliation!==Kl(f.hullBefore-f.hullAfter)||(p.captured?p.ownerAfter!==f.owner||p.defenseAfter!==0||f.shipsAfter===0:p.ownerAfter!==p.ownerBefore))return!1;const v=p.captured?"captured":f.shipsAfter===0?"repelled":"bombardment";if(h.outcome!==v||f.owner!=="player"&&p.ownerBefore!=="player")return!1}}}if(n.lastBriefing!==void 0&&n.lastBriefing!==null){const u=n.lastBriefing;if(!o(u.turn)||!Array.isArray(u.entries)||u.entries.length>op||!u.entries.every(h=>d(h)&&h.turn<=u.turn)||new Set(u.entries.map(h=>h.id)).size!==u.entries.length||!Array.isArray(u.reportIds)||u.reportIds.length>Jc||!u.reportIds.every(c)||new Set(u.reportIds).size!==u.reportIds.length)return!1}return!0}catch{return!1}}const oS=1e3,Qa=new DataView(new ArrayBuffer(8));function go(n,e){return Qa.setFloat64(0,n),Qa.setBigUint64(0,Qa.getBigUint64(0)+(e?1n:-1n)),Qa.getFloat64(0)}function lS(n,e,t,i){const r=(e-t)*i,s=t*i,a=Math.max(Number.MIN_VALUE,n-r),o=Math.min(go(n,!1),s);if(a>o)return null;const l=Math.max(a,Math.min(o,n*(t/e)));for(const c of[l,go(l,!1),go(l,!0)]){if(c<a||c>o)continue;const d=n-c;if(d>0&&d<=r&&c>0&&c<=s&&d+c===n)return{parent:d,detached:c}}return null}function dp(n,e,t=1,i="player"){const r=n.fleets.find(h=>h.id===e),s=n.factions.find(h=>h.id===i),a=r?.owner===i?r:null,o={enabled:!1,reason:"",orderCost:1,fleetId:e,systemId:a?.systemId??null,parent:null,detached:null,originalHasRoute:!!a?.route,nextFleetNumber:null},l=h=>({...o,reason:h});if(!r||r.owner!==i)return l("Select one of your own fleets.");if(!s||s.eliminated)return l("This empire is no longer active.");if(r.type==="colony")return l("Colony Arks operate independently.");if(r.ships<2)return l("A fleet needs at least two ships to detach a force.");if(!Number.isInteger(t)||t<1||t>=r.ships)return l("Detach a whole number of ships, leaving at least one in the original fleet.");const c=lS(r.hp,r.ships,t,Re[r.type].hp);if(!c)return l("This fleet has too little representable hull to divide into two surviving forces.");if(o.parent={ships:r.ships-t,hp:c.parent,movesLeft:r.movesLeft,hasRoute:!!r.route},o.detached={ships:t,hp:c.detached,movesLeft:r.movesLeft,hasRoute:!1},n.winner)return l("This campaign has ended. Start a new galaxy to continue.");if(s.orders<1)return l("No orders remaining. End the turn to receive a new mandate.");if(n.fleets.length>=oS)return l("The campaign has reached its fleet capacity. Merge a task force before detaching another.");const d=new Set(n.fleets.map(h=>h.id));let u=n.nextFleetId;if(!Number.isSafeInteger(u)||u<1)return l("This save has no available fleet identifier.");for(;u<Number.MAX_SAFE_INTEGER&&d.has(`f${u}`);)u++;return u>=Number.MAX_SAFE_INTEGER?l("This save has no available fleet identifier."):(o.nextFleetNumber=u,{...o,enabled:!0})}function up(n,e){const t=n.systems.find(h=>h.id===e),i=n.factions.find(h=>h.id===t?.owner),r={systemId:e,capacity:0,blocked:!1,totalMissingHull:0,totalRepair:0,fleets:[]};if(!t||!i)return r;const s=(t.buildings.includes("shipyard")?8:4)+Ni(t).repair,a=Ft(n,i.id,e).some(h=>i.relations[h.owner]?.status==="war"),o=n.fleets.filter(h=>h.owner===i.id&&h.systemId===e).sort((h,f)=>h.id<f.id?-1:h.id>f.id?1:0).map(h=>({fleetId:h.id,hp:h.hp,maxHp:h.ships*Re[h.type].hp,missingHull:Math.max(0,h.ships*Re[h.type].hp-h.hp),repair:0,hpAfter:h.hp})),l=o.reduce((h,f)=>h+f.missingHull,0),c={systemId:e,capacity:s,blocked:a,totalMissingHull:l,totalRepair:0,fleets:o};if(a||!l)return c;const d=Math.min(s,l),u=o.filter(h=>h.missingHull>0);for(let h=0;h<u.length;h++){const f=u[h],p=Math.max(0,d-c.totalRepair),v=Math.min(p,h===u.length-1?p:d*(f.missingHull/l));let m=Math.min(f.maxHp,f.hp+v),g=m-f.hp;for(;m>f.hp&&(g>p||c.totalRepair+g>d);)m=Math.max(f.hp,go(m,!1)),g=m-f.hp;f.hpAfter=m,f.repair=g,c.totalRepair+=g}return c}const hp=(n,e)=>n.factions.find(t=>t.id===e),Lh=(n,e)=>e&&n.relations[e]?.status==="war";function Ii(n,e,t="player"){const i=n.fleets.find(o=>o.id===e&&o.owner===t),r=hp(n,t);if(!i||!r)return{held:!1,ready:!1,reason:"Select one of your own fleets.",movesLeft:0};const s=i.hold===!0,a=n.winner?"This campaign has ended.":r.eliminated?"This empire is no longer active.":s?"Holding position until resumed or local events require attention.":i.movesLeft<1?"This fleet has used its movement this cycle.":r.orders<1?"No orders remain this cycle.":"";return{held:s,ready:!a,reason:a,movesLeft:i.movesLeft}}function Vd(n,e="player"){return n.fleets.filter(t=>t.owner===e&&Ii(n,t.id,e).ready)}function fp(n,e){const t=hp(n,e.owner),i=n.systems.find(r=>r.id===e.systemId);return{hostileFleetIds:new Set(Ft(n,e.owner,e.systemId).filter(r=>Lh(t,r.owner)).map(r=>r.id)),hostileOwner:Lh(t,i.owner)?i.owner:null}}function pp(n){return new Map(n.fleets.filter(e=>e.hold===!0).map(e=>[e.id,{systemId:e.systemId,...fp(n,e)}]))}function ed(n,e){for(const t of n.fleets){if(t.hold!==!0||!e.has(t.id))continue;const i=e.get(t.id);if(t.systemId!==i.systemId){delete t.hold;continue}const r=fp(n,t);(r.hostileOwner&&r.hostileOwner!==i.hostileOwner||[...r.hostileFleetIds].some(s=>!i.hostileFleetIds.has(s)))&&delete t.hold}}function cS(n){return n.fleets.every(e=>e.hold===void 0||typeof e.hold=="boolean")}const mp=n=>(Re[n?.type]?.attack||0)>=4,gp=n=>`${n.owner}:${n.systemId}`;function ca(n){const e=[...n],t=new Map;n.forEach((i,r)=>{const s=gp(i);t.has(s)||t.set(s,[]),t.get(s).push(r)});for(const i of t.values()){const r=i.findIndex(o=>n[o].defenseLead===!0);if(r<=0)continue;const s=i.map(o=>n[o]),[a]=s.splice(r,1);s.unshift(a),i.forEach((o,l)=>{e[o]=s[l]})}return e}function vp(n,e,t="player"){const i=n.factions.find(c=>c.id===t),r=n.fleets.find(c=>c.id===e&&c.owner===t);if(!i||!r||!mp(r))return null;const s=r.defenseLead===!0,a=n.fleets.find(c=>c.owner===t&&c.systemId===r.systemId&&c.defenseLead===!0)?.id||null,o=n.winner?"This campaign has ended. Start a new galaxy to continue.":i.eliminated?"This empire is no longer active.":"",l=c=>{const d=o||(i.orders<c?"No orders remaining. End the turn to receive a new mandate.":"");return{enabled:!d,reason:d,orders:c}};return{lead:s,currentLeadId:a,assign:l(s?0:1),clear:l(s?1:0)}}function dS(n){const e=new Set;for(const t of n.fleets){if(t.defenseLead!==void 0&&typeof t.defenseLead!="boolean")return!1;if(t.defenseLead!==!0)continue;const i=gp(t);if(!mp(t)||e.has(i))return!1;e.add(i)}return!0}const yp=1,il=120,En=Object.keys(Ke),_n=n=>Math.round(n*10)/10,We=n=>({ok:!1,message:n}),$t=n=>({ok:!0,message:n}),en=(n,e="player")=>n.factions.find(t=>t.id===e),Nn=(n,e)=>n.systems.find(t=>t.id===e),da=(n,e)=>n.fleets.find(t=>t.id===e),Qt=(n,e)=>n.techs.includes(e),td=(n,e={})=>Object.entries(e).every(([t,i])=>n[t]>=i),eo=(n,e={})=>{for(const[t,i]of Object.entries(e))n[t]-=i};function nd(n){let e=2166136261;for(const t of String(n))e=Math.imul(e^t.charCodeAt(0),16777619);return e>>>0}function Hn(n){return n.rng=Math.imul(n.rng,1664525)+1013904223>>>0,n.rng/4294967296}function xn(n,e,t="info",i=null,r={}){i&&i!=="player"||(n.log.unshift({id:n.nextLogId++,turn:n.turn,type:t,text:e,...r}),n.log.length>160&&(n.log.length=160))}function Rn(n,e){return n.lanes.flatMap(([t,i])=>t===e?[i]:i===e?[t]:[])}function Fo(n,e,t){if(!e||!t||e===t)return;const i=en(n,e),r=en(n,t);i.contacts.includes(t)||(i.contacts.push(t),r.contacts.push(e),[e,t].includes("player")&&xn(n,`First contact: ${e==="player"?r.name:i.name}. A diplomatic channel is open.`,"diplomacy",null,{targetId:e==="player"?t:e}),Zo(n))}function id(n,e,t){const i=Nn(n,e);i.knownBy.includes(t)||i.knownBy.push(t),i.owner&&Fo(n,t,i.owner)}function vo(n,e,t){const i=Nn(n,e);id(n,e,t),i.exploredBy.includes(t)||(i.exploredBy.push(t),i.anomaly&&!i.anomaly.resolved&&xn(n,`${i.name}: ${pn[i.anomaly.id].name} detected. An expedition can investigate.`,"discovery",t,{systemId:e}),t==="player"&&n.turn>1&&xn(n,`Survey complete at ${i.name}: ${mr[i.type].name} world, ${i.habitability}% habitability.`,"survey",null,{systemId:e}));for(const r of Rn(n,e))id(n,r,t);for(const r of Ft(n,t,e))Fo(n,t,r.owner);al(n,e,t)}function Qi(n,e="player"){return n.systems.filter(t=>t.knownBy.includes(e))}function ss(n,e,t,i,r=1){const s=Re[i],a={id:`f${n.nextFleetId++}`,name:`${s.name} ${n.nextFleetId-1}`,owner:e,systemId:t,type:i,ships:r,hp:s.hp*r,movesLeft:s.moves+(Qt(en(n,e),"command")&&s.attack>3?1:0)};return n.fleets.push(a),a}function _p(n="ASTERION"){const e={version:yp,seed:String(n),rng:nd(n),turn:1,nextFleetId:1,nextLogId:1,nextCombatReportId:1,systems:[],lanes:[],factions:[],fleets:[],log:[],combatReports:[],lastBriefing:null,winner:null,victoryType:null};for(const[a,o]of En.entries()){const l=Ke[o];e.factions.push({...l,credits:140,minerals:110,science:0,research:null,techs:[],orders:0,contacts:[],capitalId:`s${a}`,eliminated:!1,relations:Object.fromEntries(En.filter(c=>c!==o).map(c=>[c,{status:"peace",trust:o==="khar"||c==="khar"?-10:10,trade:!1,treatyTurn:0}]))})}const t=Object.keys(mr);for(let a=0;a<Mh.length;a++){const o=a<4;let l,c;if(o){const f=Math.PI*.25+a*Math.PI/2;l=Math.cos(f)*41,c=Math.sin(f)*41}else{const f=(a-4)*2.3999632297+(Hn(e)-.5)*.24,p=7+Math.sqrt((a-3)/38)*43;l=Math.cos(f)*p+(Hn(e)-.5)*3,c=Math.sin(f)*p+(Hn(e)-.5)*3}const d=o?"terran":t[Math.floor(Hn(e)*t.length)],u=o?90:{terran:85,ocean:75,arid:60,ice:40,volcanic:25,barren:15}[d]+Math.floor(Hn(e)*11)-5,h=Object.keys(pn).filter(f=>!pn[f].multiStage);e.systems.push({id:`s${a}`,name:Mh[a],x:_n(l),y:_n(c),type:d,habitability:u,richness:o?3:1+Math.floor(Hn(e)*5),science:o?2:1+Math.floor(Hn(e)*4),owner:o?En[a]:null,originalOwner:o?En[a]:null,population:o?4:0,growth:0,buildings:o?["mine","shipyard"]:[],queue:null,defenseDamage:0,anomaly:!o&&a%4===0?{id:h[Math.floor(Hn(e)*h.length)],resolved:!1}:null,knownBy:[],exploredBy:[]})}const i=new Set(["s0"]),r=(a,o)=>Math.hypot(a.x-o.x,a.y-o.y),s=(a,o)=>{e.lanes.some(([l,c])=>l===a&&c===o||l===o&&c===a)||e.lanes.push([a,o])};for(;i.size<e.systems.length;){let a=null;for(const o of e.systems.filter(l=>i.has(l.id)))for(const l of e.systems.filter(c=>!i.has(c.id))){const c=r(o,l);(!a||c<a.distance)&&(a={a:o,b:l,distance:c})}s(a.a.id,a.b.id),i.add(a.b.id)}for(const a of e.systems){const o=[...e.systems].filter(l=>l!==a).sort((l,c)=>r(a,l)-r(a,c));for(const l of o.slice(0,2))s(a.id,l.id)}gS(e);for(const a of e.factions){const o=Rn(e,a.capitalId).map(l=>Nn(e,l)).find(l=>!l.owner);o&&(o.type="terran",o.habitability=Math.max(75,o.habitability)),ss(e,a.id,a.capitalId,"scout"),ss(e,a.id,a.capitalId,"colony"),ss(e,a.id,a.capitalId,"frigate"),vo(e,a.capitalId,a.id),a.orders=It(e,a.id).maxOrders}return xn(e,"The gates have been silent for centuries. Today, the Concord returns to the stars.","story"),xn(e,"First mandate: send your Pathfinder through a starlane, then bring a Colony Ark to a habitable world.","objective"),e}function dt(n,e){const t=en(n,e.owner);if(!t)return{credits:0,minerals:0,science:0,production:0,growth:0,capacity:0,defense:0};const i=e.buildings.map(a=>Ye[a]),r=a=>i.reduce((o,l)=>o+(l[a]||0),0),s=Ni(e);return{credits:3+e.population*2+r("credits")+s.credits,minerals:e.richness+Math.floor(e.population/3)+r("minerals")+s.minerals,science:e.science+Math.floor(e.population/2)+r("science")+(Qt(t,"physics")?2:0)+(Qt(t,"computing")&&e.buildings.includes("lab")?4:0)+s.science,production:4+e.population+r("production")+s.production,growth:Math.max(.08,e.habitability/240)*(e.buildings.includes("habitat")?1.4:1)*(Qt(t,"terraforming")?1.5:1),capacity:5+Math.floor(e.habitability/25)+(e.buildings.includes("habitat")?4:0),defense:Math.max(0,12+e.population*3+r("defense")+(e.originalOwner?15:0)-e.defenseDamage)}}function It(n,e="player"){const t=en(n,e),i=n.systems.filter(v=>v.owner===e),r=n.fleets.filter(v=>v.owner===e),s=i.map(v=>dt(n,v)),a=v=>s.reduce((m,g)=>m+g[v],0),o=r.reduce((v,m)=>v+Re[m.type].upkeep*m.ships,0),l=Object.values(t.relations).filter(v=>v.trade).length*(Qt(t,"diplomacy")?10:6),c=Math.floor(a("credits")*(e==="veyr"?1.25:1))+l-o,d=Hf(n,e),u=d.total,h=i.reduce((v,m)=>v+m.population,0),f=r.reduce((v,m)=>v+An(n,m),0),p=i.filter(v=>v.buildings.includes("beacon")).length;return{credits:t.credits,minerals:t.minerals,science:t.science,creditIncome:c,mineralIncome:a("minerals"),scienceIncome:Math.floor(a("science")*(e==="choir"?1.25:1)),production:a("production"),upkeep:o,colonies:i.length,population:h,ships:r.reduce((v,m)=>v+m.ships,0),military:_n(f),orders:t.orders,maxOrders:u,uncappedOrders:d.uncapped,orderLimit:d.limit,score:i.length*20+h*2+t.techs.length*12+p*80+Math.floor(f/4),beacons:p,explored:n.systems.filter(v=>v.exploredBy.includes(e)).length}}function rl(n,e="player"){const t=en(n,e);return Object.values(Tt).map(i=>{const r=i.requires.filter(l=>!Qt(t,l)),s=Qt(t,i.id),a=t.research?.techId===i.id,o=s?"Already discovered":r.length?`Requires ${r.map(l=>Tt[l].name).join(" and ")}`:a?"Research in progress":"";return{...i,completed:s,active:a,enabled:!o,reason:o}})}function vi(n,e,t="player",i=null){const r=Nn(n,e),s=en(n,t);return[...Object.values(Ye).map(a=>({...a,kind:"building"})),...Object.values(Re).map(a=>({...a,kind:"ship"}))].map(a=>{const o=Cb(r,a,a.kind);let l="";!r||r.owner!==t?l="Requires an owned colony":r.queue?l="Construction already in progress":a.kind==="building"&&r.buildings.includes(a.id)?l="Already built":i!==null&&(a.kind!=="building"||!r.buildings.includes(i)||i===a.id)?l="Choose an existing building to replace with new infrastructure":a.kind==="building"&&Fn(n,r).available===0&&i===null?l="Infrastructure slots are full. Choose a building to replace":a.requires.some(u=>!Qt(s,u))?l=`Requires ${a.requires.filter(u=>!Qt(s,u)).map(u=>Tt[u].name).join(" and ")}`:a.kind==="ship"&&!r.buildings.includes("shipyard")?l="Requires an Orbital Shipyard":ad(n,r,a.id,t)?l=ad(n,r,a.id,t):td(s,o)?s.orders<1&&(l="No orders remaining"):l="Insufficient credits or minerals";const c=i&&r?.charter&&jt[r.charter.type].support===i,d=a.kind==="building"?(a.orders||0)-(Ye[i]?.orders||0)-(c?Ni(r).orders:0):0;return{...a,cost:o,replaceBuildingId:a.kind==="building"?i:null,orderEffect:ga(n,t,d),enabled:!l,reason:l,turns:r?.owner?Math.ceil(a.work/dt(n,r).production):0}})}function uS(n,e="player"){const t=en(n,e),i=It(n,e),r=ys(n,e);return{transcendence:{current:i.beacons,target:3,unlocked:Qt(t,"singularity"),alignment:r.progress,alignmentTarget:r.target,cost:r.cost,ready:r.ready,reason:r.reason,sites:r.sites},domination:{current:n.systems.filter(s=>s.originalOwner&&s.owner===e).length,target:4},legacy:{score:i.score,turn:n.turn,finalTurn:il}}}function An(n,e){const t=en(n,e.owner);return Re[e.type].attack*e.ships*(Qt(t,"weapons")?1.25:1)*(e.owner==="khar"?1.15:1)}function xp(n,e,t){const i=da(n,e),r=Nn(n,t);if(!i||!r)return null;const s=An(n,i);if(!tr(n,i.owner,t))return{attack:_n(s),defense:null,garrison:null,odds:"Unscouted",unknown:!0};const o=Ft(n,i.owner,t).filter(c=>ci(n,i.owner,c.owner)).reduce((c,d)=>c+An(n,d),0),l=r.owner&&ci(n,i.owner,r.owner)?dt(n,r).defense:0;return{attack:_n(s),defense:_n(o),garrison:l,odds:s>o*1.5+l*.45?"Favorable":s>o*.8+l*.25?"Contested":"Dangerous",unknown:!1}}function hS(n,e){const t=da(n,e);if(!t||Re[t.type].attack<4||!tr(n,t.owner,t.systemId))return null;const i=Nn(n,t.systemId);if(!i?.owner||!ci(n,t.owner,i.owner)||Ft(n,t.owner,i.id).some(u=>ci(n,t.owner,u.owner)))return null;const r=dt(n,i).defense,s=An(n,t),a=Math.round(s*.9),o=Math.round(s*(.9+4294967295/4294967296*.2)),l=Qt(en(n,t.owner),"shields"),c=Math.max(0,_n(t.hp-Math.max(4,r*.28)*(l?.8:1))),d=_n(t.hp-c);return{systemId:i.id,defense:r,damageMin:a,damageMax:o,retaliation:d,shielded:l,capturePossible:c>0&&o>=r,captureGuaranteed:c>0&&a>=r}}function ci(n,e,t){return e!==t&&en(n,e).relations[t]?.status==="war"}function rd(n,e,t){if(t===0)return;const i=Qt(en(n,e.owner),"shields")?.8:1;e.hp=Math.max(0,_n(e.hp-t*i)),e.ships=Math.ceil(e.hp/Re[e.type].hp),e.ships||(n.fleets=n.fleets.filter(r=>r.id!==e.id))}function fS(n,e){e.ships--,e.ships<=0?n.fleets=n.fleets.filter(t=>t.id!==e.id):e.hp=Math.min(e.hp,e.ships*Re[e.type].hp)}function Nh(n,e,t){delete e.hold,delete t.hold;const i=jc(e,"attacker"),r=jc(t,"defender");for(let s=0;s<4&&e.hp>0&&t.hp>0;s++){const a=An(n,e)*(.85+Hn(n)*.3),o=An(n,t)*(.85+Hn(n)*.3);if(rd(n,e,o),rd(n,t,a),a===0&&o===0)break}if(e.owner==="player"||t.owner==="player"){const s=[Qc(i,e),Qc(r,t)],a=e.hp<=0&&t.hp<=0?"mutual-destruction":e.hp<=0?"attacker-destroyed":t.hp<=0?"defender-destroyed":"contested",o=s.map(u=>`${Ke[u.owner].shortName} lost ${u.shipsBefore-u.shipsAfter} ship${u.shipsBefore-u.shipsAfter===1?"":"s"} and ${_n(u.hullBefore-u.hullAfter)} hull`).join("; "),l=a==="mutual-destruction"?"Both fleets destroyed.":a==="attacker-destroyed"?"Attacking fleet destroyed.":a==="defender-destroyed"?"Attacking fleet survives; defending fleet destroyed.":"Both fleets survive in orbit.",c=`Battle at ${Nn(n,e.systemId).name}: ${o}. ${l}`,d=lp(n,{kind:"fleet",systemId:e.systemId,participants:s,outcome:a,summary:c});return xn(n,c,"combat",null,{systemId:e.systemId,reportId:d.id}),d}return null}function sd(n,e){if(!e.research)return;const t=Tt[e.research.techId],i=Math.min(e.science,t.cost-e.research.progress);e.science-=i,e.research.progress+=i,e.research.progress>=t.cost&&(e.techs.push(t.id),e.research=null,xn(n,`Research complete: ${t.name}. ${t.description}`,"research",e.id,{techId:t.id}))}function pS(n,e,t){return!t.owner||t.owner===e||ci(n,e,t.owner)||en(n,e).relations[t.owner].trade}function Bo(n,e){if(!e||typeof e.type!="string")return We("Invalid command.");if(n.winner)return We("This campaign has ended. Start a new galaxy to continue.");const t=e.factionId||"player",i=en(n,t);if(!i||i.eliminated)return We("This empire is no longer active.");if(e.type==="endTurn")return t==="player"?Sp(n):We("Only the player can advance the turn.");if(!["research","cancelBuild","planRoute","clearRoute","continueRoute","hold","resume","leadDefense","clearDefenseLead"].includes(e.type)&&i.orders<1)return We("No orders remaining. End the turn to receive a new mandate.");const s=e.fleetId?da(n,e.fleetId):null,a=e.systemId?Nn(n,e.systemId):s?Nn(n,s.systemId):null;if(e.fleetId&&(!s||s.owner!==t))return We("Select one of your own fleets.");if(e.systemId&&!a)return We("Unknown system.");if(e.type==="leadDefense"||e.type==="clearDefenseLead"){const c=vp(n,e.fleetId,t);if(!c)return We("Select one of your military fleets.");const d=e.type==="leadDefense",u=d?c.assign:c.clear;if(!u.enabled)return We(u.reason);if(!u.orders)return $t(d?"This formation already leads its local defense.":"This formation has no defensive lead assignment.");if(d){for(const h of n.fleets)h.owner===t&&h.systemId===s.systemId&&h.defenseLead===!0&&delete h.defenseLead;s.defenseLead=!0}else delete s.defenseLead;return i.orders-=u.orders,$t(d?`${s.name} will lead its local defense.`:`${s.name} returns to the ordinary defensive order.`)}if(e.type==="hold"||e.type==="resume")return s?(e.type==="hold"?s.hold=!0:delete s.hold,$t(e.type==="hold"?`${s.name} is holding position.`:`${s.name} awaits orders.`)):We("Select a fleet first.");const o=pp(n);let l;switch(e.type){case"planRoute":{if(!s)return We("Select a fleet first.");const c=Zd(n,s.id,e.destinationId);if(!c.ok)return We(c.reason);c.jumps?s.route={destinationId:c.destinationId,path:[...c.path]}:delete s.route,l=$t(c.jumps?`Route plotted: ${c.jumps} jump${c.jumps===1?"":"s"} to ${Nn(n,c.destinationId).name}. Continue when ready.`:"The fleet is already at this destination. Route cleared.");break}case"clearRoute":{if(!s)return We("Select a fleet first.");delete s.route,l=$t("Route cleared.");break}case"continueRoute":{if(!s)return We("Select a fleet first.");if(l=AS(n,s.id,c=>Bo(n,c)),!l.ok)return l;break}case"move":{if(!s)return We("Select a fleet first.");const c=Nn(n,e.targetId);if(!c||!Rn(n,s.systemId).includes(c.id))return We("Fleets must follow a connected starlane, one jump at a time.");if(!c.knownBy.includes(t))return We("That starlane has not been charted.");if(s.movesLeft<1)return We("This fleet has used all its movement this turn.");if(!pS(n,t,c))return We("Borders are closed. Sign a trade treaty or declare war to enter.");const d=ca(n.fleets.filter(f=>f.systemId===c.id&&ci(n,t,f.owner)));if(d.length&&Re[s.type].attack<4){if(tr(n,t,c.id))return We("Civilian vessels cannot enter hostile fleet positions.");s.movesLeft--,i.orders--;for(const v of d)Fo(n,t,v.owner);const f=d.reduce((v,m)=>v+m.ships,0),p=`${s.name} encountered ${f} hostile ship${f===1?"":"s"} at ${c.name} and withdrew to ${Nn(n,s.systemId).name}. One order and one jump were spent; no survey was conducted.`;xn(n,p,"interception",t,{systemId:c.id}),l={...$t(p),outcome:"intercepted"};break}al(n,s.systemId,t);const u=s.systemId;s.systemId=c.id,s.movesLeft--,i.orders--,delete s.defenseLead,ES(s,u,c.id),vo(n,c.id,t);const h=[];for(const f of d)if(s.hp>0){const p=Nh(n,s,f);p&&h.push(p)}l=h.length?{...$t(Ph(h)),combatReports:h}:$t(`${s.name} ${s.hp>0?`arrived at ${c.name}.`:"was lost in battle."}`),d.length&&(l.combatOccurred=!0);break}case"colonize":{if(!s||s.type!=="colony")return We("A Colony Ark is required.");if(a.owner)return We("This world already belongs to an empire.");const c=Qt(i,"terraforming")?0:Qt(i,"ecology")?30:50;if(a.habitability<c)return We(`Habitability must be at least ${c}%. Research Adaptive Biospheres or Worldshaping.`);if(Ft(n,t,a.id).some(d=>ci(n,t,d.owner)))return We("Clear hostile fleets before founding a colony.");if(!td(i,{credits:30,minerals:20}))return We("Founding a colony costs 30 credits and 20 minerals.");eo(i,{credits:30,minerals:20}),i.orders--,a.owner=t,a.population=1,a.growth=0,a.defenseDamage=0,n.fleets=n.fleets.filter(d=>d.id!==s.id),vo(n,a.id,t),xn(n,`A new beginning: ${a.name} joins ${Ke[t].shortName}.`,"colony",t,{systemId:a.id}),l=$t(`Colony founded at ${a.name}.`);break}case"build":{if(!a)return We("Select a colony.");const c=vi(n,a.id,t,e.replaceBuildingId??null).find(d=>d.id===e.itemId);if(!c)return We("Unknown construction project.");if(!c.enabled)return We(c.reason);eo(i,c.cost),i.orders--,a.queue={itemId:c.id,kind:c.kind,progress:0,work:c.work,cost:{...c.cost}},c.replaceBuildingId&&(a.queue.replaceBuildingId=c.replaceBuildingId),xS(n,a.id,t,c.id),l=$t(`${c.name} commissioned at ${a.name}.`);break}case"develop":{if(!a)return We("Select a colony.");const c=_s(n,a.id,t).find(d=>d.charterType===e.charterType);if(!c)return We("Unknown colonial charter.");if(!c.enabled)return We(c.reason);eo(i,c.cost),i.orders--,a.queue={itemId:c.charterType,kind:"charter",charterType:c.charterType,charterLevel:c.level,progress:0,work:c.work,cost:{...c.cost}},l=$t(`${c.name} commissioned at ${a.name}.`);break}case"cancelBuild":{if(!a||a.owner!==t||!a.queue)return We("No owned construction project to cancel.");const c=1-a.queue.progress/a.queue.work;for(const[d,u]of Object.entries(a.queue.cost))i[d]+=Math.floor(u*c);a.queue=null,l=$t("Project cancelled. Unspent materials returned.");break}case"research":{const c=rl(n,t).find(d=>d.id===e.techId);if(!c||!c.enabled)return We(c?.reason||"Unknown technology.");i.research&&(i.science+=i.research.progress),i.research={techId:c.id,progress:0},sd(n,i),l=$t(`Research directed toward ${c.name}.`);break}case"anomaly":{if(l=bS(n,{...e,factionId:t,systemId:a?.id},{makeFleet:(c,d,u)=>ss(n,c,d,u),chart:(c,d)=>id(n,c,d),applyResearch:c=>sd(n,c),build:c=>Bo(n,c)}),!l.ok)return l;break}case"diplomacy":{if(l=Ob(n,{...e,factionId:t}),!l.ok)return l;break}case"attack":{if(!s||Re[s.type].attack<4)return We("A military fleet is required.");if(s.movesLeft<1)return We("This fleet has used all its movement this turn.");const c=ca(Ft(n,t,s.systemId).filter(w=>ci(n,t,w.owner)));if(!c.length&&(!a.owner||!ci(n,t,a.owner)))return We("No hostile target in this system.");if(i.orders--,s.movesLeft--,c.length){const w=[];for(const S of c)if(s.hp>0){const T=Nh(n,s,S);T&&w.push(T)}l={...$t(w.length?Ph(w):"Fleet engagement resolved."),combatReports:w};break}const d=jc(s,"attacker"),u=a.owner,h=dt(n,a).defense,f=An(n,s)*(.9+Hn(n)*.2);a.defenseDamage+=Math.round(f),rd(n,s,Math.max(4,h*.28));const p=dt(n,a).defense,v=p<=0&&s.hp>0;if(v){const w=[...a.knownBy];a.owner=t,a.population=Math.max(1,a.population-1),a.defenseDamage=0,a.queue=null;for(const S of w)Fo(n,S,t);vo(n,a.id,t),Nb(n,{systemId:a.id,fromId:u,toId:t,observerIds:w})}const m=Qc(d,s),g={ownerBefore:u,ownerAfter:a.owner,defenseBefore:h,defenseAfter:p,damage:_n(h-p),damageRoll:Math.round(f),retaliation:_n(d.hullBefore-s.hp),captured:v},x=v?"captured":s.hp<=0?"repelled":"bombardment",E=`Invasion of ${a.name}: ${g.damage} defense damage; ${p} defenses remain. ${Ke[t].shortName} lost ${d.shipsBefore-s.ships} ship${d.shipsBefore-s.ships===1?"":"s"} and ${g.retaliation} hull to retaliation. ${v?`${a.name} captured; invading fleet survives.`:s.hp<=0?"Invading fleet destroyed; colony holds.":"Invading fleet survives; colony holds."}`,b=lp(n,{kind:"invasion",systemId:a.id,participants:[m],outcome:x,summary:E,invasion:g});b&&xn(n,E,"combat",null,{systemId:a.id,reportId:b.id}),l={...$t(E),combatReports:b?[b]:[]};break}case"split":{if(!Number.isInteger(e.ships))return We("Detach a whole number of ships, leaving at least one in the original fleet.");const c=dp(n,e.fleetId,e.ships,t);if(!c.enabled)return We(c.reason);n.nextFleetId=c.nextFleetNumber;const d=ss(n,t,s.systemId,s.type,c.detached.ships);d.hp=c.detached.hp,d.movesLeft=c.detached.movesLeft,s.heritage!==void 0&&(s.heritage=structuredClone(s.heritage),d.heritage=structuredClone(s.heritage)),s.ships=c.parent.ships,s.hp=c.parent.hp,i.orders--,l={...$t(`${d.ships} ship${d.ships===1?"":"s"} detached as ${d.name}.`),newFleetId:d.id};break}case"merge":{const c=da(n,e.targetFleetId);if(!s||!c||c.id===s.id||c.owner!==t||c.type!==s.type||c.systemId!==s.systemId)return We("Select two of your same-type fleets in the same system.");if(s.type==="colony")return We("Colony Arks operate independently.");if(s.ships+c.ships>12)return We("A task force can contain at most 12 ships.");SS(s,c),c.defenseLead===!0&&(s.defenseLead=!0),s.ships+=c.ships,s.hp+=c.hp,s.movesLeft=Math.min(s.movesLeft,c.movesLeft),n.fleets=n.fleets.filter(d=>d.id!==c.id),i.orders--,l=$t("Fleets combined into one task force.");break}case"repair":{if(!s||a.owner!==t)return We("Repair at a friendly colony.");if(s.hp>=s.ships*Re[s.type].hp)return We("This fleet is already fully repaired.");if(!td(i,{minerals:10}))return We("Emergency repairs cost 10 minerals.");eo(i,{minerals:10}),i.orders--,s.hp=Math.min(s.ships*Re[s.type].hp,s.hp+24),l=$t("Emergency repairs completed.");break}default:return We("Unknown command.")}return s&&(["move","attack","continueRoute"].includes(e.type)||e.type==="planRoute"&&s.route)&&delete s.hold,Np(n),Ap(n),bp(n),ed(n,o),l}function bp(n){if(n.winner)return;const e=[],t=(i,r)=>It(n,r.id).score-It(n,i.id).score||nd(`${n.seed}:victory:${n.turn}:${r.id}`)-nd(`${n.seed}:victory:${n.turn}:${i.id}`)||i.id.localeCompare(r.id);for(const i of n.factions){const r=n.systems.filter(c=>c.owner===i.id),s=n.fleets.some(c=>c.owner===i.id&&c.type==="colony");if(!r.length&&!s&&!i.eliminated){i.eliminated=!0,n.fleets=n.fleets.filter(c=>c.owner!==i.id);for(const c of n.factions.filter(d=>d.id!==i.id))c.relations[i.id].trade=!1,c.relations[i.id].tradeEndsAt=0,i.relations[c.id].trade=!1,i.relations[c.id].tradeEndsAt=0;(i.id==="player"||en(n,"player").contacts.includes(i.id))&&xn(n,`${i.name} has collapsed.`,"war",null,{targetId:i.id})}r.length&&!r.some(c=>c.id===i.capitalId)&&(i.capitalId=r[0].id);const a=r.filter(c=>c.buildings.includes("beacon")).length,o=r.filter(c=>c.originalOwner).length,l=Qt(i,"singularity")&&a>=3&&(i.alignment?.progress||0)>=10;(l||o===4)&&e.push({faction:i,victoryType:l?"Transcendence":"Domination"})}if(Bd(n),e.length&&(e.sort((i,r)=>t(i.faction,r.faction)),n.winner=e[0].faction.id,n.victoryType=e[0].victoryType),!n.winner&&n.turn>=il){const i=n.factions.filter(r=>!r.eliminated).sort(t);i.length&&(n.winner=i[0].id,n.victoryType="Legacy")}en(n,"player").eliminated&&!n.winner&&(n.winner=[...n.factions].filter(i=>!i.eliminated).sort(t)[0]?.id||"none",n.victoryType="Concord defeated"),n.winner&&xn(n,`${Ke[n.winner]?.name||"The galaxy"} achieves ${n.victoryType.toLowerCase()}. The chronicle of this age is complete.`,"victory")}function Sp(n){if(n.winner)return We("This campaign has ended.");const e=pp(n),t=n.nextLogId,i=n.nextCombatReportId||1;for(const r of n.factions.filter(s=>s.id!=="player"))sS(n,r);if(n.winner)return ed(n,e),Ih(n,t,i),$t("Campaign concluded.");n.turn++,Fb(n),Np(n);for(const r of n.factions.filter(s=>!s.eliminated)){const s=It(n,r.id);if(r.credits=Math.max(0,r.credits+s.creditIncome),r.minerals+=s.mineralIncome,r.science+=s.scienceIncome,s.creditIncome<0&&r.credits===0){const a=n.fleets.filter(o=>o.owner===r.id).sort((o,l)=>Re[l.type].upkeep-Re[o.type].upkeep)[0];a&&(fS(n,a),xn(n,"Treasury exhausted: one ship was decommissioned to pay its crew. Build Exchange Ports or reduce fleet upkeep.","warning",r.id))}sd(n,r)}for(const r of n.systems.filter(s=>s.owner)){const s=dt(n,r);if(r.population<s.capacity?(r.growth=_n(r.growth+s.growth),r.growth>=1&&(r.population++,r.growth=_n(r.growth-1))):r.growth=0,r.queue&&(r.queue.progress+=s.production,r.queue.progress>=r.queue.work)){const a=Ko(r.queue);r.queue.kind==="ship"?ss(n,r.owner,r.id,a.id):r.queue.kind==="charter"?r.charter={type:r.queue.charterType,level:r.queue.charterLevel}:(r.queue.replaceBuildingId&&(r.buildings=r.buildings.filter(o=>o!==r.queue.replaceBuildingId),r.charter&&jt[r.charter.type].support===r.queue.replaceBuildingId&&delete r.charter),r.buildings.push(a.id)),xn(n,`${r.name} completed ${a.name}.`,"construction",r.owner,{systemId:r.id,...r.queue.kind==="charter"?{}:{itemId:a.id}}),r.queue=null}Ft(n,r.owner,r.id).some(a=>ci(n,r.owner,a.owner))||(r.defenseDamage=Math.max(0,r.defenseDamage-5))}MS(n);for(const r of n.fleets){const s=en(n,r.owner);r.movesLeft=Re[r.type].moves+(Qt(s,"command")&&Re[r.type].attack>3?1:0)}for(const r of n.systems.filter(s=>s.owner))for(const s of up(n,r.id).fleets)da(n,s.fleetId).hp=s.hpAfter;for(const r of n.factions)r.orders=r.eliminated?0:It(n,r.id).maxOrders;return Mb(n),bp(n),ed(n,e),Ih(n,t,i),$t(`Turn ${n.turn}: a new mandate begins.`)}function Mp(n){try{return mS(n)}catch{return!1}}function mS(n){if(!n||n.version!==yp||!Number.isInteger(n.turn)||n.turn<1||!Array.isArray(n.systems)||n.systems.length!==42||!Array.isArray(n.factions)||n.factions.length!==4||!Array.isArray(n.fleets)||!Array.isArray(n.lanes)||!Array.isArray(n.log))return!1;const e=r=>typeof r=="string"&&r.length<2e3,t=(r,s)=>typeof s=="string"&&Object.hasOwn(r,s);if(!e(n.seed)||n.fleets.length>1e3||n.log.length>160)return!1;const i=new Set(n.systems.map(r=>r.id));if(i.size!==42||[...i].some(r=>!/^s([0-9]|[1-3][0-9]|4[01])$/.test(r))||En.some(r=>!n.factions.some(s=>s.id===r))||!Number.isInteger(n.rng)||n.rng<0||n.rng>4294967295||!Number.isInteger(n.nextFleetId)||n.nextFleetId<1||!Number.isInteger(n.nextLogId)||n.nextLogId<1||n.winner!==null&&!En.includes(n.winner))return!1;for(const r of n.factions){if(!e(r.name)||!e(r.color)||!/^#[0-9a-f]{6}$/i.test(r.color)||typeof r.eliminated!="boolean"||!["credits","minerals","science","orders"].every(s=>Number.isFinite(r[s])&&r[s]>=0)||!Array.isArray(r.techs)||r.techs.some(s=>!t(Tt,s))||new Set(r.techs).size!==r.techs.length||!Array.isArray(r.contacts)||r.contacts.some(s=>!En.includes(s))||!i.has(r.capitalId)||!r.relations||r.research&&(!t(Tt,r.research.techId)||r.techs.includes(r.research.techId)||!Number.isFinite(r.research.progress)||r.research.progress<0||r.research.progress>=Tt[r.research.techId].cost)||r.strategy!==void 0&&(!r.strategy||!["defend","assemble","advance","develop"].includes(r.strategy.mode)||r.strategy.rallyId!==null&&!i.has(r.strategy.rallyId)||r.strategy.objectiveId!==null&&!i.has(r.strategy.objectiveId)||!Number.isInteger(r.strategy.turn)||r.strategy.turn<1||r.strategy.turn>n.turn))return!1;if(r.strategy?.expedition!==void 0){const s=r.strategy.expedition;if(!s||typeof s!="object"||Array.isArray(s)||Object.keys(s).some(l=>!["fleetId","targetId","systemId"].includes(l))||typeof s.fleetId!="string"||s.fleetId.length>32||!/^f[1-9][0-9]*$/.test(s.fleetId)||!En.includes(s.targetId)||s.targetId===r.id||!i.has(s.systemId)||!n.systems.find(l=>l.id===s.systemId).knownBy?.includes(r.id))return!1;const a=n.fleets.find(l=>l.id===s.fleetId),o=Number(s.fleetId.slice(1));if(a?a.owner!==r.id:!Number.isSafeInteger(o)||o>=n.nextFleetId)return!1}for(const s of En.filter(a=>a!==r.id)){const a=r.relations[s];if(!a||!["peace","war"].includes(a.status)||!Number.isFinite(a.trust)||typeof a.trade!="boolean"||!Number.isFinite(a.treatyTurn))return!1}}for(const r of n.systems)if(!e(r.name)||!t(mr,r.type)||!["x","y","habitability","richness","science","population","growth","defenseDamage"].every(s=>Number.isFinite(r[s]))||r.habitability<0||r.habitability>100||r.population<0||r.growth<0||r.owner!==null&&!En.includes(r.owner)||r.originalOwner!==null&&!En.includes(r.originalOwner)||!Array.isArray(r.buildings)||r.buildings.some(s=>!t(Ye,s))||new Set(r.buildings).size!==r.buildings.length||!Array.isArray(r.knownBy)||!Array.isArray(r.exploredBy)||[...r.knownBy,...r.exploredBy].some(s=>!En.includes(s))||r.anomaly&&(!t(pn,r.anomaly.id)||typeof r.anomaly.resolved!="boolean")||!Ib(r))return!1;if(new Set(n.fleets.map(r=>r.id)).size!==n.fleets.length)return!1;for(const r of n.fleets)if(!/^f[1-9][0-9]*$/.test(r.id)||!t(Re,r.type)||!En.includes(r.owner)||!i.has(r.systemId)||!Number.isInteger(r.ships)||r.ships<1||r.ships>12||!Number.isFinite(r.hp)||r.hp<=0||r.hp>Re[r.type].hp*r.ships||!Number.isFinite(r.movesLeft)||r.movesLeft<0||!e(r.name))return!1;return!(n.lanes.some(r=>!Array.isArray(r)||r.length!==2||!i.has(r[0])||!i.has(r[1])||r[0]===r[1])||n.log.some(r=>!Number.isInteger(r.id)||!Number.isInteger(r.turn)||!e(r.type)||!e(r.text))||!kb(n)||!aS(n)||!wb(n)||!TS(n)||!cS(n)||!dS(n)||!wS(n)||!Db(n))}const as=3,Tr=(n,e)=>n.factions.find(t=>t.id===e),Mr=(n,e)=>n.systems.find(t=>t.id===e),ya=n=>n.resolved?"resolved":n.stage||"opening",sl=n=>structuredClone(n),to=n=>({ok:!1,message:n}),Wd=(n,e,t)=>e.exploredBy.includes(t)&&tr(n,t,e.id),wp=(n,e)=>Object.entries(e||{}).every(([t,i])=>n[t]>=i),Xd=(n,e,t)=>Ft(n,t,e.id).some(i=>i.owner!==t&&Tr(n,t).relations[i.owner]?.status==="war"&&Re[i.type]?.attack>=4);function Ep(n,e){const t=e.anomaly,i=t.restoration?.buildingId||null;return{observedTurn:n.turn,phase:ya(t),progress:t.progress||0,siteId:i,siteState:i?e.buildings.includes(i)?"active":e.queue?.itemId===i?"building":"planned":null}}function Tp(n,e,t,i){e==="player"&&(n.log.unshift({id:n.nextLogId++,turn:n.turn,type:"discovery",text:i,systemId:t}),n.log.length=Math.min(n.log.length,160))}function gS(n){const e=n.systems.filter(i=>i.anomaly);if(e.length<2)return;let t=2166136261;for(const i of String(n.seed))t=Math.imul(t^i.charCodeAt(0),16777619);for(const i of["observatory","reef"]){t=Math.imul(t,1664525)+1013904223>>>0;const[r]=e.splice(t%e.length,1);r.anomaly={id:i,resolved:!1}}}function al(n,e,t){const i=Mr(n,e);if(!i?.anomaly||!Tr(n,t)||!Wd(n,i,t))return!1;for(const r of i.anomaly.history||[])r.knownBy.includes(t)||r.knownBy.push(t);return i.anomaly.observations||={},i.anomaly.observations[t]=Ep(n,i),!0}function Ap(n){for(const e of n.systems.filter(t=>t.anomaly))for(const t of n.factions)al(n,e.id,t.id)}function Jn(n,e,t="player"){const i=Mr(n,e);if(!i?.anomaly||!Tr(n,t)||!i.exploredBy.includes(t))return null;const r=i.anomaly,s=pn[r.id],a=Wd(n,i,t),o=a?Ep(n,i):r.observations?.[t],l=!o&&r.resolved&&r.resolvedBy===t,c=o?.phase||(l?"resolved":"unknown"),d=(r.history||[]).filter(u=>a||u.knownBy.includes(t)).map(({knownBy:u,...h})=>sl(h));return{id:r.id,name:s.name,systemId:e,description:c==="ready"?s.matureDescription:s.description,phase:c,progress:o?.progress||0,target:s.multiStage?as:1,observedTurn:o?.observedTurn??null,stale:!a,canInteract:a&&(!i.owner||i.owner===t),history:d,legacyOutcome:c==="resolved"&&d.length===0,site:o?.siteId?{id:o.siteId,name:Ye[o.siteId].name,state:o.siteState}:null,continuation:s.continuation||null}}function Rp(n,e,t){const i=Tr(n,t);return n.winner?"This campaign has ended.":!i||i.eliminated?"This empire is no longer active.":!e||!e.exploredBy.includes(t)?"Survey this system first.":Wd(n,e,t)?e.owner&&e.owner!==t?"Only the sovereign empire may investigate this site.":Xd(n,e,t)?"Clear hostile warships before investigating.":i.orders<1?"No orders remaining.":"":"An expedition must be present to investigate."}function ad(n,e,t,i="player"){const r=Ye[t];return r?.discovery?!e||e.owner!==i?"Requires an owned colony":e.anomaly?.id!==r.discovery?"This ancient site belongs to a different discovery world":e.anomaly.restoration?.buildingId===t?"":!e.anomaly.resolved&&ya(e.anomaly)==="ready"?Xd(n,e,i)?"Clear hostile warships before investigating.":"":"Complete this world’s discovery research before restoring its ancient site":""}function vS(n,e,t,i,r){return e.owner!==t.id?"Requires an owned colony":e.queue?"Construction already in progress":e.buildings.includes(i.id)?"Already built":r!==null&&(!e.buildings.includes(r)||r===i.id)?"Choose an existing building to replace with new infrastructure":Fn(n,e).available===0&&r===null?"Infrastructure slots are full. Choose a building to replace":i.requires.some(s=>!t.techs.includes(s))?`Requires ${i.requires.filter(s=>!t.techs.includes(s)).map(s=>Tt[s].name).join(" and ")}`:wp(t,i.cost)?ad(n,e,i.id,t.id):"Insufficient credits or minerals"}function yS(n,e,t,i,r){if(!r.canInteract)return null;const s={};if(i.population){const a=Mr(n,t.capitalId);if(a?.owner===t.id){const o=a.population,l=o+i.population,c=dt(n,a).capacity;s.population={amount:i.population,systemId:a.id,systemName:a.name,before:o,after:l,capacity:c,overCapacity:l>c}}else s.population={amount:0,systemId:null,systemName:null,before:null,after:null,capacity:null,overCapacity:!1}}if(i.habitability){const a=e.habitability,o=Math.min(100,a+i.habitability);s.habitability={amount:o-a,before:a,after:o}}return s}function _a(n,e,t="player",i=null){const r=Mr(n,e),s=Tr(n,t),a=Jn(n,e,t);if(!a||!["opening","ready"].includes(a.phase))return[];const o=pn[a.id],l=a.phase==="ready"?o.finalChoices||[]:o.choices,c=Rp(n,r,t);return l.map(d=>{const u=Ye[d.buildingId],h=u?.requires||d.requires||[],f=u?.cost||d.cost||{};let p=c;!p&&h.some(m=>!s.techs.includes(m))&&(p=`Requires ${h.filter(m=>!s.techs.includes(m)).map(m=>Tt[m].name).join(" and ")}`),!p&&u&&(p=vS(n,r,s,u,i)),!p&&!wp(s,f)&&(p="Insufficient credits or minerals");const v=a.canInteract?4+r.population+r.buildings.reduce((m,g)=>m+(Ye[g].production||0),0)+Ni(r).production:0;return{...sl(d),cost:{...f},gain:{...d.gain},requires:[...h],orders:1,enabled:!p,reason:p,stageId:a.phase,kind:u?"restore":d.preserve?"preserve":"resolve",...u?{work:u.work,turns:a.canInteract?Math.ceil(u.work/Math.max(1,v)):null,replaceBuildingId:i}:{},continuation:d.preserve?o.continuation:null,effectsPreview:yS(n,r,s,d,a)}})}const no=n=>Object.entries(n).filter(([,e])=>e>0).map(([e,t])=>`${t} ${e}`).join(" and ");function _S(n,e=""){const t=[];return no(n.paid)&&t.push(`Paid ${no(n.paid)}.`),no(n.gained)&&t.push(`Gained ${no(n.gained)}.`),n.habitability!==void 0&&t.push(`Habitability increased by ${n.habitability} points.`),n.population&&t.push(n.population.amount?`Added ${n.population.amount} population at ${n.population.systemName}.`:"No settled capital could receive the refugees."),n.charted!==void 0&&t.push(`Charted ${n.charted} new systems.`),n.fleet&&t.push(`Recovered ${n.fleet.name}, a ${Re[n.fleet.type].role.toLowerCase()}.`),n.construction&&t.push(`Commissioned ${Ye[n.construction.buildingId].name} (${n.construction.work} work). Restoration remains available if construction is cancelled or the site is later replaced.`),e&&t.push(e),t.join(" ")}function Cp(n,e,t,i,r,s,a){const o=e.anomaly,l=pn[o.id];o.history||=[];const c={id:`${e.id}:${o.history.length+1}`,stageId:r,choiceId:i.id,turn:n.turn,factionId:t,title:l.name,choiceLabel:i.label,outcomeText:_S(s,a),effects:sl(s),knownBy:[t]};o.history.push(c),Tp(n,t,e.id,`${l.name}: ${i.label}. ${c.outcomeText}`);for(const d of n.factions)al(n,e.id,d.id);return c}function xS(n,e,t,i){const r=Mr(n,e),s=Ye[i];if(!s?.discovery||r?.owner!==t||r.anomaly?.id!==s.discovery||r.anomaly.restoration||ya(r.anomaly)!=="ready"||r.queue?.itemId!==i||r.queue.kind!=="building")return!1;const a=r.anomaly;a.restoration={buildingId:i,turn:n.turn,factionId:t},a.resolved=!0,a.resolvedBy=t,a.stage="resolved";const o=pn[a.id].finalChoices.find(l=>l.buildingId===i);return Cp(n,r,t,o,"ready",{paid:{...r.queue.cost},gained:{},construction:{buildingId:i,work:r.queue.work,replaceBuildingId:r.queue.replaceBuildingId||null}}),!0}function bS(n,e,t){const i=e.factionId||"player",r=Mr(n,e.systemId),s=Tr(n,i),a=Rp(n,r,i);if(a)return to(a);if(!r.anomaly||r.anomaly.resolved)return to("No unresolved anomaly here.");const o=_a(n,r.id,i,e.replaceBuildingId??null).find(d=>d.id===e.choiceId);if(!o)return to(ya(r.anomaly)==="maturing"?"This discovery is still maturing.":"Choose an expedition outcome.");if(!o.enabled)return to(o.reason);if(o.kind==="restore")return t.build({type:"build",factionId:i,systemId:r.id,itemId:o.buildingId,...e.replaceBuildingId!==void 0?{replaceBuildingId:e.replaceBuildingId}:{}});const l={paid:{...o.cost},gained:{...o.gain}};for(const[d,u]of Object.entries(l.paid))s[d]-=u;for(const[d,u]of Object.entries(l.gained))s[d]+=u;if(s.orders--,o.population){const d=Mr(n,s.capitalId),u=d?.owner===i?o.population:0;u&&(d.population+=u),l.population={systemId:d?.id||s.capitalId,systemName:d?.name||"the former capital",amount:u}}if(o.habitability){const d=r.habitability;r.habitability=Math.min(100,d+o.habitability),l.habitability=r.habitability-d}if(o.ship){const d=t.makeFleet(i,r.id,o.ship);d.name=`Last Light of ${r.name}`,d.heritage=[{id:`${r.id}:${r.anomaly.id}:${o.id}`,name:d.name,systemId:r.id,discoveryId:r.anomaly.id,choiceId:o.id,turn:n.turn,factionId:i,fleetId:d.id}],l.fleet={id:d.id,name:d.name,type:d.type}}if(o.reveal){const d=new Set(n.systems.filter(h=>h.knownBy.includes(i)).map(h=>h.id));let u=[r.id];for(let h=0;h<o.reveal;h++){u=[...new Set(u.flatMap(f=>n.lanes.flatMap(([p,v])=>p===f?[v]:v===f?[p]:[])))];for(const f of u)t.chart(f,i)}l.charted=n.systems.filter(h=>h.knownBy.includes(i)&&!d.has(h.id)).length}const c=r.anomaly;return o.preserve?(c.stage="maturing",c.progress=0,c.startedTurn=n.turn):(c.resolved=!0,c.resolvedBy=i,c.stage="resolved"),t.applyResearch(s),Cp(n,r,i,o,o.stageId,l,o.preserve?"Preservation begun. Three qualifying colony cycles will open a further decision; the opportunity remains with this world.":""),{ok:!0,message:o.preserve?"Discovery preserved. Its colony research can now mature.":"Expedition resolved."}}function SS(n,e){!n.heritage?.length&&!e.heritage?.length||(n.heritage=[...new Map([...n.heritage||[],...e.heritage||[]].map(t=>[t.id,sl(t)])).values()])}function MS(n){if(n.winner||n.discoveriesUpdatedTurn===n.turn)return{advanced:!1,matured:[]};const e=[];for(const t of n.systems){const i=t.anomaly;if(!i||i.resolved||ya(i)!=="maturing")continue;const r=pn[i.id],s=Tr(n,t.owner);!s||s.eliminated||!t.buildings.includes(r.support)||Xd(n,t,s.id)||(i.progress=Math.min(as,(i.progress||0)+1),i.progress===as&&(i.stage="ready",e.push(t.id),Tp(n,s.id,t.id,`${r.name} at ${t.name} has matured. Choose a lasting site or its final portable reward.`)))}return n.discoveriesUpdatedTurn=n.turn,Ap(n),{advanced:!0,matured:e}}function wS(n){try{if(!n||!Array.isArray(n.systems)||!Array.isArray(n.factions)||!Array.isArray(n.fleets)||!Number.isSafeInteger(n.turn)||n.turn<1)return!1;const e=new Set(n.factions.map(l=>l.id)),t=new Set(n.systems.map(l=>l.id)),i=(l,c=Number.MAX_SAFE_INTEGER)=>Number.isSafeInteger(l)&&l>=0&&l<=c,r=l=>i(l,n.turn)&&l>=1,s=l=>typeof l=="string"&&l.length<=2e3,a=(l,c,d)=>Array.isArray(l)&&l.length<=d&&new Set(l).size===l.length&&l.every(u=>c.has(u)),o=l=>l&&typeof l=="object"&&!Array.isArray(l)&&Object.entries(l).every(([c,d])=>["credits","minerals","science"].includes(c)&&Number.isFinite(d)&&d>=0);if(n.discoveriesUpdatedTurn!==void 0&&!i(n.discoveriesUpdatedTurn,n.turn))return!1;for(const l of n.systems){const c=l.anomaly;for(const u of l.buildings)if(Ye[u]?.discovery&&c?.restoration?.buildingId!==u)return!1;if(Ye[l.queue?.itemId]?.discovery&&c?.restoration?.buildingId!==l.queue.itemId)return!1;if(!c)continue;const d=pn[c.id];if(!d||c.resolvedBy!==void 0&&!e.has(c.resolvedBy)||c.stage!==void 0&&(!["maturing","ready","resolved"].includes(c.stage)||c.stage==="resolved"!==c.resolved||c.stage!=="resolved"&&!d.multiStage)||c.progress!==void 0&&!i(c.progress,as)||c.stage==="maturing"&&(!i(c.progress,2)||!r(c.startedTurn))||c.stage==="ready"&&c.progress!==as||c.startedTurn!==void 0&&!r(c.startedTurn))return!1;if(c.restoration!==void 0){const u=c.restoration;if(!u||!d.multiStage||u.buildingId!==d.siteId||!c.resolved||!r(u.turn)||!e.has(u.factionId))return!1}if(c.history!==void 0){if(!Array.isArray(c.history)||c.history.length>(d.multiStage?2:1))return!1;const u=new Set,h=new Set;for(const f of c.history){const p=f.stageId==="opening"?d.choices:f.stageId==="ready"?d.finalChoices||[]:[],v=f.effects;if(!s(f.id)||h.has(f.id)||u.has(f.stageId)||!p.some(m=>m.id===f.choiceId)||!r(f.turn)||!e.has(f.factionId)||![f.title,f.choiceLabel,f.outcomeText].every(s)||!a(f.knownBy,e,e.size)||!f.knownBy.includes(f.factionId)||!v||!o(v.paid)||!o(v.gained)||Object.keys(v).some(m=>!["paid","gained","habitability","population","charted","fleet","construction"].includes(m))||v.habitability!==void 0&&(!Number.isFinite(v.habitability)||v.habitability<0||v.habitability>100)||v.charted!==void 0&&!i(v.charted,t.size)||v.population!==void 0&&(!v.population||!t.has(v.population.systemId)||!s(v.population.systemName)||!i(v.population.amount,100))||v.fleet!==void 0&&(!v.fleet||!/^f[1-9]\d*$/.test(v.fleet.id)||!s(v.fleet.name)||!Object.hasOwn(Re,v.fleet.type))||v.construction!==void 0&&(!v.construction||v.construction.buildingId!==d.siteId||!Number.isFinite(v.construction.work)||v.construction.work<=0||v.construction.replaceBuildingId!==null&&!Object.hasOwn(Ye,v.construction.replaceBuildingId)))return!1;h.add(f.id),u.add(f.stageId)}}if(c.observations!==void 0){if(!c.observations||typeof c.observations!="object"||Array.isArray(c.observations))return!1;for(const[u,h]of Object.entries(c.observations))if(!e.has(u)||!h||!r(h.observedTurn)||!["opening","maturing","ready","resolved"].includes(h.phase)||!i(h.progress,as)||(h.siteId===null?h.siteState!==null:h.siteId!==d.siteId||!["planned","building","active"].includes(h.siteState)))return!1}}for(const l of n.fleets)if(l.heritage!==void 0){if(!Array.isArray(l.heritage)||l.heritage.length>n.systems.length||new Set(l.heritage.map(c=>c.id)).size!==l.heritage.length)return!1;for(const c of l.heritage)if(!s(c.id)||!s(c.name)||!t.has(c.systemId)||!pn[c.discoveryId]?.choices.some(d=>d.id===c.choiceId&&d.ship)||!r(c.turn)||!e.has(c.factionId)||!/^f[1-9]\d*$/.test(c.fleetId))return!1}return!0}catch{return!1}}const ua=(n,e)=>n.systems.find(t=>t.id===e),ko=(n,e)=>n.fleets.find(t=>t.id===e),qd=(n,e)=>n.factions.find(t=>t.id===e),Ip=(n,e)=>n.lanes.flatMap(([t,i])=>t===e?[i]:i===e?[t]:[]).sort((t,i)=>Number(t.slice(1))-Number(i.slice(1))),Pp=(n,e)=>!e.owner||e.owner===n.id||n.relations[e.owner]?.status==="war"||n.relations[e.owner]?.trade,os=(n,e=null,t=[])=>({ok:!1,reason:n,destinationId:e,path:[...t],jumps:Math.max(0,t.length-1),totalOrders:Math.max(0,t.length-1),maxJumpsNow:0,maxOrdersNow:0,stopBefore:null,uncertainSystems:[]});function Yd(n,e,t){if(!t||typeof t!="object"||Array.isArray(t)||Object.keys(t).some(r=>!["destinationId","path"].includes(r))||!Array.isArray(t.path)||t.path.length<2||t.path.length>n.systems.length)return!1;const i=t.path;return i[0]===e.systemId&&i.at(-1)===t.destinationId&&new Set(i).size===i.length&&i.every((r,s)=>ua(n,r)?.knownBy.includes(e.owner)&&(s===0||Ip(n,i[s-1]).includes(r)))}function Lp(n,e,t,i){const r=qd(n,e.owner);let s=null,a=i.length-1;for(let d=1;d<i.length;d++){const u=ua(n,i[d]),h=Pp(r,u)?Ft(n,e.owner,u.id).some(f=>r.relations[f.owner]?.status==="war")?"An observed hostile fleet blocks this route. Engage it deliberately or replot.":"":"Borders are closed. Replot or restore access before continuing.";if(h){s={systemId:u.id,reason:h},a=d-1;break}}const o=i.length-1,l=Math.min(a,Math.floor(e.movesLeft),Math.floor(r.orders));return{ok:!0,reason:o?a===0?s.reason:e.movesLeft<1?"This fleet has used all its movement this turn.":r.orders<1?"No orders remaining. End the turn to receive a new mandate.":"":"The fleet is already at this destination.",destinationId:t,path:[...i],jumps:o,totalOrders:o,maxJumpsNow:l,maxOrdersNow:l,stopBefore:s,uncertainSystems:i.slice(1).filter(d=>!tr(n,e.owner,d))}}function Zd(n,e,t){const i=ko(n,e),r=ua(n,t);if(!i)return os("Select a fleet first.",t);if(!r?.knownBy.includes(i.owner))return os("Choose a charted destination.",t);const s=qd(n,i.owner),a=[[i.systemId]],o=new Set([i.systemId]);for(let l=0;l<a.length;l++){const c=a[l],d=c.at(-1);if(d===t)return Lp(n,i,t,c);for(const u of Ip(n,d)){const h=ua(n,u);o.has(u)||!h.knownBy.includes(i.owner)||!Pp(s,h)||(o.add(u),a.push([...c,u]))}}return os("No accessible charted route reaches that destination.",t)}function Ws(n,e){const t=ko(n,e);return t?t.route?Yd(n,t,t.route)?Lp(n,t,t.route.destinationId,t.route.path):os("This route no longer matches the fleet position or charted lanes. Replot it.",t.route.destinationId,Array.isArray(t.route.path)?t.route.path:[]):os("This fleet has no planned route."):os("Select a fleet first.")}function ES(n,e,t){n.route&&(n.route.path[0]===e&&n.route.path[1]===t?(n.route.path.shift(),n.route.path.length<2&&delete n.route):delete n.route)}function Np(n){for(const e of n.fleets)e.route&&!Yd(n,e,e.route)&&delete e.route}function TS(n){return n.fleets.every(e=>e.route===void 0||Yd(n,e,e.route))}function AS(n,e,t){const i=ko(n,e),r=Ws(n,e),s=[],a=(f,p,v,m,g,x)=>({ok:f,outcome:p,message:v,jumpsCompleted:m,ordersSpent:g,movesSpent:x,combatReports:s});if(!r.ok||!r.maxJumpsNow)return a(!1,"blocked",r.reason,0,0,0);const o=qd(n,i.owner),l=o.orders,c=i.movesLeft;let d=0;const u=(f,p)=>a(!0,f,p,d,l-o.orders,c-i.movesLeft);for(let f=0;f<r.maxJumpsNow;f++){const p=Ws(n,e);if(!p.ok||!p.maxJumpsNow)return u("blocked",`Route paused after ${d} jump${d===1?"":"s"}. ${p.reason}`);const v=ua(n,p.path[1]),m=i.systemId,g=v.exploredBy.includes(i.owner),x=new Set(o.contacts),E=t({type:"move",factionId:i.owner,fleetId:e,targetId:v.id});if(!E.ok)return d?u("blocked",`Route paused. ${E.message}`):a(!1,"blocked",E.message,0,0,0);if(s.push(...E.combatReports||[]),i.systemId!==m&&d++,E.outcome==="intercepted")return u("intercepted",E.message);if(!ko(n,e))return u("destroyed",E.message);if(E.combatOccurred||E.combatReports?.length)return u("combat",E.message);if(n.winner)return u("campaign-ended","Campaign concluded. Route movement has stopped.");if(o.contacts.some(w=>!x.has(w)))return u("first-contact",`Route paused at ${v.name}: first contact opened a diplomatic channel.`);const b=g?null:Jn(n,v.id,i.owner);if(b&&(b.phase!=="resolved"||b.site))return u("discovery",`Route paused at ${v.name}: ${b.name} is newly surveyed${b.site?`, including its ${b.site.name}`:""}.`);if(!i.route)return u("arrived",`${i.name} reached ${v.name} in ${d} jump${d===1?"":"s"}.`)}const h=Ws(n,e);return h.stopBefore?.systemId===h.path[1]?u("blocked",`Route paused after ${d} jump${d===1?"":"s"}. ${h.stopBefore.reason}`):u(i.movesLeft<1?"moves-exhausted":o.orders<1?"orders-exhausted":"paused",`Route paused after ${d} jump${d===1?"":"s"}. ${h.reason||"Continue the remaining route when ready."}`)}const Ps=(n,e,t)=>Math.max(e,Math.min(t,n)),io=n=>Ke[n]?.color||"#bbcadb",od=n=>n.exploredBy?.includes("player"),cr=n=>n.knownBy?.includes("player")||od(n)||n.owner==="player",Dp=n=>()=>{n|=0,n=n+1831565813|0;let e=Math.imul(n^n>>>15,1|n);return e^=e+Math.imul(e^e>>>7,61|e),((e^e>>>14)>>>0)/4294967296};function Up(n,e){const t=document.createElement("canvas");t.width=t.height=n,e(t.getContext("2d"),n);const i=new Pg(t);return i.colorSpace=hn,i}function RS(){return Up(128,(n,e)=>{const t=e/2,i=n.createRadialGradient(t,t,0,t,t,t);i.addColorStop(0,"#ffffff"),i.addColorStop(.035,"#ffffff"),i.addColorStop(.09,"rgba(255,255,255,.95)"),i.addColorStop(.21,"rgba(255,255,255,.24)"),i.addColorStop(.53,"rgba(255,255,255,.055)"),i.addColorStop(1,"rgba(255,255,255,0)"),n.fillStyle=i,n.fillRect(0,0,e,e)})}function CS(){return Up(512,(n,e)=>{const t=Dp(9148);n.clearRect(0,0,e,e);for(let i=0;i<58;i++){const r=t()*Math.PI*2,s=Math.sqrt(t())*115,a=e/2+Math.cos(r)*s*1.2,o=e/2+Math.sin(r)*s*.7,l=38+t()*98,c=n.createRadialGradient(a,o,0,a,o,l);c.addColorStop(0,`rgba(255,255,255,${.04+t()*.035})`),c.addColorStop(.45,"rgba(255,255,255,.025)"),c.addColorStop(1,"rgba(255,255,255,0)"),n.fillStyle=c,n.fillRect(a-l,o-l,l*2,l*2)}})}function Xr(n,e,t=.4,i=72,r=0,s=Math.PI*2){const a=[];for(let o=0;o<=i;o++){const l=r+o/i*(s-r);a.push(new P(Math.cos(l)*n,Math.sin(l)*n,0))}return new Rd(new Ot().setFromPoints(a),new Lo({color:e,transparent:!0,opacity:t,depthWrite:!1}))}class IS{constructor(e,{onSelect:t=()=>{},onFleetSelect:i=()=>{}}={}){this.container=e,this.onSelect=t,this.onFleetSelect=i,this.state=null,this.selectedSystemId=null,this.selectedFleetId=null,this.disposed=!1,this.paused=!1,this.surfaceVisible=!1,this.viewportVisible=!0,this.needsRender=!0,this.labelsDirty=!0,this.lastRenderTime=0,this.animate=this.animate.bind(this),this.width=1,this.height=1,this.baseHeight=800,this.unit=7,this.mapCenter=new le,this.target=new le,this.targetZoom=1,this.camera=new ma(-400,400,400,-400,.1,2e3),this.camera.position.set(0,0,1e3),this.camera.lookAt(0,0,0),this.scene=new cf,this.scene.background=new Qe("#080e1b"),this.staticGroup=new fr,this.dynamicGroup=new fr,this.scene.add(this.staticGroup,this.dynamicGroup),this.hitTargets=[],this.labels=[],this.selectionRings=[],this.raycaster=new Ev,this.pointer=new le,this.projected=new P,this.resources=new Set,this.reducedMotion=window.matchMedia("(prefers-reduced-motion: reduce)"),this.abort=new AbortController,this.container.classList.add("galaxy-view"),this.canvas=document.createElement("canvas"),this.canvas.className="galaxy-canvas",this.canvas.setAttribute("aria-hidden","true"),this.container.append(this.canvas),this.routeLayer=document.createElementNS("http://www.w3.org/2000/svg","svg"),this.routeLayer.classList.add("galaxy-route-overlay"),this.routeLayer.setAttribute("aria-hidden","true"),this.routeLayer.setAttribute("focusable","false"),this.container.append(this.routeLayer),this.routes=[],this.routePoints=new Map,this.labelLayer=document.createElement("div"),this.labelLayer.className="galaxy-labels",this.labelLayer.setAttribute("aria-label","Galaxy systems and fleets"),this.container.append(this.labelLayer),this.tooltip=document.createElement("div"),this.tooltip.className="galaxy-tooltip",this.tooltip.hidden=!0,this.container.append(this.tooltip),this.backdropLabel=document.createElement("div"),this.backdropLabel.className="galaxy-sector-label",this.backdropLabel.innerHTML="<span>THE ASTERION REACH</span><small>THE UNCHARTED EXPANSE</small>",this.container.append(this.backdropLabel);try{this.renderer=new Ff({canvas:this.canvas,antialias:!0,alpha:!1,powerPreference:"low-power"}),this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.7)),this.renderer.outputColorSpace=hn,this.renderer.setClearColor("#080e1b"),this.glow=RS(),this.cloud=CS(),this.resources.add(this.glow),this.resources.add(this.cloud)}catch{this.fallback=!0,this.canvas.hidden=!0,this.container.classList.add("galaxy-fallback"),this.fallbackNotice=document.createElement("p"),this.fallbackNotice.className="galaxy-fallback-notice",this.fallbackNotice.textContent="WebGL is unavailable. The tactical star chart remains playable. Enable hardware acceleration for the full galaxy view.",this.container.append(this.fallbackNotice)}this.bindEvents(),this.resizeObserver=new ResizeObserver(()=>this.resize()),this.resizeObserver.observe(e),this.intersectionObserver=new IntersectionObserver(([r])=>{this.viewportVisible=r.isIntersecting,this.viewportVisible?this.resize():this.cancelScheduledFrame()}),this.intersectionObserver.observe(e),this.resize(),this.lastTime=0,this.requestFrame()}bindEvents(){const{signal:e}=this.abort;this.container.addEventListener("pointerdown",t=>{t.target.closest("button, a")||t.button>1||(this.drag={x:t.clientX,y:t.clientY,startX:t.clientX,startY:t.clientY,moved:!1,pointerId:t.pointerId},this.container.setPointerCapture(t.pointerId))},{signal:e}),this.container.addEventListener("pointermove",t=>{if(this.drag){const i=t.clientX-this.drag.x,r=t.clientY-this.drag.y;if(this.drag.moved||=Math.hypot(t.clientX-this.drag.startX,t.clientY-this.drag.startY)>5,this.drag.moved){const s=this.baseHeight/this.camera.zoom/this.height;this.target.x-=i*s,this.target.y+=r*s,this.camera.position.x=this.target.x,this.camera.position.y=this.target.y,this.labelsDirty=!0,this.container.classList.add("galaxy-dragging"),this.requestFrame()}this.drag.x=t.clientX,this.drag.y=t.clientY,this.tooltip.hidden=!0}else if(t.target===this.canvas){const i=this.pick(t);this.container.classList.toggle("galaxy-pointing",!!i),this.showTooltip(i,t)}},{signal:e}),this.container.addEventListener("pointerup",t=>{if(this.drag){if(!this.drag.moved){const i=this.pick(t);i&&this.onSelect(i)}this.drag=null,this.container.classList.remove("galaxy-dragging"),this.container.hasPointerCapture(t.pointerId)&&this.container.releasePointerCapture(t.pointerId)}},{signal:e}),this.container.addEventListener("pointercancel",()=>{this.drag=null,this.container.classList.remove("galaxy-dragging")},{signal:e}),this.container.addEventListener("pointerleave",()=>{this.tooltip.hidden=!0},{signal:e}),this.container.addEventListener("dblclick",t=>{if(t.target.closest("button, a"))return;const i=this.pick(t);i&&this.focus(i)},{signal:e}),this.container.addEventListener("wheel",t=>{t.target.closest("button, a")||(t.preventDefault(),this.zoom(-Math.sign(t.deltaY)*.14))},{passive:!1,signal:e}),document.addEventListener("visibilitychange",()=>{document.hidden?this.cancelScheduledFrame():this.requestFrame()},{signal:e}),this.canvas.addEventListener("webglcontextlost",t=>{t.preventDefault(),this.contextLost=!0,this.cancelScheduledFrame(),this.contextNotice||(this.contextNotice=document.createElement("p"),this.contextNotice.className="galaxy-fallback-notice",this.contextNotice.textContent="The graphics context was interrupted. Your game is safe; reload to restore the galaxy.",this.container.append(this.contextNotice))},{signal:e}),this.canvas.addEventListener("webglcontextrestored",()=>{this.contextLost=!1,this.contextNotice?.remove(),this.contextNotice=null,this.requestFrame()},{signal:e})}resize(){if(this.disposed)return;const e=this.container.clientWidth,t=this.container.clientHeight;if(this.surfaceVisible=e>0&&t>0,!this.surfaceVisible){this.cancelScheduledFrame();return}(e!==this.width||t!==this.height||!this.hasMeasuredSize)&&this.renderer?.setSize(e,t,!1),this.width=e,this.height=t;const i=this.width/this.height;!this.hasMeasuredSize&&this.boundsWidth!==void 0&&(this.baseHeight=Math.max(this.boundsHeight*1.22,this.boundsWidth/Math.max(.7,i)*1.22,100)),this.hasMeasuredSize=!0,this.camera.left=-this.baseHeight*i/2,this.camera.right=this.baseHeight*i/2,this.camera.top=this.baseHeight/2,this.camera.bottom=-this.baseHeight/2,this.camera.updateProjectionMatrix(),this.labelsDirty=!0,this.requestFrame()}world(e){return new P(e.x,-e.y,0)}setBounds(e){const t=e.systems.map(l=>l.x),i=e.systems.map(l=>-l.y),r=Math.min(...t),s=Math.max(...t),a=Math.min(...i),o=Math.max(...i);this.boundsWidth=s-r,this.boundsHeight=o-a,this.span=Math.max(s-r,o-a,100),this.unit=this.span/110,this.mapCenter.set((r+s)/2,(a+o)/2),this.baseHeight=Math.max((o-a)*1.22,(s-r)/Math.max(.7,this.width/this.height)*1.22,100),this.target.copy(this.mapCenter),this.camera.position.x=this.target.x,this.camera.position.y=this.target.y,this.camera.zoom=this.targetZoom=1,this.resize(),this.clearGroup(this.staticGroup),this.fallback||this.buildBackground()}buildBackground(){const e=Dp(737190),t=[],i=[],r=new Qe;for(let l=0;l<2500;l++){const c=l%3,d=Math.pow(e(),.65)*this.span*.72,u=c*Math.PI*2/3+d/this.span*5.5+(e()-.5)*1.2,h=l<1600,f=h?Math.cos(u)*d:(e()-.5)*this.span*2.8,p=h?Math.sin(u)*d*.72:(e()-.5)*this.span*2.8;t.push(this.mapCenter.x+f,this.mapCenter.y+p,-70-e()*30),r.setHSL(.55+e()*.18,.1+e()*.25,.2+e()*.42),i.push(r.r,r.g,r.b)}const s=new Ot;s.setAttribute("position",new bt(t,3)),s.setAttribute("color",new bt(i,3));const a=new Ig(s,new ff({size:2.1,sizeAttenuation:!1,map:this.glow,vertexColors:!0,transparent:!0,opacity:.8,blending:Kr,depthWrite:!1}));this.staticGroup.add(a);const o=[[-.25,-.04,"#445a93",.6,.92,.5,-.3],[.07,.14,"#654285",.5,.9,.5,.4],[.3,-.22,"#236578",.32,.9,.6,-.8],[-.13,-.4,"#325567",.3,.8,.45,.5],[.05,-.06,"#53658f",.17,.58,.36,-.7]];for(const[l,c,d,u,h,f,p]of o){const v=new Nl(new uo({map:this.cloud,color:d,opacity:u,transparent:!0,blending:Kr,depthWrite:!1,rotation:p}));v.position.set(this.mapCenter.x+l*this.span,this.mapCenter.y+c*this.span,-50),v.scale.set(this.span*h*1.8,this.span*f*1.8,1),this.staticGroup.add(v)}for(let l=1;l<=3;l++){const c=Xr(this.span*.16*l,"#8195b8",.035,128);c.position.set(this.mapCenter.x,this.mapCenter.y,-35),this.staticGroup.add(c)}}update(e,t=null,i=null){if(this.disposed||!e?.systems?.length)return;const r=!this.state||this.galaxySeed!==e.seed||this.systemSignature!==e.systems.map(o=>`${o.id}:${o.x},${o.y}`).join("|");this.state=e,this.galaxySeed=e.seed,this.systemSignature=e.systems.map(o=>`${o.id}:${o.x},${o.y}`).join("|"),this.selectedSystemId=t,this.selectedFleetId=i,this.systemsById=new Map(e.systems.map(o=>[o.id,o])),this.publicBeaconIds=new Set(Zn(e).flatMap(o=>o.sites.map(l=>l.id))),this.discoverySignals=new Set(e.systems.filter(o=>["opening","maturing","ready"].includes(Jn(e,o.id)?.phase)).map(o=>o.id)),this.recentTransfers=new Map;for(const o of Fd(e))this.recentTransfers.has(o.systemId)||this.recentTransfers.set(o.systemId,o);r&&this.setBounds(e),this.clearGroup(this.dynamicGroup),this.labelLayer.replaceChildren(),this.labels=[],this.hitTargets=[],this.selectionRings=[];const s=e.fleets?.find(o=>o.id===i);this.buildRoutes(e,s);const a=new Set;if(s?.owner==="player")for(const o of e.lanes||[])o[0]===s.systemId&&a.add(o[1]),o[1]===s.systemId&&a.add(o[0]);this.fallback||this.buildLanes(e,s,a);for(const o of e.systems){const l=cr(o),c=od(o),d=this.world(o),u=o.id===t;this.fallback||this.buildStar(o,d,l,c,u,a.has(o.id)),l&&this.buildLabel(o,d,c,u,a.has(o.id))}this.buildFleetLabels(e),this.sortedLabels=[...this.labels].sort((o,l)=>l.priority-o.priority),this.labelsDirty=!0,this.requestFrame()}buildRoutes(e,t){if(this.routeLayer.replaceChildren(),this.routes=[],this.routePoints=new Map,!t||t.owner!=="player")return;const i=Ws(e,t.id),r=this.selectedSystemId&&this.selectedSystemId!==t.systemId&&this.selectedSystemId!==i.destinationId?Zd(e,t.id,this.selectedSystemId):null,s=(a,o,l)=>{const c=document.createElementNS("http://www.w3.org/2000/svg",a);for(const[d,u]of Object.entries(o))c.setAttribute(d,u);return l.append(c),c};for(const[a,o]of[["committed",i],["preview",r]]){if(!o||!Array.isArray(o.path)||o.path.length<2||o.path.some(h=>!cr(this.systemsById.get(h)||{})))continue;const l=s("g",{class:`galaxy-route galaxy-route-${a}`},this.routeLayer),c=o.path.slice(1).map((h,f)=>{const p=s("g",{},l),v=s("path",{class:"galaxy-route-shadow"},p),m=s("path",{class:"galaxy-route-line"},p);return{from:o.path[f],to:h,shadow:v,line:m}}),d=s("circle",{class:"galaxy-route-destination"},l);this.routes.push({kind:a,result:o,segments:c,destination:d});const u=new Set(o.uncertainSystems||[]);o.path.slice(1).forEach((h,f)=>this.routePoints.set(h,{id:h,kind:a,number:f+1,jumps:o.path.length-1,destination:f===o.path.length-2,uncertain:u.has(h),stopReason:o.stopBefore?.systemId===h?o.stopBefore.reason:""}))}for(const a of this.routePoints.values()){const o=s("g",{class:`galaxy-route-waypoint galaxy-route-${a.kind}${a.uncertain?" is-uncertain":""}${a.stopReason?" is-stopped":""}`},this.routeLayer);s("circle",{r:a.destination?9:8},o);const l=s("text",{"text-anchor":"middle",dy:".35em"},o);l.textContent=a.number,a.element=o}}placeRoutes(){if(!this.routes.length)return;this.routeLayer.setAttribute("viewBox",`0 0 ${this.width} ${this.height}`);const e=new Map;for(const r of this.routes)for(const s of r.result.path)e.has(s)||(this.projected.copy(this.world(this.systemsById.get(s))).project(this.camera),e.set(s,{x:(this.projected.x*.5+.5)*this.width,y:(-this.projected.y*.5+.5)*this.height+(this.fallback?27:0)}));const t=Ps(this.unit*1.65*this.height/this.baseHeight*this.camera.zoom,6,19),i=new Set(this.routes.filter(r=>r.kind==="committed").flatMap(r=>r.segments.map(s=>[s.from,s.to].sort().join(":"))));for(const r of this.routes){const s=r.result.stopBefore?r.result.path.indexOf(r.result.stopBefore.systemId):-1;r.segments.forEach((o,l)=>{const c=e.get(o.from),d=e.get(o.to),u=Math.hypot(d.x-c.x,d.y-c.y),h=(d.x-c.x)/Math.max(1,u),f=(d.y-c.y)/Math.max(1,u),p=Math.min(t,u*.3),m=r.kind==="preview"&&i.has([o.from,o.to].sort().join(":"))?3.5:0,g=`M ${c.x+h*p-f*m} ${c.y+f*p+h*m} L ${d.x-h*p-f*m} ${d.y-f*p+h*m}`;o.line.setAttribute("d",g),o.shadow.setAttribute("d",g),o.line.classList.toggle("is-blocked",s>0&&l+1>=s)});const a=e.get(r.result.path.at(-1));r.destination.setAttribute("cx",a.x),r.destination.setAttribute("cy",a.y),r.destination.setAttribute("r",t+5)}for(const r of this.routePoints.values()){const s=e.get(r.id);r.element.setAttribute("transform",`translate(${s.x-t-4} ${s.y-t-4})`)}}buildLanes(e,t,i){const r={unknown:[],known:[],owned:[],reachable:[]};for(const[a,o]of e.lanes||[]){const l=this.systemsById.get(a),c=this.systemsById.get(o);if(!l||!c||!(cr(l)&&cr(c)))continue;const h=t&&(a===t.systemId&&i.has(o)||o===t.systemId&&i.has(a))?"reachable":l.owner==="player"&&c.owner==="player"?"owned":"known",f=this.world(l),p=this.world(c),v=p.clone().sub(f).normalize().multiplyScalar(this.unit*1.35);f.add(v),p.sub(v),r[h].push(f.x,f.y,-.5,p.x,p.y,-.5)}const s={known:["#6c849a",.28],owned:["#68d9cd",.5],reachable:["#a0eee0",.8],unknown:["#67738d",.08]};for(const[a,o]of Object.entries(r))if(o.length){const l=new Ot;l.setAttribute("position",new bt(o,3));const[c,d]=s[a];this.dynamicGroup.add(new Cg(l,new Lo({color:c,opacity:d,transparent:!0,depthWrite:!1})))}}buildStar(e,t,i,r,s,a){const o=i?e.owner:null,l=o?io(o):r?mr[e.type]?.color||"#e4d6bd":"#c4d3e5",c=new Nl(new uo({map:this.glow,color:l,transparent:!0,opacity:i?1:.22,blending:Kr,depthWrite:!1}));c.position.copy(t),c.position.z=1;const d=this.unit*(i?o?5.3:4:1.6);if(c.scale.set(d,d,1),this.dynamicGroup.add(c),!i)return;const u=new Un(new Xo(this.unit*1.4,8,6),new Po({visible:!1}));if(u.position.copy(t),u.userData.systemId=e.id,this.hitTargets.push(u),this.dynamicGroup.add(u),o){const h=new Nl(new uo({map:this.glow,color:io(o),transparent:!0,opacity:.13,blending:Kr,depthWrite:!1}));h.position.copy(t),h.position.z=-2,h.scale.set(this.unit*17,this.unit*17,1),this.dynamicGroup.add(h);const f=Xr(this.unit*2.3,l,.36,56);f.position.copy(t),this.dynamicGroup.add(f);const p=new Un(new Cd(this.unit*.19,10),new Po({color:l,transparent:!0,opacity:.9}));p.position.set(t.x+this.unit*2.3,t.y,.5),this.dynamicGroup.add(p)}if(a&&e.id!==this.selectedSystemId){const h=Xr(this.unit*1.7,"#8fe6d8",.55,40,.25,Math.PI*1.8);h.position.copy(t),this.dynamicGroup.add(h)}if(s){for(let f=0;f<4;f++){const p=Xr(this.unit*3.1,"#b6f4e9",.9,15,Math.PI/2*f+.12,Math.PI/2*f+.75);p.position.copy(t),p.position.z=2,this.dynamicGroup.add(p),this.selectionRings.push(p)}const h=Xr(this.unit*3.7,"#68d9cd",.13);h.position.copy(t),this.dynamicGroup.add(h)}if(this.discoverySignals.has(e.id)){const h=[new P(0,this.unit*.5,0),new P(this.unit*.35,0,0),new P(0,-this.unit*.5,0),new P(-this.unit*.35,0,0),new P(0,this.unit*.5,0)],f=new Rd(new Ot().setFromPoints(h),new Lo({color:"#e9bb76"}));f.position.set(t.x-this.unit*2.5,t.y+this.unit*2.5,2),this.dynamicGroup.add(f)}if(this.publicBeaconIds.has(e.id)){const h=Xr(this.unit*4.3,"#e5c88c",.65,6);h.position.copy(t),h.position.z=1,this.dynamicGroup.add(h)}}buildLabel(e,t,i,r,s){const a=document.createElement("button");a.type="button",a.className=`galaxy-system-label${r?" is-selected":""}${e.owner==="player"?" is-owned":""}${i?"":" is-unsurveyed"}${s?" is-reachable":""}`,a.dataset.systemId=e.id,a.style.setProperty("--system-color",e.owner?io(e.owner):"#bac8d9"),a.setAttribute("aria-pressed",String(r));const o=document.createElement("span");o.className="galaxy-system-name",o.textContent=e.name,a.append(o);const l=document.createElement("small");l.className="galaxy-system-status";const c=this.publicBeaconIds.has(e.id);l.textContent=c?`✦ ${Ke[e.owner]?.shortName?.toUpperCase()||"RESTORED"} BEACON`:e.owner?Ke[e.owner]?.shortName?.toUpperCase()||"COLONY":i?this.discoverySignals.has(e.id)?"◇ ANOMALY":mr[e.type]?.name?.toUpperCase()||"SURVEYED":"UNSURVEYED",c&&a.classList.add("is-beacon");const d=this.routePoints.get(e.id);d&&a.classList.add(`is-route-${d.kind}`),a.append(l);const u=this.recentTransfers.get(e.id);if(u){const h=document.createElement("small");h.className="galaxy-transfer-marker",h.textContent=`↳ TRANSFER · ${u.turn}`,a.title=`Cycle ${u.turn}: ${u.to.name} took control from ${u.from.name}.`,a.append(h)}a.setAttribute("aria-label",`${e.name}, ${l.textContent.toLowerCase()}${s?", adjacent to selected fleet":""}${d?`, ${d.kind==="committed"?"plotted course":"route preview"} jump ${d.number} of ${d.jumps}${d.destination?", destination":""}${d.stopReason?`, ${d.stopReason}`:""}`:""}`),a.addEventListener("click",h=>{h.stopPropagation(),this.onSelect(e.id)}),a.addEventListener("dblclick",h=>{h.stopPropagation(),this.focus(e.id)}),this.labelLayer.append(a),this.labels.push({element:a,position:t,kind:"system",systemId:e.id,offsetX:0,offsetY:16,priority:r?100:c?85:d?84:u?82:e.owner==="player"?80:40})}buildFleetLabels(e){const t=new Map;for(const i of Ft(e,"player")){const r=this.systemsById.get(i.systemId);if(!r||!cr(r))continue;const s=t.get(r.id)||0;t.set(r.id,s+1);const a=document.createElement("button");a.type="button",a.className=`galaxy-fleet${i.id===this.selectedFleetId?" is-selected":""}${i.owner!=="player"?" is-foreign":""}${i.movesLeft<=0?" is-spent":""}`,a.dataset.fleetId=i.id,a.style.setProperty("--fleet-color",io(i.owner));const o=Re[i.type];a.textContent=`${o?.icon||"△"}${i.ships>1?` ${i.ships}`:""}`,a.title=`${i.name} · ${o?.role||i.type} · ${i.movesLeft} jump${i.movesLeft===1?"":"s"} remaining`,a.setAttribute("aria-label",`${i.name}, ${o?.role||i.type}, at ${r.name}`),a.setAttribute("aria-pressed",String(i.id===this.selectedFleetId)),a.addEventListener("click",l=>{l.stopPropagation(),this.onFleetSelect(i.id)}),this.labelLayer.append(a),this.labels.push({element:a,position:this.world(r),kind:"fleet",systemId:r.id,offsetX:25+s*28,offsetY:-16,priority:90})}}showTooltip(e,t){if(!e||!this.state){this.tooltip.hidden=!0;return}const i=this.systemsById.get(e);if(!i)return;const r=od(i)?`${mr[i.type]?.name||"World"} · ${i.habitability}% habitability${i.owner?` · ${Ke[i.owner]?.shortName||i.owner}`:""}`:"Unsurveyed · Send a fleet to explore";this.tooltip.replaceChildren();const s=document.createElement("strong");s.textContent=i.name;const a=document.createElement("span");a.textContent=r,this.tooltip.append(s,a),this.tooltip.hidden=!1;const o=this.routePoints.get(e);if(o){const c=document.createElement("span");c.className="galaxy-tooltip-route",c.textContent=`${o.kind==="committed"?"Plotted course":"Route preview"} · Jump ${o.number} of ${o.jumps}${o.stopReason?` · ${o.stopReason}`:o.uncertain?" · Fleet presence unknown":""}`,this.tooltip.append(c)}const l=this.container.getBoundingClientRect();this.tooltip.style.left=`${Ps(t.clientX-l.left+15,8,this.width-Math.min(300,this.width-16))}px`,this.tooltip.style.top=`${Ps(t.clientY-l.top-64,8,Math.max(8,this.height-this.tooltip.offsetHeight-8))}px`}pick(e){if(this.fallback||!this.renderer)return null;const t=this.container.getBoundingClientRect();return this.pointer.set((e.clientX-t.left)/this.width*2-1,-(e.clientY-t.top)/this.height*2+1),this.camera.updateMatrixWorld(),this.raycaster.setFromCamera(this.pointer,this.camera),this.raycaster.intersectObjects(this.hitTargets,!1)[0]?.object.userData.systemId||null}focus(e){const t=this.systemsById?.get(e);if(!t||!cr(t))return;const i=this.world(t);this.target.set(i.x,i.y),this.targetZoom=Math.max(this.targetZoom,1.6),this.reducedMotion.matches&&(this.camera.position.x=i.x,this.camera.position.y=i.y,this.camera.zoom=this.targetZoom,this.camera.updateProjectionMatrix()),this.labelsDirty=!0,this.requestFrame()}zoom(e){this.targetZoom=Ps(this.targetZoom*Math.exp(e),.35,4.5),this.reducedMotion.matches&&(this.camera.zoom=this.targetZoom,this.camera.updateProjectionMatrix()),this.labelsDirty=!0,this.requestFrame()}reset(){if(this.state?.systems?.length)return this.fitSystems(this.state.systems);this.target.copy(this.mapCenter),this.targetZoom=1,this.reducedMotion.matches&&(this.camera.position.x=this.target.x,this.camera.position.y=this.target.y,this.camera.zoom=this.targetZoom,this.camera.updateProjectionMatrix()),this.labelsDirty=!0,this.requestFrame()}focusRoute(e){if(!Array.isArray(e)||e.length<2)return!1;const t=e.map(i=>this.systemsById?.get(i));return t.some(i=>!i||!cr(i))?!1:this.fitSystems(t)}fitSystems(e){if(!e.length||!this.surfaceVisible)return!1;const t=this.container.getBoundingClientRect(),i=this.container.closest(".galaxy-page"),r=i?.querySelector(".map-heading")?.getBoundingClientRect(),s=i?.querySelector(".fleet-bar")?.getBoundingClientRect(),a=(this.fallbackNotice||this.contextNotice)?.getBoundingClientRect(),o=Math.min(72,this.width*.12),l=this.width-Math.min(120,this.width*.18),c=Math.max(40,r?.height?r.bottom-t.top+40:0,a?.height?a.bottom-t.top+32:0),d=s?.height&&s.top<t.bottom?s.top-t.top:this.height,u=Math.max(c+80,Math.min(this.height-45,d-50)),h=e.map(E=>this.world(E)),f=Math.min(...h.map(E=>E.x)),p=Math.max(...h.map(E=>E.x)),v=Math.min(...h.map(E=>E.y)),m=Math.max(...h.map(E=>E.y)),g=Math.min((l-o)/Math.max(this.unit*10,p-f),(u-c)/Math.max(this.unit*10,m-v));this.targetZoom=Ps(g*this.baseHeight/this.height,.35,4.5);const x=this.height*this.targetZoom/this.baseHeight;return this.target.set((f+p)/2-((o+l)/2-this.width/2)/x,(v+m)/2+((c+u)/2-this.height/2-(this.fallback?27:0))/x),this.reducedMotion.matches&&(this.camera.position.x=this.target.x,this.camera.position.y=this.target.y,this.camera.zoom=this.targetZoom,this.camera.updateProjectionMatrix()),this.labelsDirty=!0,this.requestFrame(),!0}placeLabels(){this.camera.updateMatrixWorld();const e=[],t=this.sortedLabels||this.labels;for(const i of t){this.projected.copy(i.position).project(this.camera);const r=(this.projected.x*.5+.5)*this.width+i.offsetX,s=(-this.projected.y*.5+.5)*this.height+i.offsetY;let a=r>-50&&r<this.width+50&&s>-20&&s<this.height+35;if(a&&i.kind==="system"){const o={x:r-53,y:s,w:106,h:32,systemId:i.systemId};i.priority<80&&this.camera.zoom<1.7&&(a=!e.some(l=>o.x<l.x+l.w&&o.x+o.w>l.x&&o.y<l.y+l.h&&o.y+o.h>l.y)),a&&e.push(o)}i.element.style.visibility=a?"visible":"hidden",i.element.style.transform=`translate(${Math.round(r)}px, ${Math.round(s)}px)${i.kind==="system"?" translateX(-50%)":""}`}this.placeRoutes(),this.labelsDirty=!1}setPaused(e){const t=!!e;this.paused===t||this.disposed||(this.paused=t,this.cancelScheduledFrame(),this.requestFrame())}cancelScheduledFrame(){this.frame!=null&&cancelAnimationFrame(this.frame),this.frameTimer!=null&&clearTimeout(this.frameTimer),this.frame=null,this.frameTimer=null,this.lastTime=0}requestFrame(){this.needsRender=!0,this.frameTimer!=null&&(clearTimeout(this.frameTimer),this.frameTimer=null),this.scheduleFrame()}scheduleFrame(e=0){this.frame!=null||this.frameTimer!=null||this.disposed||document.hidden||!this.surfaceVisible||!this.viewportVisible||(e>0?this.frameTimer=setTimeout(()=>{this.frameTimer=null,this.scheduleFrame()},e):this.frame=requestAnimationFrame(this.animate))}animate(e){if(this.frame=null,this.disposed||document.hidden||!this.surfaceVisible||!this.viewportVisible)return;const t=Math.min(64,this.lastTime?e-this.lastTime:16);this.lastTime=e;const i=this.reducedMotion.matches||this.paused?1:1-Math.exp(-t/95),r=this.camera.position.x,s=this.camera.position.y,a=this.camera.zoom,l=Math.abs(r-this.target.x)+Math.abs(s-this.target.y)+Math.abs(a-this.targetZoom)<=.001;this.camera.position.x=l?this.target.x:fl.lerp(r,this.target.x,i),this.camera.position.y=l?this.target.y:fl.lerp(s,this.target.y,i),this.camera.zoom=l?this.targetZoom:fl.lerp(a,this.targetZoom,i);const c=r!==this.camera.position.x||s!==this.camera.position.y||a!==this.camera.zoom;a!==this.camera.zoom&&this.camera.updateProjectionMatrix(),c&&(this.labelsDirty=!0);const d=!this.paused&&!this.reducedMotion.matches&&this.selectionRings.length>0&&!this.contextLost;if(this.needsRender||c||d&&e-this.lastRenderTime>=1e3/30){if(d)for(const h of this.selectionRings)h.rotation.z=e*9e-5;this.labelsDirty&&this.placeLabels(),this.contextLost||this.renderer?.render(this.scene,this.camera),this.lastRenderTime=e,this.needsRender=!1}const u=this.camera.position.x!==this.target.x||this.camera.position.y!==this.target.y||this.camera.zoom!==this.targetZoom;!this.paused&&u?this.scheduleFrame():d&&this.scheduleFrame(Math.max(1,1e3/30-(performance.now()-this.lastRenderTime)))}clearGroup(e){const t=new Set,i=new Set;e.traverse(r=>{if(r.geometry&&t.add(r.geometry),r.material)for(const s of Array.isArray(r.material)?r.material:[r.material])i.add(s)});for(const r of t)r.dispose();for(const r of i)r.dispose();e.clear()}dispose(){if(!this.disposed){this.disposed=!0,this.cancelScheduledFrame(),this.abort.abort(),this.resizeObserver.disconnect(),this.intersectionObserver.disconnect(),this.clearGroup(this.dynamicGroup),this.clearGroup(this.staticGroup);for(const e of this.resources)e.dispose();this.renderer?.dispose(),this.canvas.remove(),this.routeLayer.remove(),this.labelLayer.remove(),this.tooltip.remove(),this.backdropLabel.remove(),this.fallbackNotice?.remove(),this.contextNotice?.remove(),this.container.classList.remove("galaxy-view","galaxy-fallback","galaxy-dragging","galaxy-pointing")}}}const Pi=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),PS={player:"⌘",veyr:"◈",khar:"⛨",choir:"✧"};function Dh(n){const e=`<span class="government-seal" style="--government-color:${n.color||"#8296a5"}" aria-hidden="true">${PS[n.id]||"?"}</span><span>${Pi(n.shortName||n.name)}</span>`;return n.id?`<button class="government-link" data-action="report-diplomacy" data-target="${n.id}" title="Open diplomacy with ${Pi(n.name)}">${e}</button>`:`<span class="government-link unidentified-government">${e}</span>`}function LS(n){const e={war:"At war",trade:"Trade partners",truce:"Truce",peace:"At peace"}[n.status],t=n.tradeEndsAt?`Trade ends cycle ${n.tradeEndsAt}`:n.status==="truce"?`Until cycle ${n.truceUntil}`:n.sinceTurn!==null?`Since cycle ${n.sinceTurn}`:"Current public status";return`<article class="foreign-relation status-${n.status}" data-status="${n.status}">${Dh(n.participants[0])}<div class="foreign-commitment"><strong>${e}</strong><small>${t}</small></div>${Dh(n.participants[1])}</article>`}function Op(n){return`${n.systemId?`<button class="small-button ghost" data-action="report-inspect" data-system="${n.systemId}">Inspect ${Pi(n.systemName||"world")} →</button>`:""}${n.targetId?`<button class="small-button ghost" data-action="report-diplomacy" data-target="${n.targetId}">Open diplomacy →</button>`:""}`}function NS(n,e,t){const i=t?.stopBefore&&n.systems.find(a=>a.id===t.stopBefore.systemId),r=n.factions.find(a=>a.id===e.owner);if(!i?.owner||i.owner===e.owner||r.relations[i.owner].trade||r.relations[i.owner].status==="war")return"";const s=Fd(n,e.owner,1/0).find(a=>a.systemId===i.id&&a.to.id===i.owner);return s?`<div class="route-public-cause"><p>Cycle ${s.turn}: ${Pi(s.to.shortName)} took ${Pi(s.systemName)} from ${Pi(s.from.shortName)}. This course now crosses closed borders.</p><button data-action="report-inspect" data-system="${i.id}">Inspect world</button><button data-action="report-diplomacy" data-target="${s.to.id}">Negotiate access</button></div>`:""}function DS(n,e){const t=n.systems.find(r=>r.id===e),i=Fd(n,"player",1/0).find(r=>r.systemId===e&&r.to.id===t?.owner);return i?`<div class="sovereignty-note"><div class="section-label">PUBLIC RECORD · CYCLE ${i.turn}</div><p>${Pi(i.to.name)} took control of this world from ${Pi(i.from.name)}.</p></div>`:""}function US(n,{dispatchesOpen:e=!1}={}){const t=Pb(n),i=Lb(n),r=t.filter(a=>a.status==="war").length,s=i.slice(0,4);return`<section class="foreign-affairs" aria-labelledby="foreign-affairs-title"><div class="affairs-heading"><div><div class="eyebrow">GOVERNMENT BROADCASTS</div><h3 id="foreign-affairs-title">Across the Reach</h3></div><span class="affairs-count ${r?"has-war":""}">${r?`${r} public ${r===1?"war":"wars"}`:"Foreign relations"}</span></div><p class="affairs-lead">The commitments of other civilizations. These agreements do not change their relations with the Concord.</p><div class="foreign-relationships" data-public-relationships>${t.length?t.map(LS).join(""):'<p class="empty-note">No foreign commitments received. Establish contact to hear a government’s public announcements.</p>'}</div>${s.length?`<details class="public-dispatches" ${e?"open":""}><summary>Recent public dispatches <span>${s.length}</span></summary><div>${s.map(a=>`<article class="public-dispatch" data-public-dispatch="${a.id}"><time>CYCLE ${a.turn}</time><div><p>${Pi(a.text)}</p><div class="public-affair-links">${Op(a)}</div></div></article>`).join("")}</div><button class="small-button ghost" data-action="report-chronicle">Full chronicle →</button></details>`:""}<p class="affairs-footnote">Broadcasts report commitments and charted sovereignty. Distant fleets still require local sensors.</p></section>`}const ii=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]);function Ls(n,e,t,i,r=null){const s=n.actions[e];return`<button ${e==="war"?'class="danger"':""} data-action="${r||"diplomacy"}" data-stance="${e}" data-target="${t}" ${s.enabled?"":"disabled"} title="${ii(s.enabled?s.effect:s.reason)}">${i}</button>`}function OS(n,e={}){const t=n.factions.find(s=>s.id==="player");let i='<div class="page-top"><div><div class="eyebrow">THE INTERSTELLAR ASSEMBLY</div><h2>Voices in the void</h2><p>Rivals have ambitions of their own. Trade opens borders only by agreement; frontier claims create tension, and peace binds both empires.</p></div><div class="page-symbol">⛨</div></div>';const r=xs(n).filter(s=>s.to==="player");for(const s of r)i+=s.kind==="trade"?`<div class="callout peace-offer trade-offer"><div><div class="eyebrow">TRADE PROPOSAL · EXPIRES CYCLE ${s.expiresTurn}</div><h3>${ii(Ke[s.from].name)} requests open borders</h3><p>They fund the ${s.credits}-credit treaty fee. Accept for one order to open both borders and begin trade income; your treasury pays no signing fee. Borders stay closed while you decide.</p></div><button class="primary" data-action="review-trade" data-offer="${s.id}">Review terms →</button></div>`:`<div class="callout peace-offer"><div><div class="eyebrow">PEACE PROPOSAL · EXPIRES CYCLE ${s.expiresTurn}</div><h3>${ii(Ke[s.from].name)} offers a settlement</h3><p>Receive ${s.credits} credits and agree to a ${s.truceTurns}-cycle mutual truce. Fleets inside each other's territory return to their nearest colony when accepted.</p></div><button class="primary" data-action="review-peace" data-offer="${s.id}">Review terms →</button></div>`;i+=US(n,e);for(const s of n.factions.filter(a=>a.id!=="player")){const a=t.contacts.includes(s.id),o=t.relations[s.id],l=a?Di(n,"player",s.id):null,c=a?s.eliminated?"Fallen":l.truceRemaining>0?`Truce · ${l.truceRemaining} cycles`:l.tradeEndingIn>0?`Trade ending · ${l.tradeEndingIn}`:o.trade?"Trade partner":o.status:"No contact";i+=`<article class="rival-card" data-rival="${s.id}" style="--faction:${a?Ke[s.id].color:"#788898"}"><div class="rival-seal">${a?{veyr:"◈",khar:"⛨",choir:"✧"}[s.id]:"?"}</div><div><div class="eyebrow bilateral-label">RELATIONS WITH THE CONCORD</div><h3>${a?ii(s.name):"Unidentified civilization"}<span class="relation-tag ${o.status==="war"&&a?"war":""}">${c}</span></h3><div class="leader">${a?ii(s.leader):"A signal beyond our charted stars"}</div><p>${a?`${ii(s.description)}<br><em>“${ii(s.motto)}”</em>`:"Explore connected systems to establish first contact. Our envoys cannot negotiate with a civilization we have not encountered."}</p>`,a&&(i+=`<button class="small-button ghost dossier-button" data-action="rival-dossier" data-target="${s.id}" aria-controls="inspector" aria-label="View ${ii(s.name)} civilization dossier" aria-pressed="${e.selectedRivalId===s.id}">Civilization dossier ↗</button>`),a&&!s.eliminated&&(i+=`<div class="diplomatic-stats"><span>Trust <b>${o.trust}</b></span><span>Our grievance <b>${l.ourGrievance}</b></span><span>Their grievance <b>${l.theirGrievance}</b></span><span>Shared borders <b>${l.borderCount}</b></span></div><p class="empty-note">${o.trade?`Trade income +${t.techs.includes("diplomacy")?10:6} credits / cycle · Open borders`:o.status==="war"?"Military access · Hostile fleets engage on arrival":"Closed borders"} · Proposals use 1 order</p>`,l.tradeEndingIn>0&&(i+=`<div class="diplomatic-notice">Trade and border access end on cycle ${l.tradeEndsAt}. Foreign fleets will withdraw from each other's territory.</div>`),l.truceRemaining>0&&(i+=`<div class="diplomatic-notice">Neither empire can declare war before cycle ${l.truceUntil}. The signed settlement binds both sides.</div>`),o.status==="war"&&(i+=`<p class="diplomatic-willingness">${ii(l.incomingOffer?`Their funded offer remains open until cycle ${l.incomingOffer.expiresTurn}. Receive ${l.incomingOffer.credits} credits on acceptance.`:l.actions.peace.reason||l.actions.peace.willingness?.reason||"")}</p>`),i+='<div class="rival-actions">',o.status==="war"?l.incomingOffer?i+=`<button data-action="review-peace" data-offer="${l.incomingOffer.id}">Review their peace offer</button>`:i+=Ls(l,"peace",s.id,"Propose peace ◈60","peace-confirmation"):(l.incomingTradeOffer?i+=`<button data-action="review-trade" data-offer="${l.incomingTradeOffer.id}">Review their trade offer</button>`:o.trade?i+=Ls(l,"endTrade",s.id,"End trade","end-trade-confirmation"):i+=Ls(l,"trade",s.id,"Trade treaty ◈30"),i+=Ls(l,"gift",s.id,"Send gift ◈35"),i+=Ls(l,"war",s.id,"Declare war","declare-war")),i+="</div>",l.policy&&(i+=`<p class="diplomatic-policy">${ii(l.policy)}</p>`)),i+="</div></article>"}return i}const Xs=512,qs=320,FS=24,BS=new Set(["scout","colony","frigate","cruiser"]),Vi=new Map;let un=null,yo=!1,Jl=null;function kS(n){if(typeof n!="string")return"#76d7c4";const e=n.toLowerCase();return/^#[0-9a-f]{6}$/.test(e)?e:/^#[0-9a-f]{3}$/.test(e)?`#${[...e.slice(1)].map(t=>t+t).join("")}`:"#76d7c4"}function $S(n,e){const t=(r,s=.48,a=.48)=>new qu({color:r,roughness:s,metalness:a}),i=(r,s=1)=>new qu({color:r,emissive:r,emissiveIntensity:s,roughness:.35,metalness:.2});return{hull:t(e?"#65767c":"#8399ac"),pale:t(e?"#bcb49b":"#d3d4c8",.52,.32),panel:t(e?"#3b5158":"#455d73",.58),dark:t("#172b3b",.65,.35),edge:t(e?"#d2b772":"#bacad3",.3,.65),accent:t(n,.38,.4),trim:t(e?"#bf9657":"#738d9d",.4,.65),glass:i(e?"#6d9ea2":"#398baf",.22),lamp:i(e?"#efcf91":"#c0e7e7",.65),engine:i(e?"#c8adee":"#8ed8f3",1.5)}}function zS(n,e,t){const i=new fr,r=$S(e,t),s=new Map,a=(x,E)=>(s.has(x)||s.set(x,E()),s.get(x)),o=(x,E,b=0,w=0,S=0)=>{const T=new Un(x,E);return T.position.set(b,w,S),T.castShadow=T.receiveShadow=!0,i.add(T),T},l=(x,E,b,w,S,T,y=r.hull)=>{const A=o(a("box",()=>new gs(1,1,1)),y,x,E,b);return A.scale.set(w,S,T),A},c=(x,E,b,w,S,T,y=r.pale)=>{const A=o(a("sphere",()=>new Xo(1,16,10)),y,x,E,b);return A.scale.set(w,S,T),A},d=(x,E,b,w,S,T=r.hull,y="x",A=w)=>{const C=a(`cylinder:${w}:${A}:${S}`,()=>new Id(A,w,S,16)),L=o(C,T,x,E,b);return y==="x"&&(L.rotation.z=-Math.PI/2),y==="z"&&(L.rotation.x=Math.PI/2),L},u=(x,E,b,w,S,T=r.edge,y="x")=>{const A=a(`ring:${w}:${S}`,()=>new Dd(w,S,8,32)),C=o(A,T,x,E,b);return y==="x"&&(C.rotation.y=Math.PI/2),y==="y"&&(C.rotation.x=Math.PI/2),C},h=(x,E,b=0,w=r.hull,S=.065)=>{const T=new xf(x.map(([A,C])=>new le(A,-C))),y=o(new Nd(T,{depth:E,bevelEnabled:S>0,bevelSegments:1,steps:1,bevelSize:S,bevelThickness:S}),w,0,b,0);return y.rotation.x=-Math.PI/2,y},f=(x,E,b=.09,w=r.edge)=>{const S=new P(...x),T=new P(...E),y=l(...S.clone().add(T).multiplyScalar(.5).toArray(),b,S.distanceTo(T),b,w);return y.quaternion.setFromUnitVectors(new P(0,1,0),T.sub(S).normalize()),y},p=(x,E,b,w,S)=>{d(x,E,b,w,S,r.panel),d(x+S*.22,E,b,w*1.08,S*.28,r.hull),d(x-S*.46,E,b,w*.93,.1,r.dark),u(x-S*.52,E,b,w*.73,w*.16,r.edge),d(x-S*.55,E,b,w*.58,.035,r.engine);for(let T=-1;T<=1;T+=2)l(x,E+w*.91,b+T*w*.35,S*.63,.045,w*.18,r.trim)},v=(x,E,b,w,S=.22,T="x")=>{for(let y=0;y<w;y++)l(x+(T==="x"?y*S:0),E,b+(T==="z"?y*S:0),T==="x"?.085:.035,.045,T==="z"?.085:.035,r.lamp)},m=(x,E,b,w=5)=>{l(x,E,b,.85,.09,.5,r.dark);for(let S=0;S<w;S++)l(x-.34+S*.17,E+.045,b,.055,.08,.45,r.trim)},g=(x,E,b,w=!1)=>{d(x,E,b,w?.23:.16,.09,r.dark,"y"),l(x+.015,E+.09,b,w?.43:.29,.16,w?.32:.24,r.hull);for(const S of[-1,1])d(x+(w?.43:.31),E+.12,b+S*(w?.105:.065),w?.04:.027,w?.65:.43,r.edge)};if(n==="scout"){h([[2.7,0],[1.18,-.32],[-1.45,-.35],[-1.9,0],[-1.45,.35],[1.18,.32]],.28,-.12),h([[1.65,0],[.55,-.26],[-.45,-.22],[-.6,.22],[.55,.26]],.2,.2,r.panel,.04),h([[1.3,0],[.55,-.18],[.1,-.16],[.1,.16],[.55,.18]],.07,.42,r.glass,.015);for(const x of[-1,1])h([[.25,x*.25],[-.7,x*1.7],[-1.8,x*1.47],[-1.15,x*.24]],.1,-.04,r.panel,.035),h([[-.1,x*.39],[-.79,x*1.44],[-1.05,x*1.34],[-.58,x*.35]],.035,.095,r.accent,.015),p(-1.3,-.02,x*1.33,.19,1.2),f([.35,.18,x*.27],[.15,.28,x*1.5],.045,r.edge),d(.15,.28,x*1.5,.07,.52,r.edge);l(-.75,.26,0,.8,.06,.15,r.accent),m(-.77,.26,0,4),f([-.15,.4,0],[-.38,.85,0],.045),c(-.38,.85,0,.07,.045,.16,r.edge),v(.15,.36,.25,3,.23)}else if(n==="colony"){d(0,0,0,.43,4.4,r.pale),c(2.12,0,0,.63,.46,.46,r.pale),c(2.55,.12,0,.17,.22,.31,r.glass),l(.7,.47,0,1.05,.19,.46,r.pale),l(.94,.59,0,.5,.07,.36,r.glass),u(.18,0,0,1.18,.21,r.pale),u(.18,0,0,1.18,.08,r.accent),u(.42,0,0,1.16,.045,r.edge),u(-.06,0,0,1.16,.045,r.edge);for(let x=0;x<8;x++){const E=x*Math.PI/4,b=Math.cos(E),w=Math.sin(E);f([.18,b*.38,w*.38],[.18,b*1.1,w*1.1],.09,r.trim),c(.18,b*1.18,w*1.18,.17,.13,.13,r.glass)}for(const x of[-1,1]){l(-1.15,-.18,x*.67,1.7,.28,.18,r.dark);for(let E=0;E<3;E++){const b=-1.72+E*.58;l(b,-.02,x*.76,.48,.65,.5,r.pale),l(b,.32,x*.76,.48,.055,.43,r.accent),l(b,-.02,x*1.02,.13,.54,.035,r.trim)}p(-2.05,-.07,x*.75,.26,.82),c(1.13,-.4,x*.58,.68,.3,.3,r.pale),u(1.15,-.4,x*.58,.285,.045,r.trim)}d(-2.2,0,0,.41,.36,r.panel),d(-2.4,0,0,.28,.035,r.engine),v(.8,.29,.37,5,.24)}else if(n==="frigate"){h([[3.15,0],[2.1,-.48],[.4,-.62],[-1.65,-.47],[-2.25,-.25],[-2.25,.25],[-1.65,.47],[.4,.62],[2.1,.48]],.44,-.2),h([[2.77,0],[1.7,-.32],[-1.35,-.34],[-1.7,.34],[1.7,.32]],.18,.29,r.panel,.055),h([[2.5,0],[1.45,-.1],[-.7,-.1],[-.7,.1],[1.45,.1]],.04,.53,r.accent,.02);for(const x of[-1,1]){h([[.1,x*.4],[-.7,x*1.11],[-2.25,x*1],[-1.6,x*.35]],.18,-.12,r.panel),p(-1.65,-.04,x*.94,.33,1.65),l(-1.15,.31,x*.96,.65,.07,.27,r.accent);for(let E=0;E<4;E++)l(.15+E*.37,.11,x*.57,.23,.17,.13,r.edge);m(-.8,.5,x*.36,4),g(.55,.36,x*.52)}l(-.55,.64,0,.7,.28,.47,r.hull),l(-.35,.85,0,.68,.12,.55,r.panel),l(-.19,.88,0,.36,.065,.57,r.glass),g(1.42,.56,0),f([-.87,.71,0],[-1.02,1.15,0],.055),l(-1.02,1.15,0,.08,.05,.46,r.edge),v(-.58,.76,.25,3,.18)}else{h([[3,-.83],[2.45,-1.36],[1.65,-1.32],[1.3,-.82],[-1.7,-.9],[-2.5,-.58],[-2.5,.58],[-1.7,.9],[1.3,.82],[1.65,1.32],[2.45,1.36],[3,.83]],.58,-.29,r.hull,.09),h([[2.82,-.7],[2.34,-1.16],[1.8,-1.1],[1.52,-.59],[-1.7,-.64],[-2.1,.64],[1.52,.59],[1.8,1.1],[2.34,1.16],[2.82,.7]],.19,.36,r.panel,.05),h([[2.7,-.28],[1.5,-.34],[-1.8,-.34],[-1.8,.34],[1.5,.34],[2.7,.28]],.12,.59,r.hull,.04),l(2.51,.59,0,.24,.06,1.72,r.accent);for(const x of[-1,1]){for(const E of[.42,.95])p(-2.07,-.11,x*E,E<.5?.29:.36,1.25);h([[1.32,x*.64],[.64,x*1.07],[-1.72,x*1.1],[-2.1,x*.76]],.22,.12,r.hull,.045),l(-.7,.41,x*1,1.25,.045,.1,r.accent),m(-1.4,.6,x*.59,5);for(let E=0;E<3;E++)g(-.65+E*.72,.57,x*.72,E===2);for(let E=0;E<6;E++)l(-1.6+E*.48,-.08,x*.92,.29,.17,.07,r.dark);v(-.2,.32,x*1.14,5,.25)}l(-.58,.86,0,1.28,.27,.68,r.panel),l(-.61,1.08,0,.85,.21,.55,r.hull),l(-.49,1.25,0,.75,.13,.78,r.panel),l(-.32,1.28,0,.4,.075,.8,r.glass),g(1.23,.78,0,!0),f([-1,1.16,0],[-1.22,1.64,0],.065),l(-1.22,1.64,0,.09,.06,.55,r.edge),v(-.87,1.24,.41,4,.18)}if(t){const x=n==="scout"?.37:n==="colony"?.48:.64;for(const E of[-1,1])for(let b=0;b<4;b++)l(.3+b*.32,n==="colony"?.41:n==="cruiser"?.73:.5,E*x*.45,.055,.045,x*.45,r.trim);c(-.15,n==="cruiser"?1.15:n==="colony"?.48:.53,0,.11,.07,.11,r.engine)}return i.userData.materials=Object.values(r),i.updateMatrixWorld(!0),i}function HS(n){const e=new _r().setFromObject(n),t=e.getCenter(new P),i=new ma(-4,4,2.5,-2.5,.1,100);i.position.copy(t).add(new P(8,6.5,10)),i.lookAt(t),i.updateMatrixWorld();const r=new _r;for(const o of[e.min.x,e.max.x])for(const l of[e.min.y,e.max.y])for(const c of[e.min.z,e.max.z])r.expandByPoint(new P(o,l,c).applyMatrix4(i.matrixWorldInverse));const s=Xs/qs,a=Math.max((r.max.y-r.min.y)/2,(r.max.x-r.min.x)/(2*s))*1.09;return i.left=-a*s,i.right=a*s,i.top=a,i.bottom=-a,i.updateProjectionMatrix(),i}function GS(){if(un||yo)return un;const n=document.createElement("canvas"),e={alpha:!0,antialias:!0,premultipliedAlpha:!0,preserveDrawingBuffer:!0,powerPreference:"low-power"},t=n.getContext("webgl2",e);return t?(un=new Ff({canvas:n,context:t,...e}),un.setPixelRatio(1),un.setSize(Xs,qs,!1),un.setClearColor(0,0),un.outputColorSpace=hn,un.toneMapping=md,un.toneMappingExposure=1.12,un.shadowMap.enabled=!0,un.shadowMap.type=ks,n.addEventListener("webglcontextlost",i=>{i.preventDefault(),yo=!0,un=null}),un):(yo=!0,null)}function VS(n,e){const t=GS();if(!t)return null;const i=new cf;i.add(n,new _v("#c5e1f2","#233047",1.05));let r;for(const[s,a,o]of[["#e2efff",2.8,[-3,8,6]],["#8ca9d9",1.25,[3,3,-7]],["#ffe2b7",2.1,[-6,4,-3]]]){const l=new Sv(s,a);l.position.set(...o),r||(r=l,l.castShadow=!0,l.shadow.mapSize.set(512,512),Object.assign(l.shadow.camera,{left:-5,right:5,top:5,bottom:-5,near:.1,far:30}),l.shadow.bias=-2e-4,l.shadow.normalBias=.018),i.add(l)}try{return t.render(i,e),t.domElement.toDataURL("image/png")}finally{r.shadow.dispose(),t.renderLists.dispose(),i.remove(n)}}function WS(n,e){Jl||=Object.assign(document.createElement("canvas"),{width:Xs,height:qs});const t=Jl.getContext("2d");t.clearRect(0,0,Xs,qs);const i=new yt().multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),r=new P(-3,8,6).normalize(),s=[],a=new P,o=new P,l=new P,c=new P,d=new P,u=new P,h=new P,f=new P;n.traverse(p=>{if(!p.isMesh)return;const v=p.geometry.attributes.position,m=p.geometry.index,g=m?m.count:v.count;for(let x=0;x<g;x+=3){if(a.fromBufferAttribute(v,m?m.getX(x):x).applyMatrix4(p.matrixWorld),o.fromBufferAttribute(v,m?m.getX(x+1):x+1).applyMatrix4(p.matrixWorld),l.fromBufferAttribute(v,m?m.getX(x+2):x+2).applyMatrix4(p.matrixWorld),c.crossVectors(u.subVectors(o,a),h.subVectors(l,a)).normalize(),d.copy(a).add(o).add(l).multiplyScalar(1/3),c.dot(f.subVectors(e.position,d))<=0)continue;const E=p.material,b=.38+Math.max(0,c.dot(r))*.87,w=E.color.clone().multiplyScalar(b);E.emissive&&w.add(E.emissive.clone().multiplyScalar(E.emissiveIntensity*.55));const S=d.applyMatrix4(e.matrixWorldInverse).z,T=[a,o,l].map(y=>(y.applyMatrix4(i),[(y.x*.5+.5)*Xs,(-y.y*.5+.5)*qs]));s.push({points:T,depth:S,color:w.getStyle()})}}),s.sort((p,v)=>p.depth-v.depth),t.lineJoin="round",t.lineWidth=.45;for(const{points:p,color:v}of s)t.beginPath(),t.moveTo(...p[0]),t.lineTo(...p[1]),t.lineTo(...p[2]),t.closePath(),t.fillStyle=t.strokeStyle=v,t.fill(),t.stroke();return Jl.toDataURL("image/png")}function XS(n){const e=new Set;n.traverse(t=>{t.geometry&&e.add(t.geometry)});for(const t of e)t.dispose();for(const t of n.userData.materials)t.dispose()}function qS(n,{color:e="#76d7c4",ancient:t=!1}={}){n=BS.has(n)?n:"scout",e=kS(e),t=!!t;const i=`${n}:${e}:${t}`;if(Vi.has(i)){const a=Vi.get(i);return Vi.delete(i),Vi.set(i,a),a}const r=zS(n,e,t);let s;try{const a=HS(r);try{s=VS(r,a)}catch{yo=!0,un?.dispose(),un=null}s||=WS(r,a)}finally{XS(r)}return Vi.set(i,s),Vi.size>FS&&Vi.delete(Vi.keys().next().value),s}function Ui(n,e="player",t=!1){return Re[n]?`<img class="ship-portrait" src="${qS(n,{color:Ke[e]?.color||Ke.player.color,ancient:t})}" width="512" height="320" alt="${t?"Ancient ":""}${Re[n].name} hull" decoding="async" />`:""}const zt=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),Fp=n=>`${n>=0?"+":"−"}${Math.abs(n)}`,Bp=n=>n===2?"II":"I",YS={credits:"credits",minerals:"minerals",science:"science",production:"production",orders:"orders",repair:"orbital repair",militaryDiscount:"military mineral saving"};function ld(n,e=!0){return Object.entries(YS).filter(([t])=>n?.[t]).map(([t,i])=>`${e?Fp(t==="militaryDiscount"?Math.round(n[t]*100):n[t]):t==="militaryDiscount"?Math.round(n[t]*100):n[t]}${t==="militaryDiscount"?"%":""} ${i}`).join(" · ")}function Uh(n){if(!n?.nominal)return"";const e=n.change!==n.nominal;return`<p class="order-effect ${e?"capped":""}">Empire orders: <b>${n.current} → ${n.projected}</b> / cycle. ${Fp(n.change)} usable ${Math.abs(n.change)===1?"order":"orders"}${e?` · ${n.limit}-order cap applied`:""}.</p>`}function Ys(n){const e=n.charter;return e?`${jt[e.type].name} ${Bp(e.level)}`:"Unchartered"}function ZS(n,e){const t=Fn(n,e);return`<section class="panel-section colony-development"><div class="section-label">Infrastructure <span>${t.used} / ${t.capacity} slots</span></div><div class="slot-track" aria-label="${t.used} of ${t.capacity} infrastructure slots occupied">${Array.from({length:Math.max(t.used,t.capacity)},(i,r)=>`<i class="${r<t.used?"occupied":""}${r>=t.capacity?" legacy-slot":""}"></i>`).join("")}</div><div class="building-pills">${e.buildings.map(i=>`<span class="building-pill" title="${zt(Ye[i].description)}">${Ye[i].icon} ${zt(Ye[i].name)}</span>`).join("")||'<p class="empty-note">A new world, waiting to take shape.</p>'}</div><p class="development-hint">${t.overCapacity?"Existing infrastructure is retained. Replace a building to change this world’s role.":t.available>0?`${t.available} open ${t.available===1?"slot":"slots"}. More population opens slots, up to five.`:"All slots occupied. Replace infrastructure or grow the colony."}</p><div class="charter-summary"><span class="charter-emblem">${e.charter?jt[e.charter.type].icon:"⌂"}</span><div><b>${zt(Ys(e))}</b><p>${e.charter?"A specialized colonial economy.":"Give this world a lasting specialty."}</p></div><button class="small-button ghost" data-action="development-menu" data-system="${e.id}">${e.charter?"Manage":"Develop"} →</button></div>${e.charter?`<p class="charter-current-effects">${zt(ld(Ni(e)))}</p>`:""}</section>`}function KS(n,e,t="building",i=null){const r=n.systems.find(d=>d.id===e),s=Fn(n,r),a=dt(n,r),o=r.charter&&jt[r.charter.type],l=i&&Ye[i];let c=`<div class="eyebrow">COLONIAL COMMISSION · ${zt(r.name)}</div><h2 id="modal-title">Shape this world's future</h2><p class="modal-lead">${s.used} / ${s.capacity} infrastructure slots · ${a.production} production per cycle. Each commission costs one order. Payment is made now; the project completes over the following cycles.</p><div class="filter-tabs construction-tabs">${[["building","Infrastructure"],["charter","Colony charter"],["ship","Ships"]].map(([d,u])=>`<button data-action="construction-tab" data-system="${e}" data-tab="${d}" class="${d===t?"active":""}" aria-pressed="${d===t}">${u}</button>`).join("")}</div>`;return t==="charter"?(c+=`<div class="charter-intro"><strong>${r.charter?zt(Ys(r)):"One world. One specialty."}</strong><p>A charter uses existing infrastructure and no extra slot. Level I requires population 4 and Deep-space Logistics. Level II requires population 8 and Autonomous Industry. Current benefits continue while a new charter is commissioned.</p></div><div class="build-grid charter-grid">`,c+=_s(n,e).map(d=>{const u=jt[d.charterType],h=r.charter&&r.charter.type!==d.charterType;return`<button class="build-card charter-card" data-action="develop" data-system="${e}" data-charter="${d.charterType}" ${d.enabled?"":"disabled"}><span class="build-icon">${d.icon}</span><div><span class="charter-tier">${d.completed?"Established":h?"Switch to":r.charter?.type===d.charterType?"Upgrade to":"Establish"} level ${Bp(d.level)}</span><b>${zt(u.name)}</b><p>${zt(u.description||"")}</p><p class="charter-effects">${zt(ld(d.bonuses))}</p>${r.charter?`<p class="charter-delta">Change: ${zt(ld(d.delta)||"No change")}</p>`:""}${Uh(d.orderEffect)}<div class="build-cost">◈ ${d.cost.credits} &nbsp; ◇ ${d.cost.minerals} · ${d.turns} cycles · 1 order</div><p class="charter-support">Requires ${zt(Ye[u.support].name)}</p>${d.reason&&d.reason!==`Requires ${Ye[u.support].name}`?`<p class="build-reason">${zt(d.reason)}</p>`:""}${h?`<p class="build-reason">Replaces ${zt(Ys(r))} on completion. Its investment is not refunded.</p>`:""}</div></button>`}).join(""),c+"</div>"):(t==="building"?(c+=`<div class="replacement-control"><label for="replace-building">${s.available>0?"Use an open slot, or replace existing infrastructure":"Choose infrastructure to replace"}</label><select id="replace-building" data-system="${e}"><option value="">${s.available>0?"Use an open slot":"Select a building to replace…"}</option>${r.buildings.map(d=>`<option value="${d}" ${d===i?"selected":""}>Replace ${zt(Ye[d].name)}</option>`).join("")}</select></div>`,l&&(c+=`<div class="callout replacement-warning"><strong>${zt(l.name)} remains active until the new building is finished.</strong> Its benefits are then removed.${o?.support===i?` This also removes the ${zt(Ys(r))} charter.`:""}${i==="beacon"?" Removing this beacon may interrupt your alignment.":""} Cancelling construction keeps the existing infrastructure.</div>`)):c+='<p class="empty-note construction-note">Ships need an Orbital Shipyard and do not occupy infrastructure slots. Forge charter discounts are included in the prices below.</p>',c+='<div class="build-grid">'+vi(n,e,"player",t==="building"?i:null).filter(d=>d.kind===t&&(!d.discovery||r.anomaly?.id===d.discovery)).map(d=>`<button class="build-card ${t==="ship"?"ship-build-card":""}" data-action="build" data-system="${e}" data-item="${d.id}" ${t==="building"&&i?`data-replace="${i}"`:""} ${d.enabled?"":"disabled"} title="${zt(d.reason||d.description)}">${t==="ship"?Ui(d.id):`<span class="build-icon">${d.icon}</span>`}<div><b>${zt(d.name)}</b><p>${zt(d.description)}</p>${Uh(d.orderEffect)}<div class="build-cost">◈ ${d.cost.credits} &nbsp; ◇ ${d.cost.minerals} · ${d.turns} cycles${t==="ship"?` · ${d.upkeep} upkeep`:""}</div>${d.reason?`<p class="build-reason">${zt(d.reason)}</p>`:""}</div></button>`).join("")+"</div>",c)}const ro=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),jl=[["name","World"],["credits","◈ Credits"],["minerals","◇ Minerals"],["science","✧ Science"],["production","▥ Work"]];function JS(n,e="name",t="asc"){jl.some(([a])=>a===e)||(e="name");const i=t==="desc"?-1:1,r=n.systems.filter(a=>a.owner==="player").map(a=>({system:a,output:dt(n,a)}));r.sort((a,o)=>(e==="name"?a.system.name.localeCompare(o.system.name):a.output[e]-o.output[e])*i||a.system.name.localeCompare(o.system.name));const s=a=>{const o=jl.find(([l])=>l===a)[1];return`<th scope="col"${e===a?` aria-sort="${t==="desc"?"descending":"ascending"}"`:""}><button data-action="colony-sort" data-sort="${a}" title="Sort colonies by ${a==="name"?"name":a}">${o}<span aria-hidden="true">${e===a?t==="desc"?"↓":"↑":"↕"}</span></button></th>`};return`<div class="colonial-economy-heading"><div><div class="section-label">Colonial administration</div><p>Output per cycle, before fleet upkeep and trade. Select a column to compare your worlds.</p></div><span>${r.length} ${r.length===1?"colony":"colonies"}</span></div><div class="colony-scroll" role="region" aria-label="Colony economy and construction" tabindex="0"><table class="colony-table economy-table"><thead><tr>${s("name")}<th scope="col">Specialty</th>${jl.slice(1).map(([a])=>s(a)).join("")}<th scope="col">Construction</th><th scope="col"><span class="sr-only">Inspect world</span></th></tr></thead><tbody>${r.map(({system:a,output:o})=>{const l=Ko(a.queue);return`<tr data-colony="${a.id}"><td><strong>${ro(a.name)}</strong><small>${a.population} / ${o.capacity} population</small></td><td><span class="colony-charter-name">${ro(Ys(a))}</span><small class="colony-slot-count">${a.buildings.length} / ${Fn(n,a).capacity} slots</small></td>${["credits","minerals","science","production"].map(c=>`<td class="colony-output output-${c}">${o[c]}</td>`).join("")}<td>${l?`<span class="colony-project">${ro(l.name)}</span><small>${Math.ceil((a.queue.work-a.queue.progress)/o.production)} cycles remaining</small>`:'<span class="colony-idle">Idle</span>'}</td><td><button class="small-button ghost" data-action="inspect" data-system="${a.id}" aria-label="Inspect ${ro(a.name)}">↗</button></td></tr>`}).join("")}</tbody></table></div>`}const jS={veyr:{file:"veyr-consortium",position:"62% 42%",alt:"Amber glass exchange halls and orbital terraces above a Veyr world."},khar:{file:"khar-dominion",position:"64% 45%",alt:"A Khar commander overlooking immense foundries lit by molten metal."},choir:{file:"luminous-choir",position:"50% 52%",alt:"The Choir gathered around a luminous shared consciousness beneath an ancient gate."},observatory:{file:"last-observatory",position:"58% 35%",alt:"An expedition beneath a mountain encounters a great astronomical lens and a ring of ancient mirrors."},reef:{file:"patient-reef",position:"52% 48%",alt:"An expedition studies tools grown inside a pale living mineral lattice."}};function kp(n,{wide:e=!1}={}){const t=jS[n];if(!t)return"";const i="./",r=e&&n==="observatory"?"58% 28%":t.position;return`<figure class="narrative-illustration" data-illustration="${n}"><img src="${i}art/${t.file}.webp" width="1536" height="1024" loading="lazy" decoding="async" alt="${t.alt}" style="object-position:${r}" /></figure>`}const gn=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),wn=(n,e)=>`<section class="context-section"><div class="section-label">${n}</div>${e}</section>`,Oh=(n,e)=>`<button class="context-link" data-action="inspect" data-system="${n.id}"><span>${gn(n.name)}<small>${gn(e)}</small></span><span aria-hidden="true">↗</span></button>`;function QS(n,e,{rivalId:t=null}={}){const i=n.factions.find(o=>o.id==="player"),r=It(n),s=n.systems.filter(o=>o.owner==="player");if(e==="research"){const o=i.research&&Tt[i.research.techId],l=s.map(d=>({system:d,science:dt(n,d).science})).sort((d,u)=>u.science-d.science||d.system.name.localeCompare(u.system.name));let c=`<div class="context-heading"><div class="eyebrow">CONCORD RESEARCH COUNCIL</div><h2>Your archives</h2><p>${i.techs.length} of ${Object.keys(Tt).length} sciences recovered</p></div><div class="context-metric"><strong>+${r.scienceIncome}</strong><span>science each cycle</span><small>${Math.floor(i.science)} in reserve</small></div>`;if(o){const d=o.cost-i.research.progress;c+=wn("Commissioned research",`<h3>${gn(o.name)}</h3><p>${gn(o.description)}</p><div class="progress-track"><i style="width:${i.research.progress/o.cost*100}%"></i></div><p>${i.research.progress} / ${o.cost} science · ${r.scienceIncome>0?`${Math.ceil(d/r.scienceIncome)} cycles at current output`:"Awaiting science production"}</p>`);const u=Object.values(Tt).filter(f=>f.requires.includes(o.id)&&!i.techs.includes(f.id)),h=[...Object.values(Ye),...Object.values(Re)].filter(f=>f.requires.includes(o.id));(u.length||h.length)&&(c+=wn("This breakthrough opens",`<ul class="context-list">${h.map(f=>`<li>${gn(f.name)}</li>`).join("")}${u.map(f=>`<li>${gn(f.name)}<small>${f.requires.filter(p=>p!==o.id&&!i.techs.includes(p)).map(p=>`Also needs ${gn(Tt[p].name)}`).join(" · ")||"Research becomes available"}</small></li>`).join("")}</ul>`))}else c+=wn("Research direction",`<p>${i.techs.length===Object.keys(Tt).length?"The sciences of this age are complete. Your archives retain further discoveries.":"Choose a project in the archives. Stored science is applied when you commission it; changing research uses no orders."}</p>`);return c+wn("Research worlds",l.map(({system:d,science:u})=>Oh(d,`${u} science / cycle`)).join(""))}if(e==="diplomacy"){const o=n.factions.find(f=>f.id===t&&i.contacts.includes(f.id))||n.factions.find(f=>f.id!=="player"&&i.contacts.includes(f.id));if(!o)return`<div class="context-heading"><div class="eyebrow">DIPLOMATIC CHANNELS</div><h2>Beyond our signals</h2><p>Explore the Reach to make contact. A civilization's dossier becomes available when your envoys establish a channel.</p></div>${wn("Known commitments","<p>Public announcements can mention an unidentified partner. That does not reveal their civilization or give your fleets sensors in their territory.</p>")}`;const l=Di(n,"player",o.id),c=i.relations[o.id],d=Zn(n).find(f=>f.factionId===o.id);let u=`<div class="context-heading" style="--faction:${Ke[o.id].color}"><div class="eyebrow">CIVILIZATION DOSSIER</div><h2>${gn(o.name)}</h2><p>${gn(o.leader)}</p></div>${kp(o.id)}<div class="context-quotation">“${gn(o.motto)}”</div>${wn("Their civilization",`<p>${gn(o.description)}</p>`)}`;if(o.eliminated)return u+wn("Diplomatic status","<p>This government has fallen. Its public history remains in the Chronicle.</p>");const h=c.status==="war"?"At war. Military fleets engage hostile forces on arrival.":c.trade?`Open borders and +${i.techs.includes("diplomacy")?10:6} credits each cycle from trade.`:"At peace. Borders remain closed without a trade treaty.";return u+=wn("Relations with the Concord",`<p>${h}</p>${l.truceRemaining?`<p>Binding truce through cycle ${l.truceUntil}.</p>`:""}${l.tradeEndingIn?`<p>Trade ends on cycle ${l.tradeEndsAt}; foreign fleets then withdraw.</p>`:""}<button class="wide-button" data-action="rival-channel" data-target="${o.id}">View diplomatic actions →</button>`),d?.beacons>0&&(u+=wn("Public beacon signal",`<p>${d.progress} / ${d.target} alignment</p><p>Beacon locations are public. Their broadcast does not reveal defending fleets.</p><button class="wide-button ghost" data-action="review-network">Review the network →</button>`)),u}if(e==="empire"){const o=ys(n,"player"),l=s.filter(c=>c.queue).sort((c,d)=>(c.queue.work-c.queue.progress)/dt(n,c).production-(d.queue.work-d.queue.progress)/dt(n,d).production);return`<div class="context-heading"><div class="eyebrow">CONCORD ADMINISTRATION</div><h2>The working empire</h2><p>${r.colonies} worlds · ${r.population} billion citizens</p></div><div class="context-metric"><strong>${r.production}</strong><span>construction work each cycle</span><small>${s.length-l.length} idle ${s.length-l.length===1?"colony":"colonies"}</small></div>${wn("Upcoming completions",l.length?l.map(c=>Oh(c,`${Ko(c.queue).name} · ${Math.ceil((c.queue.work-c.queue.progress)/dt(n,c).production)} cycles`)).join(""):"<p>Your construction teams await their next commission.</p>")}${wn("Your beacon network",`<p>${o.progress} / ${o.target} alignment · ${o.cost} credits per advancing cycle</p><p>${gn(o.reason||"Your network is ready. Protect its three sites to keep alignment advancing.")}</p><button class="wide-button ghost" data-action="review-network">Review the network →</button>`)}`}const a=n.systems.map(o=>({system:o,view:Jn(n,o.id)})).filter(({view:o})=>o).sort((o,l)=>+(l.view.phase==="ready")-+(o.view.phase==="ready")||o.system.name.localeCompare(l.system.name));return`<div class="context-heading"><div class="eyebrow">CONCORD HISTORICAL OFFICE</div><h2>Stories of the Reach</h2><p>Received reports and the memory of your expeditions.</p></div>${wn("Latest cycle briefing",n.lastBriefing?`<p>Cycle ${n.lastBriefing.turn} · ${n.lastBriefing.entries.length} dispatches</p><button class="wide-button" data-action="briefing">Read the briefing →</button>`:"<p>Your first briefing arrives after the next cycle.</p>")}${wn("Expedition records",a.length?a.map(({system:o,view:l})=>`<button class="context-link" data-action="anomaly" data-system="${o.id}"><span>${gn(l.name)}<small>${gn(o.name)}${l.phase==="ready"?" · A final choice awaits":""}</small></span><span aria-hidden="true">↗</span></button>`).join(""):"<p>Survey new worlds to discover the histories they hold.</p>")}`}const cd=n=>({id:n.id,name:n.name,owner:n.owner,type:n.type,ships:n.ships,hp:n.hp,maxHp:n.ships*Re[n.type].hp,...n.defenseLead===!0?{defenseLead:!0}:{}});function $p(n,e,t="player"){const i=n.factions.find(s=>s.id===t),r=n.systems.find(s=>s.id===e);return!i||!r?.knownBy.includes(t)?[]:ca(n.fleets.filter(s=>s.owner===t&&s.systemId===e)).map(cd)}function eM(n,e,t,i="player"){const r=n.factions.find(d=>d.id===i),s=n.fleets.find(d=>d.id===e&&d.owner===i),a=n.systems.find(d=>d.id===t);if(!r||!s||Re[s.type]?.attack<4||!a?.knownBy.includes(i))return null;const o=s.systemId===a.id,l=n.lanes.some(([d,u])=>d===s.systemId&&u===a.id||u===s.systemId&&d===a.id);if(!o&&!l)return null;const c=tr(n,i,a.id);return{systemId:a.id,systemName:a.name,context:o?"current-system":"arrival",selected:cd(s),observed:c,opponents:c?ca(Ft(n,i,a.id).filter(d=>d.owner!==i&&r.relations[d.owner]?.status==="war")).map(cd):null,otherFriendly:$p(n,a.id,i).filter(d=>d.id!==s.id),hostileColony:!!(a.owner&&a.owner!==i&&r.relations[a.owner]?.status==="war")}}function wr(n,e,t=1){const i=10**t,r=Math.round(n*i)/i,s=l=>l.toLocaleString(void 0,{maximumFractionDigits:t}),a=s(e);return`${n>0&&r===0?`<${s(1/i)}`:n<e&&r>=e?`<${a}`:s(r)} / ${a}`}const Wi=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]);function tM(n,e,t){const i=eM(n,e,t);if(!i)return"";const r=i.opponents;if(i.observed&&!r.length&&(!i.hostileColony||i.context==="current-system"))return"";const s=i.selected;let a=`<section class="panel-section engagement-preview" data-engagement-system="${Wi(i.systemId)}"><div class="section-label">${i.observed&&r.length?"Engagement plan":"Orbital approach"}</div><div class="engagement-selected">${Ui(s.type,s.owner)}<div><strong>${Wi(s.name)}</strong><small>${s.ships} ${s.ships===1?"ship":"ships"} · ${Wi(wr(s.hp,s.maxHp))} hull</small></div></div><p class="engagement-scope">Only this formation attacks. Nearby friendly fleets do not combine their fire.</p>`;return i.observed?r.length?a+=`<div class="engagement-order-label">Visible opponent order</div><ol class="engagement-order">${r.map(o=>`<li data-opponent-id="${Wi(o.id)}"><strong>${Wi(o.name)}</strong>${o.defenseLead?'<span class="defense-badge">Lead defense</span>':""}<span>${Wi(Ke[o.owner].shortName)} · ${o.ships} ${Wi(Re[o.type].role.toLowerCase())}${o.ships===1?"":"s"} · ${Wi(wr(o.hp,o.maxHp))} hull</span></li>`).join("")}</ol><p class="engagement-sequence">Each exchange lasts up to four rounds. If your formation survives, it faces the next opponent, even if the previous defender also survives. Destruction ends the attack.</p>`:a+='<p class="engagement-clear">No hostile fleets are visible in this orbit.</p>':a+='<p class="engagement-unknown">Fleet presence unknown. Arrival can trigger combat.</p>',i.hostileColony&&(a+='<p class="engagement-colony">Colony invasion is a separate command after hostile fleets are cleared.</p>'),a+=`<div class="engagement-cost">${i.context==="arrival"?"Enter orbit":"Engage"} · 1 order + 1 move</div></section>`,a}const Ns=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]);function Kd(n){return n.defenseLead===!0?'<span class="defense-badge" title="First defensive formation for its government in this system">Lead defense</span>':""}function nM(n,e,t){const i=$p(n,e);if(!i.length)return"";const r=i.filter(l=>Re[l.type].attack>=4);if(!r.length&&i.length<2)return"";const s=i.find(l=>l.defenseLead===!0),a=r.find(l=>l.id===t);let o=`<section class="panel-section defense-controls"><div class="section-label">Defensive lead</div>${s?`<div class="defense-current"><strong>${Ns(s.name)}</strong><span>Takes your first defensive exchange</span></div>`:'<p class="defense-default">Default formation order</p>'}<p class="formation-order-note">Your formations defend separately in the order listed above. A surviving attacker can still reach later defenders.</p>`;if(a){const l=vp(n,a.id),c=l.lead?l.clear:l.assign;o+=`<button class="wide-button defense-command ${l.lead?"ghost":""}" data-action="defense-lead-toggle" data-fleet-target="${Ns(a.id)}" aria-pressed="${l.lead}" ${c.enabled?"":"disabled"}>${l.lead?"Clear lead":"Lead defense"} · ${c.orders} order</button><p class="defense-command-context">${l.lead?"Return to the default order.":`${Ns(a.name)} will take your first defensive exchange${s?`, replacing ${Ns(s.name)}`:""}.`}</p>${c.reason?`<p class="defense-reason">${Ns(c.reason)}</p>`:""}`}else r.length&&(o+='<p class="defense-select-note">Select one of your military formations above to assign or clear its lead. Either change costs one order.</p>');return s&&(o+='<p class="defense-persistence">Leaving this system clears the assignment. Hold position and local combat preserve it while the formation survives.</p>'),o+"</section>"}const es=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),Ql=n=>Number(n.toFixed(2)).toLocaleString();function Jd(n,e){const t=Ii(n,e.id),i=t.held?"Holding":t.ready?"Ready":n.winner?"Ended":t.movesLeft<1?"Spent":"No orders";return`<span class="fleet-ready fleet-attention${t.held?" is-held":""}" title="${es(t.reason)}"><b>${i}</b><small>${t.movesLeft} ${t.movesLeft===1?"jump":"jumps"}</small></span>`}function iM(n,e,t=1){const i=n.fleets.find(o=>o.id===e&&o.owner==="player");if(!i)return'<h2 id="modal-title">Fleet unavailable</h2><p class="modal-lead">Select one of your active fleets to reorganize it.</p>';const r=dp(n,e,t),s=n.systems.find(o=>o.id===i.systemId),a=(o,l,c)=>l?`<article class="split-formation"><div class="eyebrow">${o}</div><strong>${l.ships}<small>${l.ships===1?"ship":"ships"}</small></strong><p>${es(wr(l.hp,l.ships*Re[i.type].hp,2))} hull</p><p>${l.movesLeft} ${l.movesLeft===1?"jump":"jumps"} remaining</p><small>${c&&r.originalHasRoute?"Keeps its plotted course":"No course plotted"}</small></article>`:"";return`<div class="eyebrow">CONCORD FLEET COMMAND · ${es(s.name)}</div><h2 id="modal-title">Divide ${es(i.name)}</h2><div class="split-introduction">${Ui(i.type,i.owner,!!i.heritage?.length)}<p>Leave a garrison or send a separate expedition. The two formations keep the same total ships and hull, and each retains its remaining movement.</p></div><label class="form-label" for="split-ships">Ships to detach from this ${i.ships}-ship formation</label><select id="split-ships" data-fleet-target="${e}">${Array.from({length:Math.max(0,i.ships-1)},(o,l)=>l+1).map(o=>`<option value="${o}" ${o===t?"selected":""}>${o} ${o===1?"ship":"ships"}</option>`).join("")}</select><div class="split-preview">${a("Original formation",r.parent,!0)}${a("Detached formation",r.detached,!1)}</div><p class="split-note">Hull damage is shared proportionally. The original keeps its name and course${Ii(n,i.id).held?" and remains on hold":""}; the detached formation awaits orders. ${i.defenseLead?"The original keeps its defensive lead. ":""}Upkeep is unchanged.${i.heritage?.length?" Both carry the same expedition history.":""}</p>${r.enabled?"":`<p class="split-reason">${es(r.reason)}</p>`}<div class="modal-actions"><button data-action="close-modal">Keep together</button><button class="primary" data-action="split-confirm" data-fleet-target="${e}" data-ships="${t}" ${r.enabled?"":"disabled"}>Detach ${t} ${t===1?"ship":"ships"} · ${r.orderCost} order</button></div>`}function rM(n,e){if(e.owner!=="player"||!n.fleets.some(r=>r.owner==="player"&&r.systemId===e.id))return"";const t=up(n,e.id),i=t.fleets.filter(r=>r.missingHull>0);return`<section class="panel-section colony-repairs"><div class="section-label">Orbital maintenance <span>${Ql(t.capacity)} hull / cycle</span></div><p>${t.blocked?"Hostile fleets prevent passive repairs in this system.":i.length?`${Ql(t.totalRepair)} hull recovery at current damage, shared by ${i.length} ${i.length===1?"formation":"formations"}.`:"All your fleets here are fully repaired."}</p>${!t.blocked&&i.length?`<ul>${i.map(r=>{const s=n.fleets.find(a=>a.id===r.fleetId);return`<li><span>${es(s.name)}</span><b>+${Ql(r.repair)} hull</b></li>`}).join("")}</ul>`:""}<small>Ships at one colony share its repair capacity. Splitting or merging does not increase the total.</small></section>`}const ri=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),Ds=n=>n>0&&Math.round(n*10)===0?"&lt;0.1":Number.isInteger(n)?n:n.toFixed(1);function sM(n,e){const t=e[0],i=n.systems.find(o=>o.id===t.systemId);let r=`<div class="eyebrow">CONCORD OPERATIONS · CYCLE ${t.turn}</div><h2 id="modal-title">${t.kind==="invasion"?"The battle for":"Engagement at"} ${ri(i.name)}</h2>`;e.some(o=>o.kind==="fleet")&&(r+='<p class="combat-scope">Each engagement pairs one attacking formation with one defending formation. Nearby friendly fleets do not combine their fire. A surviving attacker continues to the next hostile formation; a destroyed attacker ends the sequence.</p>');for(const o of e){r+=`<section class="combat-report" data-report-id="${o.id}"><p class="combat-summary">${ri(o.summary)}</p><div class="combat-sides">`;for(const l of o.participants){const c=l.shipsBefore-l.shipsAfter;r+=`<article class="combat-side" data-owner="${l.owner}" style="--side-color:${Ke[l.owner].color}"><div class="eyebrow">${ri(Ke[l.owner].shortName)} · ${l.role}</div>${l.defenseLead?'<span class="defense-badge">Lead defender</span>':""}<div class="combat-fleet-art">${Ui(l.type,l.owner)}</div><div class="combat-fleet-heading"><div><h3>${ri(l.name)}</h3><p>${Re[l.type].role} formation</p></div></div><div class="combat-numbers"><div><strong>${l.shipsBefore} <span>→</span> ${l.shipsAfter}</strong><small>Ships remaining</small></div><div><strong class="${c?"loss":""}">${c}</strong><small>Ships lost</small></div></div><div class="combat-hull"><span>Hull ${Ds(l.hullBefore)} → ${Ds(l.hullAfter)}</span><b>${l.shipsAfter?"Survived":"Destroyed"}</b></div><div class="progress-track"><i style="width:${l.hullAfter/l.hullBefore*100}%;background:var(--side-color)"></i></div></article>`}if(o.invasion){const l=o.invasion;r+=`<article class="combat-side colony-combat" style="--side-color:${Ke[l.ownerBefore].color}"><div class="eyebrow">${ri(Ke[l.ownerBefore].shortName)} · Planetary defense</div><h3>${ri(n.systems.find(c=>c.id===o.systemId).name)}</h3><div class="combat-numbers"><div><strong>${Ds(l.defenseBefore)} <span>→</span> ${Ds(l.defenseAfter)}</strong><small>Colony defenses</small></div><div><strong>${Ds(l.retaliation)}</strong><small>Retaliation damage</small></div></div><p class="capture-outcome">${l.captured?"Colony captured. A new administration takes control.":o.outcome==="repelled"?"The invasion was repelled.":"Defenses remain. Further bombardment is required."}</p></article>`}r+="</div></section>"}const s=e.flatMap(o=>o.participants).filter((o,l,c)=>o.owner==="player"&&c.findIndex(d=>d.fleetId===o.fleetId)===l&&n.fleets.some(d=>d.id===o.fleetId)),a=e.flatMap(o=>o.participants).find(o=>o.owner!=="player")?.owner||t.invasion?.ownerBefore;return r+=`<div class="modal-actions report-actions"><button data-action="report-inspect" data-system="${t.systemId}">Inspect system</button>${s.map(o=>`<button data-action="report-select-fleet" data-fleet-target="${o.fleetId}">Select ${ri(o.name)}</button>`).join("")}${a&&a!=="player"?`<button data-action="report-diplomacy" data-target="${a}">Open diplomacy</button>`:""}<button class="primary" data-action="close-modal">Return to command →</button></div>`,r}function aM(n,e){let t="";return e.reportId&&n.combatReports?.some(i=>i.id===e.reportId)&&(t+=`<button class="small-button" data-action="combat-report" data-report="${e.reportId}">Battle report →</button>`),e.systemId&&(t+=`<button class="small-button ghost" data-action="report-inspect" data-system="${e.systemId}">Inspect ${ri(n.systems.find(i=>i.id===e.systemId)?.name||"system")}</button>`),e.techId&&(t+='<button class="small-button ghost" data-action="report-research">Choose research →</button>'),e.targetId&&(t+=`<button class="small-button ghost" data-action="report-diplomacy" data-target="${e.targetId}">Open diplomacy →</button>`),t}function oM(n){const e=n.lastBriefing;if(!e)return'<h2 id="modal-title">Your first mandate</h2><p class="modal-lead">Complete a cycle to receive a briefing from your colonies and fleet commanders.</p>';const t=[["Threats & diplomacy",r=>["combat","war","warning","diplomacy","sovereignty","victory","alignment"].includes(r.type)],["Completed projects",r=>["construction","research"].includes(r.type)],["Across the frontier",r=>!["combat","war","warning","diplomacy","sovereignty","victory","alignment","construction","research"].includes(r.type)]];let i=`<div class="eyebrow">THE SPEAKER'S BRIEFING</div><h2 id="modal-title">A new cycle. A changing Reach.</h2><p class="modal-lead">Cycle ${e.turn} · ${e.entries.length} ${e.entries.length===1?"dispatch":"dispatches"} from the latest turn. This report remains available from the top bar.</p>`;for(const[r,s]of t){const a=e.entries.filter(s);a.length&&(i+=`<div class="modal-subhead">${r} <span class="briefing-count">${a.length}</span></div><div class="briefing-entries">${a.map(o=>`<article class="briefing-entry ${["combat","war","warning"].includes(o.type)?"urgent":""}"><div class="briefing-type">${ri(o.type)}</div><p>${ri(o.text)}</p><div class="briefing-event-actions">${aM(n,o)}</div></article>`).join("")}</div>`)}return e.entries.length||(i+='<div class="callout">No major events this cycle. Income, population growth, ongoing construction and research have advanced as usual.</div>'),i+'<div class="modal-actions"><button data-action="report-chronicle">Full chronicle</button><button class="primary" data-action="close-modal">Continue planning →</button></div>'}const Xi=320,so=139,lM=50,qi=new Map,cM=new Set(["terran","ocean","arid","ice","volcanic","barren"]),wi=(n,e=0,t=1)=>Math.max(e,Math.min(t,n)),Pt=(n,e,t)=>{const i=wi((t-n)/(e-n));return i*i*(3-2*i)},Vt=(n,e,t)=>n.map((i,r)=>i+(e[r]-i)*wi(t));function dM(n){let e=2166136261;for(const t of n)e=Math.imul(e^t.charCodeAt(0),16777619);return e>>>0}function jd(n){return()=>(n=Math.imul(n,1664525)+1013904223>>>0,n/4294967296)}function uM(n){const e=jd(n),t=Array.from({length:256},(l,c)=>c);for(let l=255;l>0;l--){const c=Math.floor(e()*(l+1));[t[l],t[c]]=[t[c],t[l]]}const i=new Uint16Array(512);for(let l=0;l<512;l++)i[l]=t[l&255];const r=l=>l*l*l*(l*(l*6-15)+10),s=(l,c,d)=>l+(c-l)*d,a=(l,c,d,u)=>{const h=l&15,f=h<8?c:d,p=h<4?d:h===12||h===14?c:u;return(h&1?-f:f)+(h&2?-p:p)};function o(l,c,d){const u=Math.floor(l),h=Math.floor(c),f=Math.floor(d),p=u&255,v=h&255,m=f&255;l-=u,c-=h,d-=f;const g=r(l),x=r(c),E=r(d),b=i[p]+v,w=i[b]+m,S=i[b+1]+m,T=i[p+1]+v,y=i[T]+m,A=i[T+1]+m;return s(s(s(a(i[w],l,c,d),a(i[y],l-1,c,d),g),s(a(i[S],l,c-1,d),a(i[A],l-1,c-1,d),g),x),s(s(a(i[w+1],l,c,d-1),a(i[y+1],l-1,c,d-1),g),s(a(i[S+1],l,c-1,d-1),a(i[A+1],l-1,c-1,d-1),g),x),E)}return(l,c,d,u=4)=>{let h=0,f=.55;for(let p=0;p<u;p++)h+=o(l,c,d)*f,l=l*2.03+13.7,c=c*2.03+3.1,d=d*2.03+8.3,f*=.49;return h}}function hM(n){const e=jd(n^9522051);return Array.from({length:42},(t,i)=>{const r=e()*Math.PI*2,s=e()*2-1,a=Math.sqrt(1-s*s);return{x:Math.cos(r)*a,y:Math.sin(r)*a,z:s,radius:i<7?.13+e()*.16:.025+e()*.09}})}function fM(n,e){const t=document.createElement("canvas");t.width=t.height=Xi;const i=t.getContext("2d"),r=i.createImageData(Xi,Xi),s=r.data,a=uM(e),o=jd(e),l=[o()*25+5,o()*25+5,o()*25+5],c=(h,f,p,v,m=4)=>a(h*v+l[0],f*v+l[1],p*v+l[2],m),d=n==="barren"?hM(e):[],u={terran:[74,155,231],ocean:[62,145,240],arid:[214,154,82],ice:[143,216,244],volcanic:[180,51,21]}[n];for(let h=0;h<Xi;h++)for(let f=0;f<Xi;f++){const p=(f+.5-Xi/2)/so,v=(h+.5-Xi/2)/so,m=p*p+v*v,g=(h*Xi+f)*4;if(m>=1){if(u&&m<1.09){const I=(Math.sqrt(m)-1)*so,B=wi(.45-p*.36-v*.3);s[g]=u[0],s[g+1]=u[1],s[g+2]=u[2],s[g+3]=Math.round(65*Math.exp(-I/1.65)*B)}continue}const x=Math.sqrt(1-m),E=Math.max(0,-.56*p-.43*v+.708*x),b=.055+.97*E,w=n==="unknown"?0:c(p,v,x,2.65),S=n==="unknown"?0:c(p,v,x,12,2);let T,y=0;if(n==="terran"){const I=Pt(-.035,-.005,w),B=Pt(.01,.26,w),N=Math.abs(v*.93+p*.18),U=Pt(.02,.23,c(p+4,v,x,3,3)+.08-Math.abs(N-.3)*.2);let V=Vt([39,91,53],[160,135,83],U);V=Vt(V,[146,153,140],B*.6);const $=Vt([14,42,86],[30,112,133],Pt(-.19,-.025,w));T=Vt($,V,I),T=Vt(T,[209,225,218],Pt(.79,.96,N+w*.23)),y=(1-I)*.4}else if(n==="ocean"){const I=c(p,v,x,4.8),B=Pt(.16,.19,I),N=Pt(.04,.17,I);T=Vt([11,43,101],[26,143,166],N),T=Vt(T,Vt([178,180,126],[41,111,78],Pt(.185,.24,I)),B),y=(1-B)*.65}else if(n==="arid"){const I=c(p-3,v+1,x,4,3);T=Vt([121,65,37],[217,168,103],Pt(-.22,.22,w)),T=Vt(T,[236,206,147],Pt(.075,.24,I)*.7);const B=1-Pt(.008,.04,Math.abs(c(p,v+3,x,4,3)));T=Vt(T,[87,51,37],B*Pt(-.08,.06,w)*.42)}else if(n==="ice"){const I=1-Pt(.009,.03,Math.abs(c(p+1,v,x,5.8,3))),B=Pt(-.21,.22,w+Math.abs(v)*.1);T=Vt([88,140,170],[219,238,239],B),T=Vt(T,[37,87,119],I*.8);const N=1-Pt(.004,.013,Math.abs(c(p,v+5,x,13,2)));T=Vt(T,[111,173,196],N*.35),y=.13}else if(n==="volcanic"){T=Vt([31,30,35],[77,65,60],Pt(-.2,.25,w));const I=Math.abs(c(p,v+2,x,4.3,3)),B=Pt(-.2,.07,c(p+7,v,x,2.7,2)),N=(1-Pt(.007,.032,I))*B,U=(1-Pt(.002,.012,I))*B;T=Vt(T,[158,48,20],N*.7),T=T.map((V,$)=>V*b+[238,57,7][$]*N+[17,109,24][$]*U)}else if(n==="barren"){T=Vt([83,84,87],[162,160,151],Pt(-.25,.24,w));let I=1;for(const B of d){const N=(p-B.x)**2+(v-B.y)**2+(x-B.z)**2;if(N>B.radius*B.radius*1.45)continue;const U=Math.sqrt(N)/B.radius,V=1-Pt(.38,.9,U),$=Math.exp(-(((U-.95)/.13)**2)),ie=wi(.5-((p-B.x)*.65+(v-B.y)*.5)/B.radius,-.25,1.25);I*=1-V*.34+$*(.08+ie*.28)}T=T.map(B=>B*I)}else T=[96,108,123];if(n==="terran"||n==="ocean"){const I=c(p+5,v,x,2,2),B=c(p+I*.22,v-I*.35,x,5.1,4),N=Pt(.045,.24,B)*.85;T=Vt(T,[226,237,241],N),y*=1-N}const A=n==="unknown"?1:1+S*(n==="barren"?.2:.11);n!=="volcanic"&&(T=T.map(I=>I*b*A));const C=Math.pow(wi(-.31*p-.24*v+.92*x),54)*y*155;if(y&&(T=T.map(I=>I+C)),u){const I=Math.pow(1-x,3.1)*(.12+E*.57)*(n==="volcanic"?.25:1);T=Vt(T,u,I)}const L=wi((1-Math.sqrt(m))*so+.4);s[g]=wi(T[0],0,255),s[g+1]=wi(T[1],0,255),s[g+2]=wi(T[2],0,255),s[g+3]=Math.round(L*255)}return i.putImageData(r,0,0),t.toDataURL("image/png")}function pM(n={}){const e=cM.has(n.type)?n.type:"unknown",t=e==="unknown"?"unknown":`${n.seed??""}|${n.id??""}|${n.name??""}|${e}`;if(qi.has(t)){const r=qi.get(t);return qi.delete(t),qi.set(t,r),r}const i=fM(e,dM(t));return qi.set(t,i),qi.size>lM&&qi.delete(qi.keys().next().value),i}const Ht=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),zp={observatory:"✧",reef:"◇"},Fh=n=>Object.entries(n||{}).filter(([,e])=>e>0).map(([e,t])=>`${e==="credits"?"◈":e==="minerals"?"◇":e==="science"?"✧":""} ${t} ${e}`).join(" · ");function mM(n){const e=n.effectsPreview?.population,t=n.effectsPreview?.habitability,i=Object.entries(n.gain||{}).filter(([,s])=>s>0).map(([s,a])=>`${a} ${s}`).join(" and ");let r;if(e)r=e.amount?`${e.systemName} gains ${e.amount} population: ${e.before} → ${e.after}.`:"Your capital is not an owned colony, so this choice adds no population.";else if(t)r=t.amount?`Habitability rises from ${t.before}% to ${t.after}% (+${t.amount} points).`:`Habitability is already ${t.after}%; this choice adds no habitability.`;else return n.description;return r+(i?` Gain ${i}.`:"")}function gM(n){const e=n.effectsPreview?.population;return e?.amount?`<p class="discovery-effect-preview"><strong>${e.after} / ${e.capacity} population after arrival.</strong> ${e.overCapacity?"Refugees can exceed the natural-growth limit. Their population remains; natural growth pauses at or above the limit.":"Refugees arrive immediately, including when the natural-growth limit has been reached."}</p>`:n.reveal?'<p class="discovery-effect-preview">Already charted stars add no new chart information.</p>':""}function vM(n,e){const t=Jn(n,e.id);if(!t)return"";const i=!["resolved","unknown"].includes(t.phase);let r=`<section class="panel-section discovery-summary" data-discovery="${t.id}"><div class="section-label">${t.site?"Ancient site":i?"Unusual signal":"Expedition record"} <span>${zp[t.id]||"✦"}</span></div><h3>${Ht(t.name)}</h3>`;return t.stale&&!t.legacyOutcome&&(r+=`<p class="discovery-memory">${t.observedTurn===null?"Earlier charts contain no detailed expedition record.":`Last observed in cycle ${t.observedTurn}.`} Send an expedition for an updated report.</p>`),t.phase==="maturing"&&(r+=`<div class="discovery-progress"><span>${t.progress} / ${t.target} qualifying cycles</span><div class="progress-track"><i style="width:${t.progress/t.target*100}%"></i></div></div><p class="discovery-continuation">${Ht(t.continuation)}</p>`),t.phase==="ready"&&(r+='<p class="discovery-ready">The work is complete. A final choice awaits.</p>'),t.site&&(r+=`<p class="discovery-site-label">${Ht(t.site.name)} · ${t.site.state==="active"?"Restored":t.site.state==="building"?"Under construction":"Restoration available"}</p>`),t.history.length?r+=`<p class="discovery-history-teaser">${Ht(t.history.at(-1).choiceLabel)} · cycle ${t.history.at(-1).turn}</p>`:t.legacyOutcome&&(r+='<p class="discovery-memory">Earlier expedition; detailed outcome was not recorded.</p>'),r+=`<button class="wide-button" data-action="anomaly" data-system="${e.id}">${i&&t.canInteract&&t.phase!=="maturing"?"Investigate discovery · 1 order":"Read expedition record"} →</button>`,t.site?.state==="planned"&&e.owner==="player"&&!e.queue&&(r+=`<button class="wide-button ghost" data-action="build-menu" data-system="${e.id}">Commission restoration →</button>`),r+"</section>"}function yM(n){let e='<div class="modal-subhead">The story of this world</div>';return n.history.length?e+`<div class="discovery-history">${n.history.map(t=>`<article class="discovery-history-entry"><div class="discovery-history-meta">CYCLE ${t.turn} · ${Ht(Ke[t.factionId]?.shortName||t.factionId)}</div><h3>${Ht(t.choiceLabel)}</h3><p>${Ht(t.outcomeText)}</p></article>`).join("")}</div>`:e+`<p class="empty-note">${n.legacyOutcome?"Earlier expedition; detailed outcome was not recorded.":"Your expedition has yet to leave its mark here."}</p>`}function _M(n,e,t=null){const i=n.systems.find(o=>o.id===e),r=Jn(n,e);if(!r)return'<h2 id="modal-title">An uncharted story</h2><p class="modal-lead">Survey this world to learn what remains here.</p>';const s=r.canInteract?_a(n,e,"player",t):[];let a=`<div class="eyebrow">FIELD EXPEDITION · ${Ht(i.name)}</div><div class="discovery-title"><span>${zp[r.id]||"✦"}</span><h2 id="modal-title">${Ht(r.name)}</h2></div>${kp(r.id,{wide:!0})}<p class="modal-lead">${Ht(r.description)}</p>`;if(r.stale&&!r.legacyOutcome&&(a+=`<div class="callout">${r.observedTurn===null?"Earlier charts contain no detailed expedition record.":`Last observed in cycle ${r.observedTurn}.`} This record retains what your expedition learned. Return to the system to observe its current state.</div>`),r.phase==="maturing"&&(a+=`<div class="discovery-maturation"><div><span class="eyebrow">RESTORATION IN PROGRESS</span><strong>${r.progress}<small> / ${r.target} cycles</small></strong></div><p>${Ht(r.continuation)}</p><div class="progress-track"><i style="width:${r.progress/r.target*100}%"></i></div></div>`),r.site&&(a+=`<div class="discovery-site-card"><span>${Ye[r.site.id]?.icon||"✦"}</span><div><h3>${Ht(r.site.name)}</h3><p>${Ht(Ye[r.site.id]?.description||"A restored legacy of this world.")}</p><small>${r.site.state==="active"?"Restoration complete":r.site.state==="building"?"Construction in progress":"The restoration plan remains with this world"}</small></div></div>`),s.some(o=>o.kind==="restore")){const o=Fn(n,i);a+=`<div class="replacement-control"><label for="discovery-replacement">Restored sites use one infrastructure slot (${o.used}/${o.capacity} occupied)</label><select id="discovery-replacement" data-system="${e}"><option value="">${o.available?"Use an open slot":"Choose infrastructure to replace…"}</option>${i.buildings.map(l=>`<option value="${l}" ${t===l?"selected":""}>Replace ${Ht(Ye[l].name)}</option>`).join("")}</select></div>`,t&&(a+=`<div class="callout replacement-warning">${Ht(Ye[t].name)} continues working until restoration is complete, then is removed. Any charter it supports is also removed.</div>`)}return a+=s.map(o=>`<button class="choice-card discovery-choice" data-action="anomaly-choice" data-system="${e}" data-choice="${o.id}" ${t&&o.kind==="restore"?`data-replace="${t}"`:""} ${o.enabled?"":"disabled"}><b>${Ht(o.label)} →</b><p>${Ht(mM(o))}</p>${gM(o)}${o.continuation?`<p class="discovery-choice-future">${Ht(o.continuation)}</p>`:""}<div class="discovery-choice-cost">${Fh(o.cost)?`${Ht(Fh(o.cost))} · `:""}1 order${o.work?` · ${o.work} work · ${o.turns} cycles`:""}</div>${o.reason?`<p class="build-reason">${Ht(o.reason)}</p>`:""}</button>`).join(""),!r.canInteract&&!r.stale&&!["resolved","maturing"].includes(r.phase)&&(a+=`<p class="empty-note">${i.owner&&i.owner!=="player"?"Only this world’s sovereign can make a choice.":"An expedition must be present, or this world must belong to you, to make a choice."}</p>`),s.length&&(a+='<p class="empty-note discovery-permanence">Each choice leaves a permanent record. Restorations use ordinary construction; cancelling keeps the plan but never reopens the salvage choice.</p>'),a+yM(r)}const dr=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),Us=(n,e)=>`${n} ${e}${n===1?"":"s"}`;function xM(n,e,t){const i=e.route?Ws(n,e.id):null,r=t.id!==e.systemId?Zd(n,e.id,t.id):null,s=r?.ok&&r.path.length>2&&t.id!==i?.destinationId;return{stored:i,preview:r,proposing:s,display:s?r:i}}function bM(n,e,t){const{stored:i,preview:r,proposing:s,display:a}=t;if(!a)return"";const o=v=>n.systems.find(m=>m.id===v),l=o(a.destinationId),c=Ii(n,e.id).held,d=i?.ok&&i.maxJumpsNow>0;let u=s?`<button class="primary" data-action="plan-route" data-destination="${r.destinationId}">Plot course · free</button>`:`<button class="primary" data-action="continue-route" ${d?"":"disabled"} title="${dr(i.reason)}">${c?"Resume course":"Continue"} · up to ${Us(i.maxJumpsNow,"jump")}</button>`;i&&(u+='<button class="small-button ghost" data-action="fit-route" title="Fit the planned course on the map">⌖</button><button class="small-button ghost" data-action="replot-route" title="Recalculate a route through currently open borders">Replot</button><button class="small-button ghost" data-action="clear-route" title="Clear this fleet’s plotted route" aria-label="Clear plotted route">×</button>');const h=a.uncertainSystems.length?`Opposition unknown at ${Us(a.uncertainSystems.length,"stop")}.`:"",f=s?`Planning spends no orders.${c?" A new course resumes this fleet.":""}`:d?`${c?"Continuing resumes this held fleet. ":""}Up to ${Us(i.maxOrdersNow,"order")} now; stops for new contacts, discoveries or combat.`:i.reason,p=a.stopBefore?`Stops before ${o(a.stopBefore.systemId)?.name||"a blocked system"}: ${a.stopBefore.reason}`:"";return`<div class="route-strip ${s?"route-proposal":"route-committed"}"><div class="route-heading"><div><span class="eyebrow">${s?"COURSE PREVIEW":"PLANNED COURSE"}</span><strong>${dr(l?.name||a.destinationId)} <small>· ${Us(a.jumps,"jump")} · ${Us(a.totalOrders,"order")} total</small></strong></div><div class="route-actions">${u}</div></div><div class="route-itinerary" aria-label="${s?"Proposed":"Planned"} route">${a.path.map((v,m)=>`${m?'<span class="route-arrow" aria-hidden="true">›</span>':""}<button class="route-stop" data-system-select="${v}" title="Inspect ${dr(o(v)?.name||v)}"><span>${m===0?"●":m}</span>${dr(o(v)?.name||v)}</button>`).join("")}</div><p class="route-explanation">${dr(f)} ${dr(h)}</p>${p?`<p class="route-blockage">${dr(p)}</p>`:""}${NS(n,e,a)}</div>`}const $o=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]);function SM(n){const e=ys(n,"player"),t=n.winner==="player"&&n.victoryType==="Transcendence";return t&&(e.progress=e.target),`<div class="victory-card alignment-card"><div class="alignment-title"><h3>✦ Transcendence</h3><strong>${e.progress}<small> / ${e.target}</small></strong></div><p>Research the Asterion Protocol and hold three Beacon worlds. Maintain their alignment for ten cycles, paying ${e.cost} credits each advancing cycle.</p><div class="alignment-segments" aria-label="${e.progress} of ${e.target} alignment cycles">${Array.from({length:e.target},(i,r)=>`<i class="${r<e.progress?"complete":""}"></i>`).join("")}</div><p class="alignment-status">${e.beacons} / 3 beacons · ${$o(t?"Transcendence achieved":e.ready?"Alignment requirements met now":e.reason)}</p><p class="alignment-rules">A hostile warship over a participating beacon, fewer than three owned beacons, or insufficient funds interrupts alignment. Each interrupted cycle loses one step.</p></div>`}function MM(n){const e=Zn(n).map(t=>n.winner===t.factionId&&n.victoryType==="Transcendence"?{...t,progress:t.target,completed:!0}:t).filter(t=>t.beacons>0||t.progress>0);return e.length?`<div class="public-races">${e.map(t=>`<article class="race-card" data-race="${t.factionId}" style="--race-color:${Ke[t.factionId].color}"><div class="race-heading"><div><div class="eyebrow">${t.factionId==="player"?"YOUR NETWORK":"PUBLIC BEACON SIGNAL"}</div><h3>${$o(t.name||Ke[t.factionId].name)}</h3></div><strong>${t.progress}<small> / ${t.target}</small></strong></div><div class="progress-track"><i style="width:${t.progress/t.target*100}%;background:var(--race-color)"></i></div><p class="race-status">${t.beacons} restored ${t.beacons===1?"beacon":"beacons"} · ${t.completed?"Transcendence achieved":t.active?"Alignment advanced last cycle":t.progress?"Alignment interrupted":"Awaiting alignment"}</p><div class="beacon-sites">${t.sites.map(i=>`<button class="small-button ${t.participatingSites.includes(i.id)?"participating-beacon":"ghost"}" data-action="inspect" data-system="${i.id}" title="${t.participatingSites.includes(i.id)?"Participating in alignment":"Restored beacon"}">✦ ${$o(i.name)} ↗</button>`).join("")}</div></article>`).join("")}</div>`:'<div class="race-empty"><span>✦</span><p>No beacon signals from known civilizations yet. Restored nodes and alignment progress become public after diplomatic contact.</p></div>'}function wM(n,e){const t=Zn(n).find(r=>r.sites.some(s=>s.id===e.id));if(!t)return"";const i=t.participatingSites.includes(e.id);return`<section class="panel-section beacon-inspector"><div class="section-label">Public beacon signal <span>✦</span></div><p>${i?"This world participates in":"A restored node belonging to"} ${$o(Ke[t.factionId].shortName)}${i?"’s alignment.":"."}</p><div class="beacon-count">${t.progress} <small>/ ${t.target} cycles</small></div><p class="empty-note">Beacon signals reveal the network’s progress. Fleet presence still requires local sensors.</p></section>`}const Hp="asterion-reach-save-v1",Gp="asterion-reach-settings-v1",Oe=n=>document.querySelector(n),$e=n=>String(n??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),ha=n=>Math.round(n).toLocaleString(),Zs=n=>`${n>=0?"+":""}${ha(n)}`,Bh={galaxy:'<circle cx="12" cy="12" r="3"/><ellipse cx="12" cy="12" rx="10" ry="5" transform="rotate(-35 12 12)"/><path d="M4 4l1 1m14 14 1 1M3 17h1m16-10h1"/>',research:'<path d="M9 3h6m-5 0v6L4 19a1.4 1.4 0 001 2h14a1.4 1.4 0 001-2L14 9V3M7 15h10"/><path d="M10 17h.1m3 2h.1"/>',diplomacy:'<path d="M5 4h14v6c0 5-7 10-7 10S5 15 5 10z"/><path d="m8 10 3 3 5-6"/>',empire:'<path d="M3 21h18M5 21V10h5v11m4 0V5h5v16M8 10V4m-3 0h6M3 10h9M12 5h9"/>',journal:'<path d="M5 3h14v18H5zM8 7h8m-8 4h8m-8 4h5"/>',menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',help:'<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 115 0c0 2-2.5 2-2.5 4m0 3h.01"/>',home:'<path d="m3 10 9-7 9 7M6 8v13h12V8m-8 13v-7h4v7"/>',mark:'<path d="m12 1 3.5 7.5L23 12l-7.5 3.5L12 23l-3.5-7.5L1 12l7.5-3.5z"/><circle cx="12" cy="12" r="3"/>'},qr=(n,e=20)=>`<svg width="${e}" height="${e}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${Bh[n]||Bh.mark}</svg>`;let J,Kn={warnUnspent:!0,publicDispatchesOpen:!1},_o=!1,zo="";try{Kn={...Kn,...JSON.parse(localStorage.getItem(Gp)||"{}")}}catch{}try{const n=JSON.parse(localStorage.getItem(Hp));Mp(n)?J=n:n&&(zo="The previous save could not be read. Your new campaign is ready.")}catch{zo="Browser storage is unavailable or the previous save is invalid. Use Export in the menu to keep a backup."}const EM=!J;J||=_p("ASTERION");Zo(J);let On=J.factions.find(n=>n.id==="player").capitalId,rt=J.fleets.find(n=>n.owner==="player"&&n.type==="scout")?.id||null;J.fleets.find(n=>n.id===rt)?.route&&(On=J.fleets.find(n=>n.id===rt).systemId);let xo="name",dd="asc",Ks=null,At="galaxy",bo="All",So="All",ps=null,ud=null,kh=J.turn;const xt=()=>J.factions.find(n=>n.id==="player"),Dn=n=>J.systems.find(e=>e.id===n),Zt=n=>J.fleets.find(e=>e.id===n),Vp=()=>xt().contacts.includes(Ks)?Ks:J.factions.find(n=>n.id!=="player"&&xt().contacts.includes(n.id))?.id;Oe("#app").innerHTML=`<div class="app-shell">
  <header class="topbar"><div class="brand"><div class="brand-mark">${qr("mark",34)}</div><div><h1>ASTERION REACH</h1><small>THE STARS REMEMBER</small></div></div><div class="resources" id="resources"></div><div class="top-actions"><button data-action="briefing" id="briefing-button" aria-label="Latest cycle briefing" title="Latest cycle briefing">${qr("journal")}</button><a href="./guide.html" target="_blank" rel="noopener" aria-label="Open field guide" title="Field guide (?)">${qr("help")}</a><button data-action="menu" aria-label="Game menu" title="Game menu">${qr("menu")}</button></div></header>
  <nav class="rail" aria-label="Command views">${[["galaxy","Galaxy"],["research","Research"],["diplomacy","Diplomacy"],["empire","Empire"],["journal","Chronicle"]].map(([n,e],t)=>`<button data-page="${n}" class="${n==="galaxy"?"active":""}" title="${e} (${t+1})">${qr(n)}<span>${e}</span></button>`).join("")}<div class="rail-bottom"><button data-action="home" title="Focus homeworld (H)">${qr("home")}<span>Home</span></button></div></nav>
  <main class="main-stage"><div class="galaxy-page" id="galaxy-page"><div class="map-canvas" id="galaxy" aria-label="Interactive galaxy map"></div><div class="map-heading"><div class="eyebrow">CONCORD EXPLORATION AUTHORITY</div><h2>The Asterion Reach</h2><p id="map-meta"></p></div><div class="map-tools"><button data-action="zoom-in" aria-label="Zoom in">+</button><button data-action="zoom-out" aria-label="Zoom out">−</button><button data-action="reset-view" title="Fit galaxy" aria-label="Fit galaxy">⌖</button></div><div class="map-message" id="mandate"></div><div class="map-caption">PER ASPERA, AD ASTRA</div><div class="map-legend"><span><i></i>CONCORD</span><span><i style="background:#d9bd7c"></i>CHARTED</span><span><i style="background:#596a82"></i>UNKNOWN</span></div><div class="fleet-bar" id="fleet-bar"></div></div><div class="workspace-page" id="workspace-page" hidden></div></main>
  <aside class="inspector" aria-label="System inspector"><div class="inspector-content" id="inspector"></div><div class="turn-panel"><div class="turn-meta"><b id="turn-number"></b><span id="turn-year"></span></div><button class="primary end-turn" data-action="end-turn" id="end-turn"><span>End cycle →</span><kbd>SPACE</kbd></button><div class="turn-hint" id="turn-hint"></div></div></aside>
  <footer class="statusbar"><span class="status-message" id="status-message">Your mandate begins among the stars.</span><span class="version">ASTERION REACH <span class="green">/</span> EARLY ACCESS 0.14.0</span><span id="save-status">LOCAL CAMPAIGN</span></footer></div><div id="modal-root"></div><div class="toast-stack" id="toasts" role="status" aria-live="polite"></div><input class="sr-only" type="file" id="import-save" accept="application/json,.json" aria-label="Import campaign save" />`;const Wt=new IS(Oe("#galaxy"),{onSelect:ts,onFleetSelect:Ho});function fa(){try{localStorage.setItem(Hp,JSON.stringify(J)),_o=!1,Oe("#save-status").textContent="● AUTOSAVED"}catch{_o||bn("Autosave unavailable. Export your campaign from the menu.",!0),_o=!0,Oe("#save-status").textContent="SAVE UNAVAILABLE"}}function Qd(){try{localStorage.setItem(Gp,JSON.stringify(Kn))}catch{}}function bn(n,e=!1){const t=document.createElement("div");for(t.className=`toast${e?" error":""}`,t.textContent=n,Oe("#toasts").appendChild(t);Oe("#toasts").children.length>3;)Oe("#toasts").firstElementChild.remove();setTimeout(()=>t.remove(),e?6500:4200),Oe("#status-message").textContent=n}function ts(n){Dn(n)?.knownBy.includes("player")&&(On=n,At!=="galaxy"&&ai("galaxy"),nr())}function Ho(n){const e=Zt(n);!e||e.owner!=="player"||(rt=n,On=e.systemId,At!=="galaxy"&&ai("galaxy"),nr(),Wt.focus(e.systemId))}function ai(n){const e=At!==n;At=n,Wt.setPaused?.(!!ps||At!=="galaxy"),Oe("#galaxy-page").hidden=At!=="galaxy",Oe("#workspace-page").hidden=At==="galaxy",document.querySelectorAll("[data-page]").forEach(t=>{t.classList.toggle("active",t.dataset.page===At),t.setAttribute("aria-current",t.dataset.page===At?"page":"false")}),Js(),eu(),Oe("#inspector").scrollTop=0,e&&(Oe("#workspace-page").scrollTop=0)}function Lt(n){const e=Bo(J,n);return e.ok?(n.type==="split"&&e.newFleetId&&(rt=e.newFleetId,On=Zt(rt).systemId),["move","continueRoute"].includes(n.type)&&Zt(n.fleetId)&&(On=Zt(n.fleetId).systemId),rt&&!Zt(rt)&&(rt=null),fa(),nr(),bn(e.combatReports?.length?`${e.combatReports.length} combat report${e.combatReports.length>1?"s":""} recorded.`:e.message),J.winner?Qp():e.combatReports?.length&&Yp(e.combatReports.map(t=>t.id)),!0):(bn(e.message,!0),!1)}function nr(){const n=xt(),e=It(J);Oe("#resources").innerHTML=[["credits","◈","Credits",e.credits,e.creditIncome],["minerals","◇","Minerals",e.minerals,e.mineralIncome],["science","✧","Science",e.science,e.scienceIncome],["orders","⌘","Orders",e.orders,null]].map(([c,d,u,h,f])=>`<div class="resource ${c}" title="${u}: ${ha(h)}${f!==null?`; ${Zs(f)} per cycle${c==="credits"?` after ${e.upkeep} fleet upkeep`:""}`:` of ${e.maxOrders} available this cycle`}"><span class="symbol" aria-hidden="true">${d}</span><div><strong>${ha(h)}${c==="orders"?`<small style="color:#6f8996"> / ${e.maxOrders}</small>`:""}</strong>${f!==null?`<span class="delta ${f<0?"negative":""}">${Zs(f)}</span>`:""}<label>${u}</label></div></div>`).join(""),Oe("#turn-number").textContent=`Cycle ${String(J.turn).padStart(2,"0")}`,Oe("#turn-year").textContent=`${2400+J.turn-1} CE`,Oe("#turn-hint").textContent=J.winner?"The chronicle of this age is complete.":`${e.orders} orders remaining · ${e.colonies} ${e.colonies===1?"colony":"colonies"}`,Oe("#end-turn").disabled=!!J.winner;const t=J.lastBriefing;Oe("#briefing-button").disabled=!t,Oe("#briefing-button").classList.toggle("briefing-alert",!!(t?.entries.length&&Kn.reviewedBriefing!==Xp())),Oe("#briefing-button").title=t?`Cycle ${t.turn} briefing · ${t.entries.length} dispatches`:"Complete a cycle to receive a briefing",Oe("#map-meta").innerHTML=`<span class="live-dot"></span>${Qi(J).length} charted systems · ${e.explored} surveyed · seed ${$e(J.seed)}`;const i=ys(J,"player"),r=Zn(J).filter(c=>c.factionId!=="player"&&c.progress>0).sort((c,d)=>d.progress-c.progress)[0],s=r?.progress>=5&&r.progress>=i.progress?["A RIVAL AWAKENS THE NETWORK",`${r.name} has reached ${r.progress}/${r.target} alignment. Review its public beacon signals in Empire.`]:e.colonies<2?["YOUR FIRST MANDATE","Scout a neighboring star. Send your Colony Ark to a habitable world and establish a second home."]:!n.research&&n.techs.length<12?["THE NEXT HORIZON","Your archives await direction. Choose a research project to turn discoveries into progress."]:e.beacons>0?["THE ANCIENT NETWORK",`${e.beacons} of 3 Beacons restored · alignment ${i.progress}/${i.target}. ${i.ready?`Protect the network and fund ${i.cost} credits each cycle.`:i.reason}`]:["A CIVILIZATION TAKES SHAPE",`${e.colonies} worlds share your future. Develop your economy, meet the frontier powers, and choose your path to victory.`];Oe("#mandate").innerHTML=`<strong>${$e(s[0])}</strong>${$e(s[1])}${r?.progress>=5?'<button class="small-button ghost" data-action="review-network">Review network →</button>':""}`;const a=Oe('[data-page="empire"]');a.querySelector(".nav-badge")?.remove(),a.setAttribute("aria-label",`Empire${r?`, rival alignment ${r.progress} of ${r.target}`:""}`),r&&a.insertAdjacentHTML("beforeend",`<b class="nav-badge">${r.progress}/${r.target}</b>`);const o=xs(J).filter(c=>c.to==="player"),l=Oe('[data-page="diplomacy"]');l.setAttribute("aria-label",`Diplomacy${o.length?`, ${o.length} pending diplomatic proposal${o.length===1?"":"s"}`:""}`),l.querySelector(".nav-badge")?.remove(),o.length&&l.insertAdjacentHTML("beforeend",`<b class="nav-badge">${o.length}</b>`),eu(),AM(),Js(),Wt.update(J,On,rt)}function eu(){if(Oe(".inspector").setAttribute("aria-label",At==="galaxy"?"System inspector":`${At==="journal"?"Chronicle":At[0].toUpperCase()+At.slice(1)} context`),Oe("#inspector").classList.toggle("workspace-context",At!=="galaxy"),At!=="galaxy"){Oe("#inspector").innerHTML=QS(J,At,{rivalId:Vp()});return}const n=Dn(On);if(!n)return;const e=n.exploredBy.includes("player"),t=n.owner==="player",i=Ke[n.owner],r=mr[n.type],s=dt(J,n),a=ca(Ft(J,"player",n.id));let o=`<div class="system-header"><div class="owner-tag" style="color:${i?.color||"#bba77e"}"><i></i>${i?$e(i.name):"UNCLAIMED FRONTIER"}</div><h2>${$e(n.name)}</h2><p class="subtitle">${e?`${$e(r.name)} world · ${n.originalOwner?"Founding system":"Frontier system"}`:"Unsurveyed system · Charted starlanes"}</p></div><div class="planet-art"><img class="planet-globe" src="${pM(e?{...n,seed:J.seed}:{type:"unknown"})}" alt="${e?$e(r.name)+" world":"Unsurveyed world"}" width="142" height="142" /></div><p class="system-description">${e?$e(r.description):"Send a fleet to survey this system and reveal its worlds, resources, and hidden history."}</p>`;if(e&&(o+=`<div class="stat-grid"><div class="stat-cell"><b>${n.habitability}%</b><span>Habitability</span></div><div class="stat-cell"><b>${t?`${n.population}/${s.capacity}`:n.richness}</b><span>${t?"Population":"Ore richness"}</span></div><div class="stat-cell"><b>${t?s.production:n.science}</b><span>${t?"Production":"Science"}</span></div></div>`),t){const u=n.queue,h=Ko(u);o+=`<section class="panel-section"><div class="section-label">Colony production <span>${s.production} / cycle</span></div>${u?`<div class="production-row"><span class="big-icon">${h.icon}</span><div><b>${$e(h.name)}</b><p>${Math.ceil((u.work-u.progress)/s.production)} cycles to completion</p></div><button class="small-button ghost" data-action="cancel-build" data-system="${n.id}" title="Cancel and refund unspent work">×</button></div><div class="progress-track"><i style="width:${u.progress/u.work*100}%"></i></div>`:`<p class="empty-note">Your construction teams await a new project.</p><button class="wide-button" data-action="build-menu" data-system="${n.id}">+ Commission a project</button>`}</section>${ZS(J,n)}<section class="panel-section"><p class="empty-note">${Zs(s.credits)} credits · ${Zs(s.minerals)} minerals · ${Zs(s.science)} science</p></section>`}o+=wM(J,n),o+=DS(J,n.id),o+=vM(J,n),a.length&&(o+=`<section class="panel-section"><div class="section-label">In orbit <span>${a.length} ${a.length===1?"fleet":"fleets"}</span></div><div class="fleet-list">${a.map(u=>`<button class="fleet-row ${u.id===rt?"selected":""}" data-fleet="${u.id}" ${u.owner!=="player"?"disabled":""}>${Ui(u.type,u.owner,!!u.heritage?.length)}<span class="fleet-name">${$e(u.name)}${u.ships>1?` ×${u.ships}`:""}${Kd(u)}<small>${u.owner==="player"?Re[u.type].role:Ke[u.owner].shortName} · ${$e(wr(u.hp,u.ships*Re[u.type].hp))} hull</small></span>${u.owner==="player"?Jd(J,u):""}</button>`).join("")}</div></section>`);const l=Zt(rt);o+=nM(J,n.id,rt),l&&(o+=tM(J,l.id,n.id)),o+=rM(J,n);const c=l?.systemId===n.id?hS(J,l.id):null;c&&(o+=`<section class="panel-section"><div class="invasion-preview"><div class="section-label">Invasion forecast</div><strong>${c.defense} colony defenses</strong><br>Your volley: ${c.damageMin}–${c.damageMax} defense damage<br>Retaliation: ${c.retaliation} hull${c.shielded?" · Shields applied":""}<br>${c.captureGuaranteed?"Capture expected with this volley.":c.capturePossible?"This volley may capture the colony.":"Further bombardment is required."}<br>Cost: 1 order + 1 move</div></section>`);const d=Rn(J,n.id).map(Dn).filter(u=>u.knownBy.includes("player"));o+=`<section class="panel-section"><div class="section-label">Connected systems</div><div class="building-pills">${d.map(u=>`<button class="small-button ghost" data-system-select="${u.id}">${$e(u.name)} ↗</button>`).join("")}</div></section>`,Oe("#inspector").innerHTML=o}function TM(n,e){return Rn(J,n.systemId).includes(e.id)?n.movesLeft?xt().orders?e.owner&&e.owner!=="player"&&xt().relations[e.owner].status!=="war"&&!xt().relations[e.owner].trade?"Borders closed. Negotiate trade or declare war.":Re[n.type].attack<4&&Ft(J,"player",e.id).some(t=>t.owner!=="player"&&xt().relations[t.owner].status==="war")?"Hostile fleet present. Civilian ships cannot enter.":"":"No orders remain this cycle.":"Movement spent. End the cycle to move again.":"Choose a star connected by a starlane."}function AM(){const n=Zt(rt),e=Dn(On),t=J.fleets.filter(u=>u.owner==="player");if(!n){Oe("#fleet-bar").classList.remove("has-route"),Oe("#fleet-bar").innerHTML=`<div class="fleet-title"><div class="empty-fleet">A galaxy of possibilities.</div><p>Select a fleet in orbit to explore the frontier.</p></div>${t.length?'<button data-action="fleet-roster">Fleet roster →</button>':""}`;return}const i=Dn(n.systemId),r=Re[n.type],s=e.id!==i.id,a=Ii(J,n.id),o=xM(J,n,e),l=Rn(J,n.systemId).includes(e.id);let c=`${r.role} · ${n.ships} ${n.ships===1?"ship":"ships"} · ${n.movesLeft} jumps · ${wr(n.hp,n.ships*r.hp)} hull`,d="";if(s&&!l)c=o.preview?.ok?`${i.name} → ${e.name} · ${o.preview.jumps} charted jumps`:o.preview?.reason||"No route through charted lanes.",d=`<button class="ghost small-button" data-system-select="${i.id}" title="Back to fleet">↶</button>`;else if(s){const u=TM(n,e),h=e.owner&&e.owner!=="player"&&xt().relations[e.owner].status==="war",f=Ft(J,"player",e.id).some(v=>v.owner!=="player"&&xt().relations[v.owner].status==="war"),p=f?`${xp(J,n.id,e.id).odds} engagement`:tr(J,"player",e.id)?h?"Invasion is a separate action":"":"Fleet presence unknown";c=u||`${i.name} → ${e.name} · 1 order${p?` · ${p}`:""}`,d=`<button class="primary" data-action="move" data-target="${e.id}" ${u?"disabled":""}>${f?"Engage":h?"Enter orbit":"Move"} →</button><button class="ghost small-button" data-system-select="${i.id}" title="Back to fleet">↶</button>`}else{n.type==="colony"&&!i.owner&&(d+='<button class="primary" data-action="colonize">Settle world</button>'),Ft(J,"player",i.id).some(f=>f.owner!=="player"&&xt().relations[f.owner].status==="war")&&r.attack>3?d+=`<button class="danger" data-action="attack" ${!n.movesLeft||!xt().orders?"disabled":""}>Engage</button>`:i.owner&&i.owner!=="player"&&xt().relations[i.owner].status==="war"&&r.attack>3&&(d+=`<button class="danger" data-action="attack" ${!n.movesLeft||!xt().orders?"disabled":""}>Invade</button>`),i.owner==="player"&&n.hp<n.ships*r.hp&&(d+='<button data-action="repair">Repair ◇10</button>');const h=t.find(f=>f.id!==n.id&&f.systemId===i.id&&f.type===n.type&&n.type!=="colony");h&&(d+=`<button data-action="merge" data-target="${h.id}" title="Merge ${$e(h.name)} into this fleet; 1 order">Merge +${h.ships}</button>`),d||(c+=" · Select a star to plot a jump or a course.")}a.held&&(c+=" · Holding position"),d+=`<button class="small-button ghost fleet-hold" data-action="fleet-hold" data-fleet-target="${n.id}" aria-pressed="${a.held}" title="${a.held?"Return this fleet to the ready queue; free.":"Hold at "+$e(i.name)+"; free. Movement remains available."}" ${J.winner?"disabled":""}>${a.held?"Resume":"Hold position"}</button>`,!s&&n.ships>1&&n.type!=="colony"&&(d+=`<button data-action="split-menu" data-fleet-target="${n.id}" title="Detach ships into a separate formation; 1 order">Split fleet</button>`),n.heritage?.length&&(d+=`<button class="small-button ghost" data-action="fleet-heritage" data-fleet-target="${n.id}">Heritage ✦</button>`),Oe("#fleet-bar").classList.toggle("has-route",!!o.display),Oe("#fleet-bar").innerHTML=`${Ui(n.type,n.owner,!!n.heritage?.length)}<div class="fleet-title"><h3>${$e(n.name)} <span style="font-weight:400;color:#7f9aa9">/ ${$e(i.name)}</span></h3><p>${$e(c)}</p></div>${d}<button class="small-button ghost" data-action="fleet-roster" title="All fleets">⌁ ${t.length}</button><button class="small-button ghost" data-action="next-fleet" title="Next fleet (N)">⇥</button><div class="fleet-switch">${t.slice(0,4).map(u=>`<button data-fleet="${u.id}" class="${u.id===n.id?"selected":""}" title="${$e(u.name)} at ${$e(Dn(u.systemId).name)}">${Re[u.type].icon}</button>`).join("")}</div>${bM(J,n,o)}`}function Js(){if(At==="galaxy")return;const n=It(J),e=xt();let t="";if(At==="research"){const i=e.research&&Tt[e.research.techId],r=a=>a.completed?3:a.active?0:a.enabled?1:2,s=rl(J).filter(a=>bo==="All"||a.category===bo).sort((a,o)=>r(a)-r(o));t=`<div class="page-top"><div><div class="eyebrow">THE CONCORD ARCHIVES</div><h2>Beyond the known</h2><p>Rediscover the sciences that once connected the stars. Each breakthrough opens a different future for your civilization.</p></div><div class="page-symbol">✧</div></div>${i?`<div class="callout"><strong>${$e(i.name)}</strong> · ${e.research.progress} / ${i.cost} science · ${Math.ceil((i.cost-e.research.progress)/Math.max(1,n.scienceIncome))} cycles remaining<div class="progress-track"><i style="width:${e.research.progress/i.cost*100}%"></i></div></div>`:`<div class="callout">${e.techs.length===Object.keys(Tt).length?"The archives are complete. Your civilization has mastered the sciences of this age.":"<strong>Choose a research direction.</strong> Science accumulates in your reserves until assigned. Selecting or changing a project uses no orders."}</div>`}<div class="filter-tabs">${["All","Engineering","Society","Physics","Military"].map(a=>`<button class="${bo===a?"active":""}" data-research-filter="${a}">${a}</button>`).join("")}</div><div class="tech-grid">${s.map(a=>`<article class="tech-card ${a.completed?"researched":a.active?"current":a.enabled?"":"locked"}"><div class="tech-top"><span>${a.category}</span><span>${a.completed?"✓ DISCOVERED":`✧ ${a.cost}`}</span></div><h3>${$e(a.name)}</h3><p>${$e(a.description)}</p><div class="tech-footer"><span>${a.requires.length?`Requires ${a.requires.map(o=>$e(Tt[o].name)).join(" + ")}`:"Foundational science"}</span><button data-action="research" data-tech="${a.id}" ${a.enabled?"":"disabled"} title="${$e(a.reason)}">${a.completed?"Complete":a.active?"In progress":"Research →"}</button></div></article>`).join("")}</div>`}else if(At==="diplomacy")t=OS(J,{dispatchesOpen:Kn.publicDispatchesOpen===!0,selectedRivalId:Vp()});else if(At==="empire"){const i=uS(J);t=`<div class="page-top"><div><div class="eyebrow">MANY WORLDS. ONE HORIZON.</div><h2>The Concord</h2><p>Make a civilization worth inheriting. Prosperity, knowledge, and the strength to protect them are all part of your legacy.</p></div><div class="page-symbol">⌘</div></div><div class="empire-overview"><div class="overview-card"><div class="eyebrow">COLONIZED WORLDS</div><strong>${n.colonies}</strong><p>${n.population} billion citizens across the Reach</p></div><div class="overview-card"><div class="eyebrow">FLEET POWER</div><strong>${ha(n.military)}</strong><p>${n.ships} ships · ${n.upkeep} credits upkeep / cycle</p></div><div class="overview-card"><div class="eyebrow">LEGACY SCORE</div><strong>${ha(n.score)}</strong><p>Highest score at cycle ${i.legacy.finalTurn} wins</p></div></div>${JS(J,xo,dd)}<div class="victory-grid">${SM(J)}<div class="victory-card"><h3>⛨ Domination</h3><p>Unite the Reach under one banner by holding all four founding homeworlds at the same time.</p><div class="progress-track"><i style="width:${i.domination.current/4*100}%"></i></div><p style="margin-top:10px">${i.domination.current} / 4 founding systems</p></div></div><section class="network-section"><div class="section-label">The awakening network</div>${MM(J)}</section><div class="panel-section" style="margin-top:22px;padding-left:0;padding-right:0"><div class="section-label">Fleet registry</div><div class="fleet-list">${J.fleets.filter(r=>r.owner==="player").map(r=>`<button class="fleet-row" data-fleet="${r.id}">${Ui(r.type,r.owner,!!r.heritage?.length)}<span class="fleet-name">${$e(r.name)} ×${r.ships}${Kd(r)}<small>${$e(Dn(r.systemId).name)} · ${$e(wr(r.hp,r.ships*Re[r.type].hp))} hull · ${An(J,r)} combat power</small></span>${Jd(J,r)}</button>`).join("")}</div></div>`}else At==="journal"&&(t=`<div class="page-top"><div><div class="eyebrow">THE RECORD OF AN AGE</div><h2>Your chronicle</h2><p>Every discovery, every world, every promise. The story of your civilization, one cycle at a time.</p></div><div class="page-symbol">☷</div></div><div class="filter-tabs">${["All","discovery","construction","research","combat","diplomacy","war","sovereignty"].map(i=>`<button data-log-filter="${i}" class="${So===i?"active":""}">${i[0].toUpperCase()+i.slice(1)}</button>`).join("")}</div>${J.log.filter(i=>So==="All"||i.type===So).map(i=>`<article class="log-item"><div><time>CYCLE ${String(i.turn).padStart(2,"0")}</time><div class="log-type">${$e(i.type)}</div></div><div><p>${$e(i.text)}</p>${i.reportId&&cp(J,i.reportId)?`<button class="small-button" style="margin-top:10px" data-action="combat-report" data-report="${i.reportId}">Battle report →</button>`:""}${i.type==="discovery"&&i.systemId&&Jn(J,i.systemId)?`<button class="small-button" style="margin-top:10px" data-action="anomaly" data-system="${i.systemId}">Expedition record →</button>`:""}${i.publicAffairId?`<div class="public-affair-links">${Op({...i,systemName:Dn(i.systemId)?.name})}</div>`:""}</div></article>`).join("")||'<p class="empty-note">This chapter has yet to be written.</p>'}`);Oe("#workspace-page").innerHTML=t}function Kt(n,e,t=!1){ps||(ud=document.activeElement),Oe("#toasts").replaceChildren(),ps=n,Wt.setPaused?.(!0),Oe("#modal-root").innerHTML=`<div class="modal-overlay"><section class="modal ${t?"wide":""} ${n==="welcome"?"welcome":""}" role="dialog" aria-modal="true" aria-labelledby="modal-title"><button class="close-modal" data-action="close-modal" aria-label="Close dialog">×</button><div class="modal-content">${e}</div></section></div>`,(n==="combat-report"?Oe(".modal .close-modal"):Oe(".modal .primary:not(:disabled)")||Oe(".modal button:not(:disabled)"))?.focus({preventScroll:n==="combat-report"})}function Ut(){ps=null,Wt.setPaused?.(At!=="galaxy"),Oe("#modal-root").innerHTML="",ud?.isConnected&&ud.focus()}function Mo(n,e="building",t=null){Kt("build",KS(J,n,e,t),!0)}function hd(n,e=null){Kt("anomaly",_M(J,n,e),!0)}function Wp(n,e=1){Kt("split",iM(J,n,e))}function RM(n){const e=Zt(n);!e||e.owner!=="player"||Kt("heritage",`<div class="eyebrow">CONCORD FLEET HERITAGE</div><h2 id="modal-title">${$e(e.name)}</h2><div class="heritage-portrait">${Ui(e.type,e.owner,!0)}</div><p class="modal-lead">The discoveries carried forward by this task force. These records survive mergers; they do not imply that every original hull remains.</p><div class="discovery-history">${(e.heritage||[]).map(t=>`<article class="discovery-history-entry"><div class="discovery-history-meta">RECOVERED IN CYCLE ${t.turn} · ${$e(Ke[t.factionId].shortName)}</div><h3>${$e(t.name)}</h3><p>Recovered from ${$e(Dn(t.systemId).name)}. The expedition's story remains with this fleet.</p><button class="small-button ghost" data-action="heritage-origin" data-system="${t.systemId}">Read the expedition record →</button></article>`).join("")}</div>`)}function CM(){Kt("menu",`<div class="eyebrow">CAMPAIGN CONTROL</div><h2 id="modal-title">A moment among the stars</h2><p class="modal-lead">Cycle ${J.turn} · ${$e(J.seed)} · The Concord</p><div class="menu-grid"><button data-action="export">↓ Export campaign</button><button data-action="import">↑ Import campaign</button><a href="./guide.html" target="_blank" rel="noopener">Read the field guide ↗</a><button data-action="new-game-menu">Begin a new campaign</button></div><p class="save-meta">${_o?"Browser autosave is unavailable. Export a backup to preserve progress.":"Progress is automatically saved in this browser after every action. Export a backup to move your campaign to another device."}</p><label style="font-size:12px;display:flex;gap:10px;align-items:center"><input type="checkbox" id="warn-unspent" ${Kn.warnUnspent?"checked":""} style="width:auto">Warn before ending a cycle with unused orders</label><div class="modal-actions"><button class="primary" data-action="close-modal">Return to the Reach</button></div>`)}function Xp(){return J.lastBriefing?`${J.seed}:${J.lastBriefing.turn}:${J.lastBriefing.entries[0]?.id||0}`:""}function qp(){Kn.reviewedBriefing=Xp(),Qd(),Oe("#briefing-button").classList.remove("briefing-alert"),Kt("briefing",oM(J),!0)}function Yp(n){const e=n.map(t=>cp(J,t)).filter(Boolean);if(!e.length)return bn("This report is no longer in the active archive.",!0);Kt("combat-report",sM(J,e),!0)}function Zp(){if(!J.fleets.filter(i=>i.owner==="player").length)return bn("Your empire has no active fleets.");const e=Vd(J);if(!e.length)return bn(J.winner?"This campaign has ended.":xt().orders<1?"No orders remain. Your fleets are still available in the roster.":"No fleet awaits orders. Held and spent fleets remain available in the roster.");const t=e.findIndex(i=>i.id===rt);Ho(e[(t+1)%e.length].id)}function IM(){const n=J.fleets.filter(i=>i.owner==="player").sort((i,r)=>{const s=Ii(J,i.id),a=Ii(J,r.id);return Number(a.ready)-Number(s.ready)||Number(s.held)-Number(a.held)||i.name.localeCompare(r.name)}),e=Vd(J).length,t=n.filter(i=>Ii(J,i.id).held).length;Kt("fleet-roster",`<div class="eyebrow">CONCORD FLEET COMMAND</div><h2 id="modal-title">Your presence among the stars</h2><p class="modal-lead">${n.length} fleets · ${e} awaiting orders · ${t} holding position. Select any fleet to focus its location.</p><div class="fleet-list">${n.map(i=>`<button class="fleet-row" data-fleet="${i.id}">${Ui(i.type,i.owner,!!i.heritage?.length)}<span class="fleet-name">${$e(i.name)} ×${i.ships}${Kd(i)}<small>${$e(Dn(i.systemId).name)} · ${$e(wr(i.hp,i.ships*Re[i.type].hp))} hull · ${Re[i.type].upkeep*i.ships} credits upkeep</small></span>${Jd(J,i)}</button>`).join("")||'<p class="empty-note">Commission ships at an Orbital Shipyard to return to the stars.</p>'}</div><p class="empty-note" style="margin-top:18px">Hold position keeps a fleet out of the ready queue without spending orders or movement. Select a held fleet to resume it or issue a manual command.</p>`)}function Kp(n){const e=xs(J).find(i=>i.id===n&&i.to==="player"&&i.kind==="peace");if(!e)return bn("That proposal is no longer available.",!0);const t=Di(J,"player",e.from);Kt("peace-offer",`<div class="eyebrow">AN ENVOY FROM ${$e(Ke[e.from].shortName)}</div><h2 id="modal-title">An offer to end the war</h2><p class="modal-lead">${$e(Ke[e.from].name)} proposes a settlement. The war continues until you agree.</p><ul class="peace-terms"><li><b>Receive ${e.credits} credits.</b> Their payment is already reserved for this agreement.</li><li><b>A ${e.truceTurns}-cycle mutual truce.</b> Neither side may declare war during the truce.</li><li><b>Military withdrawal.</b> Fleets inside each other's territory return to their nearest owned colony and lose remaining movement.</li><li><b>Expires on cycle ${e.expiresTurn}.</b> Responding uses one order.</li></ul><div class="modal-actions"><button data-action="peace-response" data-stance="declinePeace" data-target="${e.from}" data-offer="${e.id}" ${t.actions.declinePeace.enabled?"":"disabled"}>Decline proposal</button><button class="primary" data-action="peace-response" data-stance="acceptPeace" data-target="${e.from}" data-offer="${e.id}" ${t.actions.acceptPeace.enabled?"":"disabled"}>Accept settlement →</button></div>${t.actions.acceptPeace.enabled?"":`<p class="empty-note" style="margin-top:14px">${$e(t.actions.acceptPeace.reason)}</p>`}`)}function Jp(n){const e=xs(J).find(r=>r.id===n&&r.to==="player"&&r.kind==="trade");if(!e)return bn("This trade offer is no longer available.",!0);const t=Di(J,"player",e.from),i=xt().techs.includes("diplomacy")?10:6;Kt("trade-offer",`<div class="eyebrow">A TRADE ENVOY FROM ${$e(Ke[e.from].shortName)}</div><h2 id="modal-title">An offer of open borders</h2><p class="modal-lead">${$e(Ke[e.from].name)} proposes a trade treaty. Your borders stay closed until you accept.</p><ul class="peace-terms"><li><b>No signing fee from your treasury.</b> The proposer has reserved ${e.credits} credits to establish the treaty.</li><li><b>Mutual border access.</b> Both empires may move their fleets through each other's territory under the ordinary movement rules.</li><li><b>Earn ${i} credits per cycle.</b> Mutual trust improves by 10; existing grievances remain.</li><li><b>Decision due before cycle ${e.expiresTurn}.</b> Accepting or declining uses one order. Refusal or expiry refunds the proposer and leaves borders closed.</li><li><b>Trade continues until cancelled.</b> Peaceful cancellation gives three cycles of notice before income and access end and visiting fleets withdraw.</li></ul><div class="modal-actions"><button data-action="trade-response" data-stance="declineTrade" data-target="${e.from}" data-offer="${e.id}" ${t.actions.declineTrade.enabled?"":"disabled"}>Decline · 1 order</button><button class="primary" data-action="trade-response" data-stance="acceptTrade" data-target="${e.from}" data-offer="${e.id}" ${t.actions.acceptTrade.enabled?"":"disabled"}>Accept trade · 1 order</button></div>${t.actions.acceptTrade.enabled?"":`<p class="empty-note" style="margin-top:14px">${$e(t.actions.acceptTrade.reason)}</p>`}`)}function $h(n,e){const t=Di(J,"player",e),i=t.actions[n],r=n==="peace";Kt("diplomatic-confirmation",`<div class="eyebrow">CONCORD FOREIGN AFFAIRS</div><h2 id="modal-title">${r?"Propose a peace settlement":"Give notice to end trade"}</h2><p class="modal-lead">${$e(i.effect)}</p><p class="empty-note">${r?$e(i.willingness?.reason||i.reason):"Trade income and open borders continue during the notice period. At its end, foreign fleets withdraw to their nearest owned colony."}</p><div class="modal-actions"><button data-action="close-modal">Keep current policy</button><button class="primary" data-action="diplomatic-confirm" data-stance="${n}" data-target="${e}" ${i.enabled?"":"disabled"}>${r?"Offer 60 credits · 1 order":"Give notice · 1 order"}</button></div>`)}function jp(){Kt("welcome",'<div class="welcome-emblem">✦</div><div class="eyebrow">A NEW CHAPTER AMONG THE STARS</div><h2 id="modal-title">The Reach is calling.</h2><p class="modal-lead">For centuries, the ancient gates have been silent.<br>From the oceans of Solace, the Concord looks outward once more.<br>You have a homeworld, three ships, and a future to decide.</p><div class="welcome-steps"><div><span>01 / EXPLORE</span><b>Follow the starlanes</b><p>Select your Pathfinder, then a neighboring star. Choose Move to survey it.</p></div><div><span>02 / ESTABLISH</span><b>Found a second home</b><p>Move your Colony Ark to a habitable world. Settle it to grow your empire.</p></div><div><span>03 / ENDURE</span><b>Every order matters</b><p>Build, research, and meet your rivals. End each cycle to renew your orders.</p></div></div><div class="modal-actions"><a href="./guide.html" target="_blank" rel="noopener" style="align-self:center;font-size:11px;margin-right:12px">Field guide ↗</a><button class="primary" data-action="begin">Take command →</button></div>')}function fd(n=!1){const e=It(J),t=Vd(J).length,i=!xt().research&&rl(J).some(a=>a.enabled);if(!n&&Kn.warnUnspent&&e.orders>0&&(t||i)){Kt("end-confirm",`<div class="eyebrow">BEFORE THE NEXT CYCLE</div><h2 id="modal-title">Conclude your mandate?</h2><p class="modal-lead">${e.orders} orders remain${t?`, and ${t} ${t===1?"fleet awaits":"fleets await"} orders`:""}. Unused orders do not carry over.${i?" Your researchers have no assigned project; their science will remain in reserve.":""}</p><p class="empty-note">Rival empires will act, colonies will grow, production and research will advance, and your orders will replenish.</p><div class="modal-actions"><button data-action="close-modal">Keep planning</button><button class="primary" data-action="end-turn-confirm">End cycle →</button></div>`);return}const r=Zn(J);Ut();const s=Sp(J);if(!s.ok)return bn(s.message,!0);if(kh=J.turn-1,fa(),nr(),bn(s.message),J.winner)Qp();else{const a=J.lastBriefing;a?.entries.length&&(Oe("#status-message").textContent=`Cycle ${a.turn}: ${a.entries.length} dispatches available in your briefing.`);const o=xs(J).find(u=>u.to==="player"&&u.createdTurn>=kh),l=Zn(J).some(u=>{const h=r.find(f=>f.factionId===u.factionId);return u.factionId!=="player"&&(u.progress>0&&!h?.progress||u.progress>=8&&(h?.progress||0)<8)}),c=u=>{const h=Dn(u.systemId);return h?.owner&&h.owner!=="player"&&!xt().relations[h.owner].trade&&xt().relations[h.owner].status!=="war"&&J.fleets.some(f=>f.owner==="player"&&f.route?.path.slice(1).includes(u.systemId))},d=a?.entries.some(u=>u.type==="war"||u.publicAffairId&&u.type==="sovereignty"&&c(u));a?.reportIds.length||l||d?qp():o&&(o.kind==="trade"?Jp(o.id):Kp(o.id))}}function Qp(){const n=J.winner==="player";Kt("victory",`<div class="eyebrow">THE END OF AN AGE · CYCLE ${J.turn}</div><h2 id="modal-title">${n?"The stars remember your name.":"A new power shapes the Reach."}</h2><p class="modal-lead">${$e(Ke[J.winner]?.name||"The galaxy")} · ${$e(J.victoryType)}<br>Your legacy: ${It(J).score} points, ${It(J).colonies} worlds, ${xt().techs.length} discoveries.</p><p class="empty-note">Your chronicle and galaxy remain available to inspect. Export the campaign from the menu to preserve this age.</p><div class="modal-actions"><button data-action="close-modal">View the galaxy</button><button class="primary" data-action="new-game-menu">A new beginning</button></div>`)}function PM(){const n=new Blob([JSON.stringify(J,null,2)],{type:"application/json"}),e=URL.createObjectURL(n),t=document.createElement("a");t.href=e,t.download=`asterion-reach-cycle-${J.turn}.json`,t.click(),setTimeout(()=>URL.revokeObjectURL(e),1e3),bn("Campaign exported. Keep this file as your backup.")}Oe("#import-save").addEventListener("change",async n=>{const e=n.target.files[0];if(n.target.value="",!!e)try{if(e.size>3e6)throw new Error("Save file is too large.");const t=JSON.parse(await e.text());if(!Mp(t))throw new Error("This file is not a valid Asterion Reach campaign.");Kt("confirm-import",`<div class="eyebrow">RESTORE A CAMPAIGN</div><h2 id="modal-title">Return to cycle ${t.turn}?</h2><p class="modal-lead">This will replace the current autosave. Export your current campaign first if you want to keep it.</p><div class="modal-actions"><button data-action="export">Export current</button><button id="confirm-import" class="primary">Restore campaign</button></div>`),Oe("#confirm-import").addEventListener("click",()=>{J=t,Zo(J),On=xt().capitalId,rt=J.fleets.find(i=>i.owner==="player")?.id||null,Zt(rt)?.route&&(On=Zt(rt).systemId),Ut(),ai("galaxy"),fa(),nr(),Wt.reset(),bn("Campaign restored.")})}catch(t){bn(t.message,!0)}});document.addEventListener("change",n=>{n.target.id==="split-ships"&&(Wp(n.target.dataset.fleetTarget,Number(n.target.value)),Oe("#split-ships")?.focus()),n.target.id==="discovery-replacement"&&(hd(n.target.dataset.system,n.target.value||null),Oe("#discovery-replacement")?.focus()),n.target.id==="replace-building"&&(Mo(n.target.dataset.system,"building",n.target.value||null),Oe("#replace-building")?.focus()),n.target.id==="warn-unspent"&&(Kn.warnUnspent=n.target.checked,Qd())});document.addEventListener("toggle",n=>{n.target.matches?.(".public-dispatches")&&n.target.isConnected&&Kn.publicDispatchesOpen!==n.target.open&&(Kn.publicDispatchesOpen=n.target.open,Qd())},!0);document.addEventListener("click",n=>{const e=n.target.closest("button,a");if(!e||e.disabled)return;if(e.dataset.page)return ai(e.dataset.page);if(e.dataset.fleet)return ps==="fleet-roster"&&Ut(),Ho(e.dataset.fleet);if(e.dataset.systemSelect)return ts(e.dataset.systemSelect);if(e.dataset.researchFilter)return bo=e.dataset.researchFilter,Js();if(e.dataset.logFilter)return So=e.dataset.logFilter,Js();switch(e.dataset.action){case"menu":CM();break;case"briefing":qp();break;case"review-network":ai("empire"),Oe(".network-section")?.scrollIntoView({block:"start"});break;case"combat-report":Yp([Number(e.dataset.report)]);break;case"colony-sort":dd=xo===e.dataset.sort?dd==="asc"?"desc":"asc":e.dataset.sort==="name"?"asc":"desc",xo=e.dataset.sort,Js(),document.querySelector(`[data-action="colony-sort"][data-sort="${xo}"]`)?.focus();break;case"report-inspect":Ut(),ts(e.dataset.system),Wt.focus(e.dataset.system);break;case"report-select-fleet":Ut(),Ho(e.dataset.fleetTarget);break;case"report-diplomacy":Ks=e.dataset.target,Ut(),ai("diplomacy"),document.querySelector(`[data-rival="${e.dataset.target}"]`)?.scrollIntoView({block:"nearest"});break;case"rival-dossier":Ks=e.dataset.target,eu(),Oe("#inspector").scrollTop=0,document.querySelectorAll('[data-action="rival-dossier"]').forEach(i=>i.setAttribute("aria-pressed",String(i.dataset.target===Ks))),matchMedia("(max-width:660px)").matches&&Oe("#inspector").scrollIntoView({block:"start"});break;case"rival-channel":document.querySelector(`[data-rival="${e.dataset.target}"]`)?.scrollIntoView({block:"center",behavior:"instant"}),document.querySelector(`[data-rival="${e.dataset.target}"] .rival-actions button:not(:disabled)`)?.focus({preventScroll:!0});break;case"report-research":Ut(),ai("research");break;case"report-chronicle":Ut(),ai("journal");break;case"close-modal":Ut();break;case"begin":Ut(),fa();break;case"home":ts(xt().capitalId),Wt.focus(xt().capitalId);break;case"fleet-roster":IM();break;case"next-fleet":Zp();break;case"fleet-hold":Lt({type:Ii(J,e.dataset.fleetTarget).held?"resume":"hold",fleetId:e.dataset.fleetTarget})&&Oe('[data-action="fleet-hold"]')?.focus();break;case"defense-lead-toggle":if(Lt({type:Zt(e.dataset.fleetTarget)?.defenseLead?"clearDefenseLead":"leadDefense",fleetId:e.dataset.fleetTarget})){const i=Oe('[data-action="defense-lead-toggle"]');(i&&!i.disabled?i:Oe('#inspector [data-fleet="'+e.dataset.fleetTarget+'"]'))?.focus()}break;case"zoom-in":Wt.zoom(1);break;case"zoom-out":Wt.zoom(-1);break;case"reset-view":Wt.reset();break;case"inspect":ts(e.dataset.system),Wt.focus(e.dataset.system);break;case"build-menu":Mo(e.dataset.system);break;case"development-menu":Mo(e.dataset.system,"charter");break;case"construction-tab":Mo(e.dataset.system,e.dataset.tab);break;case"develop":Lt({type:"develop",systemId:e.dataset.system,charterType:e.dataset.charter})&&Ut();break;case"build":Lt({type:"build",systemId:e.dataset.system,itemId:e.dataset.item,replaceBuildingId:e.dataset.replace||null})&&Ut();break;case"cancel-build":Lt({type:"cancelBuild",systemId:e.dataset.system});break;case"research":Lt({type:"research",techId:e.dataset.tech});break;case"plan-route":Lt({type:"planRoute",fleetId:rt,destinationId:e.dataset.destination})&&Wt.focusRoute?.(Zt(rt)?.route?.path);break;case"fit-route":Wt.focusRoute?.(Zt(rt)?.route?.path);break;case"continue-route":Lt({type:"continueRoute",fleetId:rt});break;case"clear-route":Lt({type:"clearRoute",fleetId:rt});break;case"replot-route":{const i=Zt(rt)?.route?.destinationId;i&&Lt({type:"planRoute",fleetId:rt,destinationId:i})&&Wt.focusRoute?.(Zt(rt)?.route?.path);break}case"move":Lt({type:"move",fleetId:rt,targetId:e.dataset.target});break;case"colonize":Kt("colonize",`<div class="eyebrow">A NEW WORLD</div><h2 id="modal-title">Settle ${$e(Dn(Zt(rt).systemId).name)}?</h2><p class="modal-lead">Your Colony Ark will become the foundation of a new settlement. Establishing the colony consumes the ark, 30 credits, 20 minerals, and 1 order.</p><p class="empty-note">Worlds need at least ${xt().techs.includes("terraforming")?0:xt().techs.includes("ecology")?30:50}% habitability with your current technology.</p><div class="modal-actions"><button data-action="close-modal">Wait</button><button class="primary" data-action="colonize-confirm">Found colony →</button></div>`);break;case"colonize-confirm":Lt({type:"colonize",fleetId:rt})&&Ut();break;case"attack":Lt({type:"attack",fleetId:rt});break;case"repair":Lt({type:"repair",fleetId:rt});break;case"merge":Lt({type:"merge",fleetId:rt,targetFleetId:e.dataset.target});break;case"split-menu":Wp(e.dataset.fleetTarget);break;case"split-confirm":Lt({type:"split",fleetId:e.dataset.fleetTarget,ships:Number(e.dataset.ships)})&&Ut();break;case"fleet-heritage":RM(e.dataset.fleetTarget);break;case"heritage-origin":hd(e.dataset.system);break;case"anomaly":hd(e.dataset.system);break;case"anomaly-choice":Lt({type:"anomaly",systemId:e.dataset.system,choiceId:e.dataset.choice,replaceBuildingId:e.dataset.replace||null})&&Ut();break;case"diplomacy":Lt({type:"diplomacy",targetId:e.dataset.target,stance:e.dataset.stance,offerId:e.dataset.offer});break;case"review-peace":Kp(e.dataset.offer);break;case"review-trade":Jp(e.dataset.offer);break;case"peace-response":Lt({type:"diplomacy",targetId:e.dataset.target,stance:e.dataset.stance,offerId:e.dataset.offer})&&Ut();break;case"trade-response":Lt({type:"diplomacy",targetId:e.dataset.target,stance:e.dataset.stance,offerId:e.dataset.offer})&&Ut();break;case"peace-confirmation":$h("peace",e.dataset.target);break;case"end-trade-confirmation":$h("endTrade",e.dataset.target);break;case"diplomatic-confirm":Lt({type:"diplomacy",targetId:e.dataset.target,stance:e.dataset.stance})&&Ut();break;case"declare-war":Kt("war",`<div class="eyebrow">A POINT OF NO RETURN</div><h2 id="modal-title">War with ${$e(Ke[e.dataset.target].shortName)}?</h2><p class="modal-lead">Trade will end immediately. Fleets will fight on contact, and colonies can be invaded. Peace negotiations will remain closed for five cycles.${xt().relations[e.dataset.target].trade?" Breaking this trade agreement also incurs a severe trust penalty and a lasting grievance.":""}</p><div class="modal-actions"><button data-action="close-modal">Stand down</button><button class="danger" data-action="war-confirm" data-target="${e.dataset.target}">Declare war · 1 order</button></div>`);break;case"war-confirm":Lt({type:"diplomacy",targetId:e.dataset.target,stance:"war"})&&Ut();break;case"end-turn":fd();break;case"end-turn-confirm":fd(!0);break;case"export":PM();break;case"import":Oe("#import-save").click();break;case"new-game-menu":Kt("new-game",`<div class="eyebrow">ANOTHER POSSIBLE FUTURE</div><h2 id="modal-title">Begin a new age</h2><p class="modal-lead">A new campaign replaces your autosave. Export this campaign from the menu if you want to return to it.</p><label class="form-label" for="galaxy-seed">Galaxy seed · the same seed creates the same frontier</label><input id="galaxy-seed" maxlength="48" value="${$e(`REACH-${Math.floor(Math.random()*9e4+1e4)}`)}"><div class="modal-actions"><button data-action="export">Export current</button><button class="primary" data-action="new-game-confirm">Begin campaign →</button></div>`);break;case"new-game-confirm":J=_p(Oe("#galaxy-seed").value.trim()||"ASTERION"),On="s0",rt=J.fleets.find(i=>i.owner==="player"&&i.type==="scout").id,Ut(),ai("galaxy"),fa(),nr(),Wt.reset(),jp();break}});document.addEventListener("keydown",n=>{if(ps){if(n.key==="Escape"&&(n.preventDefault(),Ut()),n.key==="Tab"){const e=[...document.querySelectorAll(".modal button:not(:disabled),.modal a[href],.modal input:not(:disabled),.modal select:not(:disabled),.modal textarea:not(:disabled),.modal [tabindex]")].filter(r=>r.tabIndex>=0&&r.getClientRects().length&&!r.matches(":disabled")),t=e[0],i=e.at(-1);n.shiftKey&&document.activeElement===t?(n.preventDefault(),i?.focus()):!n.shiftKey&&document.activeElement===i&&(n.preventDefault(),t?.focus())}return}n.target.matches("input,textarea,select")||n.ctrlKey||n.metaKey||n.altKey||(n.code==="Space"&&!n.repeat&&!n.target.matches("button,a")&&(n.preventDefault(),fd()),["1","2","3","4","5"].includes(n.key)&&ai(["galaxy","research","diplomacy","empire","journal"][Number(n.key)-1]),n.key.toLowerCase()==="n"&&Zp(),n.key.toLowerCase()==="h"&&(ts(xt().capitalId),Wt.focus(xt().capitalId)),n.key==="Escape"&&(rt=null,nr()),n.key==="?"&&window.open("./guide.html","_blank","noopener"))});nr();Zt(rt)?.route?Wt.focusRoute?.(Zt(rt).route.path):Wt.focus(On);zo&&bn(zo,!0);EM&&jp();window.__asterion={getState:()=>structuredClone(J),getPage:()=>At};
